<?php
require_once dirname(__DIR__) . '/erp/includes/auth.php';
send_security_headers();
start_secure_session();

$err = '';
$ok = '';
$old = [
    'full_name' => '',
    'email' => '',
    'phone' => '',
    'subject_specialty' => '',
    'qualification' => '',
    'experience_years' => '1',
    'cover_note' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    foreach ($old as $k => $_) {
        $old[$k] = trim((string) ($_POST[$k] ?? ''));
    }

    if (!empty($_POST['website_url'])) {
        $ok = 'Application received.';
    } elseif (!verify_public_captcha($_POST['captcha'] ?? null)) {
        $err = 'Security math answer is incorrect. Please check and try again.';
    } else {
        $name  = $old['full_name'];
        $email = strtolower($old['email']);
        $phone = preg_replace('/[^0-9+\- ]/', '', $old['phone']);
        $subj  = $old['subject_specialty'];
        $exp   = max(0, min(50, (int) $old['experience_years']));
        $qual  = $old['qualification'];
        $note  = $old['cover_note'];
        $ip    = client_ip();
        $pdo   = db();

        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen(preg_replace('/\D+/', '', $phone)) < 10 || $subj === '' || $qual === '') {
            $err = 'Please fill all required fields in valid format.';
        } elseif (!check_rate_limit($pdo, 'teacher_apply', $ip, 3, 30, true)) {
            $err = 'Too many applications from this IP. Please try again after 30 minutes.';
        } else {
            $resumePath = null;
            if (!empty($_FILES['resume']['name'])) {
                $up = safe_upload($_FILES['resume'], 'resumes', ['application/pdf' => 'pdf'], 2097152);
                if (!$up['ok']) {
                    $err = $up['error'];
                } else {
                    $resumePath = $up['path'];
                }
            }
            if ($err === '') {
                $pdo->prepare("INSERT INTO teacher_applications (branch_id, full_name, email, phone, subject_specialty, experience_years, qualification, resume_path, cover_note, status, ip_address) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, 'New', ?)")
                    ->execute([$name, $email, $phone, $subj, $exp, $qual, $resumePath, $note, $ip]);

                send_teacher_application_email($email, $name, $subj);
                $adminNotify = yu_admin_notify_email();
                $admBody = '<p>A new faculty application was received:</p><ul>'
                    . '<li><strong>Name:</strong> ' . e($name) . '</li>'
                    . '<li><strong>Email:</strong> ' . e($email) . '</li>'
                    . '<li><strong>Phone:</strong> ' . e($phone) . '</li>'
                    . '<li><strong>Subject:</strong> ' . e($subj) . '</li>'
                    . '<li><strong>Qualification:</strong> ' . e($qual) . ' (' . $exp . ' yrs)</li>'
                    . '</ul>';
                send_branded_email($adminNotify, 'Academic Team', 'New Faculty Application - ' . $name, $admBody);

                $ok = 'Thank you! Your Teacher Application has been submitted to Yuitor ERP. A confirmation email has been sent from ' . YU_MAIL_FROM_EMAIL . '.';
                foreach ($old as $k => $_) { $old[$k] = $k === 'experience_years' ? '1' : ''; }
            }
        }
    }
}

$captchaQ = generate_public_captcha();
$pageTitle = 'Faculty Registration & Application';
$portalMode = 'teacher';
$showPanelSidebar = false;
include dirname(__DIR__) . '/erp/includes/site_header.php';
?>
<div style="max-width:660px;margin:20px auto;">
  <div class="yu-card" style="padding:32px;">
    <div style="font-size:13px;font-weight:600;color:#0b7b82;margin-bottom:6px;">Faculty Recruitment · Yuitor Smart Classes</div>
    <h1 style="margin:0 0 6px;font-family:'Manrope',sans-serif;font-size:25px;line-height:1.2;">Apply for Teaching Position</h1>
    <p style="margin:0 0 22px;color:#64748b;font-size:14.5px;">Submit your teaching background and PDF resume. Our academic team will review your profile.</p>
    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger"><?php echo e($err); ?></div><?php endif; ?>
    <?php if ($ok !== ''): ?><div class="yu-alert yu-alert-success"><?php echo e($ok); ?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo public_captcha_field(); ?>
      <input type="text" name="website_url" style="display:none" tabindex="-1" autocomplete="off">
      <div class="yu-form-row">
        <div class="yu-field"><label for="tName">Full Name</label><input id="tName" type="text" name="full_name" required value="<?php echo e($old['full_name']); ?>" placeholder="Enter full name"></div>
        <div class="yu-field"><label for="tEmail">Email Address</label><input id="tEmail" type="email" name="email" required value="<?php echo e($old['email']); ?>" placeholder="faculty@yuitor.com"></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label for="tPhone">Mobile Number</label><input id="tPhone" type="tel" name="phone" required value="<?php echo e($old['phone']); ?>" placeholder="10-digit mobile number"></div>
        <div class="yu-field"><label for="tSubj">Subject Specialty</label><input id="tSubj" type="text" name="subject_specialty" required value="<?php echo e($old['subject_specialty']); ?>" placeholder="Maths / Physics / Coding"></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label for="tQual">Qualification</label><input id="tQual" type="text" name="qualification" required value="<?php echo e($old['qualification']); ?>" placeholder="M.Sc / B.Tech / B.Ed"></div>
        <div class="yu-field"><label for="tExp">Experience (Years)</label><input id="tExp" type="number" name="experience_years" min="0" max="50" value="<?php echo e($old['experience_years']); ?>"></div>
      </div>
      <div class="yu-field" style="margin-bottom:14px;"><label for="tRes">Resume (PDF only, Max 2MB)</label><input id="tRes" type="file" name="resume" accept=".pdf,application/pdf" style="padding:8px 10px;"></div>
      <div class="yu-field" style="margin-bottom:14px;"><label for="tNote">About Your Teaching Background</label><textarea id="tNote" name="cover_note" rows="3"><?php echo e($old['cover_note']); ?></textarea></div>
      <div class="yu-field" style="margin-bottom:18px;"><label for="tCap">Security Check: What is <?php echo e($captchaQ); ?>?</label><input id="tCap" type="number" name="captcha" required></div>
      <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;min-height:46px;font-size:15px;">Submit Faculty Application &rarr;</button>
    </form>
    <div style="margin-top:18px;padding-top:16px;border-top:1px solid #f1f5f9;text-align:center;font-size:13.5px;color:#64748b;">
      Already an approved faculty member? <a href="/teacher/login.php" style="color:#2563eb;font-weight:700;text-decoration:none;">Teacher Sign In &rarr;</a>
    </div>
  </div>
</div>
<?php include dirname(__DIR__) . '/erp/includes/site_footer.php'; ?>
