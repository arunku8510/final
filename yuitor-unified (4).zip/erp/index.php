<?php
require_once __DIR__ . '/includes/auth.php';
send_security_headers();
start_secure_session();

$existing = current_user();
if ($existing) {
    redirect_to(role_home($existing['role']));
}

$role = strtolower(trim((string) ($_GET['role'] ?? '')));
if ($role === 'student') {
    redirect_to('/student/login.php');
}
if ($role === 'teacher') {
    redirect_to('/teacher/login.php');
}
if ($role === 'parent') {
    redirect_to('/erp/parent/login.php');
}

// Bare /erp/ and any admin/unknown role probes must never reveal admin/operations login
send_noindex_headers();
http_response_code(404);
$code = 404;
include __DIR__ . '/error.php';
exit;
