<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
start_secure_session();

$existing = current_user();
if ($existing) {
    if ($existing['role'] === 'parent') {
        redirect_to('/erp/parent/dashboard.php');
    }
    http_response_code(403);
    $code = 403;
    include __DIR__ . '/../error.php';
    exit;
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $pass = (string) ($_POST['password'] ?? '');
    $ip = client_ip();
    $pdo = db();

    if (!check_rate_limit($pdo, 'parent_login_ip', $ip, 10, 15, false)) {
        $err = 'Too many attempts. Please wait 15 minutes.';
    } elseif ($email === '' || $pass === '') {
        $err = 'Email and password are required.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'parent' AND deleted_at IS NULL LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($pass, $user['password_hash'])) {
            check_rate_limit($pdo, 'parent_login_ip', $ip, 10, 15, true);
            $err = 'Invalid parent credentials.';
        } elseif ((int) $user['is_active'] !== 1) {
            $err = 'Parent account is disabled.';
        } else {
            clear_rate_limit($pdo, 'parent_login_ip', $ip);
            complete_user_login($user);
            redirect_to('/erp/parent/dashboard.php');
        }
    }
}

$pageTitle = 'Parent Portal Sign In';
$portalMode = 'parent';
$showPanelSidebar = false;
include __DIR__ . '/../includes/site_header.php';
?>
<div style="max-width:440px;margin:36px auto;">
  <div class="yu-card" style="padding:32px;">
    <div style="font-size:12px;font-weight:700;color:#0b7b82;margin-bottom:6px;">Guardian Access</div>
    <h1 style="margin:0 0 18px;font-family:'Manrope',sans-serif;font-size:23px;">Parent Sign In</h1>
    <?php echo render_flash(); ?>
    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger"><?php echo e($err); ?></div><?php endif; ?>
    <form method="post">
      <?php echo csrf_field(); ?>
      <div class="yu-field" style="margin-bottom:14px;"><label for="parEmail">Guardian Email</label><input id="parEmail" type="email" name="email" required autocomplete="username" placeholder="parent@example.com"></div>
      <div class="yu-field" style="margin-bottom:14px;">
        <label for="parPass">Password</label>
        <div class="yu-pass-wrap">
          <input id="parPass" type="password" name="password" required autocomplete="current-password" placeholder="Enter your password">
          <button type="button" class="yu-pass-toggle" data-yu-toggle-pass="parPass" aria-label="Show password" aria-pressed="false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
        </div>
      </div>
      <div style="margin-bottom:18px;font-size:13px;"><a href="<?php echo e(erp_url('forgot-password.php?portal=parent')); ?>" style="color:#2563eb;font-weight:600;text-decoration:none;">Forgot Password?</a></div>
      <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;min-height:46px;font-size:15px;">Sign In</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
