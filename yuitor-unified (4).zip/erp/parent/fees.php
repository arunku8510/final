<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('parent');
$ids = parent_linked_student_ids($user['id']);
$stId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : ($ids[0] ?? 0);
if ($stId) assert_student_access($user, $stId);

$payments = []; $acc = null; if ($stId) { $pSt = db()->prepare("SELECT * FROM fee_payments WHERE student_id = ? ORDER BY id DESC"); $pSt->execute([$stId]); $payments = $pSt->fetchAll(); $aSt = db()->prepare("SELECT * FROM student_fee_accounts WHERE student_id = ? ORDER BY id DESC LIMIT 1"); $aSt->execute([$stId]); $acc = $aSt->fetch(); }

$pageTitle = 'Child Fees & PDF Receipts';
$showPanelSidebar = true;
$portalMode = 'parent';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Child Fees &amp; Official PDF Receipts</h1></div></div>
<?php if ($acc): ?>
<div class="yu-kpi-grid">
  <div class="yu-kpi"><div class="yu-kpi-label">Net Fee</div><div class="yu-kpi-val"><?php echo format_inr($acc['net_amount']); ?></div></div>
  <div class="yu-kpi"><div class="yu-kpi-label">Paid</div><div class="yu-kpi-val st-ok"><?php echo format_inr($acc['paid_amount']); ?></div></div>
  <div class="yu-kpi"><div class="yu-kpi-label">Due</div><div class="yu-kpi-val st-bad"><?php echo format_inr(max(0, $acc['net_amount'] - $acc['paid_amount'])); ?></div></div>
</div>
<?php endif; ?>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Receipt #</th><th class="num">Amount</th><th>Mode</th><th>Status</th><th>Date</th><th>PDF</th></tr>
    <?php foreach($payments as $p): ?>
      <tr><td><strong><?php echo e($p['receipt_no']); ?></strong></td><td class="num"><?php echo format_inr($p['amount']); ?></td><td><?php echo e(strtoupper($p['payment_mode'])); ?></td><td><?php echo e(ucwords(str_replace('_',' ',$p['status']))); ?></td><td><?php echo e($p['paid_at']); ?></td><td><a class="yu-btn yu-btn-outline yu-btn-sm" target="_blank" href="<?php echo e(erp_url('student/receipt_pdf.php?id='.(int)$p['id'])); ?>">Download PDF</a></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
