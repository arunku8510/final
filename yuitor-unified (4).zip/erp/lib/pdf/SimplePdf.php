<?php
// Pure-PHP Zero-Dependency PDF 1.4 Writer (Works on all cPanel PHP 7.4 - 8.3 hosts)
class SimplePdf {
    private $commands = [];
    private $width = 595.28;  // A4 pt
    private $height = 841.89;

    private function esc($txt) {
        $txt = preg_replace('/[^ -~]/', ' ', (string)$txt);
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $txt);
    }

    public function setFillColor($r, $g, $b) {
        $this->commands[] = sprintf('%.3F %.3F %.3F rg', $r / 255, $g / 255, $b / 255);
    }

    public function setStrokeColor($r, $g, $b) {
        $this->commands[] = sprintf('%.3F %.3F %.3F RG', $r / 255, $g / 255, $b / 255);
    }

    public function rect($x, $topY, $w, $h, $style = 'F') {
        $y = $this->height - $topY - $h;
        $op = $style === 'FD' ? 'B' : ($style === 'D' ? 'S' : 'f');
        $this->commands[] = sprintf('%.2F %.2F %.2F %.2F re %s', $x, $y, $w, $h, $op);
    }

    public function line($x1, $topY1, $x2, $topY2, $lw = 0.8) {
        $y1 = $this->height - $topY1;
        $y2 = $this->height - $topY2;
        $this->commands[] = sprintf('%.2F w %.2F %.2F m %.2F %.2F l S', $lw, $x1, $y1, $x2, $y2);
    }

    public function text($x, $topY, $txt, $size = 11, $bold = false, $r = 15, $g = 23, $b = 42) {
        $y = $this->height - $topY;
        $font = $bold ? 'F2' : 'F1';
        $this->setFillColor($r, $g, $b);
        $this->commands[] = sprintf('BT /%s %.1F Tf %.2F %.2F Td (%s) Tj ET', $font, $size, $x, $y, $this->esc($txt));
    }

    public function output($filename = 'document.pdf') {
        $stream = implode("\n", $this->commands);
        $objs = [];
        $objs[] = "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj";
        $objs[] = "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj";
        $objs[] = sprintf("3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >> endobj", $this->width, $this->height);
        $objs[] = "4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj";
        $objs[] = "5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >> endobj";
        $objs[] = "6 0 obj << /Length " . strlen($stream) . " >> stream\n" . $stream . "\nendstream endobj";

        $pdf = "%PDF-1.4\n";
        $offsets = [0];
        foreach ($objs as $o) {
            $offsets[] = strlen($pdf);
            $pdf .= $o . "\n";
        }
        $xrefPos = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objs) + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= count($objs); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .= "trailer << /Size " . (count($objs) + 1) . " /Root 1 0 R >>\nstartxref\n{$xrefPos}\n%%EOF";

        $safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $safe . '"');
        header('Content-Length: ' . strlen($pdf));
        echo $pdf;
        exit;
    }
}
