<?php
// Yuitor Smart Classes - Centralized Environment & Demo Placeholder Config Loader

require_once dirname(__DIR__, 2) . '/config/env.php';

if (!defined('YU_MAIL_DOMAIN')) {
    define('YU_MAIL_DOMAIN', yu_env('MAIL_DOMAIN', 'yuitor.com'));
}
if (!defined('YU_MAIL_FROM_EMAIL')) {
    define('YU_MAIL_FROM_EMAIL', yu_normalize_sender_email(yu_env('MAIL_FROM_EMAIL', yu_env('YU_SMTP_FROM', 'no-reply@yuitor.com'))));
}
if (!defined('YU_MAIL_FROM_NAME')) {
    define('YU_MAIL_FROM_NAME', yu_env('MAIL_FROM_NAME', 'Yuitor Smart Classes'));
}
if (!defined('YU_ADMIN_NOTIFY_EMAIL')) {
    define('YU_ADMIN_NOTIFY_EMAIL', yu_normalize_sender_email(yu_env('ADMIN_NOTIFY_EMAIL', yu_env('YU_ADMIN_EMAIL', 'Arunku8510@gmail.com'))));
}
if (!defined('YU_INSTITUTE_EMAIL')) {
    define('YU_INSTITUTE_EMAIL', yu_normalize_sender_email(yu_env('YU_INSTITUTE_EMAIL', 'no-reply@yuitor.com')));
}
if (!defined('YU_INQUIRY_EMAIL')) {
    define('YU_INQUIRY_EMAIL', yu_normalize_sender_email(yu_env('YU_INQUIRY_EMAIL', 'Arunku8510@gmail.com')));
}
if (!defined('YU_DEMO_EMAIL')) {
    define('YU_DEMO_EMAIL', YU_INSTITUTE_EMAIL);
}
if (!defined('YU_DEMO_NOREPLY')) {
    define('YU_DEMO_NOREPLY', YU_MAIL_FROM_EMAIL);
}
if (!defined('YU_DEMO_ADMIN_EMAIL')) {
    define('YU_DEMO_ADMIN_EMAIL', YU_ADMIN_NOTIFY_EMAIL);
}
if (!defined('YU_DEMO_PHONE')) {
    define('YU_DEMO_PHONE', yu_env('YU_INSTITUTE_PHONE', '9999999999'));
}
if (!defined('YU_DEMO_BRANCH_PHONE')) {
    define('YU_DEMO_BRANCH_PHONE', yu_env('YU_BRANCH_PHONE', '9999999999'));
}
if (!defined('YU_DEMO_ADDRESS')) {
    define('YU_DEMO_ADDRESS', yu_env('YU_INSTITUTE_ADDRESS', 'Demo Campus, Main Road, Smart City - 100001'));
}
if (!defined('YU_DEMO_UPI_PRIMARY')) {
    define('YU_DEMO_UPI_PRIMARY', yu_env('YU_UPI_PRIMARY', 'demo@upi'));
}
if (!defined('YU_DEMO_UPI_ALT')) {
    define('YU_DEMO_UPI_ALT', yu_env('YU_UPI_ALT', 'demo2@upi'));
}
if (!defined('YU_AI_API_KEY')) {
    define('YU_AI_API_KEY', yu_env('AI_API_KEY', yu_env('GEMINI_API_KEY', '')));
}
if (!defined('YU_GEMINI_API_KEY')) {
    define('YU_GEMINI_API_KEY', YU_AI_API_KEY);
}
if (!defined('YU_GEMINI_MODEL')) {
    define('YU_GEMINI_MODEL', yu_env('GEMINI_MODEL', 'gemini-2.5-flash'));
}
