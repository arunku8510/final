<?php
// Yuitor Coaching ERP - Strict Security Configuration, Headers, Encryption & Resilient CSRF

require_once __DIR__ . '/demo_defaults.php';

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
@ini_set('log_errors', '1');
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0750, true);
}
@ini_set('error_log', $logDir . '/php_error.log');

$reqScript = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
if (strpos($reqScript, '/install/') === false && strpos($reqScript, '/api/') === false) {
    set_exception_handler(function (Throwable $ex) use ($logDir) {
        $msg = '[' . date('Y-m-d H:i:s') . '] Uncaught ' . get_class($ex) . ': ' . $ex->getMessage() . ' in ' . $ex->getFile() . ':' . $ex->getLine() . "\n";
        @file_put_contents($logDir . '/php_error.log', $msg, FILE_APPEND);
        error_log($msg);
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: text/html; charset=UTF-8');
        }
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>500 - Temporary Error | Yuitor Smart Classes</title></head><body style="margin:0;background:#f5f9fc;font-family:Arial,sans-serif;color:#0f172a;padding:40px 16px;"><div style="max-width:520px;margin:auto;background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:30px;text-align:center;"><div style="font-size:38px;font-weight:800;color:#2563eb;">500</div><h1 style="margin:8px 0 10px;font-size:20px;">Temporary Server Error</h1><p style="color:#52687c;font-size:14px;line-height:1.6;">The request could not be completed right now. Details have been recorded in the server error log (<code>erp/logs/php_error.log</code>).</p><a href="/" style="display:inline-block;margin-top:12px;background:#2563eb;color:#fff;padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:700;">Return Home</a></div></body></html>';
        exit;
    });
}

function app_secret_key() {
    $envKey = yu_env('APP_KEY', '');
    if (strlen($envKey) >= 16) return $envKey;
    if (!defined('APP_KEY') && is_file(__DIR__ . '/app.php')) {
        @include_once __DIR__ . '/app.php';
    }
    if (defined('APP_KEY') && strlen(APP_KEY) >= 16) return APP_KEY;
    return hash('sha256', dirname(__DIR__, 2) . '|' . php_uname('n'));
}

function yu_admin_login_slug(): string {
    $defaultSlug = 'yt-ctrl-94x2-gate';
    $slug = yu_env('CONSOLE_GATE_SLUG', yu_env('ADMIN_LOGIN_SLUG', $defaultSlug));
    if (!preg_match('/^[a-zA-Z0-9_-]{8,64}$/', $slug)) {
        return $defaultSlug;
    }
    $lower = strtolower($slug);
    foreach (['admin', 'login', 'panel', 'staff', 'root', 'dashboard', 'erp', 'wp-'] as $blocked) {
        if (strpos($lower, $blocked) !== false) {
            return $defaultSlug;
        }
    }
    return $slug;
}

function yu_admin_login_url(): string {
    return '/erp/' . yu_admin_login_slug();
}

function encrypt_secret($plain) {
    $plain = (string) $plain;
    if ($plain === '') return '';
    if (!function_exists('openssl_encrypt')) {
        return 'b64:' . base64_encode($plain);
    }
    $key = hash('sha256', app_secret_key(), true);
    $iv = random_bytes(16);
    $cipher = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $cipher);
}

function decrypt_secret($encoded) {
    $encoded = (string) $encoded;
    if ($encoded === '') return '';
    if (strpos($encoded, 'b64:') === 0) {
        return (string) base64_decode(substr($encoded, 4));
    }
    if (!function_exists('openssl_decrypt')) return '';
    $raw = base64_decode($encoded, true);
    if ($raw === false || strlen($raw) < 17) return '';
    $iv = substr($raw, 0, 16);
    $cipher = substr($raw, 16);
    $key = hash('sha256', app_secret_key(), true);
    $out = openssl_decrypt($cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return $out === false ? '' : $out;
}

function send_security_headers() {
    if (headers_sent()) return;
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-XSS-Protection: 1; mode=block');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

function send_noindex_headers() {
    if (headers_sent()) return;
    header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet', true);
}

function start_secure_session() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    yu_ensure_writable_session_path();
    $isHttps = yu_request_is_https();

    if (!headers_sent()) {
        @ini_set('session.use_strict_mode', '1');
        @ini_set('session.use_only_cookies', '1');
        @ini_set('session.use_trans_sid', '0');
        @ini_set('session.cookie_httponly', '1');
        @ini_set('session.cookie_samesite', 'Lax');
        @session_name('YUITORERPSESS');
        if (PHP_VERSION_ID >= 70300) {
            @session_set_cookie_params([
                'lifetime' => 0,
                'path'     => '/',
                'domain'   => '',
                'secure'   => $isHttps,
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        } else {
            @session_set_cookie_params(0, '/; samesite=Lax', '', $isHttps, true);
        }
    }
    @session_start();

    $now = time();
    if (!empty($_SESSION['user_id']) && isset($_SESSION['_last_activity']) && ($now - (int) $_SESSION['_last_activity']) > 7200) {
        $_SESSION = [];
        @session_destroy();
        @session_start();
        $_SESSION['flash'] = ['type' => 'warning', 'msg' => 'Session expired after 2 hours of inactivity. Please sign in again.'];
    }
    $_SESSION['_last_activity'] = $now;
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function yu_make_signed_csrf_token(): string {
    $nonce = bin2hex(random_bytes(16));
    $ts = (string) time();
    $host = strtolower(explode(':', (string) ($_SERVER['HTTP_HOST'] ?? 'localhost'))[0]);
    $sig = hash_hmac('sha256', $nonce . '|' . $ts . '|' . $host, app_secret_key());
    return $nonce . '.' . $ts . '.' . $sig;
}

function yu_verify_signed_csrf_token(string $token, int $maxAgeSeconds = 43200): bool {
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return false;
    }
    list($nonce, $tsStr, $sig) = $parts;
    if (!preg_match('/^[a-f0-9]{16,64}$/', $nonce) || !ctype_digit($tsStr) || !preg_match('/^[a-f0-9]{64}$/', $sig)) {
        return false;
    }
    $ts = (int) $tsStr;
    $now = time();
    if ($ts > ($now + 120) || ($now - $ts) > $maxAgeSeconds) {
        return false;
    }
    $host = strtolower(explode(':', (string) ($_SERVER['HTTP_HOST'] ?? 'localhost'))[0]);
    $expected = hash_hmac('sha256', $nonce . '|' . $tsStr . '|' . $host, app_secret_key());
    return hash_equals($expected, $sig);
}

function csrf_token() {
    start_secure_session();
    if (empty($_SESSION['_csrf_token']) || !is_string($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = yu_make_signed_csrf_token();
    }
    return $_SESSION['_csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf($providedToken = null) {
    start_secure_session();
    $token = $providedToken !== null
        ? (string) $providedToken
        : (isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));

    if ($token !== '') {
        if (!empty($_SESSION['_csrf_token']) && hash_equals((string) $_SESSION['_csrf_token'], $token)) {
            return;
        }
        if (yu_verify_signed_csrf_token($token)) {
            $_SESSION['_csrf_token'] = $token;
            return;
        }
    }

    http_response_code(403);
    if (
        (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
        || strpos(strtolower((string) ($_SERVER['HTTP_ACCEPT'] ?? '')), 'application/json') !== false
    ) {
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['ok' => false, 'error' => 'Security token expired. Please refresh and try again.']);
        exit;
    }
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Session Refresh Needed</title></head><body style="margin:0;background:#f5f9fc;font-family:Arial,sans-serif;color:#0f172a;padding:40px 16px;"><div style="max-width:480px;margin:auto;background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:28px;text-align:center;"><h2 style="margin:0 0 10px;color:#0f172a;">Security Session Refreshed</h2><p style="color:#52687c;font-size:14px;line-height:1.6;">Your previous form session expired. Click below to reload a fresh secure form and submit again.</p><a href="" onclick="window.location.href=window.location.pathname+window.location.search;return false;" style="display:inline-block;margin-top:10px;background:#2563eb;color:#fff;padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:700;">Reload Page</a></div></body></html>';
    exit;
}

function client_ip() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return filter_var($ip, FILTER_VALIDATE_IP) ? substr($ip, 0, 60) : '0.0.0.0';
}

function yu_make_signed_math_captcha($scope = 'public') {
    start_secure_session();
    $a = random_int(2, 9);
    $b = random_int(1, 9);
    $ans = (string) ($a + $b);
    $scopeClean = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $scope) ?: 'public';
    $_SESSION['yu_cap_' . $scopeClean] = $ans;
    if ($scopeClean === 'public') {
        $_SESSION['public_captcha_ans'] = $ans;
    }
    $nonce = bin2hex(random_bytes(12));
    $ts = (string) time();
    $sig = hash_hmac('sha256', $scopeClean . '|' . $nonce . '|' . $ts . '|' . $ans, app_secret_key());
    $token = $nonce . '.' . $ts . '.' . $sig;
    if ($scopeClean === 'public') {
        $GLOBALS['_yu_public_captcha_token'] = $token;
    }
    return ['question' => "{$a} + {$b}", 'token' => $token];
}

function yu_verify_signed_math_captcha($scope, $answer, $token = null) {
    start_secure_session();
    $scopeClean = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $scope) ?: 'public';
    $ansNorm = trim((string) $answer);
    if ($ansNorm === '' || !preg_match('/^\d+$/', $ansNorm)) {
        return false;
    }
    $ansNorm = (string) ((int) $ansNorm);

    $tok = trim((string) ($token !== null ? $token : ($_POST['captcha_token'] ?? '')));
    if ($tok !== '') {
        $parts = explode('.', $tok);
        if (count($parts) === 3) {
            list($nonce, $tsStr, $sig) = $parts;
            if (preg_match('/^[a-f0-9]{16,64}$/', $nonce) && ctype_digit($tsStr) && preg_match('/^[a-f0-9]{64}$/', $sig)) {
                $ts = (int) $tsStr;
                $now = time();
                if ($ts <= ($now + 120) && ($now - $ts) <= 14400) {
                    $expectedSig = hash_hmac('sha256', $scopeClean . '|' . $nonce . '|' . $tsStr . '|' . $ansNorm, app_secret_key());
                    if (hash_equals($expectedSig, $sig)) {
                        unset($_SESSION['yu_cap_' . $scopeClean]);
                        if ($scopeClean === 'public') {
                            unset($_SESSION['public_captcha_ans']);
                        }
                        return true;
                    }
                }
            }
        }
    }

    $sessionKey = $scopeClean === 'public' ? 'public_captcha_ans' : ('yu_cap_' . $scopeClean);
    $expected = (string) ($_SESSION[$sessionKey] ?? '');
    unset($_SESSION[$sessionKey]);
    return $expected !== '' && hash_equals((string) ((int) $expected), $ansNorm);
}

function generate_public_captcha(): string {
    $cap = yu_make_signed_math_captcha('public');
    return $cap['question'];
}

function public_captcha_field(): string {
    $tok = isset($GLOBALS['_yu_public_captcha_token']) ? (string) $GLOBALS['_yu_public_captcha_token'] : '';
    return '<input type="hidden" name="captcha_token" value="' . e($tok) . '">';
}

function verify_public_captcha($answer, $token = null): bool {
    return yu_verify_signed_math_captcha('public', $answer, $token);
}

