<?php
require_once __DIR__ . '/includes/auth.php';
send_security_headers();
send_noindex_headers();
start_secure_session();

if (empty($_SESSION['pending_2fa_uid'])) {
    http_response_code(404);
    $code = 404;
    include __DIR__ . '/error.php';
    exit;
}

$uid = (int) $_SESSION['pending_2fa_uid'];
$destEmail = (string) ($_SESSION['pending_2fa_email'] ?? '');
$stmt = db()->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin' AND is_active = 1 AND deleted_at IS NULL LIMIT 1");
$stmt->execute([$uid]);
$user = $stmt->fetch();
if (!$user) {
    unset($_SESSION['pending_2fa_uid'], $_SESSION['pending_2fa_email'], $_SESSION['pending_2fa_tries']);
    http_response_code(404);
    $code = 404;
    include __DIR__ . '/error.php';
    exit;
}

$err = '';
$msg = '';
$warn = $_SESSION['otp_mail_warn'] ?? '';
unset($_SESSION['otp_mail_warn']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (isset($_POST['resend'])) {
        if (!check_rate_limit(db(), 'otp_resend', (string) $uid, 3, 10, true)) {
            $err = 'Too many OTP resend requests. Please wait 10 minutes.';
        } else {
            $otp = generate_6digit_otp($uid, 'admin_2fa', 10);
            $res = send_otp_email($destEmail, $user['full_name'], $otp);
            if ($res['ok']) {
                $msg = 'A fresh 6-digit OTP has been sent from ' . YU_MAIL_FROM_EMAIL . ' to ' . mask_email($destEmail) . '.';
            } else {
                $warn = 'OTP email delivery notice: check SMTP settings in .env or Admin Settings.';
            }
        }
    } else {
        $_SESSION['pending_2fa_tries'] = (int) ($_SESSION['pending_2fa_tries'] ?? 0) + 1;
        if ($_SESSION['pending_2fa_tries'] > 5) {
            unset($_SESSION['pending_2fa_uid'], $_SESSION['pending_2fa_email'], $_SESSION['pending_2fa_tries']);
            flash_set('error', 'Too many invalid OTP attempts. Please sign in again.');
            redirect_to(yu_admin_login_url());
        }
        $code = trim((string) ($_POST['otp_code'] ?? ''));
        if (verify_6digit_otp($uid, 'admin_2fa', $code)) {
            unset($_SESSION['pending_2fa_uid'], $_SESSION['pending_2fa_email'], $_SESSION['pending_2fa_tries']);
            complete_user_login($user);
            redirect_to(role_home($user['role']));
        } else {
            $err = 'Invalid or expired 6-digit OTP code. Please try again.';
        }
    }
}

$pageTitle = 'Verify 6-Digit Admin OTP';
$pageNoIndex = true;
$portalMode = 'admin';
$showPanelSidebar = false;
include __DIR__ . '/includes/site_header.php';
$brandLogo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
$fromDisplay = yu_normalize_sender_email(get_setting('mail_from_email', YU_MAIL_FROM_EMAIL));
?>
<div style="max-width:440px;margin:36px auto;">
  <div class="yu-card" style="padding:32px;">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
      <div style="width:44px;height:44px;border-radius:50%;background:#f1f5f9;border:1px solid #cbd5e1;padding:3px;flex-shrink:0;overflow:hidden;">
        <img src="<?php echo e($brandLogo); ?>" alt="" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
      </div>
      <div>
        <div style="font-size:12px;font-weight:700;color:#0b7b82;display:flex;align-items:center;gap:5px;"><?php echo yu_icon('otp', 13); ?> 2-Step Verification</div>
        <h1 style="margin:2px 0 0;font-family:'Manrope',sans-serif;font-size:21px;line-height:1.2;">Enter 6-Digit Admin OTP</h1>
      </div>
    </div>
    <p style="margin:0 0 18px;font-size:13.5px;color:#64748b;">Code sent from <code><?php echo e($fromDisplay); ?></code> to <strong><?php echo e(mask_email($destEmail)); ?></strong>.</p>
    <?php if ($warn !== ''): ?><div class="yu-alert yu-alert-warning"><?php echo e($warn); ?></div><?php endif; ?>
    <?php if ($msg !== ''): ?><div class="yu-alert yu-alert-success"><?php echo e($msg); ?></div><?php endif; ?>
    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger"><?php echo e($err); ?></div><?php endif; ?>
    <form method="post">
      <?php echo csrf_field(); ?>
      <div class="yu-field" style="margin-bottom:14px;">
        <label for="otpCode" style="display:flex;align-items:center;gap:6px;"><?php echo yu_icon('shield', 14); ?> 6-Digit OTP Code</label>
        <input id="otpCode" type="text" name="otp_code" maxlength="6" pattern="\d{6}" inputmode="numeric" required placeholder="000000" style="font-size:22px;letter-spacing:8px;text-align:center;font-weight:800;">
      </div>
      <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;padding:12px;"><?php echo yu_icon('check', 16); ?> Verify &amp; Open Console</button>
    </form>
    <form method="post" style="margin-top:12px;display:flex;justify-content:space-between;align-items:center;">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="resend" value="1">
      <button type="submit" class="yu-btn yu-btn-outline yu-btn-sm"><?php echo yu_icon('mail', 14); ?> Resend OTP</button>
      <a href="<?php echo e(yu_admin_login_url()); ?>" style="font-size:13px;color:#52687c;">Back to Sign In</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/site_footer.php'; ?>
