<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../lib/pdf/SimplePdf.php';

$code = trim((string)($_GET['code'] ?? ''));
$st = db()->prepare("SELECT a.*, t.title AS test_title FROM admission_test_attempts a JOIN admission_tests t ON t.id=a.test_id WHERE a.candidate_code = ? LIMIT 1");
$st->execute([$code]);
$r = $st->fetch();
if (!$r) { http_response_code(404); die('Test result not found.'); }

$pdf = new SimplePdf();
$pdf->setFillColor(15, 23, 42);
$pdf->rect(36, 36, 523, 76, 'F');
$pdf->text(52, 66, strtoupper(get_setting('institute_name', 'YUITOR SMART CLASSES')), 16, true, 255, 255, 255);
$pdf->text(52, 86, 'ADMISSION TEST & SCHOLARSHIP MERIT CERTIFICATE', 10.5, false, 120, 211, 211);

$pdf->setFillColor(245, 249, 252);
$pdf->rect(36, 130, 523, 180, 'F');
$pdf->setStrokeColor(219, 230, 239);
$pdf->rect(36, 130, 523, 180, 'D');

$rows = [
    ['Candidate Code:', $r['candidate_code']],
    ['Candidate Name:', $r['full_name']],
    ['Target Class:', $r['target_class']],
    ['Test Title:', $r['test_title']],
    ['Score Obtained:', $r['score'] . ' / ' . $r['max_score'] . ' (' . $r['percentage'] . '%)'],
    ['Scholarship Award:', $r['scholarship_pct'] . '% Tuition Fee Scholarship'],
    ['Submitted On:', (string)$r['submitted_at']],
];
$y = 156;
foreach ($rows as $row) {
    $pdf->text(52, $y, $row[0], 11, true, 52, 75, 94);
    $pdf->text(195, $y, $row[1], 11, false, 15, 23, 42);
    $y += 21;
}
$pdf->text(36, 340, 'Present this certificate at Yuitor Smart Classes to redeem scholarship.', 9.5, false, 100, 116, 139);
$pdf->output('Yuitor_Test_' . $r['candidate_code'] . '.pdf');
