<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('teacher');
$pdo = db();

$batchIds = teacher_assigned_batch_ids($user['id']);
$batches = $batchIds ? $pdo->query("SELECT id, name, branch_id FROM batches WHERE id IN (" . implode(',', array_map('intval', $batchIds)) . ") AND deleted_at IS NULL")->fetchAll() : [];
$batchId = isset($_GET['batch_id']) ? (int)$_GET['batch_id'] : (!empty($batches) ? (int)$batches[0]['id'] : 0);
$attDate = $_GET['date'] ?? date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $bId = (int)$_POST['batch_id'];
    assert_teacher_batch_access($user['id'], $bId);
    $d = $_POST['att_date'] ?? date('Y-m-d');
    $brId = (int)$pdo->query("SELECT branch_id FROM batches WHERE id = " . $bId)->fetchColumn();
    foreach (($_POST['status'] ?? []) as $stId => $stVal) {
        if (!in_array($stVal, ['present','absent','late','leave'], true)) continue;
        $pdo->prepare("INSERT INTO attendance (branch_id, batch_id, student_id, att_date, status, mode, marked_by) VALUES (?, ?, ?, ?, ?, 'manual', ?)
                       ON DUPLICATE KEY UPDATE status = VALUES(status), marked_by = VALUES(marked_by)")
            ->execute([$brId, $bId, (int)$stId, $d, $stVal, $user['id']]);
    }
    flash_set('success', 'Batch attendance updated.');
    redirect_to('teacher/attendance.php?batch_id=' . $bId . '&date=' . urlencode($d));
}

$students = [];
if ($batchId) {
    assert_teacher_batch_access($user['id'], $batchId);
    $st = $pdo->prepare("SELECT s.id, s.admission_no, u.full_name, a.status AS today_status
                         FROM students s JOIN users u ON u.id=s.user_id
                         LEFT JOIN attendance a ON a.student_id=s.id AND a.att_date = ?
                         WHERE s.batch_id = ? AND s.deleted_at IS NULL AND s.status='active' ORDER BY u.full_name");
    $st->execute([$attDate, $batchId]);
    $students = $st->fetchAll();
}

$pageTitle = 'Mark Batch Attendance';
$showPanelSidebar = true;
$portalMode = 'teacher';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Mark Batch Attendance</h1><p>Assigned batches only.</p></div></div>
<div class="yu-card">
  <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;">
    <select name="batch_id" style="padding:8px 10px;border:1px solid #cbd9e6;border-radius:8px;"><?php foreach($batches as $b): ?><option value="<?php echo (int)$b['id']; ?>" <?php echo $batchId===(int)$b['id']?'selected':''; ?>><?php echo e($b['name']); ?></option><?php endforeach; ?></select>
    <input type="date" name="date" value="<?php echo e($attDate); ?>" style="padding:8px 10px;border:1px solid #cbd9e6;border-radius:8px;">
    <button class="yu-btn yu-btn-outline yu-btn-sm" type="submit">Load Batch</button>
  </form>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="batch_id" value="<?php echo $batchId; ?>">
    <input type="hidden" name="att_date" value="<?php echo e($attDate); ?>">
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Adm No</th><th>Student</th><th>Status</th></tr>
      <?php foreach ($students as $st): $cur = $st['today_status'] ?: 'present'; ?>
        <tr>
          <td><?php echo e($st['admission_no']); ?></td>
          <td><strong><?php echo e($st['full_name']); ?></strong></td>
          <td><select name="status[<?php echo (int)$st['id']; ?>]" style="padding:6px 10px;border:1px solid #cbd9e6;border-radius:8px;">
            <?php foreach(['present'=>'Present','absent'=>'Absent','late'=>'Late','leave'=>'Leave'] as $k=>$v): ?><option value="<?php echo $k; ?>" <?php echo $cur===$k?'selected':''; ?>><?php echo $v; ?></option><?php endforeach; ?>
          </select></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?php if ($students): ?><button class="yu-btn yu-btn-primary" style="margin-top:14px;" type="submit">Save Attendance</button><?php endif; ?>
  </form>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
