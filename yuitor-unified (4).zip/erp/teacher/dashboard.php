<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('teacher');
$pdo = db();

$batchIds = teacher_assigned_batch_ids($user['id']);
$batches = [];
$studentCount = 0;
$todayCount = 0;
if ($batchIds) {
    $ids = array_values(array_map('intval', $batchIds));
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $qB = $pdo->prepare("SELECT ba.*, c.title AS course_title, b.name AS branch_name FROM batches ba JOIN courses c ON c.id=ba.course_id JOIN branches b ON b.id=ba.branch_id WHERE ba.id IN ({$ph}) AND ba.deleted_at IS NULL");
    $qB->execute($ids);
    $batches = $qB->fetchAll();
    $qS = $pdo->prepare("SELECT COUNT(*) FROM students WHERE batch_id IN ({$ph}) AND deleted_at IS NULL AND status='active'");
    $qS->execute($ids);
    $studentCount = (int)$qS->fetchColumn();
    $qA = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE batch_id IN ({$ph}) AND att_date = CURDATE() AND status IN ('present','late')");
    $qA->execute($ids);
    $todayCount = (int)$qA->fetchColumn();
}
$notices = $pdo->query("SELECT * FROM notices WHERE deleted_at IS NULL AND audience IN ('all','teachers','batch') ORDER BY id DESC LIMIT 6")->fetchAll();

$pageTitle = 'Teacher Dashboard';
$showPanelSidebar = true;
$portalMode = 'teacher';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Faculty Academic Workspace</h1><p>Assigned batches only &bull; Attendance, materials, homework grading &amp; test marks.</p></div>
</div>
<div class="yu-kpi-grid">
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Assigned Batches</div><span class="yu-kpi-ico"><?php echo yu_icon('book', 17); ?></span></div>
    <div class="yu-kpi-val"><?php echo count($batches); ?></div>
  </div>
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Active Batch Students</div><span class="yu-kpi-ico teal"><?php echo yu_icon('students', 17); ?></span></div>
    <div class="yu-kpi-val"><?php echo $studentCount; ?></div>
  </div>
  <div class="yu-kpi">
    <div class="yu-kpi-head"><div class="yu-kpi-label">Marked Present Today</div><span class="yu-kpi-ico"><?php echo yu_icon('attendance', 17); ?></span></div>
    <div class="yu-kpi-val"><?php echo $todayCount; ?></div>
  </div>
</div>
<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">My Assigned Batches</div>
    <?php if (empty($batches)): ?>
      <p style="color:#64748b;">No batches assigned yet. Please ask Admin to assign batches.</p>
    <?php else: ?>
      <div class="yu-table-wrap"><table class="yu-table">
        <tr><th>Batch</th><th>Course</th><th>Timing</th><th>Quick Actions</th></tr>
        <?php foreach ($batches as $b): ?>
          <tr>
            <td><strong><?php echo e($b['name']); ?></strong><div style="font-size:12px;color:#64748b;"><?php echo e($b['branch_name']); ?></div></td>
            <td><?php echo e($b['course_title']); ?></td>
            <td><?php echo e($b['timing']); ?></td>
            <td><a class="yu-btn yu-btn-outline yu-btn-sm" href="<?php echo e(erp_url('teacher/attendance.php?batch_id='.(int)$b['id'])); ?>"><?php echo yu_icon('attendance', 13); ?> Attendance</a></td>
          </tr>
        <?php endforeach; ?>
      </table></div>
    <?php endif; ?>
  </div>
  <div class="yu-card">
    <div class="yu-card-title">Recent Academic Notices</div>
    <?php foreach ($notices as $n): ?>
      <div style="padding:10px 0;border-bottom:1px solid #ebf1f6;">
        <strong><?php echo e($n['title']); ?></strong>
        <div style="font-size:13px;color:#475569;margin-top:2px;"><?php echo e($n['body']); ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
