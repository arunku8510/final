<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('teacher');
$pdo = db();

$batchIds = teacher_assigned_batch_ids($user['id']);
$ids = array_values(array_map('intval', $batchIds)); $ph = $ids ? implode(',', array_fill(0, count($ids), '?')) : '';
$batches = []; if ($ids) { $qb = $pdo->prepare("SELECT id, name FROM batches WHERE id IN ({$ph}) AND deleted_at IS NULL"); $qb->execute($ids); $batches = $qb->fetchAll(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $bId = (int)$_POST['batch_id'];
    assert_teacher_batch_access($user['id'], $bId);
    $pdo->prepare("INSERT INTO notices (batch_id, title, body, audience, created_by) VALUES (?, ?, ?, 'batch', ?)")
        ->execute([$bId, trim($_POST['title']), trim($_POST['body']), $user['id']]);
    flash_set('success', 'Academic batch notice posted.');
    redirect_to('teacher/notices.php');
}

if ($ids) { $qn = $pdo->prepare("SELECT n.*, ba.name AS batch_name FROM notices n LEFT JOIN batches ba ON ba.id=n.batch_id WHERE n.deleted_at IS NULL AND (n.batch_id IN ({$ph}) OR n.audience IN ('all','teachers')) ORDER BY n.id DESC LIMIT 20"); $qn->execute($ids); $notices = $qn->fetchAll(); } else { $notices = $pdo->query("SELECT n.*, ba.name AS batch_name FROM notices n LEFT JOIN batches ba ON ba.id=n.batch_id WHERE n.deleted_at IS NULL AND n.audience IN ('all','teachers') ORDER BY n.id DESC LIMIT 20")->fetchAll(); }

$pageTitle = 'Batch Notices';
$showPanelSidebar = true;
$portalMode = 'teacher';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Academic Batch Notices</h1></div></div>
<div class="yu-card">
  <div class="yu-card-title">Post Notice for Assigned Batch</div>
  <form method="post">
    <?php echo csrf_field(); ?>
    <div class="yu-form-row">
      <div class="yu-field"><label>Batch</label><select name="batch_id"><?php foreach($batches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['name']); ?></option><?php endforeach; ?></select></div>
      <div class="yu-field"><label>Title</label><input type="text" name="title" required></div>
    </div>
    <div class="yu-field" style="margin-bottom:10px;"><label>Notice Content</label><textarea name="body" rows="3" required></textarea></div>
    <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Post Notice</button>
  </form>
</div>
<div class="yu-card">
  <div class="yu-card-title">Recent Notices</div>
  <?php foreach($notices as $n): ?>
    <div style="padding:10px 0;border-bottom:1px solid #ebf1f6;">
      <strong><?php echo e($n['title']); ?></strong> <span style="font-size:12px;color:#0b7b82;">(<?php echo e($n['batch_name'] ?: 'All'); ?>)</span>
      <div style="font-size:13.5px;color:#475569;margin-top:2px;"><?php echo e($n['body']); ?></div>
    </div>
  <?php endforeach; ?>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
