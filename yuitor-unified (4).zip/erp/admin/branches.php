<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'add_branch') {
        $code = strtoupper(preg_replace('/[^A-Z0-9]/i', '', $_POST['code'] ?? ''));
        $name = trim($_POST['name'] ?? '');
        if ($code !== '' && $name !== '') {
            $pdo->prepare("INSERT INTO branches (code, name, city, phone, email, address) VALUES (?, ?, ?, ?, ?, ?)")
                ->execute([$code, $name, trim($_POST['city'] ?? ''), trim($_POST['phone'] ?? ''), trim($_POST['email'] ?? ''), trim($_POST['address'] ?? '')]);
            audit_log('branch_created', 'branches', (int)$pdo->lastInsertId(), $code . ' - ' . $name);
            flash_set('success', 'Branch added successfully.');
        }
    } elseif ($act === 'add_session') {
        $name = trim($_POST['name'] ?? '');
        $sdate = $_POST['start_date'] ?? date('Y-04-01');
        $edate = $_POST['end_date'] ?? date('Y-03-31', strtotime('+1 year'));
        $curr = !empty($_POST['is_current']) ? 1 : 0;
        if ($curr) $pdo->exec("UPDATE academic_sessions SET is_current = 0");
        $pdo->prepare("INSERT INTO academic_sessions (name, start_date, end_date, is_current) VALUES (?, ?, ?, ?)")
            ->execute([$name, $sdate, $edate, $curr]);
        flash_set('success', 'Academic session added.');
    } elseif ($act === 'promote_students') {
        $fromSess = (int)$_POST['from_session_id'];
        $toSess = (int)$_POST['to_session_id'];
        if ($fromSess && $toSess && $fromSess !== $toSess) {
            $st = $pdo->prepare("UPDATE students SET session_id = ? WHERE session_id = ? AND status = 'active' AND deleted_at IS NULL");
            $st->execute([$toSess, $fromSess]);
            audit_log('students_promoted', 'academic_sessions', $toSess, 'Promoted ' . $st->rowCount() . ' students');
            flash_set('success', $st->rowCount() . ' active student(s) promoted to selected session.');
        }
    } elseif ($act === 'add_course') {
        $pdo->prepare("INSERT INTO courses (code, title, category, duration_months, default_fee, description) VALUES (?, ?, ?, ?, ?, ?)")
            ->execute([strtoupper(trim($_POST['code'])), trim($_POST['title']), trim($_POST['category']), (int)$_POST['duration_months'], (float)$_POST['default_fee'], trim($_POST['description'] ?? '')]);
        flash_set('success', 'Course added.');
    } elseif ($act === 'add_batch') {
        $pdo->prepare("INSERT INTO batches (branch_id, session_id, course_id, name, timing, room_no, capacity) VALUES (?, ?, ?, ?, ?, ?, ?)")
            ->execute([(int)$_POST['branch_id'], (int)$_POST['session_id'], (int)$_POST['course_id'], trim($_POST['name']), trim($_POST['timing']), trim($_POST['room_no']), (int)$_POST['capacity']]);
        flash_set('success', 'Batch created.');
    } elseif ($act === 'add_timetable') {
        $pdo->prepare("INSERT INTO timetable (batch_id, day_of_week, start_time, end_time, subject, teacher_id, room) VALUES (?, ?, ?, ?, ?, ?, ?)")
            ->execute([(int)$_POST['batch_id'], $_POST['day_of_week'], trim($_POST['start_time']), trim($_POST['end_time']), trim($_POST['subject']), !empty($_POST['teacher_id'])?(int)$_POST['teacher_id']:null, trim($_POST['room'])]);
        flash_set('success', 'Timetable slot added.');
    } elseif ($act === 'soft_delete_batch') {
        $pdo->prepare("UPDATE batches SET deleted_at = NOW() WHERE id = ?")->execute([(int)$_POST['id']]);
        flash_set('success', 'Batch archived.');
    } elseif ($act === 'restore_batch') {
        $pdo->prepare("UPDATE batches SET deleted_at = NULL WHERE id = ?")->execute([(int)$_POST['id']]);
        flash_set('success', 'Batch restored.');
    }
    redirect_to('admin/branches.php');
}

$branches = $pdo->query("SELECT * FROM branches WHERE deleted_at IS NULL ORDER BY id ASC")->fetchAll();
$sessions = $pdo->query("SELECT * FROM academic_sessions ORDER BY id DESC")->fetchAll();
$courses = $pdo->query("SELECT * FROM courses WHERE deleted_at IS NULL ORDER BY id DESC")->fetchAll();
$batches = $pdo->query("SELECT ba.*, b.name AS branch_name, c.title AS course_title, s.name AS session_name
                        FROM batches ba
                        JOIN branches b ON b.id = ba.branch_id
                        JOIN courses c ON c.id = ba.course_id
                        JOIN academic_sessions s ON s.id = ba.session_id
                        ORDER BY ba.deleted_at IS NOT NULL, ba.id DESC")->fetchAll();
$teachers = $pdo->query("SELECT id, full_name FROM users WHERE role='teacher' AND is_active=1 AND deleted_at IS NULL ORDER BY full_name")->fetchAll();
$timetable = $pdo->query("SELECT t.*, ba.name AS batch_name, u.full_name AS teacher_name FROM timetable t JOIN batches ba ON ba.id = t.batch_id LEFT JOIN users u ON u.id = t.teacher_id ORDER BY ba.name, FIELD(t.day_of_week,'Mon','Tue','Wed','Thu','Fri','Sat','Sun'), t.start_time")->fetchAll();

$pageTitle = 'Branches, Sessions, Courses & Timetable';
$showPanelSidebar = true;
$pageNoIndex = true;
$portalMode = 'admin';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Branches, Sessions, Courses &amp; Timetable</h1><p>Configure multi-branch structure, promote sessions, and schedule batches.</p></div>
</div>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Add Coaching Branch</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="add_branch">
      <div class="yu-form-row">
        <div class="yu-field"><label>Branch Code (Receipt Prefix)</label><input type="text" name="code" placeholder="e.g. YS02" required></div>
        <div class="yu-field"><label>Branch Name</label><input type="text" name="name" required></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>City</label><input type="text" name="city" required></div>
        <div class="yu-field"><label>Phone</label><input type="text" name="phone"></div>
      </div>
      <div class="yu-field" style="margin-bottom:12px;"><label>Address</label><input type="text" name="address"></div>
      <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Create Branch</button>
    </form>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Academic Sessions &amp; Student Promotion</div>
    <form method="post" style="margin-bottom:16px;">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="add_session">
      <div class="yu-form-row">
        <div class="yu-field"><label>Session Name</label><input type="text" name="name" placeholder="2027-28" required></div>
        <div class="yu-field"><label>Start Date</label><input type="date" name="start_date" required></div>
        <div class="yu-field"><label>End Date</label><input type="date" name="end_date" required></div>
      </div>
      <label style="font-size:13px;display:flex;gap:8px;align-items:center;margin-bottom:10px;"><input type="checkbox" name="is_current" value="1"> Set as Active Current Session</label>
      <button class="yu-btn yu-btn-teal yu-btn-sm" type="submit">Save Session</button>
    </form>
    <form method="post" style="border-top:1px solid #e5eef5;padding-top:12px;">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="promote_students">
      <div class="yu-form-row">
        <div class="yu-field"><label>From Session</label><select name="from_session_id"><?php foreach($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>"><?php echo e($s['name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Promote To</label><select name="to_session_id"><?php foreach($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>"><?php echo e($s['name']); ?></option><?php endforeach; ?></select></div>
      </div>
      <button class="yu-btn yu-btn-outline yu-btn-sm" type="submit">Promote Active Students</button>
    </form>
  </div>
</div>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Add Course</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="add_course">
      <div class="yu-form-row">
        <div class="yu-field"><label>Course Code</label><input type="text" name="code" placeholder="CUET-26" required></div>
        <div class="yu-field"><label>Title</label><input type="text" name="title" required></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Category</label><input type="text" name="category" value="School"></div>
        <div class="yu-field"><label>Months</label><input type="number" name="duration_months" value="12"></div>
        <div class="yu-field"><label>Default Fee (Rs.)</label><input type="number" step="0.01" name="default_fee" value="18000"></div>
      </div>
      <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Add Course</button>
    </form>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Create Batch</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="add_batch">
      <div class="yu-form-row">
        <div class="yu-field"><label>Branch</label><select name="branch_id"><?php foreach($branches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['code'].' - '.$b['name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Session</label><select name="session_id"><?php foreach($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>"><?php echo e($s['name']); ?></option><?php endforeach; ?></select></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Course</label><select name="course_id"><?php foreach($courses as $c): ?><option value="<?php echo (int)$c['id']; ?>"><?php echo e($c['title']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Batch Name</label><input type="text" name="name" required></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Timing</label><input type="text" name="timing" placeholder="04:00 PM - 06:00 PM"></div>
        <div class="yu-field"><label>Room</label><input type="text" name="room_no" placeholder="Room 2"></div>
        <div class="yu-field"><label>Capacity</label><input type="number" name="capacity" value="40"></div>
      </div>
      <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Create Batch</button>
    </form>
  </div>
</div>

<div class="yu-card">
  <div class="yu-card-title">All Batches</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Batch</th><th>Branch</th><th>Course</th><th>Session</th><th>Timing</th><th>Status</th><th>Action</th></tr>
    <?php foreach ($batches as $ba): ?>
      <tr>
        <td><strong><?php echo e($ba['name']); ?></strong></td>
        <td><?php echo e($ba['branch_name']); ?></td>
        <td><?php echo e($ba['course_title']); ?></td>
        <td><?php echo e($ba['session_name']); ?></td>
        <td><?php echo e($ba['timing']); ?></td>
        <td><?php echo $ba['deleted_at'] ? '<span class="yu-status-text st-muted">Archived</span>' : '<span class="yu-status-text st-ok">Active</span>'; ?></td>
        <td>
          <form method="post" style="margin:0;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo (int)$ba['id']; ?>">
            <input type="hidden" name="act" value="<?php echo $ba['deleted_at'] ? 'restore_batch' : 'soft_delete_batch'; ?>">
            <button class="yu-btn yu-btn-outline yu-btn-sm" type="submit"><?php echo $ba['deleted_at'] ? 'Restore' : 'Archive'; ?></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="yu-card">
  <div class="yu-card-title">Class Timetable</div>
  <form method="post" style="margin-bottom:14px;">
    <?php echo csrf_field(); ?><input type="hidden" name="act" value="add_timetable">
    <div class="yu-form-row">
      <div class="yu-field"><label>Batch</label><select name="batch_id"><?php foreach($batches as $ba): if($ba['deleted_at']) continue; ?><option value="<?php echo (int)$ba['id']; ?>"><?php echo e($ba['name']); ?></option><?php endforeach; ?></select></div>
      <div class="yu-field"><label>Day</label><select name="day_of_week"><?php foreach(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $d): ?><option><?php echo $d; ?></option><?php endforeach; ?></select></div>
      <div class="yu-field"><label>Start</label><input type="text" name="start_time" placeholder="04:00 PM" required></div>
      <div class="yu-field"><label>End</label><input type="text" name="end_time" placeholder="05:30 PM" required></div>
      <div class="yu-field"><label>Subject</label><input type="text" name="subject" required></div>
      <div class="yu-field"><label>Teacher</label><select name="teacher_id"><option value="">-- Optional --</option><?php foreach($teachers as $t): ?><option value="<?php echo (int)$t['id']; ?>"><?php echo e($t['full_name']); ?></option><?php endforeach; ?></select></div>
      <div class="yu-field"><label>Room</label><input type="text" name="room" placeholder="Hall A"></div>
    </div>
    <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Add Timetable Slot</button>
  </form>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Batch</th><th>Day</th><th>Time</th><th>Subject</th><th>Faculty</th><th>Room</th></tr>
    <?php foreach ($timetable as $tt): ?>
      <tr><td><?php echo e($tt['batch_name']); ?></td><td><?php echo e($tt['day_of_week']); ?></td><td><?php echo e($tt['start_time'].' - '.$tt['end_time']); ?></td><td><strong><?php echo e($tt['subject']); ?></strong></td><td><?php echo e($tt['teacher_name'] ?: '-'); ?></td><td><?php echo e($tt['room']); ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
