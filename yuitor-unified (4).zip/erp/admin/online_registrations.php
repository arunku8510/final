<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role(['admin', 'staff']);
$pdo = db();
$allowedStatuses = ['New', 'Contacted', 'Admitted', 'Rejected'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = (string) ($_POST['act'] ?? 'update_status');
    $regId = (int) ($_POST['reg_id'] ?? 0);

    if ($act === 'activate_student' && $regId > 0) {
        $q = $pdo->prepare("SELECT * FROM online_registrations WHERE id = ? LIMIT 1");
        $q->execute([$regId]);
        $reg = $q->fetch();
        if ($reg && ($user['role'] === 'admin' || (int) $reg['branch_id'] === (int) $user['branch_id'])) {
            $email = strtolower(trim((string) $reg['email']));
            $exists = $pdo->prepare("SELECT id FROM users WHERE email = ? AND deleted_at IS NULL LIMIT 1");
            $exists->execute([$email]);
            if ($exists->fetchColumn()) {
                $pdo->prepare("UPDATE online_registrations SET status = 'Admitted' WHERE id = ?")->execute([$regId]);
                flash_set('warning', 'Student login already exists for ' . $email . '. Status marked Admitted.');
            } else {
                $courseId = (int) $pdo->query("SELECT id FROM courses WHERE is_active = 1 ORDER BY id ASC LIMIT 1")->fetchColumn();
                $bSt = $pdo->prepare("SELECT id FROM batches WHERE branch_id = ? AND is_active = 1 ORDER BY id ASC LIMIT 1");
                $bSt->execute([(int) $reg['branch_id']]);
                $batchId = (int) $bSt->fetchColumn();
                $sessId = current_academic_session_id();
                if ($batchId < 1 || $sessId < 1 || $courseId < 1) {
                    flash_set('error', 'Create at least one active Session, Course, and Batch before activating a Student Portal account.');
                } else {
                    $passHash = !empty($reg['password_hash']) ? $reg['password_hash'] : password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT);
                    $pdo->beginTransaction();
                    try {
                        $pdo->prepare("INSERT INTO users (branch_id, role, full_name, email, phone, password_hash, is_active) VALUES (?, 'student', ?, ?, ?, ?, 1)")
                            ->execute([(int) $reg['branch_id'], $reg['student_name'], $email, $reg['phone'], $passHash]);
                        $uid = (int) $pdo->lastInsertId();
                        $admNo = 'YSC-' . date('Y') . '-' . str_pad((string) $uid, 4, '0', STR_PAD_LEFT);
                        $qrToken = bin2hex(random_bytes(16));
                        $pdo->prepare("INSERT INTO students (user_id, branch_id, session_id, course_id, batch_id, admission_no, father_name, guardian_phone, qr_token, admission_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), 'active')")
                            ->execute([$uid, (int) $reg['branch_id'], $sessId, $courseId, $batchId, $admNo, $reg['parent_name'] ?: '-', $reg['phone'], $qrToken]);
                        $stId = (int) $pdo->lastInsertId();
                        $pdo->prepare("INSERT INTO student_fee_accounts (student_id, branch_id, session_id, gross_amount, discount_amount, discount_reason, net_amount, paid_amount) VALUES (?, ?, ?, 0, 0, '', 0, 0)")
                            ->execute([$stId, (int) $reg['branch_id'], $sessId]);
                        $pdo->prepare("UPDATE online_registrations SET status = 'Admitted', email_verified = 1 WHERE id = ?")
                            ->execute([$regId]);
                        $pdo->commit();

                        $loginUrl = yu_site_url() . '/student/login.php';
                        send_student_welcome_email($email, $reg['student_name'], $reg['class_grade'], $loginUrl);
                        audit_log('student_admitted_from_web', 'online_registrations', $regId, "Admission No {$admNo}");
                        flash_set('success', "Student Portal activated ({$admNo}) and welcome email sent.");
                    } catch (Throwable $ex) {
                        if ($pdo->inTransaction()) $pdo->rollBack();
                        error_log('Activate student error: ' . $ex->getMessage());
                        flash_set('error', 'Unable to activate student account. Check server logs.');
                    }
                }
            }
        }
    } else {
        $status = trim((string) ($_POST['status'] ?? ''));
        $notes = trim((string) ($_POST['admin_notes'] ?? ''));
        if ($regId > 0 && in_array($status, $allowedStatuses, true)) {
            if ($user['role'] === 'staff') {
                $stmt = $pdo->prepare("UPDATE online_registrations SET status = ?, admin_notes = ? WHERE id = ? AND branch_id = ?");
                $stmt->execute([$status, $notes, $regId, (int) $user['branch_id']]);
            } else {
                $stmt = $pdo->prepare("UPDATE online_registrations SET status = ?, admin_notes = ? WHERE id = ?");
                $stmt->execute([$status, $notes, $regId]);
            }
            audit_log('online_reg_updated', 'online_registrations', $regId, "Status -> {$status}");
            flash_set('success', 'Registration status updated.');
        }
    }
    redirect_to('admin/online_registrations.php');
}

$filter = trim((string) ($_GET['status'] ?? ''));
$where = [];
$params = [];
if ($user['role'] === 'staff') {
    $where[] = 'branch_id = ?';
    $params[] = (int) $user['branch_id'];
}
if (in_array($filter, $allowedStatuses, true)) {
    $where[] = 'status = ?';
    $params[] = $filter;
}
$sql = 'SELECT * FROM online_registrations' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY id DESC LIMIT 150';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$pageTitle = 'Online Registrations';
$pageNoIndex = true;
$portalMode = 'admin';
$showPanelSidebar = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Online Registrations &amp; Admission Inquiries</h1><p>Website se aane wale sabhi student registrations aur email verification status.</p></div>
</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;">
  <a href="online_registrations.php" class="yu-btn yu-btn-sm <?php echo $filter === '' ? 'yu-btn-primary' : 'yu-btn-outline'; ?>">All</a>
  <?php foreach ($allowedStatuses as $st): ?>
    <a href="online_registrations.php?status=<?php echo e(urlencode($st)); ?>" class="yu-btn yu-btn-sm <?php echo $filter === $st ? 'yu-btn-primary' : 'yu-btn-outline'; ?>"><?php echo e($st); ?></a>
  <?php endforeach; ?>
</div>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Student / Parent</th><th>Class / Course</th><th>Contact &amp; Email</th><th>Message</th><th>Status</th><th>Actions</th></tr>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><strong><?php echo e($r['student_name']); ?></strong><br><span style="font-size:12px;color:#64748b;">Parent: <?php echo e($r['parent_name'] ?: '-'); ?></span></td>
        <td><?php echo e($r['class_grade']); ?> (<?php echo e($r['board']); ?>)<br><span style="font-size:12px;color:#64748b;"><?php echo e($r['course_interest']); ?></span></td>
        <td>
          <?php echo e($r['phone']); ?><br>
          <span style="font-size:12px;color:#64748b;"><?php echo e($r['email']); ?></span><br>
          <?php if (!empty($r['email_verified'])): ?>
            <span class="yu-status-text st-ok" style="font-size:11px;">Email Verified</span>
          <?php else: ?>
            <span class="yu-status-text st-warn" style="font-size:11px;">Pending Email OTP</span>
          <?php endif; ?>
        </td>
        <td style="max-width:220px;font-size:12.5px;"><?php echo nl2br(e($r['message'] ?: '-')); ?></td>
        <td><strong><?php echo e($r['status']); ?></strong><br><span style="font-size:11px;color:#64748b;"><?php echo e($r['created_at']); ?></span></td>
        <td>
          <form method="post" style="display:grid;gap:6px;min-width:170px;margin-bottom:6px;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="act" value="update_status">
            <input type="hidden" name="reg_id" value="<?php echo (int) $r['id']; ?>">
            <select name="status" style="padding:6px;border:1px solid #cbd9e6;border-radius:8px;">
              <?php foreach ($allowedStatuses as $st): ?>
                <option value="<?php echo e($st); ?>" <?php echo $r['status'] === $st ? 'selected' : ''; ?>><?php echo e($st); ?></option>
              <?php endforeach; ?>
            </select>
            <input type="text" name="admin_notes" value="<?php echo e($r['admin_notes'] ?? ''); ?>" placeholder="Remark / follow-up" style="padding:6px;border:1px solid #cbd9e6;border-radius:8px;font-size:12px;">
            <button type="submit" class="yu-btn yu-btn-primary yu-btn-sm">Save Status</button>
          </form>
          <?php if ($r['status'] !== 'Admitted'): ?>
            <form method="post" style="margin:0;">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="act" value="activate_student">
              <input type="hidden" name="reg_id" value="<?php echo (int) $r['id']; ?>">
              <button type="submit" class="yu-btn yu-btn-teal yu-btn-sm" style="width:100%;">Admit &amp; Activate Login</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (empty($rows)): ?>
      <tr><td colspan="6" style="text-align:center;color:#64748b;padding:24px;">No registrations found.</td></tr>
    <?php endif; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
