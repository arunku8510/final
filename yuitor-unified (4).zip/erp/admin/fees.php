<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/fee_helpers.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    csv_download_headers('yuitor_fee_payments_' . date('Ymd') . '.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Receipt No', 'Student', 'Admission No', 'Branch', 'Amount', 'Mode', 'UTR', 'Status', 'Paid At']);
    $rows = $pdo->query("SELECT fp.receipt_no, u.full_name, s.admission_no, b.name, fp.amount, fp.payment_mode, fp.utr_number, fp.status, fp.paid_at
                         FROM fee_payments fp JOIN students s ON s.id=fp.student_id JOIN users u ON u.id=s.user_id JOIN branches b ON b.id=fp.branch_id ORDER BY fp.id DESC")->fetchAll();
    foreach ($rows as $r) fputcsv($out, $r);
    fclose($out);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'add_structure') {
        $pdo->prepare("INSERT INTO fee_structures (course_id, session_id, title, total_amount, installments_count, late_fee_per_day) VALUES (?, ?, ?, ?, ?, ?)")
            ->execute([(int)$_POST['course_id'], current_academic_session_id(), trim($_POST['title']), (float)$_POST['total_amount'], (int)$_POST['installments_count'], (float)$_POST['late_fee_per_day']]);
        flash_set('success', 'Fee structure saved.');
    } elseif ($act === 'allocate_fee') {
        $stId = (int)$_POST['student_id'];
        $st = $pdo->prepare("SELECT branch_id, session_id FROM students WHERE id = ?");
        $st->execute([$stId]);
        $row = $st->fetch();
        if ($row) {
            allocate_student_fee_account($stId, $row['branch_id'], $row['session_id'], (float)$_POST['gross_amount'], (float)$_POST['discount_amount'], trim($_POST['discount_reason'] ?? ''), (int)$_POST['installments_count']);
            flash_set('success', 'Student fee account & installments generated.');
        }
    } elseif ($act === 'collect_cash') {
        $stId = (int)$_POST['student_id'];
        $acc = $pdo->prepare("SELECT * FROM student_fee_accounts WHERE student_id = ? ORDER BY id DESC LIMIT 1");
        $acc->execute([$stId]);
        $accRow = $acc->fetch();
        if (!$accRow) {
            flash_set('error', 'Allocate a fee account for this student first.');
        } else {
            $res = record_fee_payment([
                'student_id' => $stId,
                'branch_id' => $accRow['branch_id'],
                'fee_account_id' => $accRow['id'],
                'amount' => (float)$_POST['amount'],
                'payment_mode' => $_POST['payment_mode'] ?? 'cash',
                'utr_number' => trim($_POST['utr_number'] ?? ''),
                'status' => 'verified',
                'remarks' => trim($_POST['remarks'] ?? 'Collected by Admin'),
                'collected_by' => $user['id'],
            ]);
            flash_set($res['ok'] ? 'success' : 'error', $res['ok'] ? ('Payment recorded! Receipt: ' . $res['receipt_no']) : $res['error']);
        }
    } elseif ($act === 'verify_upi') {
        $pid = (int)$_POST['payment_id'];
        $dec = $_POST['decision'] === 'verified' ? 'verified' : 'rejected';
        $pStmt = $pdo->prepare("SELECT * FROM fee_payments WHERE id = ? AND status = 'pending_verification'");
        $pStmt->execute([$pid]);
        $pRow = $pStmt->fetch();
        if ($pRow) {
            $pdo->prepare("UPDATE fee_payments SET status = ?, verified_by = ?, verified_at = NOW() WHERE id = ?")
                ->execute([$dec, $user['id'], $pid]);
            if ($dec === 'verified') {
                recalculate_fee_account($pRow['fee_account_id']);
                notify_payment_confirmed($pid);
            }
            audit_log('upi_' . $dec, 'fee_payments', $pid, 'Receipt ' . $pRow['receipt_no']);
            flash_set('success', 'UPI payment marked as ' . $dec . '.');
        }
    } elseif ($act === 'reverse_payment') {
        $pid = (int)$_POST['payment_id'];
        $pStmt = $pdo->prepare("SELECT * FROM fee_payments WHERE id = ? AND status = 'verified'");
        $pStmt->execute([$pid]);
        $pRow = $pStmt->fetch();
        if ($pRow) {
            $pdo->prepare("UPDATE fee_payments SET status = 'reversed', remarks = CONCAT(remarks, ' [Reversed by Admin]') WHERE id = ?")->execute([$pid]);
            recalculate_fee_account($pRow['fee_account_id']);
            audit_log('payment_reversed', 'fee_payments', $pid, 'Reversed receipt ' . $pRow['receipt_no']);
            flash_set('success', 'Payment reversed and ledger recalculated.');
        }
    }
    redirect_to('admin/fees.php');
}

$courses = $pdo->query("SELECT id, title, default_fee FROM courses WHERE deleted_at IS NULL")->fetchAll();
$students = $pdo->query("SELECT s.id, s.admission_no, u.full_name FROM students s JOIN users u ON u.id=s.user_id WHERE s.deleted_at IS NULL ORDER BY u.full_name")->fetchAll();
$pendingPayments = $pdo->query("SELECT fp.*, u.full_name, s.admission_no FROM fee_payments fp JOIN students s ON s.id=fp.student_id JOIN users u ON u.id=s.user_id WHERE fp.status='pending_verification' ORDER BY fp.id ASC")->fetchAll();
$payments = $pdo->query("SELECT fp.*, u.full_name, s.admission_no, b.code AS branch_code FROM fee_payments fp JOIN students s ON s.id=fp.student_id JOIN users u ON u.id=s.user_id JOIN branches b ON b.id=fp.branch_id ORDER BY fp.id DESC LIMIT 80")->fetchAll();
$accounts = $pdo->query("SELECT sfa.*, u.full_name, s.admission_no, b.name AS branch_name FROM student_fee_accounts sfa JOIN students s ON s.id=sfa.student_id JOIN users u ON u.id=s.user_id JOIN branches b ON b.id=sfa.branch_id ORDER BY (sfa.net_amount - sfa.paid_amount) DESC LIMIT 60")->fetchAll();

$pageTitle = 'Fees, UPI Verification & Ledger';
$showPanelSidebar = true;
$pageNoIndex = true;
$portalMode = 'admin';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Fees, Installments &amp; UPI Verification</h1><p>Receipt format <code>YS01-2026-0001</code> &bull; Official UPIs: <code><?php echo e(get_setting('upi_id_primary','demo@upi')); ?></code> / <code><?php echo e(get_setting('upi_id_secondary','demo2@upi')); ?></code></p></div>
  <a href="?export=csv" class="yu-btn yu-btn-outline yu-btn-sm">Export Payments CSV</a>
</div>

<?php if (!empty($pendingPayments)): ?>
  <div class="yu-card" style="border-color:#f59e0b;background:#fffdf5;">
    <div class="yu-card-title" style="color:#92400e;">Pending Student/Parent UPI Proofs (<?php echo count($pendingPayments); ?>)</div>
    <div class="yu-table-wrap"><table class="yu-table">
      <tr><th>Student</th><th>Amount</th><th>UPI / UTR</th><th>Proof</th><th>Verify</th></tr>
      <?php foreach ($pendingPayments as $pp): ?>
        <tr>
          <td><strong><?php echo e($pp['full_name']); ?></strong><div style="font-size:12px;"><?php echo e($pp['admission_no']); ?></div></td>
          <td class="num"><strong><?php echo format_inr($pp['amount']); ?></strong></td>
          <td><div><?php echo e($pp['upi_id_used']); ?></div><code><?php echo e($pp['utr_number']); ?></code></td>
          <td><?php if($pp['proof_path']): ?><a href="<?php echo e(erp_url($pp['proof_path'])); ?>" target="_blank" class="yu-btn yu-btn-outline yu-btn-sm">View Screenshot</a><?php else: ?>No Image<?php endif; ?></td>
          <td>
            <form method="post" style="display:flex;gap:6px;">
              <?php echo csrf_field(); ?><input type="hidden" name="act" value="verify_upi"><input type="hidden" name="payment_id" value="<?php echo (int)$pp['id']; ?>">
              <button class="yu-btn yu-btn-primary yu-btn-sm" name="decision" value="verified" type="submit">Approve</button>
              <button class="yu-btn yu-btn-danger yu-btn-sm" name="decision" value="rejected" type="submit">Reject</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
<?php endif; ?>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Allocate / Update Student Fee Account</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="allocate_fee">
      <div class="yu-field" style="margin-bottom:10px;"><label>Student</label><select name="student_id"><?php foreach($students as $st): ?><option value="<?php echo (int)$st['id']; ?>"><?php echo e($st['admission_no'].' - '.$st['full_name']); ?></option><?php endforeach; ?></select></div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Total Fee (Rs.)</label><input type="number" step="0.01" name="gross_amount" value="18000" required></div>
        <div class="yu-field"><label>Discount (Rs.)</label><input type="number" step="0.01" name="discount_amount" value="0"></div>
        <div class="yu-field"><label>Installments</label><input type="number" min="1" max="12" name="installments_count" value="3"></div>
      </div>
      <div class="yu-field" style="margin-bottom:10px;"><label>Discount Reason</label><input type="text" name="discount_reason" placeholder="Scholarship / Sibling discount"></div>
      <button class="yu-btn yu-btn-teal yu-btn-sm" type="submit">Generate Fee Account</button>
    </form>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Collect Fee Payment (Cash / Desk UPI)</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="collect_cash">
      <div class="yu-field" style="margin-bottom:10px;"><label>Student</label><select name="student_id"><?php foreach($students as $st): ?><option value="<?php echo (int)$st['id']; ?>"><?php echo e($st['admission_no'].' - '.$st['full_name']); ?></option><?php endforeach; ?></select></div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Amount (Rs.)</label><input type="number" step="0.01" name="amount" required></div>
        <div class="yu-field"><label>Mode</label><select name="payment_mode"><option value="cash">Cash</option><option value="upi">UPI</option><option value="bank_transfer">Bank Transfer</option><option value="card">Card</option></select></div>
        <div class="yu-field"><label>UTR (If UPI/Bank)</label><input type="text" name="utr_number"></div>
      </div>
      <div class="yu-field" style="margin-bottom:10px;"><label>Remarks</label><input type="text" name="remarks" placeholder="Installment received"></div>
      <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Collect &amp; Issue Receipt</button>
    </form>
  </div>
</div>

<div class="yu-card">
  <div class="yu-card-title">Recent Fee Receipts &amp; Ledger</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Receipt #</th><th>Student</th><th>Mode</th><th class="num">Amount</th><th>Status</th><th>Date</th><th>Actions</th></tr>
    <?php foreach ($payments as $p): ?>
      <tr>
        <td><strong><?php echo e($p['receipt_no']); ?></strong></td>
        <td><?php echo e($p['full_name']); ?> <span style="font-size:12px;color:#64748b;">(<?php echo e($p['admission_no']); ?>)</span></td>
        <td><?php echo e(strtoupper($p['payment_mode'])); ?><?php if($p['utr_number']): ?><div style="font-size:11px;color:#64748b;">UTR: <?php echo e($p['utr_number']); ?></div><?php endif; ?></td>
        <td class="num"><strong><?php echo format_inr($p['amount']); ?></strong></td>
        <td><span class="yu-status-text <?php echo $p['status']==='verified'?'st-ok':($p['status']==='pending_verification'?'st-warn':'st-bad'); ?>"><?php echo e(ucwords(str_replace('_',' ',$p['status']))); ?></span></td>
        <td style="font-size:12px;"><?php echo e($p['paid_at']); ?></td>
        <td style="white-space:nowrap;">
          <a class="yu-btn yu-btn-outline yu-btn-sm" target="_blank" href="<?php echo e(erp_url('student/receipt_pdf.php?id='.(int)$p['id'])); ?>">PDF</a>
          <?php if ($p['status'] === 'verified'): ?>
            <form method="post" style="display:inline;" onsubmit="return confirm('Reverse this verified payment?');"><?php echo csrf_field(); ?><input type="hidden" name="act" value="reverse_payment"><input type="hidden" name="payment_id" value="<?php echo (int)$p['id']; ?>"><button class="yu-btn yu-btn-outline yu-btn-sm" type="submit">Reverse</button></form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="yu-card">
  <div class="yu-card-title">Student Fee Balances (Due vs Paid)</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Student</th><th>Branch</th><th class="num">Net Fee</th><th class="num">Paid</th><th class="num">Balance Due</th></tr>
    <?php foreach ($accounts as $ac): $due = max(0, (float)$ac['net_amount'] - (float)$ac['paid_amount']); ?>
      <tr>
        <td><strong><?php echo e($ac['full_name']); ?></strong> (<?php echo e($ac['admission_no']); ?>)</td>
        <td><?php echo e($ac['branch_name']); ?></td>
        <td class="num"><?php echo format_inr($ac['net_amount']); ?></td>
        <td class="num st-ok"><?php echo format_inr($ac['paid_amount']); ?></td>
        <td class="num <?php echo $due>0?'st-bad':'st-ok'; ?>"><strong><?php echo format_inr($due); ?></strong></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
