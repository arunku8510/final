<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role(['admin', 'staff']);
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $msgId = (int) ($_POST['msg_id'] ?? 0);
    $status = trim((string) ($_POST['status'] ?? ''));
    if ($msgId > 0 && in_array($status, ['Unread', 'Read', 'Replied'], true)) {
        $pdo->prepare("UPDATE contact_messages SET status = ? WHERE id = ?")->execute([$status, $msgId]);
        flash_set('success', 'Message status updated.');
    }
    redirect_to('admin/contact_messages.php');
}

$rows = $pdo->query("SELECT * FROM contact_messages ORDER BY id DESC LIMIT 150")->fetchAll();
$pageTitle = 'Contact Messages';
$showPanelSidebar = true;
$pageNoIndex = true;
$portalMode = 'admin';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Contact Messages</h1><p>Website Contact form se aane wale messages.</p></div></div>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Sender</th><th>Course</th><th>Message</th><th>Received</th><th>Status</th></tr>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><strong><?php echo e($r['name']); ?></strong><br><?php echo e($r['phone']); ?><br><span style="font-size:12px;color:#64748b;"><?php echo e($r['email']); ?></span></td>
        <td><?php echo e($r['course'] ?: '-'); ?></td>
        <td style="max-width:300px;"><?php echo nl2br(e($r['message'])); ?></td>
        <td style="font-size:12px;"><?php echo e($r['created_at']); ?></td>
        <td>
          <form method="post" style="display:flex;gap:6px;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="msg_id" value="<?php echo (int) $r['id']; ?>">
            <select name="status" style="padding:6px;border:1px solid #cbd9e6;border-radius:8px;">
              <?php foreach (['Unread', 'Read', 'Replied'] as $st): ?>
                <option value="<?php echo e($st); ?>" <?php echo $r['status'] === $st ? 'selected' : ''; ?>><?php echo e($st); ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="yu-btn yu-btn-primary yu-btn-sm">Update</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (empty($rows)): ?>
      <tr><td colspan="5" style="text-align:center;color:#64748b;padding:24px;">No contact messages yet.</td></tr>
    <?php endif; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
