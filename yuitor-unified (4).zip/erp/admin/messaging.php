<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/messaging_providers.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'enqueue_campaign') {
        $channel = in_array($_POST['channel'], ['email','sms','whatsapp'], true) ? $_POST['channel'] : 'email';
        $audience = $_POST['audience'] ?? 'all_students';
        $batchId = (int)($_POST['batch_id'] ?? 0);
        $subject = trim($_POST['subject'] ?? 'Update from Yuitor Smart Classes');
        $body = trim($_POST['body'] ?? '');
        $tmpl = trim($_POST['template_id'] ?? '');
        $sql = "SELECT u.full_name, u.email, u.phone FROM users u JOIN students s ON s.user_id=u.id WHERE s.deleted_at IS NULL AND s.status='active'";
        $params = [];
        if ($audience === 'batch' && $batchId > 0) {
            $sql .= " AND s.batch_id = ?";
            $params[] = $batchId;
        } elseif ($audience === 'due_fees') {
            $sql .= " AND s.id IN (SELECT student_id FROM student_fee_accounts WHERE net_amount > paid_amount)";
        }
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $cnt = 0;
        foreach ($st->fetchAll() as $rec) {
            $contact = $channel === 'email' ? $rec['email'] : $rec['phone'];
            $personalBody = str_replace('{name}', $rec['full_name'], $body);
            if (enqueue_message($channel, $contact, $rec['full_name'], $subject, $personalBody, $tmpl, null, $user['id'])) {
                $cnt++;
            }
        }
        audit_log('campaign_enqueued', 'message_queue', null, "{$channel} queued {$cnt} messages");
        flash_set('success', "{$cnt} message(s) queued for {$channel} delivery.");
    } elseif ($act === 'run_queue_now') {
        $res = dispatch_queue_batch(30);
        flash_set('success', "Queue run complete: processed {$res['processed']}, sent {$res['sent']}.");
    } elseif ($act === 'test_send') {
        $ch = $_POST['test_channel'] ?? 'email';
        $to = trim($_POST['test_to'] ?? '');
        $txt = trim($_POST['test_msg'] ?? 'Test message from Yuitor Smart Classes ERP');
        if ($ch === 'email') $res = send_branded_email($to, 'Test Recipient', 'Yuitor ERP SMTP Test', '<p>' . e($txt) . '</p>');
        elseif ($ch === 'sms') $res = send_fast2sms($to, $txt);
        else $res = send_whatsapp_cloud($to, $txt);
        flash_set($res['ok'] ? 'success' : 'error', $res['ok'] ? 'Test message sent!' : $res['error']);
    }
    redirect_to('admin/messaging.php');
}

$batches = $pdo->query("SELECT id, name FROM batches WHERE deleted_at IS NULL")->fetchAll();
$queue = $pdo->query("SELECT * FROM message_queue ORDER BY id DESC LIMIT 40")->fetchAll();
$pageTitle = 'Email, Fast2SMS & WhatsApp Campaigns';
$showPanelSidebar = true;
$pageNoIndex = true;
$portalMode = 'admin';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Multi-Channel Messaging Engine</h1><p>Send branded emails (<code>no-reply@yuitor.com</code>), Fast2SMS alerts &amp; WhatsApp Cloud messages.</p></div>
  <form method="post" style="margin:0;"><?php echo csrf_field(); ?><input type="hidden" name="act" value="run_queue_now"><button class="yu-btn yu-btn-teal yu-btn-sm" type="submit">Process Queue Now</button></form>
</div>

<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Send Bulk / Batch / Fee Due Campaign</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="enqueue_campaign">
      <div class="yu-form-row">
        <div class="yu-field"><label>Channel</label><select name="channel"><option value="email">Email (Branded Theme)</option><option value="sms">Fast2SMS</option><option value="whatsapp">WhatsApp Cloud API</option></select></div>
        <div class="yu-field"><label>Target Audience</label><select name="audience"><option value="all_students">All Active Students</option><option value="due_fees">Students With Pending Fees</option><option value="batch">Specific Batch</option></select></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Batch (If Specific)</label><select name="batch_id"><option value="0">-- All --</option><?php foreach($batches as $b): ?><option value="<?php echo (int)$b['id']; ?>"><?php echo e($b['name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>DLT / WA Template ID (Optional)</label><input type="text" name="template_id"></div>
      </div>
      <div class="yu-field" style="margin-bottom:10px;"><label>Email Subject</label><input type="text" name="subject" value="Important Update - Yuitor Smart Classes"></div>
      <div class="yu-field" style="margin-bottom:12px;"><label>Message (supports {name})</label><textarea name="body" rows="3" required placeholder="Hello {name}, kindly check your upcoming class/fee schedule."></textarea></div>
      <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Queue Campaign</button>
    </form>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">Instant Single Test Send</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="test_send">
      <div class="yu-field" style="margin-bottom:10px;"><label>Channel</label><select name="test_channel"><option value="email">Email (no-reply@yuitor.com)</option><option value="sms">Fast2SMS</option><option value="whatsapp">WhatsApp Cloud</option></select></div>
      <div class="yu-field" style="margin-bottom:10px;"><label>Recipient Email or 10-digit Mobile</label><input type="text" name="test_to" required placeholder="Arunku8510@gmail.com or 9999999999"></div>
      <div class="yu-field" style="margin-bottom:12px;"><label>Test Content</label><textarea name="test_msg" rows="2">Test notification from Yuitor Smart Classes ERP.</textarea></div>
      <button class="yu-btn yu-btn-outline yu-btn-sm" type="submit">Send Test Now</button>
    </form>
  </div>
</div>

<div class="yu-card">
  <div class="yu-card-title">Recent Delivery Queue</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Channel</th><th>Recipient</th><th>Subject / Snippet</th><th>Status</th><th>Error</th><th>Time</th></tr>
    <?php foreach ($queue as $q): ?>
      <tr>
        <td><strong><?php echo e(strtoupper($q['channel'])); ?></strong></td>
        <td><?php echo e($q['recipient']); ?></td>
        <td><?php echo e(substr($q['subject'] ?: $q['body'], 0, 50)); ?></td>
        <td><span class="yu-status-text <?php echo $q['status']==='sent'?'st-ok':($q['status']==='pending'?'st-warn':'st-bad'); ?>"><?php echo e(ucfirst($q['status'])); ?></span></td>
        <td style="font-size:12px;color:#b91c1c;"><?php echo e($q['error_message']); ?></td>
        <td style="font-size:12px;"><?php echo e($q['sent_at'] ?: $q['scheduled_at']); ?></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
