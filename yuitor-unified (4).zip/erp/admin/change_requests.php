<?php
require_once __DIR__ . '/../includes/auth.php';
send_security_headers();
$user = require_role('admin');
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $crId = (int)$_POST['cr_id'];
    $decision = $_POST['decision'] ?? '';
    $remark = trim($_POST['admin_remark'] ?? '');
    $stmt = $pdo->prepare("SELECT * FROM change_requests WHERE id = ? AND status = 'pending' LIMIT 1");
    $stmt->execute([$crId]);
    $cr = $stmt->fetch();

    if ($cr && in_array($decision, ['approved', 'rejected'], true)) {
        if ($decision === 'approved') {
            $payload = json_decode((string)$cr['payload_json'], true) ?: [];
            $tbl = $cr['target_table'];
            $tid = (int)$cr['target_id'];
            if ($cr['action_type'] === 'delete') {
                if ($tbl === 'students') {
                    $pdo->prepare("UPDATE students SET deleted_at = NOW(), status='dropped' WHERE id = ?")->execute([$tid]);
                } elseif ($tbl === 'inquiries') {
                    $pdo->prepare("UPDATE inquiries SET deleted_at = NOW() WHERE id = ?")->execute([$tid]);
                }
            } elseif ($cr['action_type'] === 'update' && $tbl === 'students') {
                $allowed = ['father_name', 'guardian_phone', 'address', 'roll_no', 'batch_id'];
                $sets = [];
                $vals = [];
                foreach ($allowed as $col) {
                    if (array_key_exists($col, $payload)) {
                        $sets[] = "{$col} = ?";
                        $vals[] = $payload[$col];
                    }
                }
                if ($sets) {
                    $vals[] = $tid;
                    $pdo->prepare("UPDATE students SET " . implode(', ', $sets) . " WHERE id = ?")->execute($vals);
                }
            }
        }
        $pdo->prepare("UPDATE change_requests SET status = ?, reviewed_by = ?, admin_remark = ?, reviewed_at = NOW() WHERE id = ?")
            ->execute([$decision, $user['id'], $remark, $crId]);
        audit_log('change_request_' . $decision, 'change_requests', $crId, $cr['summary'] . ' | Remark: ' . $remark);
        flash_set('success', "Change request #{$crId} marked as {$decision}.");
    }
    redirect_to('admin/change_requests.php');
}

$reqs = $pdo->query("SELECT cr.*, u.full_name AS staff_name, b.name AS branch_name FROM change_requests cr JOIN users u ON u.id=cr.requested_by JOIN branches b ON b.id=cr.branch_id ORDER BY cr.status='pending' DESC, cr.id DESC LIMIT 100")->fetchAll();

$pageTitle = 'Operations Change Requests';
$showPanelSidebar = true;
$pageNoIndex = true;
$portalMode = 'admin';
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head">
  <div><h1>Operations Change Request Approvals</h1><p>Branch staff cannot directly edit or delete records; review and approve/reject safely here.</p></div>
</div>
<div class="yu-card">
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>ID</th><th>Branch</th><th>Staff</th><th>Action</th><th>Summary &amp; Payload</th><th>Status</th><th>Decision</th></tr>
    <?php foreach ($reqs as $r): ?>
      <tr>
        <td>#<?php echo (int)$r['id']; ?></td>
        <td><?php echo e($r['branch_name']); ?></td>
        <td><?php echo e($r['staff_name']); ?></td>
        <td><strong><?php echo e(strtoupper($r['action_type'])); ?></strong><div style="font-size:12px;color:#64748b;"><?php echo e($r['target_table'].' #'.$r['target_id']); ?></div></td>
        <td><?php echo e($r['summary']); ?><div style="font-size:11.5px;color:#475569;font-family:monospace;margin-top:3px;"><?php echo e($r['payload_json']); ?></div></td>
        <td><span class="yu-status-text <?php echo $r['status']==='approved'?'st-ok':($r['status']==='rejected'?'st-bad':'st-warn'); ?>"><?php echo e(ucfirst($r['status'])); ?></span></td>
        <td>
          <?php if ($r['status'] === 'pending'): ?>
            <form method="post" style="display:grid;gap:6px;min-width:190px;">
              <?php echo csrf_field(); ?><input type="hidden" name="cr_id" value="<?php echo (int)$r['id']; ?>">
              <input type="text" name="admin_remark" placeholder="Admin remark..." style="padding:5px 8px;border:1px solid #cbd9e6;border-radius:6px;font-size:12px;">
              <div style="display:flex;gap:6px;">
                <button class="yu-btn yu-btn-primary yu-btn-sm" name="decision" value="approved" type="submit">Approve</button>
                <button class="yu-btn yu-btn-danger yu-btn-sm" name="decision" value="rejected" type="submit">Reject</button>
              </div>
            </form>
          <?php else: ?>
            <span style="font-size:12px;color:#64748b;"><?php echo e($r['admin_remark'] ?: 'Reviewed'); ?></span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
