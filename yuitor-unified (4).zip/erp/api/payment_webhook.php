<?php
require_once __DIR__ . '/../includes/fee_helpers.php';
header('Content-Type: application/json; charset=UTF-8');
$raw = file_get_contents('php://input');
$sig = $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? '';
$expected = hash_hmac('sha256', $raw, app_secret_key());
if ($sig === '' || !hash_equals($expected, $sig)) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Invalid webhook signature']);
    exit;
}
$data = json_decode($raw, true);
if (!is_array($data) || empty($data['student_id']) || empty($data['amount'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing fields']);
    exit;
}
$acc = db()->prepare("SELECT * FROM student_fee_accounts WHERE student_id = ? ORDER BY id DESC LIMIT 1");
$acc->execute([(int)$data['student_id']]);
$accRow = $acc->fetch();
if (!$accRow) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Fee account not found']);
    exit;
}
$res = record_fee_payment([
    'student_id' => (int)$data['student_id'],
    'branch_id' => $accRow['branch_id'],
    'fee_account_id' => $accRow['id'],
    'amount' => (float)$data['amount'],
    'payment_mode' => 'gateway',
    'utr_number' => $data['utr'] ?? ('GW-' . time()),
    'status' => 'verified',
    'remarks' => 'Verified Webhook',
]);
echo json_encode($res);
