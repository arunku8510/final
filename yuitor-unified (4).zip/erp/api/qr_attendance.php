<?php
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json; charset=UTF-8');
$user = require_role(['admin', 'staff', 'teacher']);
verify_csrf();

$token = trim((string)($_POST['qr_token'] ?? ''));
if ($token === '') {
    echo json_encode(['ok' => false, 'message' => 'Empty QR token.']);
    exit;
}
$stmt = db()->prepare("SELECT s.id, s.branch_id, s.batch_id, s.admission_no, u.full_name FROM students s JOIN users u ON u.id=s.user_id WHERE s.qr_token = ? AND s.deleted_at IS NULL AND s.status='active' LIMIT 1");
$stmt->execute([$token]);
$st = $stmt->fetch();
if (!$st) {
    echo json_encode(['ok' => false, 'message' => 'Invalid or inactive student QR token.']);
    exit;
}
if ($user['role'] === 'staff') {
    assert_branch_access($user, (int)$st['branch_id']);
} elseif ($user['role'] === 'teacher') {
    assert_teacher_batch_access($user['id'], (int)$st['batch_id']);
}
db()->prepare("INSERT INTO attendance (branch_id, batch_id, student_id, att_date, status, mode, marked_by) VALUES (?, ?, ?, CURDATE(), 'present', 'qr', ?)
               ON DUPLICATE KEY UPDATE status = 'present', mode = 'qr', marked_by = VALUES(marked_by)")
    ->execute([$st['branch_id'], $st['batch_id'], $st['id'], $user['id']]);
audit_log('qr_attendance', 'students', (int)$st['id'], 'QR marked present for ' . $st['admission_no']);
echo json_encode(['ok' => true, 'message' => 'Marked Present: ' . $st['full_name'] . ' (' . $st['admission_no'] . ')']);
