<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/fee_helpers.php';
send_security_headers();
$user = require_role('staff');
$pdo = db();
$brId = (int)$user['branch_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $act = $_POST['act'] ?? '';
    if ($act === 'add_inquiry') {
        $pdo->prepare("INSERT INTO inquiries (branch_id, name, phone, email, course_interest, source, status, follow_up_date, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, 'new', ?, ?, ?)")
            ->execute([$brId, trim($_POST['name']), trim($_POST['phone']), trim($_POST['email'] ?? ''), trim($_POST['course_interest']), trim($_POST['source'] ?? 'Walk-in'), !empty($_POST['follow_up_date'])?$_POST['follow_up_date']:null, trim($_POST['notes'] ?? ''), $user['id']]);
        flash_set('success', 'Walk-in inquiry recorded.');
    } elseif ($act === 'add_student') {
        $fullName = trim($_POST['full_name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $courseId = (int)$_POST['course_id'];
        $batchId = (int)$_POST['batch_id'];
        $sessId = current_academic_session_id();
        $pass = 'Yuitor@1234';
        try {
            $pdo->beginTransaction();
            $pdo->prepare("INSERT INTO users (branch_id, role, full_name, email, phone, password_hash, is_active) VALUES (?, 'student', ?, ?, ?, ?, 1)")
                ->execute([$brId, $fullName, $email, $phone, password_hash($pass, PASSWORD_DEFAULT)]);
            $uId = (int)$pdo->lastInsertId();
            $bSt = $pdo->prepare("SELECT code FROM branches WHERE id = ?"); $bSt->execute([$brId]); $bCode = (string)($bSt->fetchColumn() ?: 'YS01');
            $admNo = $bCode . '-ADM-' . date('y') . '-' . sprintf('%04d', random_int(100, 9999));
            $qr = bin2hex(random_bytes(16));
            $pdo->prepare("INSERT INTO students (user_id, branch_id, session_id, course_id, batch_id, admission_no, father_name, guardian_phone, qr_token, admission_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), 'active')")
                ->execute([$uId, $brId, $sessId, $courseId, $batchId, $admNo, trim($_POST['father_name'] ?? ''), $phone, $qr]);
            $stId = (int)$pdo->lastInsertId();
            $pdo->commit();
            if ((float)$_POST['total_fee'] > 0) {
                allocate_student_fee_account($stId, $brId, $sessId, (float)$_POST['total_fee'], 0, 'Staff Admission', 3);
            }
            $loginUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? 'yuitor.com') . erp_url('index.php');
            send_welcome_email($email, $fullName, 'student', $loginUrl, $pass);
            flash_set('success', "Student admitted ({$admNo}).");
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('Admissions error: ' . $e->getMessage());
            flash_set('error', 'Could not complete admission. Please check details or contact admin.');
        }
    }
    redirect_to('operations/admissions.php');
}

$courses = $pdo->query("SELECT id, title FROM courses WHERE deleted_at IS NULL")->fetchAll();
$bQ = $pdo->prepare("SELECT id, name FROM batches WHERE branch_id = ? AND deleted_at IS NULL"); $bQ->execute([$brId]); $batches = $bQ->fetchAll();
$iQ = $pdo->prepare("SELECT * FROM inquiries WHERE branch_id = ? AND deleted_at IS NULL ORDER BY id DESC LIMIT 30"); $iQ->execute([$brId]); $inquiries = $iQ->fetchAll();

$pageTitle = 'Branch Inquiries & Admissions';
$showPanelSidebar = true;
$portalMode = 'admin';
$pageNoIndex = true;
include __DIR__ . '/../includes/site_header.php';
include __DIR__ . '/../includes/panel_nav.php';
?>
<div class="yu-page-head"><div><h1>Branch Inquiries &amp; New Admissions</h1></div></div>
<div class="yu-grid-2">
  <div class="yu-card">
    <div class="yu-card-title">Log Walk-in Inquiry</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="add_inquiry">
      <div class="yu-form-row">
        <div class="yu-field"><label>Student Name</label><input type="text" name="name" required></div>
        <div class="yu-field"><label>Phone</label><input type="text" name="phone" required></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Course Interest</label><input type="text" name="course_interest" placeholder="Class 10 / JEE / NEET"></div>
        <div class="yu-field"><label>Follow-up Date</label><input type="date" name="follow_up_date"></div>
      </div>
      <div class="yu-field" style="margin-bottom:10px;"><label>Notes</label><input type="text" name="notes"></div>
      <button class="yu-btn yu-btn-primary yu-btn-sm" type="submit">Save Inquiry</button>
    </form>
  </div>

  <div class="yu-card">
    <div class="yu-card-title">New Branch Admission</div>
    <form method="post">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="add_student">
      <div class="yu-form-row">
        <div class="yu-field"><label>Full Name</label><input type="text" name="full_name" required></div>
        <div class="yu-field"><label>Email</label><input type="email" name="email" required></div>
        <div class="yu-field"><label>Phone</label><input type="text" name="phone" required></div>
      </div>
      <div class="yu-form-row">
        <div class="yu-field"><label>Course</label><select name="course_id"><?php foreach($courses as $c): ?><option value="<?php echo (int)$c['id']; ?>"><?php echo e($c['title']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Branch Batch</label><select name="batch_id"><?php foreach($batches as $ba): ?><option value="<?php echo (int)$ba['id']; ?>"><?php echo e($ba['name']); ?></option><?php endforeach; ?></select></div>
        <div class="yu-field"><label>Total Fee (Rs.)</label><input type="number" name="total_fee" value="18000"></div>
      </div>
      <button class="yu-btn yu-btn-teal yu-btn-sm" type="submit">Admit Student</button>
    </form>
  </div>
</div>

<div class="yu-card">
  <div class="yu-card-title">Recent Branch Inquiries</div>
  <div class="yu-table-wrap"><table class="yu-table">
    <tr><th>Name</th><th>Phone</th><th>Course</th><th>Follow-up</th><th>Status</th><th>Notes</th></tr>
    <?php foreach($inquiries as $inq): ?>
      <tr><td><strong><?php echo e($inq['name']); ?></strong></td><td><?php echo e($inq['phone']); ?></td><td><?php echo e($inq['course_interest']); ?></td><td><?php echo e($inq['follow_up_date'] ?: '-'); ?></td><td><?php echo e(ucfirst($inq['status'])); ?></td><td><?php echo e($inq['notes']); ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include __DIR__ . '/../includes/site_footer.php'; ?>
