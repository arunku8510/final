<?php
// Yuitor Coaching ERP - Utility Helpers

function erp_base_url() {
    return '/erp';
}

function erp_url($path = '') {
    $path = ltrim((string)$path, '/');
    return $path === '' ? '/erp/' : '/erp/' . $path;
}

function redirect_to($path) {
    if (strpos($path, 'http://') === 0 || strpos($path, 'https://') === 0 || strpos($path, '/') === 0) {
        $url = $path;
    } else {
        $url = erp_url($path);
    }
    header('Location: ' . $url);
    exit;
}

function flash_set($type, $message) {
    start_secure_session();
    $_SESSION['flash'] = ['type' => $type, 'msg' => $message];
}

function flash_get() {
    start_secure_session();
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

function render_flash() {
    $f = flash_get();
    if (!$f) return '';
    $type = $f['type'] ?? 'info';
    $cls = 'yu-alert-info';
    if ($type === 'success') $cls = 'yu-alert-success';
    elseif ($type === 'error' || $type === 'danger') $cls = 'yu-alert-danger';
    elseif ($type === 'warning') $cls = 'yu-alert-warning';
    return '<div class="yu-alert ' . $cls . '" role="alert">' . e($f['msg']) . '</div>';
}

function mask_phone($phone) {
    $digits = preg_replace('/\D+/', '', (string)$phone);
    $len = strlen($digits);
    if ($len < 4) return '******';
    return substr($digits, 0, 2) . str_repeat('X', max(4, $len - 4)) . substr($digits, -2);
}

function mask_email($email) {
    $email = (string)$email;
    $pos = strpos($email, '@');
    if ($pos === false || $pos < 1) return '***@***';
    $local = substr($email, 0, $pos);
    $domain = substr($email, $pos);
    $show = strlen($local) >= 2 ? substr($local, 0, 2) : substr($local, 0, 1);
    return $show . str_repeat('*', max(3, strlen($local) - strlen($show))) . $domain;
}

function format_inr($amount) {
    return 'Rs. ' . number_format((float)$amount, 2);
}

function safe_upload($fileArray, $subFolder, $allowedMimes, $maxBytes = 5242880) {
    if (!isset($fileArray['error']) || $fileArray['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => false, 'path' => '', 'error' => 'No file uploaded.'];
    }
    if ($fileArray['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'path' => '', 'error' => 'Upload failed with code ' . (int)$fileArray['error']];
    }
    if ((int)$fileArray['size'] > $maxBytes) {
        return ['ok' => false, 'path' => '', 'error' => 'File exceeds maximum allowed size (' . round($maxBytes / 1048576, 1) . ' MB).'];
    }
    $tmp = $fileArray['tmp_name'];
    if (!is_uploaded_file($tmp)) {
        return ['ok' => false, 'path' => '', 'error' => 'Invalid upload source.'];
    }
    $mime = '';
    if (function_exists('finfo_open')) {
        $fi = finfo_open(FILEINFO_MIME_TYPE);
        $mime = (string)finfo_file($fi, $tmp);
        finfo_close($fi);
    } elseif (function_exists('mime_content_type')) {
        $mime = (string)mime_content_type($tmp);
    }
    if (!isset($allowedMimes[$mime])) {
        return ['ok' => false, 'path' => '', 'error' => 'Unsupported or unsafe file type (' . $mime . ').'];
    }
    $ext = $allowedMimes[$mime];
    $cleanFolder = preg_replace('/[^a-zA-Z0-9_-]/', '', $subFolder);
    $destDir = __DIR__ . '/../uploads/' . $cleanFolder;
    if (!is_dir($destDir)) {
        mkdir($destDir, 0755, true);
    }
    $newName = date('Ymd_His') . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $destPath = $destDir . '/' . $newName;
    if (!move_uploaded_file($tmp, $destPath)) {
        return ['ok' => false, 'path' => '', 'error' => 'Unable to store uploaded file.'];
    }
    return ['ok' => true, 'path' => 'uploads/' . $cleanFolder . '/' . $newName, 'error' => ''];
}

function csv_download_headers($filename) {
    $safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $safe . '"');
    echo "\xEF\xBB\xBF";
}

function current_academic_session_id() {
    $id = db()->query("SELECT id FROM academic_sessions WHERE is_current = 1 ORDER BY id DESC LIMIT 1")->fetchColumn();
    if (!$id) {
        $id = db()->query("SELECT id FROM academic_sessions ORDER BY id DESC LIMIT 1")->fetchColumn();
    }
    return (int)$id;
}

function is_active_nav($needle) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    return strpos($uri, $needle) !== false;
}

function role_home($role) {
    switch ($role) {
        case 'admin': return 'admin/dashboard.php';
        case 'teacher': return 'teacher/dashboard.php';
        case 'student': return 'student/dashboard.php';
        case 'parent': return 'parent/dashboard.php';
        case 'staff': return 'operations/dashboard.php';
        default: return 'index.php';
    }
}
