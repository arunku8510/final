<?php
$instName = function_exists('get_setting') ? get_setting('institute_name', 'Yuitor Smart Classes') : 'Yuitor Smart Classes';
$portalModeSafe = isset($portalMode) ? $portalMode : 'public';
?>
  </div><!-- /.yuitor-erp-layout -->
</main>

<footer class="yu-erp-footer">
  <div class="yu-container yu-erp-footer-inner">
    <span>&copy; <?php echo date('Y'); ?> <?php echo e($instName); ?>.</span>
    <nav class="yu-erp-footer-links" aria-label="Portal Footer Links">
      <a href="/">Main Website</a>
      <?php if ($portalModeSafe !== 'admin'): ?>
        <a href="/student/login.php">Student Login</a>
        <a href="/teacher/login.php">Teacher Login</a>
      <?php endif; ?>
      <a href="/privacy">Privacy</a>
      <a href="/terms">Terms</a>
    </nav>
  </div>
</footer>

<script>
(function(){
  var openBtn = document.getElementById('yuMobileOpenBtn');
  var closeBtn = document.getElementById('yuMobileCloseBtn');
  var drawer = document.getElementById('yuMobileDrawer');
  if (openBtn && drawer) {
    openBtn.addEventListener('click', function(){ drawer.classList.add('is-open'); drawer.setAttribute('aria-hidden','false'); });
  }
  if (closeBtn && drawer) {
    closeBtn.addEventListener('click', function(){ drawer.classList.remove('is-open'); drawer.setAttribute('aria-hidden','true'); });
  }
  document.querySelectorAll('[data-yu-toggle-pass]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var id = btn.getAttribute('data-yu-toggle-pass');
      var inp = document.getElementById(id);
      if (!inp) return;
      var show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      btn.setAttribute('aria-pressed', show ? 'true' : 'false');
      btn.style.color = show ? '#2563eb' : '';
    });
  });
})();
</script>
</body>
</html>
