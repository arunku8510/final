<?php
// Yuitor Coaching ERP - Branded Email Theme & Authenticated SMTP Delivery (.env + Admin Settings)
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

function yu_admin_notify_email() {
    $envNotify = yu_env('ADMIN_NOTIFY_EMAIL', '');
    if ($envNotify !== '' && filter_var($envNotify, FILTER_VALIDATE_EMAIL)) {
        return $envNotify;
    }
    $settingNotify = get_setting('admin_2fa_email', '');
    if ($settingNotify !== '' && strtolower($settingNotify) !== 'demo@example.com' && filter_var($settingNotify, FILTER_VALIDATE_EMAIL)) {
        return $settingNotify;
    }
    return YU_ADMIN_NOTIFY_EMAIL;
}

function build_yuitor_email_html($recipientName, $subject, $bodyHtml, $ctaText = '', $ctaUrl = '', $footerNote = '') {
    $origin = yu_site_url();

    $instName = get_setting('institute_name', 'Yuitor Smart Classes');
    $instPhone = get_setting('institute_phone', YU_DEMO_PHONE);
    $instEmail = yu_normalize_sender_email(get_setting('institute_email', YU_INSTITUTE_EMAIL));
    $instAddr = get_setting('institute_address', YU_DEMO_ADDRESS);
    $logoRel = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
    $logoUrl = (strpos($logoRel, 'http') === 0) ? $logoRel : ($origin . $logoRel);

    $greet = trim((string) $recipientName) !== '' ? ('Dear ' . e($recipientName) . ',') : 'Hello,';
    $ctaBlock = '';
    if ($ctaText !== '' && $ctaUrl !== '') {
        $ctaBlock = '<div style="margin:26px 0 18px;"><a href="' . e($ctaUrl) . '" style="display:inline-block;background:#2563eb;color:#ffffff;font-weight:700;text-decoration:none;padding:12px 24px;border-radius:10px;font-size:15px;">' . e($ctaText) . '</a></div>';
    }
    $noteBlock = $footerNote !== '' ? '<p style="margin:18px 0 0;font-size:12.5px;color:#557184;">' . e($footerNote) . '</p>' : '';

    return '<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>' . e($subject) . '</title></head>
<body style="margin:0;padding:0;background:#f5f9fc;font-family:\'DM Sans\',Arial,Helvetica,sans-serif;color:#0f172a;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f5f9fc;padding:28px 12px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#ffffff;border:1px solid #dbe6ef;border-radius:16px;overflow:hidden;">
      <tr>
        <td style="background:#0f172a;padding:22px 28px;">
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="56" valign="middle">
                <img src="' . e($logoUrl) . '" alt="' . e($instName) . '" width="46" height="46" style="display:block;border-radius:50%;background:#ffffff;padding:3px;">
              </td>
              <td valign="middle" style="padding-left:12px;">
                <div style="color:#ffffff;font-size:20px;font-weight:800;letter-spacing:-0.02em;">' . e($instName) . '</div>
                <div style="color:#78d3d3;font-size:12px;letter-spacing:0.08em;text-transform:uppercase;">AI-Assisted · Expert-Led Learning</div>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 28px 24px;font-size:15px;line-height:1.65;color:#344b5e;">
          <p style="margin:0 0 14px;font-size:16px;font-weight:700;color:#0f172a;">' . $greet . '</p>
          ' . $bodyHtml . '
          ' . $ctaBlock . '
          ' . $noteBlock . '
        </td>
      </tr>
      <tr>
        <td style="background:#edf5fa;border-top:1px solid #dbe6ef;padding:18px 28px;font-size:12.5px;color:#557184;">
          <strong style="color:#0f172a;">' . e($instName) . '</strong><br>
          ' . e($instAddr) . '<br>
          Phone: ' . e($instPhone) . ' | Official Mail: ' . e($instEmail) . '
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>';
}

function yu_html_to_plain_text($html) {
    $text = preg_replace('/<br\s*\/?>/i', "\n", (string) $html);
    $text = preg_replace('/<\/(p|div|tr|li|h[1-6])>/i', "\n", $text);
    $text = strip_tags($text);
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = preg_replace("/\n{3,}/", "\n\n", $text);
    return trim($text);
}

function smtp_read_line($fp) {
    $data = '';
    while (($str = fgets($fp, 1024)) !== false) {
        $data .= $str;
        if (strlen($str) < 4 || substr($str, 3, 1) === ' ') {
            break;
        }
    }
    return $data;
}

function smtp_cmd($fp, $cmd, $expectedCodePrefix = '2') {
    if ($cmd !== null) {
        fwrite($fp, $cmd . "\r\n");
    }
    $resp = smtp_read_line($fp);
    $ok = strlen($resp) > 0 && substr($resp, 0, strlen($expectedCodePrefix)) === $expectedCodePrefix;
    return [$ok, $resp];
}

function yu_resolve_smtp_config() {
    $rawFrom = yu_env('MAIL_FROM_EMAIL', get_setting('mail_from_email', YU_MAIL_FROM_EMAIL));
    $fromEmail = yu_normalize_sender_email($rawFrom);
    $fromName = trim(str_replace(["\r", "\n", '"'], '', yu_env('MAIL_FROM_NAME', get_setting('mail_from_name', YU_MAIL_FROM_NAME))));
    if ($fromName === '') {
        $fromName = 'Yuitor Smart Classes';
    }

    $smtpHost = trim(yu_env('SMTP_HOST', yu_env('YU_SMTP_HOST', get_setting('smtp_host', 'mail.yuitor.com'))));
    $smtpPort = (int) yu_env('SMTP_PORT', yu_env('YU_SMTP_PORT', get_setting('smtp_port', '465')));
    $smtpUser = trim(yu_env('SMTP_USER', yu_env('YU_SMTP_USERNAME', get_setting('smtp_user', $fromEmail))));
    if (strtolower($smtpUser) === 'demo@example.com') {
        $smtpUser = $fromEmail;
    }
    $smtpPass = yu_env('SMTP_PASS', yu_env('YU_SMTP_PASSWORD', get_setting('smtp_pass', '')));
    $smtpSecure = strtolower(trim(yu_env('SMTP_SECURE', yu_env('YU_SMTP_ENCRYPTION', get_setting('smtp_secure', 'ssl')))));

    if ($smtpPort <= 0 || $smtpPort > 65535) {
        $smtpPort = 465;
    }
    if (!in_array($smtpSecure, ['tls', 'ssl', 'none'], true)) {
        $smtpSecure = $smtpPort === 465 ? 'ssl' : 'tls';
    }

    return [
        'from_email'  => $fromEmail,
        'from_name'   => $fromName,
        'smtp_host'   => $smtpHost,
        'smtp_port'   => $smtpPort,
        'smtp_user'   => $smtpUser,
        'smtp_pass'   => $smtpPass,
        'smtp_secure' => $smtpSecure,
    ];
}

function send_branded_email($toEmail, $toName, $subject, $bodyHtml, $ctaText = '', $ctaUrl = '', $footerNote = '') {
    $toEmail = trim((string) $toEmail);
    $toName = str_replace(["\r", "\n", '"'], '', (string) $toName);
    $subject = str_replace(["\r", "\n"], ' ', (string) $subject);

    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => 'Invalid recipient email address.'];
    }

    $cfg = yu_resolve_smtp_config();
    $fromEmail = $cfg['from_email'];
    $fromName = $cfg['from_name'];

    $html = build_yuitor_email_html($toName, $subject, $bodyHtml, $ctaText, $ctaUrl, $footerNote);
    $plain = yu_html_to_plain_text(($toName !== '' ? "Dear {$toName},\n\n" : '') . $bodyHtml . ($ctaUrl !== '' ? "\n\n{$ctaText}: {$ctaUrl}" : '') . "\n\n--\n{$fromName} (" . $fromEmail . ")");

    $boundary = '=_yuitor_' . bin2hex(random_bytes(10));
    $domainHost = preg_replace('/[^a-zA-Z0-9.-]/', '', YU_MAIL_DOMAIN) ?: 'example.com';
    $messageId = '<' . bin2hex(random_bytes(12)) . '@' . $domainHost . '>';
    $encodedFromName = '=?UTF-8?B?' . base64_encode($fromName) . '?=';
    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $toHeader = $toName !== '' ? ('=?UTF-8?B?' . base64_encode($toName) . '?= <' . $toEmail . '>') : '<' . $toEmail . '>';

    $mimeBody = "--{$boundary}\r\n"
        . "Content-Type: text/plain; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: base64\r\n\r\n"
        . chunk_split(base64_encode($plain), 76, "\r\n") . "\r\n"
        . "--{$boundary}\r\n"
        . "Content-Type: text/html; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: base64\r\n\r\n"
        . chunk_split(base64_encode($html), 76, "\r\n") . "\r\n"
        . "--{$boundary}--\r\n";

    $smtpHost = $cfg['smtp_host'];
    $smtpPort = $cfg['smtp_port'];
    $smtpUser = $cfg['smtp_user'];
    $smtpPass = $cfg['smtp_pass'];
    $smtpSecure = $cfg['smtp_secure'];

    if ($smtpHost !== '' && !yu_is_placeholder_value($smtpHost)) {
        $isLocalTestHost = in_array(strtolower($smtpHost), ['127.0.0.1', 'localhost', '::1'], true);
        $attempts = [
            ['port' => $smtpPort, 'secure' => $smtpSecure, 'strict' => !$isLocalTestHost],
        ];
        if (!$isLocalTestHost) {
            $altPort = ($smtpPort === 465) ? 587 : 465;
            $altSec = ($altPort === 465) ? 'ssl' : 'tls';
            $attempts[] = ['port' => $smtpPort, 'secure' => $smtpSecure, 'strict' => false];
            $attempts[] = ['port' => $altPort, 'secure' => $altSec, 'strict' => true];
            $attempts[] = ['port' => $altPort, 'secure' => $altSec, 'strict' => false];
        }

        foreach ($attempts as $att) {
            try {
                $remote = ($att['secure'] === 'ssl' ? 'ssl://' : 'tcp://') . $smtpHost . ':' . $att['port'];
                $ctx = stream_context_create([
                    'ssl' => [
                        'verify_peer'      => $att['strict'],
                        'verify_peer_name' => $att['strict'],
                        'allow_self_signed'=> !$att['strict'],
                        'peer_name'        => $smtpHost,
                        'SNI_enabled'      => true,
                    ],
                ]);
                $fp = @stream_socket_client($remote, $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $ctx);
                if (!$fp) {
                    error_log("SMTP connect error ({$smtpHost}:{$att['port']} {$att['secure']}): ({$errno}) {$errstr}");
                    continue;
                }
                stream_set_timeout($fp, 12);
                smtp_read_line($fp);
                smtp_cmd($fp, 'EHLO ' . $domainHost, '2');

                if ($att['secure'] === 'tls') {
                    list($okTls,) = smtp_cmd($fp, 'STARTTLS', '2');
                    if ($okTls) {
                        @stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
                        smtp_cmd($fp, 'EHLO ' . $domainHost, '2');
                    }
                }

                if ($smtpUser !== '' && $smtpPass !== '') {
                    smtp_cmd($fp, 'AUTH LOGIN', '3');
                    smtp_cmd($fp, base64_encode($smtpUser), '3');
                    list($okAuth, $authResp) = smtp_cmd($fp, base64_encode($smtpPass), '2');
                    if (!$okAuth) {
                        fclose($fp);
                        error_log('SMTP Auth failed: ' . trim($authResp));
                        return ['ok' => false, 'error' => 'SMTP authentication failed. Check email password in .env.'];
                    }
                } elseif (!$isLocalTestHost) {
                    fclose($fp);
                    return ['ok' => false, 'error' => 'SMTP credentials are required for remote hosts.'];
                }

                list($okMf, $mfResp) = smtp_cmd($fp, 'MAIL FROM:<' . $fromEmail . '>', '2');
                if (!$okMf) {
                    fclose($fp);
                    error_log('SMTP MAIL FROM failed: ' . trim($mfResp));
                    return ['ok' => false, 'error' => 'SMTP rejected sender address.'];
                }
                list($okRt, $rtResp) = smtp_cmd($fp, 'RCPT TO:<' . $toEmail . '>', '2');
                if (!$okRt) {
                    fclose($fp);
                    error_log('SMTP RCPT TO failed: ' . trim($rtResp));
                    return ['ok' => false, 'error' => 'SMTP rejected recipient address.'];
                }
                smtp_cmd($fp, 'DATA', '3');

                $headers = "Date: " . gmdate('D, d M Y H:i:s') . " +0000\r\n"
                    . "From: {$encodedFromName} <{$fromEmail}>\r\n"
                    . "Sender: {$fromEmail}\r\n"
                    . "Return-Path: <{$fromEmail}>\r\n"
                    . "Reply-To: {$fromEmail}\r\n"
                    . "To: {$toHeader}\r\n"
                    . "Subject: {$encodedSubject}\r\n"
                    . "Message-ID: {$messageId}\r\n"
                    . "MIME-Version: 1.0\r\n"
                    . "X-Auto-Response-Suppress: OOF, AutoReply\r\n"
                    . "Content-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n\r\n";

                $payload = $headers . $mimeBody . "\r\n.";
                list($okData, $dataResp) = smtp_cmd($fp, $payload, '2');
                smtp_cmd($fp, 'QUIT', '2');
                fclose($fp);
                if ($okData) {
                    return ['ok' => true, 'error' => '', 'sender' => $fromEmail];
                }
                error_log('SMTP Send failed: ' . trim($dataResp));
            } catch (Throwable $e) {
                error_log('SMTP exception: ' . $e->getMessage());
            }
        }
    }

    $headers = "From: {$encodedFromName} <{$fromEmail}>\r\n"
        . "Sender: {$fromEmail}\r\n"
        . "Return-Path: <{$fromEmail}>\r\n"
        . "Reply-To: {$fromEmail}\r\n"
        . "Message-ID: {$messageId}\r\n"
        . "MIME-Version: 1.0\r\n"
        . "Content-Type: multipart/alternative; boundary=\"{$boundary}\"";
    $sent = @mail($toEmail, $encodedSubject, $mimeBody, $headers, '-f ' . $fromEmail);
    return [
        'ok'     => (bool) $sent,
        'error'  => $sent ? '' : 'Mail transport failed. Configure SMTP credentials in .env or Admin Settings.',
        'sender' => $fromEmail,
    ];
}

function send_admin_notification_email($subject, $bodyHtml, $ctaText = '', $ctaUrl = '') {
    $to = yu_admin_notify_email();
    return send_branded_email($to, 'Academic Admin', $subject, $bodyHtml, $ctaText, $ctaUrl);
}

function send_welcome_email($toEmail, $toName, $role, $loginUrl, $plainPassword = '') {
    $roleLabel = ucfirst(trim((string) $role));
    $credsHtml = '';
    if (trim((string) $plainPassword) !== '') {
        $credsHtml = '<div style="margin:16px 0;padding:14px;background:#edf5fa;border:1px solid #cfe0eb;border-radius:10px;font-size:14px;">'
            . '<strong>Portal Login Details:</strong><br>'
            . 'Email: <code>' . e($toEmail) . '</code><br>'
            . 'Temporary Password: <code>' . e($plainPassword) . '</code><br>'
            . '<span style="font-size:12px;color:#557184;">Please change your password after signing in.</span>'
            . '</div>';
    }
    $body = '<p>Welcome to <strong>Yuitor Smart Classes ERP</strong>! Your <strong>' . e($roleLabel) . '</strong> portal account has been created and activated.</p>'
        . $credsHtml
        . '<p>Use the button below to sign in to your dashboard.</p>';
    return send_branded_email($toEmail, $toName, 'Welcome to Yuitor Smart Classes ERP (' . $roleLabel . ' Portal)', $body, 'Sign In to Portal', $loginUrl);
}

function send_fee_email($toEmail, $toName, $subject, $bodyHtml, $pdfUrl = '') {
    return send_branded_email(
        $toEmail,
        $toName,
        $subject,
        $bodyHtml,
        $pdfUrl !== '' ? 'Download Fee Receipt PDF' : '',
        $pdfUrl
    );
}

function send_otp_email($toEmail, $toName, $otpCode) {
    $body = '<p>Use the 6-digit verification code below to complete your Admin sign-in on <strong>Yuitor Smart Classes ERP</strong>:</p>
    <div style="margin:20px 0;padding:18px;background:#edf5fa;border:1px solid #cfe0eb;border-radius:12px;text-align:center;">
      <div style="font-size:12px;color:#557184;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;">6-Digit Security OTP</div>
      <div style="font-size:32px;font-weight:800;letter-spacing:8px;color:#0f172a;margin-top:6px;">' . e($otpCode) . '</div>
    </div>
    <p>This OTP is valid for <strong>10 minutes</strong>. Never share this code with anyone.</p>';
    return send_branded_email($toEmail, $toName, 'Your 6-Digit Admin Login OTP - Yuitor ERP', $body, '', '', 'Requested from IP: ' . client_ip());
}

function send_forgot_password_email($toEmail, $toName, $otpCode, $resetUrl) {
    $body = '<p>We received a request to reset your Yuitor ERP password. Enter the 6-digit verification code below:</p>
    <div style="margin:18px 0;padding:16px;background:#edf5fa;border:1px solid #cfe0eb;border-radius:12px;text-align:center;">
      <div style="font-size:12px;color:#557184;text-transform:uppercase;letter-spacing:1.2px;font-weight:700;">Password Reset Code</div>
      <div style="font-size:28px;font-weight:800;letter-spacing:6px;color:#2563eb;margin-top:6px;">' . e($otpCode) . '</div>
    </div>
    <p>This code expires in <strong>15 minutes</strong>. If you did not request this, you can safely ignore this message.</p>';
    return send_branded_email($toEmail, $toName, 'Reset Your Password - Yuitor Smart Classes', $body, 'Open Password Reset Page', $resetUrl);
}

function send_student_verification_email($toEmail, $toName, $otpCode, $verifyUrl) {
    $body = '<p>Welcome to <strong>Yuitor Smart Classes</strong>! Please verify your email address using the 6-digit code below:</p>
    <div style="margin:18px 0;padding:16px;background:#edf5fa;border:1px solid #cfe0eb;border-radius:12px;text-align:center;">
      <div style="font-size:12px;color:#557184;text-transform:uppercase;letter-spacing:1.2px;font-weight:700;">Email Verification Code</div>
      <div style="font-size:30px;font-weight:800;letter-spacing:7px;color:#0b7b82;margin-top:6px;">' . e($otpCode) . '</div>
    </div>
    <p>After verifying your email, our admissions counsellor will review and activate your student dashboard.</p>';
    return send_branded_email($toEmail, $toName, 'Verify Your Email & Welcome - Yuitor Smart Classes', $body, 'Verify Student Email', $verifyUrl);
}

function send_student_welcome_email($toEmail, $toName, $classGrade, $loginUrl) {
    $body = '<p>Congratulations! Your student portal account at <strong>Yuitor Smart Classes</strong> is now active for <strong>' . e($classGrade) . '</strong>.</p>
    <p>You can sign in anytime to view attendance, study materials, test marks, QR ID card, and fee schedule.</p>';
    return send_branded_email($toEmail, $toName, 'Student Portal Activated - Welcome to Yuitor Smart Classes', $body, 'Sign In to Student Portal', $loginUrl);
}

function send_teacher_application_email($toEmail, $toName, $subjectSpecialty) {
    $body = '<p>Thank you for applying for a Faculty position (<strong>' . e($subjectSpecialty) . '</strong>) at <strong>Yuitor Smart Classes</strong>.</p>
    <p>Our academic committee has received your application and will reach out after reviewing your profile.</p>';
    return send_branded_email($toEmail, $toName, 'Faculty Application Received - Yuitor Smart Classes', $body);
}
