<?php
// Yuitor Smart Classes ERP - Distraction-Free Portal Header & Scoped Shell Styles
require_once __DIR__ . '/icons.php';
if (!isset($pageTitle)) $pageTitle = 'Yuitor Smart Classes';
if (!isset($portalMode)) $portalMode = 'public';
$instName = function_exists('get_setting') ? get_setting('institute_name', 'Yuitor Smart Classes') : 'Yuitor Smart Classes';
$instLogo = function_exists('get_setting') ? get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png') : '/erp/assets/images/yuitor-smart-classes-logo.png';
$currentUser = function_exists('current_user') ? current_user() : null;
$reqPath = parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?: '';
$isRegisterPage = strpos($reqPath, '/student/register.php') !== false;
$isTeacherRegPage = strpos($reqPath, '/teacher/register.php') !== false;
$isAdminArea = ($portalMode === 'admin') || ($currentUser && in_array($currentUser['role'], ['admin', 'staff'], true));
$brandHref = $currentUser ? erp_url(role_home($currentUser['role'])) : '/';
$roleLabels = [
    'admin'   => 'Operations Console',
    'staff'   => 'Operations Desk',
    'teacher' => 'Faculty Portal',
    'student' => 'Student Portal',
    'parent'  => 'Parent Portal',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($pageTitle); ?> | <?php echo e($instName); ?></title>
  <?php if (!empty($pageNoIndex)): ?><meta name="robots" content="noindex, nofollow, noarchive"><?php endif; ?>
  <meta name="description" content="<?php echo e($instName); ?> — Academic &amp; Admissions Portal.">
  <meta property="og:title" content="<?php echo e($pageTitle); ?> | <?php echo e($instName); ?>">
  <meta property="og:image" content="/erp/assets/images/opengraph-yuitor.jpg">
  <link rel="icon" type="image/png" sizes="192x192" href="/erp/assets/images/yuitor-icon-192.png">
  <link rel="icon" type="image/svg+xml" href="/erp/assets/images/favicon.svg">
  <link rel="shortcut icon" href="/erp/assets/images/favicon.ico">
  <link rel="apple-touch-icon" href="/erp/assets/images/yuitor-icon-192.png">
  <link rel="manifest" href="/erp/manifest.json">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700;1,9..40,400..700&family=Manrope:wght@600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --brand-blue: #2563eb;
      --brand-blue-deep: #1d4ed8;
      --brand-teal: #12a1a1;
      --brand-deep-teal: #0b7b82;
      --brand-navy: #0f172a;
      --brand-paper: #f8fafc;
      --brand-white: #ffffff;
      --brand-copy: #334155;
      --brand-muted: #64748b;
      --brand-line: #e2e8f0;
    }
    *, *::before, *::after { box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      font-family: "DM Sans", -apple-system, BlinkMacSystemFont, sans-serif;
      background: var(--brand-paper);
      color: var(--brand-navy);
      font-size: 15px;
      line-height: 1.6;
      -webkit-font-smoothing: antialiased;
    }
    a { color: inherit; }
    img { max-width: 100%; }

    /* ===== Clean 3-Zone ERP Header (Zero Marketing Clutter) ===== */
    .yu-erp-header {
      position: sticky;
      top: 0;
      z-index: 50;
      background: rgba(255, 255, 255, 0.96);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--brand-line);
    }
    .yu-container {
      width: 100%;
      max-width: 1320px;
      margin: 0 auto;
      padding: 0 18px;
    }
    @media (min-width: 1024px) {
      .yu-container { padding: 0 28px; }
    }
    .yu-navbar-inner {
      height: 64px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    @media (min-width: 900px) {
      .yu-navbar-inner { gap: 24px; }
    }
    .yu-brand-link {
      display: inline-flex;
      align-items: center;
      gap: 9px;
      text-decoration: none;
      flex-shrink: 1;
      min-width: 0;
    }
    .yu-brand-logo-box {
      width: 34px;
      height: 34px;
      border-radius: 50%;
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      padding: 2px;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      flex-shrink: 0;
    }
    .yu-brand-logo-box img { width: 100%; height: 100%; object-fit: contain; display: block; border-radius: 50%; }
    .yu-brand-name {
      font-family: "Manrope", "DM Sans", sans-serif;
      font-size: 15px;
      font-weight: 800;
      letter-spacing: -0.02em;
      color: var(--brand-navy);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    @media (min-width: 480px) {
      .yu-brand-logo-box { width: 38px; height: 38px; }
      .yu-brand-name { font-size: 17px; }
    }

    .yu-erp-nav {
      display: none;
      align-items: center;
      gap: 24px;
      font-size: 14px;
      font-weight: 600;
      color: var(--brand-copy);
    }
    .yu-erp-nav a {
      text-decoration: none;
      padding: 6px 2px;
      white-space: nowrap;
      border-bottom: 2px solid transparent;
      transition: color .15s ease, border-color .15s ease;
    }
    .yu-erp-nav a:hover {
      color: var(--brand-blue);
      border-bottom-color: rgba(37, 99, 235, 0.35);
    }
    .yu-erp-nav a.is-current {
      color: var(--brand-blue-deep);
      border-bottom-color: var(--brand-blue);
    }
    .yu-workspace-label {
      font-size: 13px;
      font-weight: 700;
      color: var(--brand-muted);
      white-space: nowrap;
    }

    .yu-erp-actions {
      display: none;
      align-items: center;
      gap: 12px;
      flex-shrink: 0;
    }
    .yu-cta-primary {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      background: var(--brand-blue);
      color: #ffffff;
      padding: 9px 18px;
      border-radius: 9px;
      font-size: 13.5px;
      font-weight: 700;
      text-decoration: none;
      white-space: nowrap;
      transition: background-color .15s ease, transform .15s ease;
    }
    .yu-cta-primary:hover { background: var(--brand-blue-deep); }
    .yu-cta-outline {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      border: 1px solid #cbd5e1;
      background: #ffffff;
      color: var(--brand-navy);
      padding: 8px 15px;
      border-radius: 9px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      white-space: nowrap;
      transition: border-color .15s ease, background-color .15s ease, color .15s ease;
    }
    .yu-cta-outline:hover { border-color: var(--brand-blue); color: var(--brand-blue-deep); background: #f8fafc; }

    .yu-mobile-actions { display: flex; align-items: center; gap: 10px; margin-left: auto; }
    .yu-hamburger {
      width: 40px;
      height: 40px;
      border-radius: 9px;
      border: 1px solid #cbd5e1;
      background: #ffffff;
      color: var(--brand-navy);
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    @media (min-width: 900px) {
      .yu-erp-nav { display: flex; }
      .yu-erp-actions { display: flex; }
      .yu-mobile-actions { display: none; }
    }

    /* Clean Mobile Drawer */
    .yu-mobile-menu {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 90;
      background: #ffffff;
      overflow-y: auto;
    }
    .yu-mobile-menu.is-open { display: block; }

    /* ===== Minimal 1-Row ERP Footer ===== */
    footer.yu-erp-footer {
      margin-top: auto;
      border-top: 1px solid var(--brand-line);
      background: #ffffff;
      color: var(--brand-muted);
      font-size: 13px;
      padding: 18px 0;
    }
    .yu-erp-footer-inner {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .yu-erp-footer-links {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 16px;
    }
    .yu-erp-footer-links a {
      text-decoration: none;
      color: var(--brand-copy);
      font-weight: 500;
      transition: color .15s ease;
    }
    .yu-erp-footer-links a:hover { color: var(--brand-blue); }

    /* ===== Scoped ERP Panel Styles (.yuitor-erp-shell) ===== */
    .yuitor-erp-shell {
      flex: 1 0 auto;
      padding: 28px 18px 44px;
    }
    .yuitor-erp-layout {
      max-width: 1320px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 1fr;
      gap: 24px;
      align-items: start;
    }
    @media (min-width: 1024px) {
      .yuitor-erp-shell { padding: 34px 28px 56px; }
      .yuitor-erp-layout.has-sidebar { grid-template-columns: 260px minmax(0, 1fr); }
    }
    .yu-sidebar {
      background: #ffffff;
      border: 1px solid var(--brand-line);
      border-radius: 14px;
      padding: 16px;
      box-shadow: 0 4px 18px rgba(15, 23, 42, 0.04);
    }
    .yu-sidebar-user {
      padding: 12px 14px;
      border-radius: 10px;
      background: #f1f5f9;
      border: 1px solid #e2e8f0;
      margin-bottom: 14px;
    }
    .yu-sidebar-role {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.04em;
      color: var(--brand-deep-teal);
    }
    .yu-sidebar-name {
      font-family: "Manrope", sans-serif;
      font-size: 15px;
      font-weight: 700;
      color: var(--brand-navy);
      margin: 2px 0;
    }
    .yu-side-nav { display: flex; flex-direction: column; gap: 4px; }
    .yu-side-link {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 9px 12px;
      border-radius: 9px;
      text-decoration: none;
      font-size: 13.5px;
      font-weight: 600;
      color: var(--brand-copy);
      transition: all .15s ease;
    }
    .yu-side-link-main {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      min-width: 0;
    }
    .yu-side-link-ico {
      width: 28px;
      height: 28px;
      border-radius: 8px;
      background: #f1f5f9;
      color: var(--brand-deep-teal);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .yu-side-link:hover { background: #f1f5f9; color: var(--brand-blue-deep); }
    .yu-side-link:hover .yu-side-link-ico { background: #e0ecfb; color: var(--brand-blue-deep); }
    .yu-side-link.active {
      background: var(--brand-blue);
      color: #ffffff;
    }
    .yu-side-link.active .yu-side-link-ico {
      background: rgba(255,255,255,0.18);
      color: #ffffff;
    }
    .yu-main-content { min-width: 0; }
    .yu-page-head {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 20px;
    }
    .yu-page-head h1 {
      margin: 0;
      font-family: "Manrope", sans-serif;
      font-size: clamp(22px, 2.2vw, 28px);
      font-weight: 800;
      color: var(--brand-navy);
      letter-spacing: -0.02em;
    }
    .yu-page-head p { margin: 2px 0 0; font-size: 13.5px; color: var(--brand-muted); }

    .yu-card {
      background: #ffffff;
      border: 1px solid var(--brand-line);
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 8px 28px rgba(15, 23, 42, 0.04);
      margin-bottom: 20px;
    }
    .yu-card-title {
      margin: 0 0 14px;
      font-family: "Manrope", sans-serif;
      font-size: 16.5px;
      font-weight: 700;
      color: var(--brand-navy);
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .yu-kpi-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(195px, 1fr));
      gap: 14px;
      margin-bottom: 20px;
    }
    .yu-kpi {
      background: #ffffff;
      border: 1px solid var(--brand-line);
      border-radius: 14px;
      padding: 16px 18px;
    }
    .yu-kpi-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }
    .yu-kpi-ico {
      width: 34px;
      height: 34px;
      border-radius: 10px;
      background: #eff6ff;
      color: var(--brand-blue-deep);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .yu-kpi-ico.teal {
      background: #ecfeff;
      color: var(--brand-deep-teal);
    }
    .yu-kpi-label { font-size: 12.5px; font-weight: 600; color: var(--brand-muted); }
    .yu-kpi-val {
      font-family: "Manrope", sans-serif;
      font-size: 24px;
      font-weight: 800;
      color: var(--brand-navy);
      margin-top: 4px;
      font-variant-numeric: tabular-nums;
    }
    .yu-kpi-sub { font-size: 12px; color: var(--brand-deep-teal); margin-top: 2px; }

    .yu-grid-2 { display: grid; grid-template-columns: 1fr; gap: 18px; }
    .yu-grid-3 { display: grid; grid-template-columns: 1fr; gap: 14px; }
    @media (min-width: 768px) {
      .yu-grid-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .yu-grid-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
    }

    .yu-form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 14px; margin-bottom: 14px; }
    .yu-field label {
      display: block;
      font-size: 13px;
      font-weight: 600;
      color: var(--brand-copy);
      margin-bottom: 6px;
    }
    .yu-field input, .yu-field select, .yu-field textarea {
      width: 100%;
      min-height: 42px;
      padding: 10px 13px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      background: #ffffff;
      color: var(--brand-navy);
      font: inherit;
      font-size: 14.5px;
      transition: border-color .15s ease, box-shadow .15s ease;
    }
    .yu-field input:focus, .yu-field select:focus, .yu-field textarea:focus {
      outline: none;
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.16);
      border-color: var(--brand-blue);
    }
    .yu-pass-wrap {
      position: relative;
      display: flex;
      align-items: center;
    }
    .yu-pass-wrap input {
      padding-right: 46px;
    }
    .yu-pass-toggle {
      position: absolute;
      right: 8px;
      top: 50%;
      transform: translateY(-50%);
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 7px;
      background: transparent;
      color: var(--brand-muted);
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .yu-pass-toggle:hover { color: var(--brand-navy); background: #f1f5f9; }

    .yu-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 7px;
      min-height: 42px;
      padding: 10px 18px;
      border-radius: 10px;
      border: 1px solid transparent;
      font: inherit;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      white-space: nowrap;
      transition: all .16s ease;
    }
    .yu-btn-primary {
      background: var(--brand-blue);
      color: #ffffff;
    }
    .yu-btn-primary:hover { background: var(--brand-blue-deep); }
    .yu-btn-teal { background: var(--brand-deep-teal); color: #ffffff; }
    .yu-btn-teal:hover { background: #09656b; }
    .yu-btn-outline { background: #ffffff; border-color: #cbd5e1; color: var(--brand-navy); }
    .yu-btn-outline:hover { background: #f8fafc; border-color: var(--brand-blue); color: var(--brand-blue-deep); }
    .yu-btn-danger { background: #dc2626; color: #ffffff; }
    .yu-btn-sm { min-height: 34px; padding: 6px 12px; font-size: 12.5px; border-radius: 8px; }

    .yu-table-wrap { width: 100%; overflow-x: auto; border: 1px solid var(--brand-line); border-radius: 12px; }
    table.yu-table { width: 100%; border-collapse: collapse; font-size: 13.5px; background: #ffffff; }
    table.yu-table th {
      background: #f1f5f9;
      color: var(--brand-navy);
      text-align: left;
      padding: 10px 12px;
      font-weight: 700;
      border-bottom: 1px solid var(--brand-line);
      white-space: nowrap;
    }
    table.yu-table td {
      padding: 10px 12px;
      border-bottom: 1px solid #f1f5f9;
      color: var(--brand-copy);
      vertical-align: middle;
    }
    table.yu-table tbody tr:hover { background: #f8fafc; }
    .num { text-align: right; font-variant-numeric: tabular-nums; }

    .yu-alert {
      padding: 12px 15px;
      border-radius: 10px;
      margin-bottom: 16px;
      font-size: 13.5px;
      font-weight: 600;
      border: 1px solid;
    }
    .yu-alert-success { background: #ecfdf5; border-color: #a7f3d0; color: #065f46; }
    .yu-alert-danger { background: #fef2f2; border-color: #fecaca; color: #991b1b; }
    .yu-alert-warning { background: #fffbeb; border-color: #fde68a; color: #92400e; }
    .yu-alert-info { background: #eff6ff; border-color: #bfdbfe; color: #1e40af; }

    .yu-status-text { font-weight: 700; font-size: 12.5px; }
    .st-ok { color: #15803d; }
    .st-warn { color: #b45309; }
    .st-bad { color: #b91c1c; }
    .st-muted { color: #64748b; }
  </style>
</head>
<body>
<header class="yu-erp-header">
  <div class="yu-container yu-navbar-inner">
    <a href="<?php echo e($brandHref); ?>" class="yu-brand-link" aria-label="<?php echo e($instName); ?>">
      <span class="yu-brand-logo-box"><img src="<?php echo e($instLogo); ?>" alt=""></span>
      <span class="yu-brand-name"><?php echo e($instName); ?></span>
    </a>

    <nav class="yu-erp-nav" aria-label="Portal Navigation">
      <?php if ($currentUser): ?>
        <span class="yu-workspace-label"><?php echo e($roleLabels[$currentUser['role']] ?? 'Workspace'); ?></span>
        <a href="<?php echo e(erp_url(role_home($currentUser['role']))); ?>">Dashboard</a>
        <?php if (!$isAdminArea): ?>
          <a href="/">Main Website</a>
        <?php endif; ?>
      <?php elseif ($portalMode === 'admin'): ?>
        <span class="yu-workspace-label">Restricted Operations Console</span>
      <?php else: ?>
        <a href="/">Main Website</a>
        <a href="/student/login.php" class="<?php echo $portalMode === 'student' && !$isRegisterPage ? 'is-current' : ''; ?>">Student Login</a>
        <a href="/student/register.php" class="<?php echo $isRegisterPage ? 'is-current' : ''; ?>">New Admission</a>
        <a href="<?php echo e(erp_url('admission-test/index.php')); ?>" class="<?php echo strpos($reqPath, '/admission-test/') !== false ? 'is-current' : ''; ?>">Scholarship Test</a>
      <?php endif; ?>
    </nav>

    <div class="yu-erp-actions">
      <?php if ($currentUser): ?>
        <span style="font-size:13px;color:var(--brand-muted);font-weight:600;"><?php echo e($currentUser['full_name']); ?></span>
        <a href="<?php echo e(erp_url('logout.php')); ?>" class="yu-cta-outline"><?php echo yu_icon('logout', 14); ?> Sign Out</a>
      <?php elseif ($portalMode === 'admin'): ?>
        <a href="/" class="yu-cta-outline">Website Home</a>
      <?php elseif ($portalMode === 'teacher'): ?>
        <?php if ($isTeacherRegPage): ?>
          <a href="/teacher/login.php" class="yu-cta-primary">Teacher Sign In</a>
        <?php else: ?>
          <a href="/teacher/register.php" class="yu-cta-primary">Apply as Teacher</a>
        <?php endif; ?>
      <?php elseif ($isRegisterPage): ?>
        <a href="/student/login.php" class="yu-cta-outline">Student Sign In</a>
      <?php else: ?>
        <a href="/student/register.php" class="yu-cta-primary">Apply for Admission &rarr;</a>
      <?php endif; ?>
    </div>

    <div class="yu-mobile-actions">
      <?php if ($currentUser): ?>
        <a href="<?php echo e(erp_url('logout.php')); ?>" class="yu-cta-outline" style="padding:6px 12px;font-size:12.5px;">Sign Out</a>
      <?php elseif ($portalMode !== 'admin'): ?>
        <a href="/student/register.php" class="yu-cta-primary" style="padding:7px 12px;font-size:12.5px;">Admission</a>
      <?php endif; ?>
      <button type="button" class="yu-hamburger" id="yuMobileOpenBtn" aria-label="Open menu">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 5h16"/><path d="M4 12h16"/><path d="M4 19h16"/></svg>
      </button>
    </div>
  </div>
</header>

<div class="yu-mobile-menu" id="yuMobileDrawer" aria-hidden="true">
  <div style="padding:14px 18px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;">
    <span style="font-family:'Manrope',sans-serif;font-weight:800;font-size:16px;"><?php echo e($instName); ?></span>
    <button type="button" id="yuMobileCloseBtn" style="background:#f1f5f9;border:0;color:#0f172a;border-radius:8px;padding:7px 12px;font-weight:700;cursor:pointer;">Close</button>
  </div>
  <div style="padding:16px;display:flex;flex-direction:column;gap:8px;">
    <?php if ($currentUser): ?>
      <a href="<?php echo e(erp_url(role_home($currentUser['role']))); ?>" style="padding:12px 14px;border-radius:10px;background:#eff6ff;font-weight:700;text-decoration:none;color:#1d4ed8;">Dashboard</a>
      <a href="/" style="padding:12px 14px;border-radius:10px;text-decoration:none;">Main Website</a>
      <a href="<?php echo e(erp_url('logout.php')); ?>" style="padding:12px 14px;border-radius:10px;background:#fef2f2;color:#b91c1c;font-weight:700;text-decoration:none;">Sign Out</a>
    <?php elseif ($portalMode === 'admin'): ?>
      <a href="/" style="padding:12px 14px;border-radius:10px;background:#f8fafc;font-weight:600;text-decoration:none;">Return to Website</a>
    <?php else: ?>
      <a href="/student/register.php" style="padding:12px 14px;border-radius:10px;background:#2563eb;color:#ffffff;font-weight:700;text-decoration:none;">Apply for New Admission</a>
      <a href="/student/login.php" style="padding:12px 14px;border-radius:10px;background:#f1f5f9;font-weight:700;text-decoration:none;">Student Sign In</a>
      <a href="<?php echo e(erp_url('admission-test/index.php')); ?>" style="padding:12px 14px;border-radius:10px;text-decoration:none;">Scholarship Test</a>
      <a href="/teacher/login.php" style="padding:12px 14px;border-radius:10px;text-decoration:none;">Teacher Login</a>
      <a href="/" style="padding:12px 14px;border-radius:10px;text-decoration:none;">Main Website</a>
    <?php endif; ?>
  </div>
</div>

<main class="yuitor-erp-shell">
  <div class="yuitor-erp-layout <?php echo !empty($showPanelSidebar) ? 'has-sidebar' : ''; ?>">
