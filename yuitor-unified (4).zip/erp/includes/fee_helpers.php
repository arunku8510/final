<?php
// Yuitor Coaching ERP - Fee Ledger, Installments, UPI Verification & Receipt Helpers
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/mail_theme.php';

function recalculate_fee_account($feeAccountId) {
    $feeAccountId = (int)$feeAccountId;
    $st = db()->prepare("SELECT COALESCE(SUM(amount),0) FROM fee_payments WHERE fee_account_id = ? AND status = 'verified'");
    $st->execute([$feeAccountId]);
    $paidSum = (float)$st->fetchColumn();

    db()->prepare("UPDATE student_fee_accounts SET paid_amount = ? WHERE id = ?")->execute([$paidSum, $feeAccountId]);

    $insts = db()->prepare("SELECT * FROM fee_installments WHERE fee_account_id = ? ORDER BY installment_no ASC, id ASC");
    $insts->execute([$feeAccountId]);
    $rem = $paidSum;
    $today = date('Y-m-d');
    foreach ($insts->fetchAll() as $ins) {
        $due = (float)$ins['amount'] + (float)$ins['late_fee'];
        $alloc = min($due, max(0, $rem));
        $rem -= $alloc;
        if ($alloc >= $due - 0.01) {
            $status = 'paid';
        } elseif ($alloc > 0.01) {
            $status = 'partial';
        } elseif ($ins['due_date'] < $today) {
            $status = 'overdue';
        } else {
            $status = 'pending';
        }
        db()->prepare("UPDATE fee_installments SET paid_amount = ?, status = ? WHERE id = ?")
            ->execute([$alloc, $status, (int)$ins['id']]);
    }
}

function allocate_student_fee_account($studentId, $branchId, $sessionId, $grossAmount, $discountAmount = 0, $discountReason = '', $installmentsCount = 3) {
    $gross = max(0, (float)$grossAmount);
    $disc = max(0, min($gross, (float)$discountAmount));
    $net = $gross - $disc;
    $installmentsCount = max(1, min(12, (int)$installmentsCount));

    $chk = db()->prepare("SELECT id FROM student_fee_accounts WHERE student_id = ? AND session_id = ? LIMIT 1");
    $chk->execute([(int)$studentId, (int)$sessionId]);
    $accId = (int)$chk->fetchColumn();

    if ($accId) {
        db()->prepare("UPDATE student_fee_accounts SET gross_amount = ?, discount_amount = ?, discount_reason = ?, net_amount = ? WHERE id = ?")
            ->execute([$gross, $disc, $discountReason, $net, $accId]);
        db()->prepare("DELETE FROM fee_installments WHERE fee_account_id = ? AND paid_amount = 0")->execute([$accId]);
    } else {
        db()->prepare("INSERT INTO student_fee_accounts (student_id, branch_id, session_id, gross_amount, discount_amount, discount_reason, net_amount, paid_amount) VALUES (?, ?, ?, ?, ?, ?, ?, 0)")
            ->execute([(int)$studentId, (int)$branchId, (int)$sessionId, $gross, $disc, $discountReason, $net]);
        $accId = (int)db()->lastInsertId();
    }

    $existingInst = (int)db()->query("SELECT COUNT(*) FROM fee_installments WHERE fee_account_id = " . $accId)->fetchColumn();
    if ($existingInst === 0) {
        $per = round($net / $installmentsCount, 2);
        $assigned = 0.0;
        for ($i = 1; $i <= $installmentsCount; $i++) {
            $amt = ($i === $installmentsCount) ? round($net - $assigned, 2) : $per;
            $assigned += $amt;
            $dueDate = date('Y-m-d', strtotime('+' . (($i - 1) * 30) . ' days'));
            db()->prepare("INSERT INTO fee_installments (fee_account_id, student_id, installment_no, title, due_date, amount, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')")
                ->execute([$accId, (int)$studentId, $i, 'Installment #' . $i, $dueDate, $amt]);
        }
    }
    recalculate_fee_account($accId);
    return $accId;
}

function record_fee_payment($params) {
    $pdo = db();
    $studentId = (int)$params['student_id'];
    $branchId = (int)$params['branch_id'];
    $accId = (int)$params['fee_account_id'];
    $instId = !empty($params['installment_id']) ? (int)$params['installment_id'] : null;
    $amount = round((float)$params['amount'], 2);
    $mode = $params['payment_mode'] ?? 'upi';
    $upiUsed = trim((string)($params['upi_id_used'] ?? ''));
    $utr = trim((string)($params['utr_number'] ?? ''));
    $proofPath = (string)($params['proof_path'] ?? '');
    $status = $params['status'] ?? 'verified';
    $remarks = trim((string)($params['remarks'] ?? ''));
    $collectedBy = !empty($params['collected_by']) ? (int)$params['collected_by'] : null;

    if ($amount <= 0) {
        return ['ok' => false, 'error' => 'Amount must be greater than zero.'];
    }
    if ($utr !== '') {
        $dup = $pdo->prepare("SELECT id FROM fee_payments WHERE utr_number = ? LIMIT 1");
        $dup->execute([$utr]);
        if ($dup->fetchColumn()) {
            return ['ok' => false, 'error' => 'Duplicate UTR / Transaction reference already submitted!'];
        }
    } else {
        $utr = null;
    }

    $bStmt = $pdo->prepare("SELECT code FROM branches WHERE id = ?");
    $bStmt->execute([$branchId]);
    $branchCode = (string)($bStmt->fetchColumn() ?: get_setting('receipt_prefix', 'YS01'));

    $pdo->beginTransaction();
    try {
        $receiptNo = next_receipt_no($branchCode);
        $verifiedBy = $status === 'verified' ? $collectedBy : null;
        $verifiedAt = $status === 'verified' ? date('Y-m-d H:i:s') : null;
        $pdo->prepare("INSERT INTO fee_payments (branch_id, student_id, fee_account_id, installment_id, receipt_no, amount, payment_mode, upi_id_used, utr_number, proof_path, status, remarks, collected_by, verified_by, verified_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$branchId, $studentId, $accId, $instId, $receiptNo, $amount, $mode, $upiUsed, $utr, $proofPath, $status, $remarks, $collectedBy, $verifiedBy, $verifiedAt]);
        $payId = (int)$pdo->lastInsertId();
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        error_log('Fee payment error: ' . $e->getMessage());
        return ['ok' => false, 'error' => 'Could not save payment. Please try again.'];
    }

    if ($status === 'verified') {
        recalculate_fee_account($accId);
        notify_payment_confirmed($payId);
    }
    audit_log('fee_payment_' . $status, 'fee_payments', $payId, "Receipt {$receiptNo} Amount {$amount}");
    return ['ok' => true, 'payment_id' => $payId, 'receipt_no' => $receiptNo];
}

function notify_payment_confirmed($paymentId) {
    $stmt = db()->prepare("SELECT fp.*, u.full_name, u.email FROM fee_payments fp
                           JOIN students s ON s.id = fp.student_id
                           JOIN users u ON u.id = s.user_id
                           WHERE fp.id = ?");
    $stmt->execute([(int)$paymentId]);
    $p = $stmt->fetch();
    if (!$p || empty($p['email'])) return;
    $body = '<p>Your fee payment has been verified and recorded in Yuitor Smart Classes ERP.</p>
    <table style="width:100%;border-collapse:collapse;margin:14px 0;font-size:14px;">
      <tr><td style="padding:8px;border:1px solid #dbe6ef;background:#f5f9fc;"><strong>Receipt No</strong></td><td style="padding:8px;border:1px solid #dbe6ef;">' . e($p['receipt_no']) . '</td></tr>
      <tr><td style="padding:8px;border:1px solid #dbe6ef;background:#f5f9fc;"><strong>Amount Paid</strong></td><td style="padding:8px;border:1px solid #dbe6ef;">Rs. ' . number_format((float)$p['amount'], 2) . '</td></tr>
      <tr><td style="padding:8px;border:1px solid #dbe6ef;background:#f5f9fc;"><strong>Mode</strong></td><td style="padding:8px;border:1px solid #dbe6ef;">' . e(strtoupper($p['payment_mode'])) . '</td></tr>
    </table>';
    $pdfUrl = yu_site_url() . erp_url('student/receipt_pdf.php?id=' . (int)$p['id']);
    send_fee_email($p['email'], $p['full_name'], 'Fee Receipt ' . $p['receipt_no'] . ' - Payment Confirmed', $body, $pdfUrl);
}
