<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/mail_theme.php';

function current_user() {
    start_secure_session();
    if (empty($_SESSION['user_id'])) return null;
    static $cached = null;
    if ($cached !== null && (int) $cached['id'] === (int) $_SESSION['user_id']) {
        return $cached;
    }
    $stmt = db()->prepare("SELECT id, branch_id, role, full_name, email, phone, is_active, twofa_enabled FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1");
    $stmt->execute([(int) $_SESSION['user_id']]);
    $u = $stmt->fetch();
    if (!$u || (int) $u['is_active'] !== 1) {
        $_SESSION = [];
        session_destroy();
        return null;
    }
    $cached = $u;
    return $u;
}

function portal_login_url_for_roles($allowedRoles) {
    if (!is_array($allowedRoles)) $allowedRoles = [$allowedRoles];
    if (in_array('teacher', $allowedRoles, true) && count($allowedRoles) === 1) {
        return '/teacher/login.php';
    }
    if (in_array('student', $allowedRoles, true) && !in_array('admin', $allowedRoles, true) && !in_array('staff', $allowedRoles, true)) {
        return '/student/login.php';
    }
    if (in_array('parent', $allowedRoles, true) && count($allowedRoles) === 1) {
        return '/erp/parent/login.php';
    }
    if (in_array('admin', $allowedRoles, true) || in_array('staff', $allowedRoles, true)) {
        return '';
    }
    return '';
}

function require_login($loginUrl = '/student/login.php') {
    $u = current_user();
    if (!$u) {
        if ($loginUrl === '') {
            send_noindex_headers();
            http_response_code(404);
            $code = 404;
            include __DIR__ . '/../error.php';
            exit;
        }
        flash_set('warning', 'Please sign in to continue.');
        redirect_to($loginUrl);
    }
    return $u;
}

function require_role($allowedRoles) {
    if (!is_array($allowedRoles)) $allowedRoles = [$allowedRoles];
    $u = current_user();
    $isAdminArea = in_array('admin', $allowedRoles, true) || in_array('staff', $allowedRoles, true);
    if ($isAdminArea) {
        send_noindex_headers();
    }
    if (!$u) {
        $targetLogin = portal_login_url_for_roles($allowedRoles);
        if ($targetLogin === '') {
            send_noindex_headers();
            http_response_code(404);
            $code = 404;
            include __DIR__ . '/../error.php';
            exit;
        }
        flash_set('warning', 'Please sign in to continue.');
        redirect_to($targetLogin);
    }
    if (!in_array($u['role'], $allowedRoles, true)) {
        http_response_code(403);
        $code = 403;
        include __DIR__ . '/../error.php';
        exit;
    }
    return $u;
}

function forbid_teacher_from_fees() {
    $u = require_login();
    if ($u['role'] === 'teacher') {
        http_response_code(403);
        $code = 403;
        include __DIR__ . '/../error.php';
        exit;
    }
}

function ensure_security_rate_limits_table(PDO $pdo): void {
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS `security_rate_limits` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `scope` VARCHAR(50) NOT NULL,
                `identifier` VARCHAR(190) NOT NULL,
                `hit_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_rate_scope_id_time` (`scope`, `identifier`, `hit_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {
        error_log('Rate limit table check warning: ' . $e->getMessage());
    }
}

function check_rate_limit(PDO $pdo, string $scope, string $identifier, int $maxHits = 5, int $windowMinutes = 15, bool $recordHit = true): bool {
    $mins = max(1, (int) $windowMinutes);
    $idTrim = substr((string) $identifier, 0, 190);
    try {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM security_rate_limits
             WHERE scope = ? AND identifier = ? AND hit_at >= DATE_SUB(NOW(), INTERVAL {$mins} MINUTE)"
        );
        $stmt->execute([$scope, $idTrim]);
        $count = (int) $stmt->fetchColumn();
        if ($count >= $maxHits) {
            return false;
        }
        if ($recordHit) {
            $pdo->prepare("INSERT INTO security_rate_limits (scope, identifier) VALUES (?, ?)")
                ->execute([$scope, $idTrim]);
        }
        return true;
    } catch (Throwable $e) {
        ensure_security_rate_limits_table($pdo);
        try {
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM security_rate_limits
                 WHERE scope = ? AND identifier = ? AND hit_at >= DATE_SUB(NOW(), INTERVAL {$mins} MINUTE)"
            );
            $stmt->execute([$scope, $idTrim]);
            $count = (int) $stmt->fetchColumn();
            if ($count >= $maxHits) {
                return false;
            }
            if ($recordHit) {
                $pdo->prepare("INSERT INTO security_rate_limits (scope, identifier) VALUES (?, ?)")
                    ->execute([$scope, $idTrim]);
            }
            return true;
        } catch (Throwable $ex) {
            error_log('Rate limit fallback error: ' . $ex->getMessage());
            return true;
        }
    }
}

function clear_rate_limit(PDO $pdo, string $scope, string $identifier): void {
    try {
        $pdo->prepare("DELETE FROM security_rate_limits WHERE scope = ? AND identifier = ?")
            ->execute([$scope, substr((string) $identifier, 0, 190)]);
    } catch (Throwable $e) {
        error_log('Clear rate limit warning: ' . $e->getMessage());
    }
}

function current_student_record($userId) {
    $stmt = db()->prepare("SELECT s.*, b.name AS branch_name, b.code AS branch_code, c.title AS course_title, ba.name AS batch_name
                           FROM students s
                           JOIN branches b ON b.id = s.branch_id
                           JOIN courses c ON c.id = s.course_id
                           JOIN batches ba ON ba.id = s.batch_id
                           WHERE s.user_id = ? AND s.deleted_at IS NULL LIMIT 1");
    $stmt->execute([(int) $userId]);
    return $stmt->fetch();
}

function teacher_assigned_batch_ids($teacherUserId) {
    $stmt = db()->prepare("SELECT batch_id FROM teacher_batches WHERE teacher_user_id = ?");
    $stmt->execute([(int) $teacherUserId]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

function assert_teacher_batch_access($teacherUserId, $batchId) {
    $allowed = teacher_assigned_batch_ids($teacherUserId);
    if (!in_array((int) $batchId, $allowed, true)) {
        http_response_code(403);
        die('Access Denied (403): This batch is not assigned to you.');
    }
}

function parent_linked_student_ids($parentUserId) {
    $stmt = db()->prepare("SELECT student_id FROM parent_students WHERE parent_user_id = ?");
    $stmt->execute([(int) $parentUserId]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

function assert_student_access($user, $studentId) {
    $studentId = (int) $studentId;
    if ($user['role'] === 'admin') return true;
    if ($user['role'] === 'staff') {
        $stmt = db()->prepare("SELECT branch_id FROM students WHERE id = ? AND deleted_at IS NULL");
        $stmt->execute([$studentId]);
        $br = $stmt->fetchColumn();
        if ($br && (int) $br === (int) $user['branch_id']) return true;
    } elseif ($user['role'] === 'student') {
        $st = current_student_record($user['id']);
        if ($st && (int) $st['id'] === $studentId) return true;
    } elseif ($user['role'] === 'parent') {
        if (in_array($studentId, parent_linked_student_ids($user['id']), true)) return true;
    } elseif ($user['role'] === 'teacher') {
        $stmt = db()->prepare("SELECT batch_id FROM students WHERE id = ? AND deleted_at IS NULL");
        $stmt->execute([$studentId]);
        $batchId = (int) $stmt->fetchColumn();
        if ($batchId && in_array($batchId, teacher_assigned_batch_ids($user['id']), true)) return true;
    }
    http_response_code(403);
    die('Access Denied (403): Unauthorized student record access.');
}

function assert_branch_access($user, $branchId) {
    if ($user['role'] === 'admin') return true;
    if ((int) $user['branch_id'] !== (int) $branchId) {
        http_response_code(403);
        die('Access Denied (403): Cross-branch access is restricted.');
    }
    return true;
}

function generate_6digit_otp($userId, $purpose = 'admin_2fa', $minutes = 10) {
    $code = sprintf('%06d', random_int(0, 999999));
    $hash = password_hash($code, PASSWORD_DEFAULT);
    $mins = max(1, min(1440, (int) $minutes));
    db()->prepare("UPDATE otp_tokens SET used_at = NOW() WHERE user_id = ? AND purpose = ? AND used_at IS NULL")
        ->execute([(int) $userId, $purpose]);
    db()->prepare("INSERT INTO otp_tokens (user_id, purpose, code_hash, expires_at, ip_address) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL {$mins} MINUTE), ?)")
        ->execute([(int) $userId, $purpose, $hash, client_ip()]);
    return $code;
}

function verify_6digit_otp($userId, $purpose, $code) {
    $code = trim((string) $code);
    if (!preg_match('/^\d{6}$/', $code)) return false;
    $stmt = db()->prepare("SELECT id, code_hash FROM otp_tokens WHERE user_id = ? AND purpose = ? AND used_at IS NULL AND expires_at >= NOW() ORDER BY id DESC LIMIT 1");
    $stmt->execute([(int) $userId, $purpose]);
    $row = $stmt->fetch();
    if (!$row) return false;
    if (!password_verify($code, $row['code_hash'])) return false;
    db()->prepare("UPDATE otp_tokens SET used_at = NOW() WHERE id = ?")->execute([(int) $row['id']]);
    return true;
}

function complete_user_login($user) {
    start_secure_session();
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['branch_id'] = $user['branch_id'] ? (int) $user['branch_id'] : 0;
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['_last_activity'] = time();
    db()->prepare("UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = NOW() WHERE id = ?")->execute([(int) $user['id']]);
    audit_log('login_success', 'users', (int) $user['id'], 'Role: ' . $user['role'], (int) $user['id']);
}
