<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
send_security_headers();

$channel = in_array($_GET['ch'] ?? 'email', ['email', 'sms', 'whatsapp'], true) ? $_GET['ch'] : 'email';
$contact = trim((string)($_GET['c'] ?? ''));
$done = false;
if ($contact !== '') {
    db()->prepare("INSERT IGNORE INTO message_unsubscribes (channel, contact) VALUES (?, ?)")->execute([$channel, $contact]);
    $done = true;
}
$pageTitle = 'Communication Preferences';
$showPanelSidebar = false;
include __DIR__ . '/includes/site_header.php';
?>
<div style="max-width:520px;margin:28px auto;">
  <div class="yu-card">
    <h1 style="margin:0 0 8px;font-family:'Manrope',sans-serif;">Unsubscribe Preference</h1>
    <?php if ($done): ?>
      <div class="yu-alert yu-alert-success">You have been opted out from <strong><?php echo e(strtoupper($channel)); ?></strong> promotional notifications for <code><?php echo e($contact); ?></code>.</div>
    <?php else: ?>
      <p>No valid contact parameter was provided.</p>
    <?php endif; ?>
    <a href="https://yuitor.com/" class="yu-btn yu-btn-outline">Return to Yuitor Smart Classes</a>
  </div>
</div>
<?php include __DIR__ . '/includes/site_footer.php'; ?>
