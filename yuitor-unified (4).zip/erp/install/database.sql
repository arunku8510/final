-- Yuitor Coaching ERP Database Schema (26 Tables, InnoDB, UTF8MB4)
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `branches` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(16) NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `city` VARCHAR(80) NOT NULL DEFAULT '',
  `address` TEXT NULL,
  `phone` VARCHAR(30) NOT NULL DEFAULT '',
  `email` VARCHAR(120) NOT NULL DEFAULT '',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_branch_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `academic_sessions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(40) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `is_current` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_session_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NULL DEFAULT NULL,
  `role` ENUM('admin','teacher','student','parent','staff') NOT NULL DEFAULT 'student',
  `full_name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(25) NOT NULL DEFAULT '',
  `password_hash` VARCHAR(255) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `twofa_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `failed_attempts` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` DATETIME NULL DEFAULT NULL,
  `last_login_at` DATETIME NULL DEFAULT NULL,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_email` (`email`),
  KEY `idx_user_role_branch` (`role`, `branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `courses` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(30) NOT NULL,
  `title` VARCHAR(140) NOT NULL,
  `category` VARCHAR(60) NOT NULL DEFAULT 'School',
  `duration_months` SMALLINT UNSIGNED NOT NULL DEFAULT 12,
  `default_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `description` TEXT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_course_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `batches` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NOT NULL,
  `session_id` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `timing` VARCHAR(80) NOT NULL DEFAULT '',
  `room_no` VARCHAR(40) NOT NULL DEFAULT '',
  `capacity` SMALLINT UNSIGNED NOT NULL DEFAULT 40,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_batch_branch_session` (`branch_id`, `session_id`),
  KEY `idx_batch_course` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `timetable` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `batch_id` INT UNSIGNED NOT NULL,
  `day_of_week` ENUM('Mon','Tue','Wed','Thu','Fri','Sat','Sun') NOT NULL,
  `start_time` VARCHAR(20) NOT NULL,
  `end_time` VARCHAR(20) NOT NULL,
  `subject` VARCHAR(100) NOT NULL,
  `teacher_id` INT UNSIGNED NULL DEFAULT NULL,
  `room` VARCHAR(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_tt_batch` (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `students` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `branch_id` INT UNSIGNED NOT NULL,
  `session_id` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `batch_id` INT UNSIGNED NOT NULL,
  `admission_no` VARCHAR(40) NOT NULL,
  `roll_no` VARCHAR(40) NOT NULL DEFAULT '',
  `dob` DATE NULL DEFAULT NULL,
  `gender` ENUM('Male','Female','Other') NOT NULL DEFAULT 'Male',
  `father_name` VARCHAR(120) NOT NULL DEFAULT '',
  `mother_name` VARCHAR(120) NOT NULL DEFAULT '',
  `guardian_phone` VARCHAR(25) NOT NULL DEFAULT '',
  `address` TEXT NULL,
  `photo_path` VARCHAR(255) NOT NULL DEFAULT '',
  `qr_token` VARCHAR(64) NOT NULL,
  `admission_date` DATE NOT NULL,
  `status` ENUM('active','transferred','completed','dropped') NOT NULL DEFAULT 'active',
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_student_user` (`user_id`),
  UNIQUE KEY `uk_student_adm` (`admission_no`),
  UNIQUE KEY `uk_student_qr` (`qr_token`),
  KEY `idx_student_branch_batch` (`branch_id`, `batch_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `student_transfers` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_id` INT UNSIGNED NOT NULL,
  `from_branch_id` INT UNSIGNED NOT NULL,
  `to_branch_id` INT UNSIGNED NOT NULL,
  `from_batch_id` INT UNSIGNED NOT NULL,
  `to_batch_id` INT UNSIGNED NOT NULL,
  `reason` VARCHAR(255) NOT NULL DEFAULT '',
  `transferred_by` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_transfer_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `parent_students` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `parent_user_id` INT UNSIGNED NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `relation` VARCHAR(40) NOT NULL DEFAULT 'Guardian',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_parent_student` (`parent_user_id`, `student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `teacher_batches` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `teacher_user_id` INT UNSIGNED NOT NULL,
  `batch_id` INT UNSIGNED NOT NULL,
  `subject` VARCHAR(100) NOT NULL DEFAULT 'All Subjects',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_teacher_batch` (`teacher_user_id`, `batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `inquiries` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(25) NOT NULL,
  `email` VARCHAR(150) NOT NULL DEFAULT '',
  `course_interest` VARCHAR(120) NOT NULL DEFAULT '',
  `source` VARCHAR(60) NOT NULL DEFAULT 'Walk-in',
  `status` ENUM('new','follow_up','demo_scheduled','converted','closed') NOT NULL DEFAULT 'new',
  `follow_up_date` DATE NULL DEFAULT NULL,
  `notes` TEXT NULL,
  `created_by` INT UNSIGNED NULL DEFAULT NULL,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inq_branch_status` (`branch_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `attendance` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NOT NULL,
  `batch_id` INT UNSIGNED NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `att_date` DATE NOT NULL,
  `status` ENUM('present','absent','late','leave') NOT NULL DEFAULT 'present',
  `mode` ENUM('manual','qr') NOT NULL DEFAULT 'manual',
  `remarks` VARCHAR(200) NOT NULL DEFAULT '',
  `marked_by` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_att_student_date` (`student_id`, `att_date`),
  KEY `idx_att_batch_date` (`batch_id`, `att_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `study_materials` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `batch_id` INT UNSIGNED NOT NULL,
  `uploaded_by` INT UNSIGNED NOT NULL,
  `title` VARCHAR(160) NOT NULL,
  `material_type` ENUM('notes','homework','video_link','syllabus') NOT NULL DEFAULT 'notes',
  `description` TEXT NULL,
  `file_path` VARCHAR(255) NOT NULL DEFAULT '',
  `external_url` VARCHAR(255) NOT NULL DEFAULT '',
  `due_date` DATE NULL DEFAULT NULL,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mat_batch` (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `assignment_submissions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `material_id` INT UNSIGNED NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `file_path` VARCHAR(255) NOT NULL DEFAULT '',
  `notes` TEXT NULL,
  `marks` DECIMAL(5,2) NULL DEFAULT NULL,
  `teacher_feedback` TEXT NULL,
  `graded_by` INT UNSIGNED NULL DEFAULT NULL,
  `submitted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sub_mat_student` (`material_id`, `student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `batch_tests` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `batch_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(160) NOT NULL,
  `subject` VARCHAR(100) NOT NULL DEFAULT 'General',
  `test_date` DATE NOT NULL,
  `max_marks` DECIMAL(6,2) NOT NULL DEFAULT 100.00,
  `created_by` INT UNSIGNED NOT NULL,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_bt_batch` (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `test_marks` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `test_id` INT UNSIGNED NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `marks_obtained` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `is_absent` TINYINT(1) NOT NULL DEFAULT 0,
  `remarks` VARCHAR(200) NOT NULL DEFAULT '',
  `updated_by` INT UNSIGNED NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tm_test_student` (`test_id`, `student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `notices` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NULL DEFAULT NULL,
  `batch_id` INT UNSIGNED NULL DEFAULT NULL,
  `title` VARCHAR(180) NOT NULL,
  `body` TEXT NOT NULL,
  `audience` ENUM('all','batch','teachers','students') NOT NULL DEFAULT 'all',
  `created_by` INT UNSIGNED NOT NULL,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fee_structures` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` INT UNSIGNED NOT NULL,
  `session_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(120) NOT NULL,
  `total_amount` DECIMAL(10,2) NOT NULL,
  `installments_count` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `late_fee_per_day` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `student_fee_accounts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_id` INT UNSIGNED NOT NULL,
  `branch_id` INT UNSIGNED NOT NULL,
  `session_id` INT UNSIGNED NOT NULL,
  `gross_amount` DECIMAL(10,2) NOT NULL,
  `discount_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `discount_reason` VARCHAR(160) NOT NULL DEFAULT '',
  `net_amount` DECIMAL(10,2) NOT NULL,
  `paid_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sfa_student_session` (`student_id`, `session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fee_installments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fee_account_id` INT UNSIGNED NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `installment_no` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `title` VARCHAR(100) NOT NULL,
  `due_date` DATE NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `late_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `paid_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `status` ENUM('pending','partial','paid','overdue') NOT NULL DEFAULT 'pending',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inst_student_status` (`student_id`, `status`, `due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fee_payments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `fee_account_id` INT UNSIGNED NOT NULL,
  `installment_id` INT UNSIGNED NULL DEFAULT NULL,
  `receipt_no` VARCHAR(40) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_mode` ENUM('cash','upi','bank_transfer','card','gateway') NOT NULL DEFAULT 'upi',
  `upi_id_used` VARCHAR(120) NOT NULL DEFAULT '',
  `utr_number` VARCHAR(80) NULL DEFAULT NULL,
  `proof_path` VARCHAR(255) NOT NULL DEFAULT '',
  `status` ENUM('pending_verification','verified','rejected','reversed') NOT NULL DEFAULT 'verified',
  `remarks` VARCHAR(255) NOT NULL DEFAULT '',
  `collected_by` INT UNSIGNED NULL DEFAULT NULL,
  `verified_by` INT UNSIGNED NULL DEFAULT NULL,
  `verified_at` DATETIME NULL DEFAULT NULL,
  `paid_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_receipt_no` (`receipt_no`),
  UNIQUE KEY `uk_utr_unique` (`utr_number`),
  KEY `idx_fp_student_status` (`student_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `change_requests` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NOT NULL,
  `requested_by` INT UNSIGNED NOT NULL,
  `target_table` VARCHAR(60) NOT NULL,
  `target_id` INT UNSIGNED NOT NULL,
  `action_type` ENUM('update','delete') NOT NULL DEFAULT 'update',
  `summary` VARCHAR(255) NOT NULL,
  `payload_json` MEDIUMTEXT NOT NULL,
  `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reviewed_by` INT UNSIGNED NULL DEFAULT NULL,
  `admin_remark` VARCHAR(255) NOT NULL DEFAULT '',
  `reviewed_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cr_status_branch` (`status`, `branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `admission_tests` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(160) NOT NULL,
  `course_label` VARCHAR(120) NOT NULL DEFAULT '',
  `duration_minutes` SMALLINT UNSIGNED NOT NULL DEFAULT 30,
  `total_marks` SMALLINT UNSIGNED NOT NULL DEFAULT 100,
  `pass_percentage` DECIMAL(5,2) NOT NULL DEFAULT 40.00,
  `scholarship_slab_json` TEXT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_by` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `admission_test_questions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `test_id` INT UNSIGNED NOT NULL,
  `question_text` TEXT NOT NULL,
  `option_a` VARCHAR(255) NOT NULL,
  `option_b` VARCHAR(255) NOT NULL,
  `option_c` VARCHAR(255) NOT NULL,
  `option_d` VARCHAR(255) NOT NULL,
  `correct_option` ENUM('A','B','C','D') NOT NULL,
  `marks` TINYINT UNSIGNED NOT NULL DEFAULT 4,
  PRIMARY KEY (`id`),
  KEY `idx_atq_test` (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `admission_test_attempts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `test_id` INT UNSIGNED NOT NULL,
  `branch_id` INT UNSIGNED NOT NULL,
  `candidate_code` VARCHAR(32) NOT NULL,
  `full_name` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(25) NOT NULL,
  `email` VARCHAR(150) NOT NULL DEFAULT '',
  `target_class` VARCHAR(60) NOT NULL DEFAULT '',
  `answers_json` MEDIUMTEXT NULL,
  `score` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `max_score` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `percentage` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `scholarship_pct` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('in_progress','completed') NOT NULL DEFAULT 'in_progress',
  `started_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `submitted_at` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ata_code` (`candidate_code`),
  KEY `idx_ata_test` (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `message_queue` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `channel` ENUM('email','sms','whatsapp') NOT NULL,
  `recipient` VARCHAR(180) NOT NULL,
  `recipient_name` VARCHAR(120) NOT NULL DEFAULT '',
  `subject` VARCHAR(200) NOT NULL DEFAULT '',
  `body` MEDIUMTEXT NOT NULL,
  `template_id` VARCHAR(80) NOT NULL DEFAULT '',
  `status` ENUM('pending','sent','failed','skipped') NOT NULL DEFAULT 'pending',
  `attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `error_message` VARCHAR(255) NOT NULL DEFAULT '',
  `scheduled_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sent_at` DATETIME NULL DEFAULT NULL,
  `created_by` INT UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mq_status_sched` (`status`, `scheduled_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `message_unsubscribes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `channel` ENUM('email','sms','whatsapp') NOT NULL DEFAULT 'email',
  `contact` VARCHAR(180) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_unsub` (`channel`, `contact`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `otp_tokens` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `purpose` ENUM('admin_2fa','password_reset') NOT NULL DEFAULT 'admin_2fa',
  `code_hash` VARCHAR(255) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `used_at` DATETIME NULL DEFAULT NULL,
  `ip_address` VARCHAR(64) NOT NULL DEFAULT '',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_otp_user_purpose` (`user_id`, `purpose`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `settings` (
  `setting_key` VARCHAR(80) NOT NULL,
  `setting_value` MEDIUMTEXT NULL,
  `is_encrypted` TINYINT(1) NOT NULL DEFAULT 0,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NULL DEFAULT NULL,
  `action` VARCHAR(80) NOT NULL,
  `entity_type` VARCHAR(60) NOT NULL DEFAULT '',
  `entity_id` INT UNSIGNED NULL DEFAULT NULL,
  `details` TEXT NULL,
  `ip_address` VARCHAR(64) NOT NULL DEFAULT '',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- Safe Initial Seed Data (INSERT IGNORE prevents errors on re-run)
INSERT IGNORE INTO `branches` (`id`, `code`, `name`, `city`, `address`, `phone`, `email`, `is_active`)
VALUES (1, 'YS01', 'Muradnagar Main Centre', 'Muradnagar', 'Demo Campus, Main Road, Smart City - 100001', '9999999999', 'no-reply@yuitor.com', 1);

INSERT IGNORE INTO `academic_sessions` (`id`, `name`, `start_date`, `end_date`, `is_current`)
VALUES (1, '2026-27', '2026-04-01', '2027-03-31', 1);

INSERT IGNORE INTO `courses` (`id`, `code`, `title`, `category`, `duration_months`, `default_fee`, `description`, `is_active`)
VALUES
(1, 'CLS-10', 'Class 9 & 10 Foundation (CBSE/UP)', 'School', 12, 18000.00, 'Maths, Science, English & Social Science with AI-assisted practice tests.', 1),
(2, 'JEE-26', 'IIT-JEE & Class 11-12 PCM', 'Competitive', 12, 36000.00, 'Physics, Chemistry & Mathematics expert-led JEE Main + Board coaching.', 1),
(3, 'NEET-26', 'NEET UG & Class 11-12 PCB', 'Competitive', 12, 36000.00, 'Biology, Physics & Chemistry complete NCERT + PYQ mastery.', 1);

INSERT IGNORE INTO `batches` (`id`, `branch_id`, `session_id`, `course_id`, `name`, `timing`, `room_no`, `capacity`, `is_active`)
VALUES
(1, 1, 1, 1, 'Class 10 Morning Alpha', '07:30 AM - 09:30 AM', 'Hall A', 40, 1),
(2, 1, 1, 2, 'JEE Target Evening', '04:00 PM - 06:30 PM', 'Lab 1', 35, 1);

INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`, `is_encrypted`) VALUES
('institute_name', 'Yuitor Smart Classes', 0),
('institute_tagline', 'AI-Assisted · Expert-Led Learning', 0),
('institute_phone', '9999999999', 0),
('institute_email', 'no-reply@yuitor.com', 0),
('institute_address', 'Demo Campus, Main Road, Smart City - 100001', 0),
('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png', 0),
('receipt_prefix', 'YS01', 0),
('upi_id_primary', 'demo@upi', 0),
('upi_id_secondary', 'demo2@upi', 0),
('upi_payee_name', 'Yuitor Smart Classes', 0),
('mail_from_email', 'no-reply@yuitor.com', 0),
('mail_from_name', 'Yuitor Smart Classes', 0),
('smtp_host', 'mail.yuitor.com', 0),
('smtp_port', '465', 0),
('smtp_secure', 'ssl', 0),
('smtp_user', 'no-reply@yuitor.com', 0),
('smtp_pass', '', 1),
('admin_2fa_enabled', '1', 0),
('admin_2fa_email', 'Arunku8510@gmail.com', 0),
('sms_provider', 'fast2sms', 0),
('fast2sms_api_key', '', 1),
('fast2sms_sender_id', 'YUITOR', 0),
('fast2sms_route', 'dlt', 0),
('fast2sms_dlt_template_id', '', 0),
('whatsapp_phone_number_id', '', 0),
('whatsapp_access_token', '', 1),
('auto_due_reminder_days', '3', 0),
('late_fee_per_day', '20', 0);


-- Added Tables: Website -> ERP Integrations & Security Rate Limits
CREATE TABLE IF NOT EXISTS `online_registrations` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NOT NULL DEFAULT 1,
  `student_name` VARCHAR(120) NOT NULL,
  `parent_name` VARCHAR(120) NOT NULL DEFAULT '',
  `email` VARCHAR(190) NOT NULL,
  `phone` VARCHAR(25) NOT NULL,
  `class_grade` VARCHAR(80) NOT NULL,
  `board` VARCHAR(60) NOT NULL DEFAULT 'CBSE',
  `course_interest` VARCHAR(120) NOT NULL DEFAULT '',
  `message` TEXT NULL,
  `password_hash` VARCHAR(255) NULL DEFAULT NULL,
  `email_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `verification_code_hash` VARCHAR(255) NULL DEFAULT NULL,
  `verification_expires_at` DATETIME NULL DEFAULT NULL,
  `status` ENUM('New','Contacted','Admitted','Rejected') NOT NULL DEFAULT 'New',
  `admin_notes` TEXT NULL,
  `ip_address` VARCHAR(60) NOT NULL DEFAULT '0.0.0.0',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_online_reg_branch_status` (`branch_id`, `status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `teacher_applications` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NOT NULL DEFAULT 1,
  `full_name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `phone` VARCHAR(25) NOT NULL,
  `subject_specialty` VARCHAR(120) NOT NULL,
  `experience_years` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `qualification` VARCHAR(150) NOT NULL,
  `resume_path` VARCHAR(255) NULL DEFAULT NULL,
  `cover_note` TEXT NULL,
  `status` ENUM('New','Shortlisted','Interviewed','Hired','Rejected') NOT NULL DEFAULT 'New',
  `ip_address` VARCHAR(60) NOT NULL DEFAULT '0.0.0.0',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_teacher_app_status` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` INT UNSIGNED NOT NULL DEFAULT 1,
  `name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(190) NOT NULL DEFAULT '',
  `phone` VARCHAR(25) NOT NULL,
  `course` VARCHAR(120) NOT NULL DEFAULT '',
  `message` TEXT NOT NULL,
  `status` ENUM('Unread','Read','Replied') NOT NULL DEFAULT 'Unread',
  `ip_address` VARCHAR(60) NOT NULL DEFAULT '0.0.0.0',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contact_msg_status` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `security_rate_limits` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `scope` VARCHAR(50) NOT NULL,
  `identifier` VARCHAR(190) NOT NULL,
  `hit_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_rate_scope_id_time` (`scope`, `identifier`, `hit_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
