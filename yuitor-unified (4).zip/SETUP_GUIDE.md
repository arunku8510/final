# Yuitor Smart Classes — Unified Production Package Setup Guide

Everything (Website Frontend, Festival Engine & `/admin/` Portal, Full PHP/MySQL ERP, Contact/Registration Sync, Floating AI Chatbot + 108k Python Chatbot Backend) is merged cleanly into this single `public_html`-ready webroot.

---

## 1. Upload & Permissions
1. Extract the entire ZIP directly inside your domain root (`public_html/`).
2. Ensure writable (`0755` or `0775`) permissions on:
   - `data/`
   - `erp/config/`
   - `erp/uploads/`
   - `erp/backups/`
   - `erp/logs/`
   - `erp/install/`

---

## 2. Configure `.env` (Single Shared Config)
1. Copy `.env.example` to `.env` in the webroot (`/public_html/.env`):
   ```bash
   cp .env.example .env
   ```
2. Fill in your real production values inside `.env`:
   - **Database**: `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`
   - **SMTP & Alerts**: `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM_EMAIL`, `ADMIN_NOTIFY_EMAIL`
   - **AI Chatbot**: `AI_API_KEY` (or `GEMINI_API_KEY`)
   - **Institute Contact & UPI**: `SITE_URL`, `YU_INSTITUTE_PHONE`, `YU_INSTITUTE_EMAIL`, `YU_INSTITUTE_ADDRESS`, `YU_UPI_PRIMARY`, `YU_UPI_ALT`
   - **Console Gate (Optional)**: `CONSOLE_GATE_SLUG` (defaults to `yt-ctrl-94x2-gate`)

> All hardcoded personal emails, phone numbers, and UPI IDs have been removed and replaced with safe placeholders (`demo@example.com`, `9999999999`, `demo@upi`). Enter real values ONLY inside `.env` (and/or ERP Admin -> Settings).

---

## 3. MySQL Database Setup
Choose either method:
- **Option A (cPanel Wizard):** Visit `https://yourdomain.com/erp/install/install.php` and follow Steps 1–6.
- **Option B (phpMyAdmin Import):** Create a MySQL database & user in cPanel, import `erp/install/database.sql`, and configure `DB_*` in `.env` (or `erp/config/database.php`).

> After installation finishes, delete `/erp/install/` (or keep `install.lock`) for maximum security.

---

## 4. Portal & Feature Links
- **Main Website:** `https://yourdomain.com/`
  - Header **Student Login** -> `/erp/index.php?role=student`
  - Footer **Teacher Login** -> `/erp/index.php?role=teacher`
  - Floating **AI Guide Chatbot** -> `/api/chatbot.php` (reads `AI_API_KEY` from `.env`, with Hinglish FAQ fallback, prompt-injection & PII blocking, zero DB access, IP rate limiting)
- **ERP Unified Role Portal:** `https://yourdomain.com/erp/index.php`
  - `?role=student` | `?role=teacher` | `?role=admin`
  - Mobile-first order (login box top, role info bottom on mobile; split-screen desktop; empty left pane on Admin tab)
- **Website Admin & Festival Studio:** `https://yourdomain.com/admin/`
  - First-time setup: `https://yourdomain.com/admin/setup.php` (no cPanel BasicAuth blocker)
  - Includes **Open Full ERP Console** quick button to jump directly to `/erp/index.php?role=admin`
- **Forms Synced to ERP:**
  - Website Contact Form (`POST /api/inquiries`) -> SQLite + ERP `contact_messages` + Email alert to `ADMIN_NOTIFY_EMAIL`
  - Student Admission / Registration (`/student/register.php`, `POST /api/register.php`) -> ERP `online_registrations` (`New / Contacted / Admitted / Rejected`)
  - Teacher Application (`/teacher/register.php`) -> ERP `teacher_applications`
- **Festival Engine (Untouched):**
  - `assets/festival-engine.js`, `assets/festival-system.js`, `assets/festival-themes.css`, `api/festival.php` preserved 100% identically.

---

## 5. Optional Python FastAPI 108k Chatbot Service (`/chatbot/`)
To run the standalone FastAPI + 108k FTS5 KB engine:
```bash
cd chatbot
pip install -r requirements.txt
python run_tests.py
uvicorn backend.main:app --host 0.0.0.0 --port 8000
```
If you update `chatbot/business_config.json`, run `python chatbot/generate_dataset.py` to rebuild `chatbot/data/`.
