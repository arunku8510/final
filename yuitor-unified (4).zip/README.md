# Yuitor Smart Classes — Complete Website & Hardened ERP Package

A unified, production-ready web + ERP distribution combining the public Yuitor Smart Classes website, separated Student and Faculty portals, a configurable hidden Administration gate, strict PHP/MySQL security, server-side AI Guide chatbot, and domain-aligned email delivery (`demo@example.com`).

---

## 1. Directory Structure

```text
public_html/
├── index.html & static site routes (/about, /contact, /blog, /class/*, /course/*, /exam/*, /board/*)
├── .htaccess                     # Clean API routing, blocks /admin, .env, .sql, .log, .sqlite, data/
├── .env.example                  # Copy to .env with real production secrets
├── robots.txt                    # Disallows /erp/, /api/, /admin/, /data/
├── README.md                     # This complete deployment & DNS guide
├── student/
│   ├── index.php                 # Redirects to Student Dashboard or /student/login.php
│   ├── login.php                 # Dedicated Student-only Login (MySQL + CSRF + rate limit)
│   ├── register.php              # Dedicated Student Registration + 6-digit OTP Verification email
│   └── verify-email.php          # Dedicated 6-digit Email OTP Verification & Resend
├── teacher/
│   ├── index.php                 # Redirects to Teacher Dashboard or /teacher/login.php
│   ├── login.php                 # Dedicated Teacher-only Login (MySQL + CSRF + rate limit)
│   └── register.php              # Dedicated Teacher Registration/Application + PDF Resume upload
├── api/
│   ├── csrf.php                  # Session CSRF token issuer
│   ├── inquiries.php             # Contact & inquiry handler -> MySQL contact_messages + Admin mail
│   ├── register.php              # Student registration API -> MySQL + demo@example.com OTP mail
│   ├── chatbot.php               # Zero-DB Gemini AI Guide (reads server-side GEMINI_API_KEY)
│   ├── smtp-mailer.php           # Aligned SMTP mailer (demo@example.com)
│   └── festival.php              # Festival calendar configuration endpoint
└── erp/
    ├── .htaccess                 # Routes /erp/<CONSOLE_GATE_SLUG> -> ctrl_desk_entry_94x.php
    ├── ctrl_desk_entry_94x.php        # Configurable hidden Admin/Staff login (noindex, 2FA, rate limit)
    ├── verify-otp.php            # Mandatory 6-digit Admin 2FA verification (5-attempt cap)
    ├── forgot-password.php       # Role-isolated password reset via 6-digit OTP (demo@example.com)
    ├── config/
    │   ├── demo_defaults.php     # .env loader & sender normalization (forces demo@example.com)
    │   └── security.php          # Headers, AES-256 secret encryption, Strict SameSite sessions, CSRF
    ├── includes/
    │   ├── auth.php              # RBAC guards (returns 404 on unauth admin, blocks teacher from fees)
    │   ├── mail_theme.php        # Multipart/alternative (Text+HTML) SMTP & mail() transport
    │   └── site_header.php / site_footer.php / panel_nav.php
    ├── admin/                    # Admin-only dashboards, Online Registrations, Teacher Apps, Contact Msgs, Settings
    ├── operations/               # Branch staff workflows
    ├── teacher/                  # Teacher-only dashboards, attendance, materials, tests (no fee access)
    ├── student/                  # Student-only dashboards, attendance, fees, results, QR ID card
    ├── parent/                   # Dedicated Parent login & child overview
    ├── install/
    │   ├── database.sql          # Full MySQL schema (26+ tables including web lead & rate-limit tables)
    │   └── install.php           # CSRF-protected 6-step web installer
    └── cron/                     # db_backup.php, overdue_check.php, send_queue.php
```

---

## 2. Portal Separation & Security Architecture

| Portal | Entry Route | Auth Rules |
| --- | --- | --- |
| **Student Portal** | `/student/login.php` · `/student/register.php` · `/student/verify-email.php` | Authenticates `role = 'student'` only. Email OTP required before admission activation. Zero Teacher or Admin links. |
| **Teacher Portal** | `/teacher/login.php` · `/teacher/register.php` | Authenticates `role = 'teacher'` only. Zero Student or Admin links. Strictly blocked (`403`) from all fees & receipt routes. |
| **Parent Portal** | `/erp/parent/login.php` | Authenticates `role = 'parent'` only for linked children. |
| **Admin Portal (Hidden)** | `/erp/<CONSOLE_GATE_SLUG>` (default: `/erp/yt-ctrl-94x2-gate`) | Configurable via `CONSOLE_GATE_SLUG` in `.env`. Public `/admin`, `/admin/*`, `/erp/admin/` return **HTTP 404**. Mandatory 2FA OTP, `noindex, nofollow`, IP/account lockout, CSRF, and strict server-side `require_role('admin')`. |

---

## 3. Environment Setup (`.env`)

Copy `.env.example` to `.env` inside `public_html/`:

```dotenv
APP_ENV=production
APP_URL=https://yuitor.com
APP_KEY=generate-64-char-random-hex-secret

# Change this to your own secret slug (8-64 chars, letters/numbers/-/_)
CONSOLE_GATE_SLUG=yt-ctrl-94x2-gate

DB_HOST=localhost
DB_NAME=your_mysql_database
DB_USER=your_mysql_user
DB_PASS=your_mysql_password

MAIL_FROM_EMAIL=demo@example.com
MAIL_FROM_NAME="Yuitor Smart Classes"
YU_INSTITUTE_EMAIL=demo@example.com
YU_ADMIN_EMAIL=demo@example.com

SMTP_HOST=mail.yuitor.com
SMTP_PORT=587
SMTP_SECURE=tls
SMTP_USER=demo@example.com
SMTP_PASS=your_mailbox_password

GEMINI_API_KEY=your_server_side_gemini_api_key
GEMINI_MODEL=gemini-2.5-flash
```

---

## 4. Email System (`demo@example.com`) & Anti-Spam DNS Records

All system emails (Password Reset OTP, Admin 2FA OTP, Student Registration Verification, Welcome Emails, Teacher Application Confirmations, and Contact Notifications) are sent via `demo@example.com` using `multipart/alternative` (both Plain-Text + HTML) and base64 MIME encoding. Any `@example.com` sender is automatically rejected and normalized to `demo@example.com`.

### Required cPanel / Domain DNS Records (SPF, DKIM, DMARC)

Add these DNS TXT records in **cPanel -> Zone Editor** (or Cloudflare / Domain Registrar) so emails land in **Inbox** instead of Spam:

1. **SPF Record (TXT at `@` / `yuitor.com`):**
   ```text
   v=spf1 a mx ip4:<YOUR_SERVER_PUBLIC_IP> ~all
   ```
   *(If you use external SMTP such as Google Workspace or Zoho/SES, include their SPF mechanism before `~all`, e.g., `include:_spf.google.com` or `include:zoho.in`.)*

2. **DKIM Record (TXT at `default._domainkey.yuitor.com`):**
   - Open **cPanel -> Email Deliverability -> Manage (`yuitor.com`)**.
   - Click **Install the Suggested Record** to publish your 2048-bit RSA DKIM public key (`v=DKIM1; k=rsa; p=...`).

3. **DMARC Record (TXT at `_dmarc.yuitor.com`):**
   ```text
   v=DMARC1; p=quarantine; rua=mailto:demo@example.com; adkim=s; aspf=s; pct=100
   ```

4. **PTR / Reverse DNS:**
   - Ensure your hosting server's IP has a valid PTR record matching your mail server hostname (`mail.yuitor.com`) inside cPanel Email Deliverability.

5. **Create Mailbox:**
   - Inside **cPanel -> Email Accounts**, create `demo@example.com`, then test live SMTP delivery from **Admin -> Messaging & Queue -> Instant Single Test Send** (or **Admin -> Settings**).

---

## 5. Installation & Cron Jobs

1. Extract this ZIP directly into `public_html/`.
2. Create a MySQL database & user in cPanel, then either:
   - Import `erp/install/database.sql` via phpMyAdmin and configure `erp/config/database.php` + `.env`, **OR**
   - Visit `/erp/install/install.php` to run the 6-step installer, then **delete `erp/install/`** after completion.
3. Ensure `erp/logs/` and `erp/uploads/` are writable (`0755`).
4. Add cPanel Cron Jobs:
   - **Daily DB Backup (2:00 AM):**
     `0 2 * * * /usr/local/bin/php -q /home/<cpanel_user>/public_html/erp/cron/db_backup.php >/dev/null 2>&1`
   - **Overdue Fee Check (8:00 AM):**
     `0 8 * * * /usr/local/bin/php -q /home/<cpanel_user>/public_html/erp/cron/overdue_check.php >/dev/null 2>&1`
   - **Queued Notifications (Every 5 mins):**
     `*/5 * * * * /usr/local/bin/php -q /home/<cpanel_user>/public_html/erp/cron/send_queue.php >/dev/null 2>&1`
