<?php
declare(strict_types=1);
/**
 * Yuitor Smart Classes - Shared Environment, HTTP/HTTPS & Session Helpers
 * Used by both /api/* (website/festival/chatbot) and /erp/* (MySQL ERP).
 */

if (!function_exists('yu_load_env_file')) {
    function yu_load_env_file(): array
    {
        static $loaded = null;
        if ($loaded !== null) {
            return $loaded;
        }
        $loaded = [];
        $rootDir = dirname(__DIR__);
        $candidates = [
            $rootDir . '/.env',
            $rootDir . '/erp/.env',
        ];
        foreach ($candidates as $envPath) {
            if (!is_file($envPath) || !is_readable($envPath)) {
                continue;
            }
            $lines = @file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (!is_array($lines)) {
                continue;
            }
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) {
                    continue;
                }
                list($k, $v) = explode('=', $line, 2);
                $k = trim($k);
                $v = trim($v);
                if (
                    strlen($v) >= 2 &&
                    (($v[0] === '"' && substr($v, -1) === '"') || ($v[0] === "'" && substr($v, -1) === "'"))
                ) {
                    $v = substr($v, 1, -1);
                }
                if ($k !== '' && !isset($loaded[$k])) {
                    $loaded[$k] = $v;
                }
            }
        }
        return $loaded;
    }
}

if (!function_exists('yu_is_placeholder_value')) {
    function yu_is_placeholder_value(string $val): bool
    {
        $v = strtolower(trim($val));
        if ($v === '') {
            return true;
        }
        foreach (['replace-with-', 'your-', 'changeme', 'dummy-key', 'demo@example.com', 'smtp.example.com'] as $prefix) {
            if (strpos($v, $prefix) !== false) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('yu_env')) {
    function yu_env(string $key, string $default = ''): string
    {
        $val = getenv($key);
        if ($val !== false && trim((string) $val) !== '' && !yu_is_placeholder_value((string) $val)) {
            return trim((string) $val);
        }
        if (isset($_ENV[$key]) && trim((string) $_ENV[$key]) !== '' && !yu_is_placeholder_value((string) $_ENV[$key])) {
            return trim((string) $_ENV[$key]);
        }
        $fileEnv = yu_load_env_file();
        if (isset($fileEnv[$key]) && trim((string) $fileEnv[$key]) !== '' && !yu_is_placeholder_value((string) $fileEnv[$key])) {
            return trim((string) $fileEnv[$key]);
        }
        return $default;
    }
}

if (!function_exists('yu_normalize_sender_email')) {
    function yu_normalize_sender_email(string $email): string
    {
        $email = trim($email);
        if ($email === '' || strtolower($email) === 'demo@example.com' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return 'no-reply@yuitor.com';
        }
        return $email;
    }
}

if (!function_exists('yu_request_is_https')) {
    function yu_request_is_https(): bool
    {
        if (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') {
            return true;
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
            return true;
        }
        if (!empty($_SERVER['HTTP_CF_VISITOR']) && strpos((string) $_SERVER['HTTP_CF_VISITOR'], '"https"') !== false) {
            return true;
        }
        return isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443;
    }
}

if (!function_exists('yu_ensure_writable_session_path')) {
    function yu_ensure_writable_session_path(): void
    {
        $current = (string) @session_save_path();
        if ($current !== '' && strpos($current, ';') === false && @is_dir($current) && @is_writable($current)) {
            return;
        }
        $candidates = [
            dirname(__DIR__) . '/erp/logs/sessions',
            dirname(__DIR__) . '/logs/sessions',
            rtrim((string) sys_get_temp_dir(), '/\\') . '/yuitor_sessions',
        ];
        foreach ($candidates as $dir) {
            if (!is_dir($dir)) {
                @mkdir($dir, 0700, true);
            }
            if (is_dir($dir) && is_writable($dir)) {
                $ht = $dir . '/.htaccess';
                if (!is_file($ht)) {
                    @file_put_contents($ht, "Require all denied\nDeny from all\n");
                }
                @session_save_path($dir);
                return;
            }
        }
    }
}

if (!function_exists('yu_site_url')) {
    function yu_site_url(): string
    {
        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
        if ($host !== '') {
            $scheme = yu_request_is_https() ? 'https://' : 'http://';
            return $scheme . $host;
        }
        $configured = rtrim(yu_env('SITE_URL', yu_env('APP_URL', '')), '/');
        if ($configured !== '') {
            return $configured;
        }
        return 'https://yuitor.com';
    }
}
