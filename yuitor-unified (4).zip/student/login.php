<?php
require_once dirname(__DIR__) . '/erp/includes/auth.php';
send_security_headers();
start_secure_session();

$existing = current_user();
if ($existing) {
    if ($existing['role'] === 'student') {
        redirect_to('/erp/student/dashboard.php');
    }
    http_response_code(403);
    $code = 403;
    include dirname(__DIR__) . '/erp/error.php';
    exit;
}

$err = '';
$emailVal = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $emailVal = strtolower(trim((string) ($_POST['email'] ?? '')));
    $pass = (string) ($_POST['password'] ?? '');
    $ip = client_ip();
    $pdo = db();

    if (($_SESSION['student_login_fail'] ?? 0) >= 3) {
        if (!yu_verify_signed_math_captcha('student_login', $_POST['captcha'] ?? '', $_POST['captcha_token'] ?? '')) {
            $err = 'Security verification math answer is incorrect.';
        }
    }

    if ($err === '') {
        if (!check_rate_limit($pdo, 'student_login_ip', $ip, 10, 15, false)) {
            $err = 'Too many sign-in attempts from this IP. Please try again in 15 minutes.';
        } elseif ($emailVal === '' || $pass === '') {
            $err = 'Email and password are required.';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'student' AND deleted_at IS NULL LIMIT 1");
            $stmt->execute([$emailVal]);
            $user = $stmt->fetch();

            if ($user && !empty($user['locked_until']) && strtotime($user['locked_until']) > time()) {
                $err = 'This student account is temporarily locked. Please try again after 15 minutes.';
            } elseif ($user && password_verify($pass, $user['password_hash'])) {
                if ((int) $user['is_active'] !== 1) {
                    $err = 'Your student account is currently disabled. Please contact the centre.';
                } else {
                    $_SESSION['student_login_fail'] = 0;
                    clear_rate_limit($pdo, 'student_login_ip', $ip);
                    complete_user_login($user);
                    redirect_to('/erp/student/dashboard.php');
                }
            } else {
                // Check if student registered online and is pending email verification or centre approval
                $regSt = $pdo->prepare("SELECT id, email_verified, status, password_hash FROM online_registrations WHERE email = ? ORDER BY id DESC LIMIT 1");
                $regSt->execute([$emailVal]);
                $reg = $regSt->fetch();
                if ($reg && !empty($reg['password_hash']) && password_verify($pass, (string) $reg['password_hash'])) {
                    if ((int) $reg['email_verified'] !== 1) {
                        $err = 'Your email is not verified yet. Please verify your 6-digit OTP first on the Verify Email page.';
                    } elseif ($reg['status'] === 'Rejected') {
                        $err = 'Your admission inquiry was closed. Please contact the centre for assistance.';
                    } else {
                        $err = 'Your email is verified and your registration is under review. Student dashboard activates once admission is confirmed by the centre.';
                    }
                } else {
                    $_SESSION['student_login_fail'] = (int) ($_SESSION['student_login_fail'] ?? 0) + 1;
                    check_rate_limit($pdo, 'student_login_ip', $ip, 10, 15, true);
                    if ($user) {
                        $fails = (int) $user['failed_attempts'] + 1;
                        $lock = $fails >= 5 ? date('Y-m-d H:i:s', time() + 900) : null;
                        $pdo->prepare("UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?")
                            ->execute([$fails, $lock, (int) $user['id']]);
                    }
                    $err = 'Invalid student email or password.';
                }
            }
        }
    }
}

$needCaptcha = ($_SESSION['student_login_fail'] ?? 0) >= 3;
$stuCapData = $needCaptcha ? yu_make_signed_math_captcha('student_login') : null;

$pageTitle = 'Student Portal Sign In';
$portalMode = 'student';
$showPanelSidebar = false;
include dirname(__DIR__) . '/erp/includes/site_header.php';
$brandLogo = get_setting('institute_logo', '/erp/assets/images/yuitor-smart-classes-logo.png');
?>
<style>
  .yu-portal-split {
    max-width: 960px;
    margin: 16px auto 0;
    display: grid;
    grid-template-columns: 1fr;
    gap: 24px;
    align-items: stretch;
  }
  .yu-split-form { order: 1; }
  .yu-split-info { order: 2; }
  @media (min-width: 900px) {
    .yu-portal-split { grid-template-columns: 1.05fr 0.95fr; margin-top: 28px; }
    .yu-split-info { order: 1; }
    .yu-split-form { order: 2; }
  }
  .yu-portal-promo {
    margin: 0;
    height: 100%;
    padding: 36px 32px;
    background: linear-gradient(150deg, #0f172a 0%, #103248 62%, #0b7b82 100%);
    color: #f1f5f9;
    border-color: #164e63;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
  .yu-benefit-list {
    list-style: none;
    padding: 0;
    margin: 0 0 28px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    font-size: 14.5px;
    color: #e2e8f0;
  }
  .yu-benefit-list li {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .yu-benefit-list svg { color: #5eead4; flex-shrink: 0; }
</style>

<div class="yu-portal-split">
  <div class="yu-split-info">
    <div class="yu-card yu-portal-promo">
      <div>
        <div style="font-size:12px;font-weight:700;letter-spacing:.06em;color:#5eead4;margin-bottom:10px;">
          Admissions Open 2026–27
        </div>
        <h2 style="margin:0 0 12px;font-family:'Manrope',sans-serif;font-size:clamp(24px,2.4vw,30px);line-height:1.2;color:#ffffff;text-wrap:balance;">
          Build Stronger Concepts. Score Higher.
        </h2>
        <p style="margin:0 0 22px;font-size:15px;line-height:1.6;color:#cbd5e1;">
          Classes 5–12, JEE, NEET, CUET &amp; Coding batches with max 20 students per batch for personal mentor attention.
        </p>
        <ul class="yu-benefit-list">
          <li><?php echo yu_icon('check', 16); ?> <span>Daily Attendance &amp; Parent Progress Updates</span></li>
          <li><?php echo yu_icon('check', 16); ?> <span>Structured Study Notes &amp; Weekly Mock Tests</span></li>
          <li><?php echo yu_icon('check', 16); ?> <span>Up to 50% Merit Scholarship Test Every Sunday</span></li>
        </ul>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:10px;">
        <a href="/student/register.php" class="yu-btn" style="background:#ffffff;color:#0f172a;font-weight:800;">
          Apply for New Admission &rarr;
        </a>
        <a href="<?php echo e(erp_url('admission-test/index.php')); ?>" class="yu-btn" style="background:rgba(255,255,255,0.12);color:#ffffff;border:1px solid rgba(255,255,255,0.26);">
          Scholarship Test
        </a>
      </div>
    </div>
  </div>

  <div class="yu-split-form">
    <div class="yu-card" style="margin:0;height:100%;padding:32px;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
        <div style="width:44px;height:44px;border-radius:50%;background:#f1f5f9;border:1px solid #cbd5e1;padding:3px;flex-shrink:0;overflow:hidden;">
          <img src="<?php echo e($brandLogo); ?>" alt="" style="width:100%;height:100%;object-fit:contain;border-radius:50%;">
        </div>
        <div>
          <h1 style="margin:0;font-family:'Manrope',sans-serif;font-size:23px;line-height:1.2;">Student Sign In</h1>
          <p style="margin:2px 0 0;font-size:13px;color:#64748b;">Access classes, notes, marks &amp; fee receipts</p>
        </div>
      </div>

      <?php echo render_flash(); ?>
      <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger"><?php echo e($err); ?></div><?php endif; ?>

      <form method="post">
        <?php echo csrf_field(); ?>
        <div class="yu-field" style="margin-bottom:14px;">
          <label for="stuEmail">Student Email Address</label>
          <input id="stuEmail" type="email" name="email" required autocomplete="username" value="<?php echo e($emailVal); ?>" placeholder="you@example.com">
        </div>
        <div class="yu-field" style="margin-bottom:14px;">
          <label for="stuPass">Password</label>
          <div class="yu-pass-wrap">
            <input id="stuPass" type="password" name="password" required autocomplete="current-password" placeholder="Enter your password">
            <button type="button" class="yu-pass-toggle" data-yu-toggle-pass="stuPass" aria-label="Show password" aria-pressed="false">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
          </div>
        </div>
        <?php if ($needCaptcha && $stuCapData): ?>
          <input type="hidden" name="captcha_token" value="<?php echo e($stuCapData['token']); ?>">
          <div class="yu-field" style="margin-bottom:14px;">
            <label for="stuCap">Security Check: What is <?php echo e($stuCapData['question']); ?>?</label>
            <input id="stuCap" type="number" name="captcha" required>
          </div>
        <?php endif; ?>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;font-size:13px;gap:8px;flex-wrap:wrap;">
          <a href="<?php echo e(erp_url('forgot-password.php?portal=student')); ?>" style="color:#2563eb;font-weight:600;text-decoration:none;">Forgot Password?</a>
          <a href="/student/verify-email.php" style="color:#0b7b82;font-weight:600;text-decoration:none;">Verify Email OTP</a>
        </div>

        <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;min-height:46px;font-size:15px;">
          Sign In to Student Portal
        </button>

        <div style="margin-top:18px;padding-top:16px;border-top:1px solid #f1f5f9;text-align:center;font-size:13.5px;color:#64748b;">
          New student? <a href="/student/register.php" style="color:#2563eb;font-weight:700;text-decoration:none;">Apply for New Admission &rarr;</a>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__) . '/erp/includes/site_footer.php'; ?>
