<?php
require_once dirname(__DIR__) . '/erp/includes/auth.php';
send_security_headers();
start_secure_session();

$emailVal = strtolower(trim((string) ($_GET['email'] ?? ($_POST['email'] ?? ($_SESSION['pending_verify_email'] ?? '')))));
$err = '';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $pdo = db();
    $ip = client_ip();
    $action = (string) ($_POST['action'] ?? 'verify');

    if (!filter_var($emailVal, FILTER_VALIDATE_EMAIL)) {
        $err = 'Please enter a valid registered email address.';
    } elseif ($action === 'resend') {
        if (!check_rate_limit($pdo, 'stu_verify_resend', $ip . '|' . $emailVal, 3, 15, true)) {
            $err = 'Too many verification code requests. Please wait 15 minutes.';
        } else {
            $st = $pdo->prepare("SELECT id, student_name, email_verified FROM online_registrations WHERE email = ? ORDER BY id DESC LIMIT 1");
            $st->execute([$emailVal]);
            $row = $st->fetch();
            if ($row && (int) $row['email_verified'] === 0) {
                $otpCode = sprintf('%06d', random_int(0, 999999));
                $otpHash = password_hash($otpCode, PASSWORD_DEFAULT);
                $pdo->prepare("UPDATE online_registrations SET verification_code_hash = ?, verification_expires_at = DATE_ADD(NOW(), INTERVAL 30 MINUTE) WHERE id = ?")
                    ->execute([$otpHash, (int) $row['id']]);
                send_student_verification_email($emailVal, $row['student_name'], $otpCode, yu_site_url() . '/student/verify-email.php?email=' . urlencode($emailVal));
            }
            $msg = 'If an unverified registration exists for this email, a fresh 6-digit code has been sent from ' . YU_MAIL_FROM_EMAIL . '.';
        }
    } else {
        $code = trim((string) ($_POST['otp_code'] ?? ''));
        if (!check_rate_limit($pdo, 'stu_verify_try', $ip . '|' . $emailVal, 6, 15, true)) {
            $err = 'Too many invalid attempts. Please wait 15 minutes or request a new code.';
        } elseif (!preg_match('/^\d{6}$/', $code)) {
            $err = 'Please enter the 6-digit numeric verification code.';
        } else {
            $st = $pdo->prepare(
                "SELECT id, student_name, email_verified, verification_code_hash, verification_expires_at
                 FROM online_registrations WHERE email = ? ORDER BY id DESC LIMIT 1"
            );
            $st->execute([$emailVal]);
            $row = $st->fetch();
            if (!$row) {
                $err = 'No registration found for this email address.';
            } elseif ((int) $row['email_verified'] === 1) {
                $msg = 'Your email is already verified! You can sign in once the centre approves your admission.';
            } elseif (empty($row['verification_expires_at']) || strtotime((string) $row['verification_expires_at']) < time()) {
                $err = 'This verification code has expired. Click Resend Code to get a new one.';
            } elseif (!password_verify($code, (string) $row['verification_code_hash'])) {
                $err = 'Invalid 6-digit verification code.';
            } else {
                $pdo->prepare("UPDATE online_registrations SET email_verified = 1, verification_code_hash = NULL WHERE id = ?")
                    ->execute([(int) $row['id']]);
                clear_rate_limit($pdo, 'stu_verify_try', $ip . '|' . $emailVal);
                unset($_SESSION['pending_verify_email']);
                $msg = 'Email verified successfully! Our admissions team will review your registration and activate your Student Portal account.';
            }
        }
    }
}

$pageTitle = 'Verify Student Email';
$portalMode = 'student';
$showPanelSidebar = false;
include dirname(__DIR__) . '/erp/includes/site_header.php';
?>
<div style="max-width:480px;margin:24px auto;">
  <div class="yu-card">
    <div style="font-size:11.5px;font-weight:700;color:#0b7b82;text-transform:uppercase;letter-spacing:.08em;">Student Registration Security</div>
    <h1 style="margin:4px 0 8px;font-family:'Manrope',sans-serif;font-size:22px;">Verify Your Email Address</h1>
    <p style="margin:0 0 16px;font-size:13.5px;color:#52687c;">Enter the 6-digit verification code sent from <code><?php echo e(YU_MAIL_FROM_EMAIL); ?></code>.</p>

    <?php echo render_flash(); ?>
    <?php if ($msg !== ''): ?><div class="yu-alert yu-alert-success"><?php echo e($msg); ?></div><?php endif; ?>
    <?php if ($err !== ''): ?><div class="yu-alert yu-alert-danger"><?php echo e($err); ?></div><?php endif; ?>

    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="verify">
      <div class="yu-field" style="margin-bottom:12px;">
        <label for="vEmail">Registered Email</label>
        <input id="vEmail" type="email" name="email" required value="<?php echo e($emailVal); ?>">
      </div>
      <div class="yu-field" style="margin-bottom:14px;">
        <label for="vOtp">6-Digit Verification Code</label>
        <input id="vOtp" type="text" name="otp_code" maxlength="6" pattern="\d{6}" inputmode="numeric" required placeholder="000000" style="font-size:22px;letter-spacing:8px;text-align:center;font-weight:800;">
      </div>
      <button type="submit" class="yu-btn yu-btn-primary" style="width:100%;padding:12px;">Verify Email</button>
    </form>

    <form method="post" style="margin-top:12px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="resend">
      <input type="hidden" name="email" value="<?php echo e($emailVal); ?>">
      <button type="submit" class="yu-btn yu-btn-outline yu-btn-sm">Resend Verification Code</button>
      <a href="/student/login.php" style="font-size:13px;color:#2563eb;font-weight:600;text-decoration:none;">&larr; Student Sign In</a>
    </form>
  </div>
</div>
<?php include dirname(__DIR__) . '/erp/includes/site_footer.php'; ?>
