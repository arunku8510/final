<?php
declare(strict_types=1);
require dirname(__DIR__) . '/portal-shell.php';
