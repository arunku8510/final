<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/api/bootstrap.php';
yu_api_init();

session_regenerate_id(true);
$_SESSION['yu_admin_setup_authorized_at'] = time();

require dirname(__DIR__) . '/portal-shell.php';
