<?php

ob_start();
@ini_set('display_errors', '0');

$emitCsrfJson = function ($statusCode, $payload) {
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    if (!headers_sent()) {
        http_response_code((int) $statusCode);
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
    }
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $encoded = json_encode($payload, $flags);
    if ($encoded === false) {
        $encoded = '{"csrf_token":"","error":"JSON encoding error"}';
    }
    echo $encoded;
    exit;
};

set_exception_handler(static function (Throwable $ex) use ($emitCsrfJson) {
    error_log('Yuitor /api/csrf.php exception: ' . $ex->getMessage());
    $emitCsrfJson(500, ['csrf_token' => '', 'error' => 'Temporary security token error']);
});

register_shutdown_function(static function () use ($emitCsrfJson) {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        error_log('Yuitor /api/csrf.php fatal: ' . ($err['message'] ?? 'unknown'));
        $emitCsrfJson(500, ['csrf_token' => '', 'error' => 'Temporary security token fatal error']);
    }
});

require_once dirname(__DIR__) . '/erp/config/security.php';
send_security_headers();
start_secure_session();

$emitCsrfJson(200, [
    'csrf_token'   => csrf_token(),
    'demo_phone'   => defined('YU_DEMO_PHONE') ? YU_DEMO_PHONE : '9999999999',
    'demo_email'   => defined('YU_DEMO_EMAIL') ? YU_DEMO_EMAIL : 'no-reply@yuitor.com',
    'demo_address' => defined('YU_DEMO_ADDRESS') ? YU_DEMO_ADDRESS : 'Demo Campus, Main Road, Smart City - 100001',
]);
