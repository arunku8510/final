<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/smtp-mailer.php';
yu_api_init();

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    header('Allow: POST');
    yu_fail(405, 'Method not allowed.');
}

yu_require_same_origin();
$input = yu_read_json(16000);

// Quiet honeypot field catches bots cleanly
if (trim((string) ($input['website'] ?? '')) !== '' || trim((string) ($input['website_url'] ?? '')) !== '') {
    yu_json(201, array('accepted' => true, 'success' => true, 'message' => 'Thank you. Your enquiry has been received.'));
}

$now = time();
if (isset($_SESSION['yuitor_last_inquiry']) && ($now - (int) $_SESSION['yuitor_last_inquiry']) < 15) {
    yu_fail(429, 'Please wait a few seconds before sending another enquiry.');
}

$name = yu_text($input, 'name', 120, true);
$phone = yu_text($input, 'phone', 24, true);
$email = yu_email(yu_text($input, 'email', 254), false);
$course = yu_text($input, 'course', 120, false);
$message = yu_text($input, 'message', 2000);

if (strlen($name) < 2) {
    yu_fail(400, 'Please enter your name.');
}
if (!yu_valid_phone($phone)) {
    yu_fail(400, 'Please enter a valid phone number.');
}
if ($course === '') {
    $course = 'General Inquiry';
}

$stored = false;
try {
    $db = yu_db();
    $insert = $db->prepare(
        "INSERT INTO inquiries (name, phone, email, course, message, status, received_at)
         VALUES (?, ?, ?, ?, ?, 'new', ?)"
    );
    $insert->execute(array($name, $phone, $email, $course, $message, gmdate('c')));
    $stored = true;
} catch (Throwable $error) {
    error_log('Yuitor SQLite inquiry storage warning: ' . $error->getMessage());
}

// Sync contact inquiry directly into MySQL ERP contact_messages table when MySQL is configured
$erpPdo = yu_try_erp_pdo();
if ($erpPdo instanceof PDO) {
    try {
        $ip = filter_var((string) ($_SERVER['REMOTE_ADDR'] ?? ''), FILTER_VALIDATE_IP) ? (string) $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
        $erpPdo->prepare(
            "INSERT INTO contact_messages (branch_id, name, email, phone, subject, message, status, ip_address)
             VALUES (1, ?, ?, ?, ?, ?, 'New', ?)"
        )->execute(array($name, $email, $phone, $course, $message, $ip));
        $stored = true;
    } catch (Throwable $error) {
        error_log('Yuitor ERP MySQL contact_messages sync warning: ' . $error->getMessage());
    }
}

if (!$stored) {
    yu_fail(503, 'Your enquiry could not be saved right now. Please try again later.');
}

$_SESSION['yuitor_last_inquiry'] = $now;

// Send SMTP notification to ADMIN_NOTIFY_EMAIL (.env)
$recipient = yu_private_setting('ADMIN_NOTIFY_EMAIL', 'Arunku8510@gmail.com');
if (filter_var($recipient, FILTER_VALIDATE_EMAIL) && strtolower($recipient) !== 'demo@example.com') {
    $subject = 'New Website Contact / Inquiry - Yuitor Smart Classes';
    $body = "A new inquiry was submitted on the Yuitor website.\n\n"
        . "Name: {$name}\n"
        . "Phone: {$phone}\n"
        . "Email: " . ($email !== '' ? $email : 'Not provided') . "\n"
        . "Course / Topic: {$course}\n"
        . "Message: " . ($message !== '' ? $message : 'Not provided') . "\n"
        . "Received (UTC): " . gmdate('c') . "\n";
    try {
        yu_smtp_send_message($recipient, $subject, $body);
    } catch (Throwable $mailErr) {
        error_log('Inquiry notification SMTP error: ' . $mailErr->getMessage());
    }
}

yu_json(201, array(
    'accepted' => true,
    'success' => true,
    'message' => 'Thank you. Your enquiry has been received.',
));
