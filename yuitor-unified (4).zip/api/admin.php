<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/smtp-mailer.php';
yu_api_init();

try {
    $db = yu_db();
} catch (Throwable $error) {
    error_log('Yuitor portal database error: ' . $error->getMessage());
    yu_fail(503, 'The portal database is not ready. Please contact the website administrator.');
}

yu_require_role($db, 'admin');
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$action = strtolower(trim((string) ($_GET['action'] ?? 'dashboard')));

if ($method === 'GET' && $action === 'dashboard') {
    $students = $db->query(
        'SELECT id, full_name, email, phone, class_level, selected_subject,
                course_duration_months, admission_date, fee_status, next_fee_due,
                fee_alert_note, registration_status, is_active, created_at, updated_at
         FROM students ORDER BY datetime(created_at) DESC, id DESC'
    )->fetchAll();
    foreach ($students as &$student) {
        $student = yu_public_student($student);
    }
    unset($student);

    $inquiries = $db->query(
        'SELECT id, name, phone, email, course, message, status, received_at
         FROM inquiries ORDER BY datetime(received_at) DESC, id DESC'
    )->fetchAll();
    foreach ($inquiries as &$inquiry) {
        $inquiry['id'] = (int) $inquiry['id'];
    }
    unset($inquiry);

    $summary = array(
        'students' => count($students),
        'pendingRegistrations' => 0,
        'feesDue' => 0,
        'newInquiries' => 0,
    );
    foreach ($students as $student) {
        if ($student['registration_status'] === 'pending') {
            $summary['pendingRegistrations']++;
        }
        if ($student['fee_status'] !== 'paid') {
            $summary['feesDue']++;
        }
    }
    foreach ($inquiries as $inquiry) {
        if ($inquiry['status'] === 'new') {
            $summary['newInquiries']++;
        }
    }
    yu_json(200, array('summary' => $summary, 'students' => $students, 'inquiries' => $inquiries));
}

if ($method === 'GET' && $action === 'festival-config') {
    yu_json(200, array('config' => yu_get_festival_config($db)));
}

if ($method !== 'POST') {
    header('Allow: GET, POST');
    yu_fail(405, 'Method not allowed.');
}

yu_require_same_origin();
$input = yu_read_json();
yu_require_csrf();

if ($action === 'update-student') {
    $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
    if ($id === false || $id < 1) {
        yu_fail(400, 'Choose a valid student profile.');
    }
    $subject = yu_text($input, 'selectedSubject', 120, true);
    $classLevel = yu_text($input, 'classLevel', 60, true);
    $duration = filter_var($input['courseDurationMonths'] ?? null, FILTER_VALIDATE_INT);
    $feeStatus = strtolower(yu_text($input, 'feeStatus', 20, true));
    $registrationStatus = strtolower(yu_text($input, 'registrationStatus', 20, true));
    $admissionDate = yu_valid_date_or_null(yu_text($input, 'admissionDate', 10), 'admission date');
    $nextFeeDue = yu_valid_date_or_null(yu_text($input, 'nextFeeDue', 10), 'fee due date');
    $feeAlertNote = yu_text($input, 'feeAlertNote', 300);
    $isActive = filter_var($input['isActive'] ?? null, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);

    if ($duration === false || $duration < 1 || $duration > 60) {
        yu_fail(400, 'Course duration must be between 1 and 60 months.');
    }
    if (!in_array($feeStatus, array('pending', 'partial', 'paid', 'overdue'), true)) {
        yu_fail(400, 'Choose a valid fee status.');
    }
    if (!in_array($registrationStatus, array('pending', 'active', 'completed', 'inactive'), true)) {
        yu_fail(400, 'Choose a valid registration status.');
    }
    if ($isActive === null) {
        yu_fail(400, 'Choose whether this account is active.');
    }

    $update = $db->prepare(
        'UPDATE students
         SET class_level = ?, selected_subject = ?, course_duration_months = ?,
             admission_date = ?, fee_status = ?, next_fee_due = ?, fee_alert_note = ?,
             registration_status = ?, is_active = ?, updated_at = ?
         WHERE id = ?'
    );
    $update->execute(array(
        $classLevel,
        $subject,
        $duration,
        $admissionDate,
        $feeStatus,
        $nextFeeDue,
        $feeAlertNote,
        $registrationStatus,
        $isActive ? 1 : 0,
        gmdate('c'),
        $id,
    ));
    if ($update->rowCount() < 1) {
        $exists = $db->prepare('SELECT id FROM students WHERE id = ?');
        $exists->execute(array($id));
        if (!$exists->fetchColumn()) {
            yu_fail(404, 'Student profile not found.');
        }
    }

    $select = $db->prepare(
        'SELECT id, full_name, email, phone, class_level, selected_subject,
                course_duration_months, admission_date, fee_status, next_fee_due,
                fee_alert_note, registration_status, is_active, created_at, updated_at
         FROM students WHERE id = ?'
    );
    $select->execute(array($id));
    $student = $select->fetch();
    yu_json(200, array('student' => yu_public_student($student)));
}

if ($action === 'update-inquiry') {
    $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
    $status = strtolower(yu_text($input, 'status', 20, true));
    if ($id === false || $id < 1 || !in_array($status, array('new', 'contacted', 'converted', 'closed'), true)) {
        yu_fail(400, 'Choose a valid inquiry and status.');
    }
    $update = $db->prepare('UPDATE inquiries SET status = ? WHERE id = ?');
    $update->execute(array($status, $id));
    if ($update->rowCount() < 1) {
        $exists = $db->prepare('SELECT id FROM inquiries WHERE id = ?');
        $exists->execute(array($id));
        if (!$exists->fetchColumn()) {
            yu_fail(404, 'Inquiry not found.');
        }
    }
    yu_json(200, array('updated' => true));
}

if ($action === 'send-student-email') {
    $rawIds = $input['studentIds'] ?? null;
    if (!is_array($rawIds) || count($rawIds) < 1 || count($rawIds) > 100) {
        yu_fail(400, 'Select between 1 and 100 students to email.');
    }
    $studentIds = array();
    foreach ($rawIds as $rawId) {
        $id = filter_var($rawId, FILTER_VALIDATE_INT);
        if ($id === false || $id < 1) {
            yu_fail(400, 'The selected student list is invalid.');
        }
        $studentIds[] = (int) $id;
    }
    $studentIds = array_values(array_unique($studentIds));
    if (count($studentIds) < 1 || count($studentIds) > 100) {
        yu_fail(400, 'Select between 1 and 100 students to email.');
    }

    $subject = trim(yu_text($input, 'subject', 180, true));
    if (strpos($subject, "\r") !== false || strpos($subject, "\n") !== false) {
        yu_fail(400, 'The email subject cannot contain line breaks.');
    }
    $body = yu_text($input, 'message', 6000, true);
    if (trim($body) === '') {
        yu_fail(400, 'Enter an email message.');
    }

    $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
    $recipientsQuery = $db->prepare(
        'SELECT id, email FROM students WHERE id IN (' . $placeholders . ') ORDER BY id'
    );
    $recipientsQuery->execute($studentIds);
    $recipients = $recipientsQuery->fetchAll();
    if (count($recipients) !== count($studentIds)) {
        yu_fail(400, 'One or more selected student records no longer exist. Refresh the dashboard and try again.');
    }
    foreach ($recipients as $recipient) {
        if (!filter_var((string) $recipient['email'], FILTER_VALIDATE_EMAIL)) {
            yu_fail(400, 'A selected student does not have a valid email address.');
        }
    }

    try {
        yu_smtp_configuration();
    } catch (Throwable $error) {
        error_log('Yuitor student email configuration error: ' . $error->getMessage());
        yu_fail(503, 'Student email is unavailable. Enable PHP OpenSSL and stream-socket support, then set the private YU_SMTP_HOST, YU_SMTP_PORT, YU_SMTP_USERNAME, YU_SMTP_PASSWORD, and YU_SMTP_ENCRYPTION settings on the hosting account.');
    }

    $sent = 0;
    $failed = 0;
    foreach ($recipients as $recipient) {
        try {
            yu_smtp_send_message((string) $recipient['email'], $subject, $body);
            $sent++;
        } catch (Throwable $error) {
            error_log('Yuitor student email delivery failed for student id ' . (int) $recipient['id'] . ': ' . $error->getMessage());
            $failed++;
        }
    }
    if ($sent === 0) {
        yu_fail(502, 'No student emails were confirmed by the SMTP server. Check the private SMTP settings and hosting server logs.');
    }
    yu_json(200, array(
        'sent' => $sent,
        'failed' => $failed,
        'message' => $failed > 0
            ? $sent . ' email(s) sent; ' . $failed . ' could not be sent.'
            : $sent . ' email(s) sent successfully.',
    ));
}

if ($action === 'save-festival-config') {
    $config = yu_save_festival_config($db, $input);
    yu_json(200, array('config' => $config, 'message' => 'Festival theme settings saved.'));
}

if ($action === 'restore-festival-defaults') {
    $clearOverrides = !empty($input['clearOverrides']);
    $current = yu_get_festival_config($db);
    $config = yu_save_festival_config($db, array(
        'mode' => 'automatic',
        'manualFestivalId' => null,
        'simulatedDateIST' => null,
        'overrides' => $clearOverrides ? array() : $current['overrides'],
    ));
    yu_json(200, array('config' => $config, 'message' => 'Automatic Indian festival calendar restored.'));
}

yu_fail(404, 'Unknown admin action.');
