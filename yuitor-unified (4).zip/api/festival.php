<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
yu_api_init();

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') {
    header('Allow: GET');
    yu_fail(405, 'Method not allowed.');
}

try {
    $db = yu_db();
    yu_json(200, array('config' => yu_get_festival_config($db)));
} catch (Throwable $error) {
    error_log('Yuitor festival config error: ' . $error->getMessage());
    yu_json(200, array(
        'config' => array(
            'mode' => 'automatic',
            'manualFestivalId' => null,
            'simulatedDateIST' => null,
            'overrides' => new stdClass(),
        ),
    ));
}
