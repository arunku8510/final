<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
yu_api_init();

try {
    $db = yu_db();
} catch (Throwable $error) {
    error_log('Yuitor portal database error: ' . $error->getMessage());
    yu_json(503, array(
        'error' => 'Pre-installation checks found a server issue. Fix the items marked as errors below, then reload this page.',
        'checks' => yu_installation_checks($error->getMessage()),
    ));
}

$adminCount = (int) $db->query('SELECT COUNT(*) FROM admins')->fetchColumn();
$checks = yu_installation_checks();
$checksReady = true;
foreach ($checks as $check) {
    if ($check['status'] === 'error') {
        $checksReady = false;
        break;
    }
}
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

if ($method === 'GET') {
    yu_json(200, array(
        'setupAvailable' => $adminCount === 0 && $checksReady,
        'adminExists' => $adminCount > 0,
        'checks' => $checks,
        'csrfToken' => yu_csrf_token(),
    ));
}

if ($method !== 'POST') {
    header('Allow: GET, POST');
    yu_fail(405, 'Method not allowed.');
}

yu_require_same_origin();
$input = yu_read_json();
yu_require_csrf();
if ($adminCount > 0) {
    yu_fail(409, 'Admin setup is already complete. Use the Admin sign-in page.');
}

$name = yu_text($input, 'displayName', 120, true);
$email = yu_email(yu_text($input, 'email', 254, true));
$phone = yu_text($input, 'phone', 10, true);
$password = yu_text($input, 'password', 200, true);
if (strlen($name) < 2) {
    yu_fail(400, 'Enter the admin full name.');
}
if (!yu_valid_indian_mobile($phone)) {
    yu_fail(400, 'Enter a valid Indian mobile number: exactly 10 digits, starting with 6, 7, 8, or 9.');
}
$passwordError = yu_password_policy_error($password);
if ($passwordError !== '') {
    yu_fail(400, $passwordError);
}

$rateIdentity = (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . '|' . $email;
yu_check_login_limit($db, 'setup', $rateIdentity);

try {
    $db->exec('BEGIN IMMEDIATE TRANSACTION');
    if ((int) $db->query('SELECT COUNT(*) FROM admins')->fetchColumn() > 0) {
        $db->exec('ROLLBACK');
        yu_fail(409, 'Admin setup is already complete. Use the Admin sign-in page.');
    }
    $insert = $db->prepare(
        'INSERT INTO admins (display_name, email, phone, password_hash, created_at)
         VALUES (?, ?, ?, ?, ?)'
    );
    $insert->execute(array($name, $email, $phone, password_hash($password, PASSWORD_DEFAULT), gmdate('c')));
    $db->exec('COMMIT');
} catch (PDOException $error) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    if (stripos($error->getMessage(), 'unique') !== false) {
        yu_fail(409, 'An admin account already exists for this email.');
    }
    error_log('Yuitor admin setup error: ' . $error->getMessage());
    yu_fail(500, 'The admin account could not be created.');
} catch (Throwable $error) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Yuitor admin setup error: ' . $error->getMessage());
    yu_fail(500, 'The admin account could not be created.');
}

yu_clear_login_failures($db, 'setup', $rateIdentity);
unset($_SESSION['yu_admin_setup_authorized_at']);
yu_json(201, array('created' => true, 'message' => 'Admin account created. Sign in to continue.'));
