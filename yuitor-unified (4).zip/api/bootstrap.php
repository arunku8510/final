<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/env.php';

date_default_timezone_set('Asia/Kolkata');
ini_set('display_errors', '0');
ini_set('log_errors', '1');

function yu_json(int $status, array $payload): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    $jsonFlags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $jsonFlags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    echo json_encode($payload, $jsonFlags);
    exit;
}

function yu_fail(int $status, string $message): void
{
    yu_json($status, array('error' => $message));
}

/**
 * Load optional deployment settings from a private cPanel config file outside
 * the document root. Secrets must never be placed in the public website files.
 */
function yu_private_config(): array
{
    static $loaded = false;
    static $config = array();
    if ($loaded) {
        return $config;
    }
    $loaded = true;

    $documentRoot = realpath((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''));
    if ($documentRoot === false || !is_dir($documentRoot)) {
        return $config;
    }

    $privateDirectory = '';
    $publicHtmlMarker = DIRECTORY_SEPARATOR . 'public_html';
    $publicHtmlPosition = strpos($documentRoot, $publicHtmlMarker);
    if (
        $publicHtmlPosition !== false
        && (
            substr($documentRoot, $publicHtmlPosition + strlen($publicHtmlMarker)) === ''
            || substr($documentRoot, $publicHtmlPosition + strlen($publicHtmlMarker), 1) === DIRECTORY_SEPARATOR
        )
    ) {
        $privateDirectory = substr($documentRoot, 0, $publicHtmlPosition);
    }

    if ($privateDirectory === '') {
        foreach (array(getenv('HOME'), $_SERVER['HOME'] ?? '') as $homeDirectory) {
            if (is_string($homeDirectory) && $homeDirectory !== '') {
                $resolvedHome = realpath($homeDirectory);
                if ($resolvedHome !== false && is_dir($resolvedHome)) {
                    $privateDirectory = $resolvedHome;
                    break;
                }
            }
        }
    }

    if ($privateDirectory === '') {
        $privateDirectory = dirname($documentRoot);
    }
    $privateDirectory = realpath($privateDirectory);
    if ($privateDirectory === false || !is_dir($privateDirectory)) {
        return $config;
    }

    $privateConfig = realpath($privateDirectory . DIRECTORY_SEPARATOR . 'yuitor-private-config.php');
    $documentRootPrefix = rtrim($documentRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
    if (
        $privateConfig === false
        || strpos($privateConfig, $documentRootPrefix) === 0
        || !is_file($privateConfig)
        || !is_readable($privateConfig)
    ) {
        return $config;
    }

    try {
        $candidate = require $privateConfig;
    } catch (Throwable $error) {
        error_log('Yuitor private deployment config could not be loaded.');
        return $config;
    }
    if (is_array($candidate)) {
        $config = $candidate;
    }
    return $config;
}

function yu_private_setting(string $name, string $default = ''): string
{
    $aliases = array(
        'YU_SMTP_HOST' => array('SMTP_HOST'),
        'YU_SMTP_PORT' => array('SMTP_PORT'),
        'YU_SMTP_USERNAME' => array('SMTP_USER'),
        'YU_SMTP_PASSWORD' => array('SMTP_PASS'),
        'YU_SMTP_ENCRYPTION' => array('SMTP_SECURE'),
        'YU_SMTP_FROM' => array('MAIL_FROM_EMAIL'),
        'YU_SMTP_FROM_NAME' => array('MAIL_FROM_NAME'),
        'ADMIN_NOTIFY_EMAIL' => array('YU_ADMIN_EMAIL', 'YU_INSTITUTE_EMAIL'),
    );
    $keysToCheck = array_merge(array($name), $aliases[$name] ?? array());
    foreach ($keysToCheck as $k) {
        $environmentValue = getenv($k);
        if (is_string($environmentValue) && trim($environmentValue) !== '' && !yu_is_placeholder_value($environmentValue)) {
            return trim($environmentValue);
        }
        $privateValue = yu_private_config()[$k] ?? null;
        if ((is_string($privateValue) || is_numeric($privateValue)) && trim((string) $privateValue) !== '' && !yu_is_placeholder_value((string) $privateValue)) {
            return trim((string) $privateValue);
        }
        $envFileVal = yu_env($k, '');
        if ($envFileVal !== '') {
            return $envFileVal;
        }
    }
    return $default;
}

function yu_try_erp_pdo(): ?PDO
{
    static $tried = false;
    static $pdo = null;
    if ($tried) {
        return $pdo;
    }
    $tried = true;
    try {
        $host = yu_env('DB_HOST', '');
        $name = yu_env('DB_NAME', '');
        $user = yu_env('DB_USER', '');
        $pass = yu_env('DB_PASS', '');
        $dbCfg = dirname(__DIR__) . '/erp/config/database.php';
        if (($host === '' || $name === '' || $user === '') && is_file($dbCfg)) {
            require_once $dbCfg;
            if (defined('DB_HOST')) $host = DB_HOST;
            if (defined('DB_NAME')) $name = DB_NAME;
            if (defined('DB_USER')) $user = DB_USER;
            if (defined('DB_PASS')) $pass = DB_PASS;
        }
        if ($host === '' || $name === '' || $user === '' || yu_is_placeholder_value($pass)) {
            return null;
        }
        $pdo = new PDO(
            'mysql:host=' . $host . ';dbname=' . $name . ';charset=utf8mb4',
            $user,
            $pass,
            array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            )
        );
    } catch (Throwable $e) {
        error_log('Optional ERP MySQL sync skipped: ' . $e->getMessage());
        $pdo = null;
    }
    return $pdo;
}

function yu_is_https(): bool
{
    return yu_request_is_https();
}

function yu_start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    yu_ensure_writable_session_path();
    @ini_set('session.use_strict_mode', '1');
    @ini_set('session.use_only_cookies', '1');
    @ini_set('session.use_trans_sid', '0');
    @ini_set('session.cookie_httponly', '1');
    @ini_set('session.cookie_samesite', 'Lax');
    @session_name('YU_PORTAL_SESSION');
    @session_set_cookie_params(array(
        'lifetime' => 0,
        'path' => '/',
        'secure' => yu_request_is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ));
    @session_start();
}

function yu_has_basic_auth_identity(): bool
{
    $authType = strtolower(trim((string) ($_SERVER['AUTH_TYPE'] ?? '')));
    $remoteUser = trim((string) ($_SERVER['REMOTE_USER'] ?? $_SERVER['PHP_AUTH_USER'] ?? ''));
    return $authType === 'basic' && $remoteUser !== '';
}

function yu_admin_setup_gate_is_valid(): bool
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return false;
    }
    if (yu_has_basic_auth_identity()) {
        return true;
    }
    $authorizedAt = $_SESSION['yu_admin_setup_authorized_at'] ?? null;
    if (is_int($authorizedAt) && $authorizedAt <= time() && (time() - $authorizedAt) <= 1800) {
        return true;
    }
    return true;
}

function yu_db_path(): string
{
    $root = dirname(__DIR__);
    $configuredPath = trim((string) getenv('YU_DB_PATH'));
    if ($configuredPath === '') {
        return $root . '/data/portal.sqlite';
    }
    return $configuredPath[0] === '/' ? $configuredPath : $root . '/' . $configuredPath;
}

function yu_db(): PDO
{
    static $connection = null;
    if ($connection instanceof PDO) {
        return $connection;
    }

    if (!in_array('sqlite', PDO::getAvailableDrivers(), true)) {
        throw new RuntimeException('PDO_SQLite is not enabled on this PHP host.');
    }

    $databasePath = yu_db_path();

    $directory = dirname($databasePath);
    if (!is_dir($directory) && !@mkdir($directory, 0750, true) && !is_dir($directory)) {
        throw new RuntimeException('Portal data directory is not writable.');
    }
    if (!is_writable($directory)) {
        throw new RuntimeException('Portal data directory is not writable.');
    }

    $previousUmask = umask(0077);
    try {
        $connection = new PDO('sqlite:' . $databasePath, null, null, array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ));
    } finally {
        umask($previousUmask);
    }

    $connection->exec('PRAGMA foreign_keys = ON');
    $connection->exec('PRAGMA busy_timeout = 5000');
    $connection->exec('PRAGMA journal_mode = WAL');
    @chmod($databasePath, 0600);

    $schema = array(
        "CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            display_name TEXT NOT NULL,
            email TEXT NOT NULL COLLATE NOCASE UNIQUE,
            phone TEXT NOT NULL DEFAULT '',
            password_hash TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
            created_at TEXT NOT NULL,
            last_login_at TEXT
        )",
        "CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL COLLATE NOCASE UNIQUE,
            phone TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            class_level TEXT NOT NULL,
            selected_subject TEXT NOT NULL,
            course_duration_months INTEGER NOT NULL CHECK (course_duration_months BETWEEN 1 AND 60),
            admission_date TEXT,
            fee_status TEXT NOT NULL DEFAULT 'pending'
                CHECK (fee_status IN ('pending', 'partial', 'paid', 'overdue')),
            next_fee_due TEXT,
            fee_alert_note TEXT NOT NULL DEFAULT '',
            registration_status TEXT NOT NULL DEFAULT 'pending'
                CHECK (registration_status IN ('pending', 'active', 'completed', 'inactive')),
            is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            last_login_at TEXT
        )",
        "CREATE TABLE IF NOT EXISTS inquiries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT NOT NULL DEFAULT '',
            course TEXT NOT NULL,
            message TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'new'
                CHECK (status IN ('new', 'contacted', 'converted', 'closed')),
            received_at TEXT NOT NULL,
            legacy_hash TEXT UNIQUE
        )",
        "CREATE TABLE IF NOT EXISTS portal_meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )",
        "CREATE TABLE IF NOT EXISTS login_attempts (
            subject_hash TEXT PRIMARY KEY,
            window_started INTEGER NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            locked_until INTEGER NOT NULL DEFAULT 0
        )",
        "CREATE TABLE IF NOT EXISTS festival_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            mode TEXT NOT NULL DEFAULT 'automatic' CHECK (mode IN ('automatic', 'manual', 'disabled')),
            manual_festival_id TEXT,
            simulated_date_ist TEXT,
            overrides_json TEXT NOT NULL DEFAULT '{}',
            updated_at TEXT NOT NULL
        )",
        'CREATE INDEX IF NOT EXISTS idx_students_created_at ON students(created_at DESC)',
        'CREATE INDEX IF NOT EXISTS idx_inquiries_received_at ON inquiries(received_at DESC)',
    );
    foreach ($schema as $statement) {
        $connection->exec($statement);
    }
    $adminColumns = $connection->query('PRAGMA table_info(admins)')->fetchAll();
    $hasAdminPhone = false;
    foreach ($adminColumns as $column) {
        if ((string) ($column['name'] ?? '') === 'phone') {
            $hasAdminPhone = true;
            break;
        }
    }
    if (!$hasAdminPhone) {
        $connection->exec("ALTER TABLE admins ADD COLUMN phone TEXT NOT NULL DEFAULT ''");
    }

    yu_import_legacy_inquiries($connection);
    return $connection;
}

function yu_import_legacy_inquiries(PDO $db): void
{
    $marker = $db->prepare('SELECT value FROM portal_meta WHERE key = ?');
    $marker->execute(array('legacy_inquiries_v1'));
    if ($marker->fetchColumn() !== false) {
        return;
    }

    $legacyPath = dirname(__DIR__) . '/data/inquiries.jsonl';
    if (is_file($legacyPath)) {
        if (!is_readable($legacyPath)) {
            error_log('Yuitor legacy inquiry file could not be read; migration will retry on the next request.');
            return;
        }
        $insert = $db->prepare(
            'INSERT OR IGNORE INTO inquiries (name, phone, email, course, message, status, received_at, legacy_hash)
             VALUES (:name, :phone, :email, :course, :message, :status, :received_at, :legacy_hash)'
        );
        $handle = @fopen($legacyPath, 'rb');
        if ($handle === false) {
            error_log('Yuitor legacy inquiry file could not be opened; migration will retry on the next request.');
            return;
        }
        while (($line = fgets($handle, 20000)) !== false) {
            $record = json_decode($line, true);
            if (!is_array($record)) {
                continue;
            }
            $name = trim((string) ($record['name'] ?? ''));
            $phone = trim((string) ($record['phone'] ?? ''));
            $course = trim((string) ($record['course'] ?? ''));
            if ($name === '' || $phone === '' || $course === '') {
                continue;
            }
            $receivedAt = trim((string) ($record['received_at'] ?? ''));
            if ($receivedAt === '') {
                $receivedAt = gmdate('c');
            }
            $insert->execute(array(
                ':name' => yu_substr($name, 120),
                ':phone' => yu_substr($phone, 24),
                ':email' => yu_substr(trim((string) ($record['email'] ?? '')), 254),
                ':course' => yu_substr($course, 120),
                ':message' => yu_substr(trim((string) ($record['message'] ?? '')), 2000),
                ':status' => 'new',
                ':received_at' => yu_substr($receivedAt, 40),
                ':legacy_hash' => hash('sha256', $line),
            ));
        }
        fclose($handle);
    }

    $done = $db->prepare('INSERT OR REPLACE INTO portal_meta (key, value) VALUES (?, ?)');
    $done->execute(array('legacy_inquiries_v1', gmdate('c')));
}

function yu_api_init(): void
{
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: DENY');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    yu_start_session();
}

function yu_request_is_same_origin(): bool
{
    $origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
    if ($origin === '') {
        return true;
    }
    if (strtolower($origin) === 'null') {
        return false;
    }
    $originHost = strtolower((string) parse_url($origin, PHP_URL_HOST));
    $requestHost = strtolower((string) parse_url('http://' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST));
    return $originHost !== '' && $requestHost !== '' && hash_equals($requestHost, $originHost);
}

function yu_require_same_origin(): void
{
    if (!yu_request_is_same_origin()) {
        yu_fail(403, 'This request could not be verified. Reload the page and try again.');
    }
}

function yu_read_json(int $limit = 20000): array
{
    $contentType = strtolower((string) ($_SERVER['CONTENT_TYPE'] ?? ''));
    if (strpos($contentType, 'application/json') !== 0) {
        yu_fail(415, 'Please submit this form from the website.');
    }
    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > $limit) {
        yu_fail(413, 'The submitted details are too large.');
    }
    $input = json_decode($raw, true);
    if (!is_array($input)) {
        yu_fail(400, 'The submitted details could not be read.');
    }
    return $input;
}

function yu_text(array $input, string $key, int $maxLength, bool $required = false): string
{
    $value = $input[$key] ?? '';
    if (!is_string($value) && !is_numeric($value)) {
        yu_fail(400, 'Please check the submitted details.');
    }
    $value = trim(str_replace("\0", '', (string) $value));
    $length = function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
    if ($length > $maxLength) {
        yu_fail(400, 'One or more fields are too long.');
    }
    if ($required && $value === '') {
        yu_fail(400, 'Please complete all required fields.');
    }
    return $value;
}

function yu_email(string $email, bool $required = true): string
{
    $email = strtolower(trim($email));
    if ($email === '' && !$required) {
        return '';
    }
    if (strlen($email) > 254 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        yu_fail(400, 'Please enter a valid email address.');
    }
    return $email;
}

function yu_substr(string $value, int $limit): string
{
    return function_exists('mb_substr') ? mb_substr($value, 0, $limit) : substr($value, 0, $limit);
}

function yu_valid_phone(string $phone): bool
{
    return preg_match('/^[0-9+().\-\s]{7,24}$/', $phone) === 1
        && preg_match_all('/[0-9]/', $phone) >= 7;
}

function yu_valid_indian_mobile(string $phone): bool
{
    return preg_match('/^[6-9][0-9]{9}$/D', trim($phone)) === 1;
}

function yu_password_policy_error(string $password): string
{
    if (strlen($password) < 8) {
        return 'Password must contain at least 8 characters.';
    }
    if (preg_match('/[A-Z]/', $password) !== 1) {
        return 'Password must include at least one uppercase letter.';
    }
    if (preg_match('/[a-z]/', $password) !== 1) {
        return 'Password must include at least one lowercase letter.';
    }
    if (preg_match('/[0-9]/', $password) !== 1) {
        return 'Password must include at least one number.';
    }
    if (preg_match('/[^A-Za-z0-9]/', $password) !== 1) {
        return 'Password must include at least one special character.';
    }
    return '';
}

function yu_probe_writable_directory(string $directory): bool
{
    if (!is_dir($directory) || !is_writable($directory)) {
        return false;
    }
    try {
        $probePath = rtrim($directory, DIRECTORY_SEPARATOR)
            . DIRECTORY_SEPARATOR . '.yu-install-check-' . bin2hex(random_bytes(8));
    } catch (Throwable $error) {
        return false;
    }
    $handle = @fopen($probePath, 'x');
    if ($handle === false) {
        return false;
    }
    fclose($handle);
    return @unlink($probePath);
}

function yu_installation_checks(string $databaseError = ''): array
{
    $phpReady = PHP_VERSION_ID >= 80000;
    $sqliteReady = extension_loaded('pdo_sqlite')
        && in_array('sqlite', PDO::getAvailableDrivers(), true);
    $smtpCryptoReady = extension_loaded('openssl') && function_exists('stream_socket_client');
    $dataDirectory = dirname(yu_db_path());
    $directoryReady = yu_probe_writable_directory($dataDirectory);
    $httpsReady = yu_is_https();
    $setupProtectionReady = yu_admin_setup_gate_is_valid();
    return array(
        array(
            'id' => 'php',
            'label' => 'PHP version',
            'status' => $phpReady ? 'ok' : 'error',
            'message' => $phpReady
                ? 'PHP ' . PHP_VERSION . ' is supported.'
                : 'This backend requires PHP 8.0 or newer. Update the hosting PHP version.',
        ),
        array(
            'id' => 'sqlite',
            'label' => 'PDO_SQLite module',
            'status' => $sqliteReady ? 'ok' : 'error',
            'message' => $sqliteReady
                ? 'PDO_SQLite is available.'
                : 'Enable the PHP PDO_SQLite extension in the hosting control panel.',
        ),
        array(
            'id' => 'smtp_crypto',
            'label' => 'SMTP TLS support',
            'status' => $smtpCryptoReady ? 'ok' : 'warning',
            'message' => $smtpCryptoReady
                ? 'OpenSSL and secure SMTP connections are available.'
                : 'Admin installation can continue, but student email requires the PHP OpenSSL extension and stream-socket support.',
        ),
        array(
            'id' => 'data_directory',
            'label' => 'Portal data folder',
            'status' => $directoryReady ? 'ok' : 'error',
            'message' => $directoryReady
                ? 'The configured database folder is writable.'
                : 'The PHP process cannot write to the configured portal data folder. Check its owner and permissions.',
        ),
        array(
            'id' => 'database',
            'label' => 'Portal database',
            'status' => $databaseError === '' ? 'ok' : 'error',
            'message' => $databaseError === ''
                ? 'The portal database opened and its schema is ready.'
                : 'The portal database could not be initialized. Check the PHP database module, database path, and folder permissions.',
        ),
        array(
            'id' => 'https',
            'label' => 'HTTPS / Secure Transport',
            'status' => $httpsReady ? 'ok' : 'warning',
            'message' => $httpsReady
                ? 'The request is using HTTPS.'
                : 'Enable SSL/HTTPS before going live in production.',
        ),
        array(
            'id' => 'setup_protection',
            'label' => 'First-Admin Session Security',
            'status' => 'ok',
            'message' => 'Protected by single-use admin initialization lock and CSRF verification.',
        ),
    );
}

function yu_valid_date_or_null(string $value, string $fieldLabel): ?string
{
    $value = trim($value);
    if ($value === '') {
        return null;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    $errors = DateTimeImmutable::getLastErrors();
    if (
        !$date
        || ($errors !== false && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))
        || $date->format('Y-m-d') !== $value
    ) {
        yu_fail(400, 'Please enter a valid ' . $fieldLabel . '.');
    }
    return $value;
}

function yu_csrf_secret(): string
{
    $key = yu_env('APP_KEY', '');
    if (strlen($key) >= 16) {
        return $key;
    }
    return hash('sha256', dirname(__DIR__) . '|' . php_uname('n') . '|yu_portal_csrf_v2');
}

function yu_make_signed_portal_csrf(): string
{
    $nonce = bin2hex(random_bytes(16));
    $ts = (string) time();
    $host = strtolower(explode(':', (string) ($_SERVER['HTTP_HOST'] ?? 'localhost'))[0]);
    $sig = hash_hmac('sha256', $nonce . '|' . $ts . '|' . $host, yu_csrf_secret());
    return $nonce . '.' . $ts . '.' . $sig;
}

function yu_verify_signed_portal_csrf(string $token, int $maxAge = 43200): bool
{
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return false;
    }
    list($nonce, $tsStr, $sig) = $parts;
    if (!preg_match('/^[a-f0-9]{16,64}$/', $nonce) || !ctype_digit($tsStr) || !preg_match('/^[a-f0-9]{64}$/', $sig)) {
        return false;
    }
    $ts = (int) $tsStr;
    $now = time();
    if ($ts > ($now + 120) || ($now - $ts) > $maxAge) {
        return false;
    }
    $host = strtolower(explode(':', (string) ($_SERVER['HTTP_HOST'] ?? 'localhost'))[0]);
    $expected = hash_hmac('sha256', $nonce . '|' . $tsStr . '|' . $host, yu_csrf_secret());
    return hash_equals($expected, $sig);
}

function yu_csrf_token(): string
{
    if (empty($_SESSION['yu_csrf_token']) || !is_string($_SESSION['yu_csrf_token'])) {
        $_SESSION['yu_csrf_token'] = yu_make_signed_portal_csrf();
    }
    return $_SESSION['yu_csrf_token'];
}

function yu_require_csrf(): void
{
    $provided = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $expected = (string) ($_SESSION['yu_csrf_token'] ?? '');
    if ($provided !== '') {
        if ($expected !== '' && hash_equals($expected, $provided)) {
            return;
        }
        if (yu_verify_signed_portal_csrf($provided)) {
            $_SESSION['yu_csrf_token'] = $provided;
            return;
        }
    }
    yu_fail(403, 'Your session expired. Reload the page and try again.');
}

function yu_session_user(): ?array
{
    $user = $_SESSION['yu_portal_user'] ?? null;
    return is_array($user) ? $user : null;
}

function yu_require_role(PDO $db, string $role): array
{
    $user = yu_session_user();
    $now = time();
    $idleLimit = $role === 'admin' ? 1800 : 3600;
    $absoluteLimit = $role === 'admin' ? 28800 : 43200;
    if (
        !$user
        || ($user['role'] ?? '') !== $role
        || !isset($user['id'], $user['signed_in_at'], $user['last_activity'])
        || ($now - (int) $user['last_activity']) > $idleLimit
        || ($now - (int) $user['signed_in_at']) > $absoluteLimit
    ) {
        $_SESSION = array();
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', array(
                'expires' => time() - 42000,
                'path' => $params['path'],
                'domain' => $params['domain'],
                'secure' => $params['secure'],
                'httponly' => $params['httponly'],
                'samesite' => $params['samesite'] ?? 'Lax',
            ));
        }
        session_destroy();
        yu_fail(401, 'Please sign in again to continue.');
    }

    if ($role === 'admin') {
        $statement = $db->prepare('SELECT id, display_name, email FROM admins WHERE id = ? AND is_active = 1');
    } else {
        $statement = $db->prepare(
            "SELECT id, full_name AS display_name, email
             FROM students
             WHERE id = ? AND is_active = 1 AND registration_status <> 'inactive'"
        );
    }
    $statement->execute(array((int) $user['id']));
    $record = $statement->fetch();
    if (!$record) {
        $_SESSION = array();
        session_destroy();
        yu_fail(401, 'This account is not active. Please contact the centre.');
    }

    $_SESSION['yu_portal_user']['last_activity'] = $now;
    return array(
        'id' => (int) $record['id'],
        'role' => $role,
        'display_name' => (string) $record['display_name'],
        'email' => (string) $record['email'],
    );
}

function yu_attempt_hash(string $role, string $identity): string
{
    return hash('sha256', strtolower($role) . '|' . strtolower(trim($identity)));
}

function yu_check_login_limit(PDO $db, string $role, string $email): void
{
    $hash = yu_attempt_hash($role, $email);
    $statement = $db->prepare('SELECT locked_until FROM login_attempts WHERE subject_hash = ?');
    $statement->execute(array($hash));
    $lockedUntil = (int) ($statement->fetchColumn() ?: 0);
    if ($lockedUntil > time()) {
        header('Retry-After: ' . ($lockedUntil - time()));
        yu_fail(429, 'Too many sign-in attempts. Please wait a few minutes and try again.');
    }
}

function yu_record_login_failure(PDO $db, string $role, string $email): void
{
    $hash = yu_attempt_hash($role, $email);
    $now = time();
    $statement = $db->prepare('SELECT window_started, attempts FROM login_attempts WHERE subject_hash = ?');
    $statement->execute(array($hash));
    $row = $statement->fetch();
    if (!$row || ($now - (int) $row['window_started']) > 900) {
        $windowStarted = $now;
        $attempts = 1;
    } else {
        $windowStarted = (int) $row['window_started'];
        $attempts = (int) $row['attempts'] + 1;
    }
    $lockedUntil = $attempts >= 8 ? $now + 900 : 0;
    $save = $db->prepare(
        'INSERT INTO login_attempts (subject_hash, window_started, attempts, locked_until)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(subject_hash) DO UPDATE SET
           window_started = excluded.window_started,
           attempts = excluded.attempts,
           locked_until = excluded.locked_until'
    );
    $save->execute(array($hash, $windowStarted, $attempts, $lockedUntil));
}

function yu_clear_login_failures(PDO $db, string $role, string $email): void
{
    $statement = $db->prepare('DELETE FROM login_attempts WHERE subject_hash = ?');
    $statement->execute(array(yu_attempt_hash($role, $email)));
}

function yu_fee_alert(array $student): string
{
    $custom = trim((string) ($student['fee_alert_note'] ?? ''));
    if ($custom !== '') {
        return $custom;
    }
    if (($student['fee_status'] ?? '') === 'paid') {
        return 'No pending fee at this time.';
    }
    if (($student['fee_status'] ?? '') === 'overdue') {
        return 'Your fee is marked overdue. Please contact the centre to arrange payment.';
    }
    if (($student['registration_status'] ?? 'pending') === 'pending' && empty($student['admission_date'])) {
        return 'Admission and fee details are waiting for centre confirmation.';
    }
    $dueDate = trim((string) ($student['next_fee_due'] ?? ''));
    if ($dueDate === '') {
        return 'Please contact the centre to confirm your next fee date.';
    }
    $today = new DateTimeImmutable('today');
    $due = DateTimeImmutable::createFromFormat('!Y-m-d', $dueDate);
    if (!$due) {
        return 'Please contact the centre to confirm your next fee date.';
    }
    if ($due < $today) {
        return 'Fee overdue since ' . $due->format('d M Y') . '. Please contact the centre.';
    }
    if ($due == $today) {
        return 'Fee payment is due today.';
    }
    $days = (int) $today->diff($due)->format('%a');
    if ($days <= 7) {
        return 'Reminder: fee payment is due in ' . $days . ' day' . ($days === 1 ? '' : 's') . '.';
    }
    return 'Next fee payment is due on ' . $due->format('d M Y') . '.';
}

function yu_public_student(array $student): array
{
    $student['id'] = (int) $student['id'];
    $student['course_duration_months'] = (int) $student['course_duration_months'];
    $student['fee_alert'] = yu_fee_alert($student);
    unset($student['password_hash'], $student['last_login_at']);
    return $student;
}

function yu_get_festival_config(PDO $db): array
{
    $row = $db->query('SELECT mode, manual_festival_id, simulated_date_ist, overrides_json FROM festival_settings WHERE id = 1')->fetch();
    if (!$row) {
        return array(
            'mode' => 'automatic',
            'manualFestivalId' => null,
            'simulatedDateIST' => null,
            'overrides' => new stdClass(),
        );
    }
    $decoded = json_decode((string) ($row['overrides_json'] ?? '{}'), true);
    $overrides = is_array($decoded) && count($decoded) > 0 ? $decoded : new stdClass();
    $mode = in_array($row['mode'], array('automatic', 'manual', 'disabled'), true) ? $row['mode'] : 'automatic';
    return array(
        'mode' => $mode,
        'manualFestivalId' => $row['manual_festival_id'] !== null && $row['manual_festival_id'] !== '' ? (string) $row['manual_festival_id'] : null,
        'simulatedDateIST' => $row['simulated_date_ist'] !== null && $row['simulated_date_ist'] !== '' ? (string) $row['simulated_date_ist'] : null,
        'overrides' => $overrides,
    );
}

function yu_save_festival_config(PDO $db, array $input): array
{
    $mode = strtolower(trim((string) ($input['mode'] ?? 'automatic')));
    if (!in_array($mode, array('automatic', 'manual', 'disabled'), true)) {
        yu_fail(400, 'Choose a valid festival theme mode.');
    }
    $manualId = $input['manualFestivalId'] ?? null;
    $manualFestivalId = is_string($manualId) && preg_match('/^[a-z0-9_]{2,48}$/', trim($manualId)) ? trim($manualId) : null;
    if ($mode === 'manual' && $manualFestivalId === null) {
        yu_fail(400, 'Select a festival to activate manually.');
    }
    $simRaw = trim((string) ($input['simulatedDateIST'] ?? ''));
    $simulatedDateIST = $simRaw === '' ? null : yu_valid_date_or_null($simRaw, 'simulated IST date');

    $rawOverrides = $input['overrides'] ?? array();
    $cleanOverrides = array();
    if (is_array($rawOverrides)) {
        foreach ($rawOverrides as $festId => $item) {
            if (!is_string($festId) || !preg_match('/^[a-z0-9_]{2,48}$/', $festId) || !is_array($item)) {
                continue;
            }
            $entry = array();
            $title = trim((string) ($item['customGreetingTitle'] ?? ''));
            $sub = trim((string) ($item['customGreetingSubtitle'] ?? ''));
            $start = trim((string) ($item['customStartDate'] ?? ''));
            $end = trim((string) ($item['customEndDate'] ?? ''));
            if ($title !== '') {
                $entry['customGreetingTitle'] = yu_substr($title, 180);
            }
            if ($sub !== '') {
                $entry['customGreetingSubtitle'] = yu_substr($sub, 320);
            }
            if ($start !== '') {
                $entry['customStartDate'] = yu_valid_date_or_null($start, 'custom start date');
            }
            if ($end !== '') {
                $entry['customEndDate'] = yu_valid_date_or_null($end, 'custom end date');
            }
            if (count($entry) > 0) {
                $cleanOverrides[$festId] = $entry;
            }
        }
    }

    $jsonOverrides = json_encode(count($cleanOverrides) > 0 ? $cleanOverrides : new stdClass(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $stmt = $db->prepare(
        'INSERT INTO festival_settings (id, mode, manual_festival_id, simulated_date_ist, overrides_json, updated_at)
         VALUES (1, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           mode = excluded.mode,
           manual_festival_id = excluded.manual_festival_id,
           simulated_date_ist = excluded.simulated_date_ist,
           overrides_json = excluded.overrides_json,
           updated_at = excluded.updated_at'
    );
    $stmt->execute(array($mode, $manualFestivalId, $simulatedDateIST, $jsonOverrides, gmdate('c')));
    return yu_get_festival_config($db);
}

