(() => {
  "use strict";
  if (document.getElementById("yu-ai-guide-root")) return;

  let csrfToken = "";

  async function safeJson(res) {
    const raw = await res.text();
    try {
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  async function refreshCsrf(force = false) {
    if (csrfToken && !force) return csrfToken;
    for (const ep of ["/api/csrf.php", "/api/csrf"]) {
      try {
        const res = await fetch(ep, {
          credentials: "same-origin",
          cache: "no-store",
          headers: { Accept: "application/json" },
        });
        if (!res.ok) continue;
        const data = await safeJson(res);
        if (data && typeof data.csrf_token === "string" && data.csrf_token) {
          csrfToken = data.csrf_token;
          return csrfToken;
        }
      } catch {
        // try next endpoint
      }
    }
    return csrfToken;
  }

  refreshCsrf(false);

  const root = document.createElement("div");
  root.id = "yu-ai-guide-root";
  root.style.cssText = "position:fixed;bottom:92px;right:20px;z-index:9999;font-family:system-ui,-apple-system,sans-serif;";

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.id = "yu-smart-ai-toggle";
  toggle.textContent = "Yuitor Smart AI";
  toggle.style.cssText = "background:#0f172a;color:#fff;border:2px solid #12a1a1;padding:11px 18px;border-radius:999px;font-weight:700;font-size:14px;cursor:pointer;box-shadow:0 10px 25px rgba(15,23,42,.28);";

  const box = document.createElement("div");
  box.hidden = true;
  box.style.cssText = "width:360px;max-width:calc(100vw - 32px);background:#fff;border:1px solid #cbd9e6;border-radius:16px;box-shadow:0 18px 40px rgba(15,23,42,.24);overflow:hidden;margin-bottom:10px;";

  box.innerHTML = `
    <div style="background:#0f172a;color:#fff;padding:12px 14px;display:flex;justify-content:space-between;align-items:center;">
      <div>
        <div style="font-weight:700;font-size:14.5px;">Yuitor Smart AI</div>
        <div style="font-size:11px;color:#78d3d3;">Courses, A-to-Z Fees, Discounts, Admission &amp; ERP</div>
      </div>
      <button type="button" id="yu-chat-close" style="background:none;border:0;color:#fff;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
    </div>
    <div id="yu-chat-msgs" style="height:275px;overflow-y:auto;padding:12px;background:#f5f9fc;display:flex;flex-direction:column;gap:8px;font-size:13px;line-height:1.48;">
      <div style="background:#fff;border:1px solid #dbe6ef;color:#0f172a;padding:9px 11px;border-radius:12px;max-width:90%;">
        Namaste! Main <strong>Yuitor Smart AI</strong> hoon. Aap Classes 5–12, JEE/NEET/CUET/Coding courses, A-to-Z fees, scholarship discounts (up to 50% off), admission, ERP login ya contact ke baare me kuch bhi pooch sakte hain!
      </div>
    </div>
    <div id="yu-chat-quick" style="display:flex;flex-wrap:wrap;gap:6px;padding:8px 10px;background:#fff;border-top:1px solid #edf2f7;">
      <button type="button" data-yu-q="A to Z fee structure batao" style="background:#eef6fa;color:#0b7b82;border:1px solid #bfe3eb;border-radius:8px;padding:4px 9px;font-size:11.5px;font-weight:700;cursor:pointer;">A-to-Z Fees</button>
      <button type="button" data-yu-q="Kitna discount aur scholarship milta hai?" style="background:#eef6fa;color:#0b7b82;border:1px solid #bfe3eb;border-radius:8px;padding:4px 9px;font-size:11.5px;font-weight:700;cursor:pointer;">Discounts</button>
      <button type="button" data-yu-q="Admission process kya hai?" style="background:#eef6fa;color:#0b7b82;border:1px solid #bfe3eb;border-radius:8px;padding:4px 9px;font-size:11.5px;font-weight:700;cursor:pointer;">Admission</button>
      <button type="button" data-yu-q="Student aur Teacher login kaise karein?" style="background:#eef6fa;color:#0b7b82;border:1px solid #bfe3eb;border-radius:8px;padding:4px 9px;font-size:11.5px;font-weight:700;cursor:pointer;">ERP Login</button>
    </div>
    <form id="yu-chat-form" style="display:flex;gap:6px;padding:10px;border-top:1px solid #dbe6ef;background:#fff;">
      <input id="yu-chat-in" type="text" maxlength="500" required placeholder="Fee, course, discount, login poochein..." style="flex:1;padding:8px 10px;border:1px solid #cbd9e6;border-radius:10px;font-size:13px;">
      <button type="submit" style="background:#12a1a1;color:#fff;border:0;padding:8px 14px;border-radius:10px;font-weight:700;cursor:pointer;">Send</button>
    </form>
  `;

  root.append(box, toggle);
  document.body.appendChild(root);

  const msgs = box.querySelector("#yu-chat-msgs");
  const form = box.querySelector("#yu-chat-form");
  const input = box.querySelector("#yu-chat-in");
  const closeBtn = box.querySelector("#yu-chat-close");
  const quickBar = box.querySelector("#yu-chat-quick");

  const addBubble = (text, isUser) => {
    const div = document.createElement("div");
    div.style.cssText = isUser
      ? "align-self:flex-end;background:#0f172a;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;"
      : "align-self:flex-start;background:#fff;border:1px solid #dbe6ef;color:#0f172a;padding:9px 11px;border-radius:12px;max-width:90%;white-space:pre-line;";
    div.textContent = text;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  };

  async function postChatbot(message, token) {
    let lastRes = null;
    for (const ep of ["/api/chatbot.php", "/api/chatbot"]) {
      const res = await fetch(ep, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "X-CSRF-TOKEN": token || "",
        },
        credentials: "same-origin",
        cache: "no-store",
        body: JSON.stringify({ message, csrf_token: token || "" }),
      });
      lastRes = res;
      if (res.status !== 404 && res.status !== 405) {
        return { res, data: await safeJson(res) };
      }
    }
    return { res: lastRes, data: lastRes ? await safeJson(lastRes) : null };
  }

  async function sendQuestion(txt) {
    const clean = String(txt || "").trim();
    if (!clean) return;
    addBubble(clean, true);
    input.value = "";
    input.disabled = true;

    try {
      let token = await refreshCsrf(false);
      let attempt = await postChatbot(clean, token);

      if (attempt.res && attempt.res.status === 403) {
        token = await refreshCsrf(true);
        if (token) {
          attempt = await postChatbot(clean, token);
        }
      }

      if (attempt.data && typeof attempt.data.reply === "string" && attempt.data.reply.trim() !== "") {
        addBubble(attempt.data.reply, false);
      } else if (attempt.res && !attempt.res.ok) {
        addBubble(`Server error (HTTP ${attempt.res.status}). Kripya page refresh karke dobara try karein.`, false);
      } else {
        addBubble("Server se sahi response nahi aaya. Kripya page refresh karke dobara poochein.", false);
      }
    } catch {
      addBubble("Connection error. Kripya page refresh karein ya Contact page (/contact) dekhein.", false);
    } finally {
      input.disabled = false;
      input.focus();
    }
  }

  toggle.addEventListener("click", () => {
    box.hidden = !box.hidden;
    if (!box.hidden) {
      refreshCsrf(false);
      input.focus();
    }
  });
  closeBtn.addEventListener("click", () => { box.hidden = true; });

  quickBar.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-yu-q]");
    if (btn && !input.disabled) {
      sendQuestion(btn.getAttribute("data-yu-q"));
    }
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendQuestion(input.value);
  });
})();
