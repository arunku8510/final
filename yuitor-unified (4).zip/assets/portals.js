(() => {
  "use strict";

  const root = document.getElementById("root");
  if (!root) return;

  const state = {
    csrfToken: "",
    dashboard: null,
    view: "students",
    selectedStudentId: null,
    refreshTimer: null,
    festivalConfig: null,
    festivalFilterYear: 2026,
    festivalFilterTradition: "All",
    festivalSearch: "",
    editingFestivalId: null,
    previewFestivalId: null,
  };

  const escapeHtml = (value) =>
    String(value ?? "").replace(/[&<>"']/g, (character) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    })[character]);

  const getMain = () => root.querySelector("main");

  async function api(url, options = {}) {
    const headers = { Accept: "application/json", ...(options.headers || {}) };
    const requestOptions = {
      credentials: "same-origin",
      cache: "no-store",
      ...options,
      headers,
    };
    if (options.body && typeof options.body !== "string") {
      headers["Content-Type"] = "application/json";
      requestOptions.body = JSON.stringify(options.body);
    }

    let response;
    try {
      response = await fetch(url, requestOptions);
    } catch (_error) {
      throw new Error("The portal could not connect. Check your connection and try again.");
    }
    let result = {};
    try {
      result = await response.json();
    } catch (_error) {
      result = {};
    }
    if (!response.ok) {
      const error = new Error(result.error || "The request could not be completed.");
      error.status = response.status;
      error.details = result;
      throw error;
    }
    return result;
  }

  async function csrfToken(force = false) {
    if (!state.csrfToken || force) {
      const result = await api("/api/auth.php?action=csrf");
      state.csrfToken = result.csrfToken || "";
    }
    return state.csrfToken;
  }

  async function post(url, body) {
    let token = await csrfToken(false);
    try {
      return await api(url, {
        method: "POST",
        headers: { "X-CSRF-Token": token },
        body,
      });
    } catch (error) {
      if (error && error.status === 403) {
        token = await csrfToken(true);
        return api(url, {
          method: "POST",
          headers: { "X-CSRF-Token": token },
          body,
        });
      }
      throw error;
    }
  }

  function setPortalMain(html) {
    const main = getMain();
    if (!main) return null;
    main.classList.add("portal-main");
    main.dataset.yuPortalMounted = "true";
    main.innerHTML = html;
    return main;
  }

  function messageMarkup(text, type = "info") {
    return `<div class="portal-message${type === "error" ? " portal-message--error" : type === "success" ? " portal-message--success" : ""}" role="status">${escapeHtml(text)}</div>`;
  }

  function setFeedback(text, type = "info", selector = "[data-portal-feedback]") {
    const target = root.querySelector(selector);
    if (!target) return;
    target.className = `portal-message${type === "error" ? " portal-message--error" : type === "success" ? " portal-message--success" : ""}`;
    target.textContent = text;
    target.hidden = !text;
  }

  function setBusy(button, busy, busyLabel = "Please wait…") {
    if (!button) return;
    if (busy) {
      button.dataset.originalLabel = button.textContent;
      button.textContent = busyLabel;
      button.disabled = true;
    } else {
      button.textContent = button.dataset.originalLabel || button.textContent;
      button.disabled = false;
    }
  }

  function formattedDate(value, fallback = "Awaiting confirmation") {
    if (!value) return fallback;
    const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(String(value));
    const date = new Date(dateOnly ? `${value}T00:00:00Z` : value);
    if (Number.isNaN(date.getTime())) return String(value);
    return new Intl.DateTimeFormat("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
      timeZone: dateOnly ? "UTC" : "Asia/Kolkata",
    }).format(date);
  }

  function labelText(value) {
    if (!value) return "Not set";
    return String(value)
      .replace(/[_-]+/g, " ")
      .replace(/\b\w/g, (letter) => letter.toUpperCase());
  }

  function statusBadge(value, display = labelText(value)) {
    const status = String(value || "pending").toLowerCase().replace(/[^a-z0-9_-]/g, "");
    return `<span class="portal-status portal-status--${escapeHtml(status)}">${escapeHtml(display)}</span>`;
  }

  function detail(label, value) {
    return `<div class="portal-detail"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value || "—")}</strong></div>`;
  }

  function loginMarkup(role, notice = "") {
    const admin = role === "admin";
    const title = admin ? "Admin sign in" : "Student sign in";
    const destination = admin ? "Admin dashboard" : "Student dashboard";
    const accountLinks = admin
      ? `<a href="/admin/setup.php">Set up the first admin</a><a href="/student/login.php">Student portal</a>`
      : `<a href="/student/register.php">New student? Register here</a><a href="/contact">Contact the centre</a>`;
    document.title = `${title} | Yuitor Smart Classes`;
    return `<div class="portal-shell">
      <div class="portal-login-card portal-card">
        <p class="portal-kicker">Yuitor Smart Classes · ${admin ? "Admin portal" : "Customer / Student portal"}</p>
        <div class="portal-heading"><h1>${title}</h1><p class="portal-subtitle">Sign in to view your ${admin ? "student records and enquiries" : "course and fee details"}.</p></div>
        ${notice ? messageMarkup(notice, "error") : ""}
        <form class="portal-form" data-portal-login>
          <div class="portal-field"><label for="portal-login-email">Email address</label><input id="portal-login-email" name="email" type="email" autocomplete="username" maxlength="254" required></div>
          <div class="portal-field"><label for="portal-login-password">Password</label><input id="portal-login-password" name="password" type="password" autocomplete="current-password" maxlength="200" required></div>
          <div class="portal-message" data-portal-feedback hidden role="status"></div>
          <button class="portal-button" type="submit">${destination}</button>
        </form>
        <div class="portal-inline-links">${accountLinks}</div>
        ${admin ? `<p class="portal-hint" style="margin-top:16px">Admin accounts are created only through the one-time secure setup. There is no public admin registration.</p>` : `<p class="portal-hint" style="margin-top:16px">New registrations stay pending until the centre confirms admission and fee details.</p>`}
      </div>
    </div>`;
  }

  function bindLogin(role) {
    const form = root.querySelector("[data-portal-login]");
    if (!form) return;
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = form.querySelector('button[type="submit"]');
      const values = new FormData(form);
      setFeedback("", "info");
      setBusy(button, true, "Signing in…");
      try {
        const result = await post("/api/auth.php?action=login", {
          role,
          email: values.get("email"),
          password: values.get("password"),
        });
        state.csrfToken = result.csrfToken || "";
        window.location.assign(role === "admin" ? "/admin/" : "/student/");
      } catch (error) {
        setFeedback(error.message, "error");
        setBusy(button, false);
      }
    });
  }

  async function renderLogin(role, notice = "") {
    setPortalMain(loginMarkup(role, notice));
    bindLogin(role);
  }

  function installationChecksMarkup(checks = []) {
    const rows = Array.isArray(checks) ? checks : [];
    if (!rows.length) return "";
    return `<section class="portal-install-checks" aria-labelledby="install-checks-title">
      <h2 id="install-checks-title">Pre-installation system check</h2>
      <ul>${rows.map((check) => {
        const status = check.status || "error";
        const label = status === "ok" ? "Ready" : status === "warning" ? "Optional" : "Action needed";
        return `<li class="${status === "ok" ? "is-ready" : status === "warning" ? "is-warning" : "is-error"}">
          <span class="portal-install-check-status">${label}</span>
          <div><strong>${escapeHtml(check.label || "System check")}</strong><span>${escapeHtml(check.message || "")}</span></div>
        </li>`;
      }).join("")}</ul>
    </section>`;
  }

  async function renderSetup() {
    document.title = "One-time Admin Setup | Yuitor Smart Classes";
    setPortalMain(`<div class="portal-shell">
      <div class="portal-login-card portal-card">
        <p class="portal-kicker">Yuitor Smart Classes · Admin portal</p>
        <div class="portal-heading"><h1>Create the first Super Admin</h1><p class="portal-subtitle">One-time secure initialization for the Admin &amp; Festival Studio console.</p></div>
        <div data-setup-state>${messageMarkup("Running pre-installation checks…")}</div>
        <div class="portal-inline-links"><a href="/admin/login.php">Admin sign in</a><a href="/">Back to website</a></div>
      </div>
    </div>`);

    const stateBox = root.querySelector("[data-setup-state]");
    try {
      const setup = await api("/api/setup-admin.php");
      state.csrfToken = setup.csrfToken || "";
      const checksMarkup = installationChecksMarkup(setup.checks);
      if (setup.adminExists) {
        stateBox.innerHTML = `${checksMarkup}${messageMarkup("Admin setup is already complete. Use the Admin sign-in page.", "success")}`;
        return;
      }
      if (!setup.setupAvailable) {
        const protectionMissing = (setup.checks || []).some((check) => check.id === "setup_protection" && check.status === "error");
        const notice = protectionMissing
          ? "In cPanel, open Security → Directory Privacy, password-protect the admin folder, then reload this page and complete the browser password prompt."
          : "Setup is unavailable until every failed check above is resolved. No first-admin form is exposed while any required check fails.";
        stateBox.innerHTML = `${checksMarkup}${messageMarkup(notice, "error")}`;
        return;
      }
      stateBox.innerHTML = `${checksMarkup}<form class="portal-form" data-admin-setup>
        <div class="portal-field"><label for="setup-name">Full name</label><input id="setup-name" name="displayName" maxlength="120" autocomplete="name" required></div>
        <div class="portal-field"><label for="setup-email">Email ID</label><input id="setup-email" name="email" type="email" maxlength="254" autocomplete="email" required></div>
        <div class="portal-field"><label for="setup-phone">Indian mobile number</label><input id="setup-phone" name="phone" type="tel" inputmode="numeric" minlength="10" maxlength="10" pattern="[6-9][0-9]{9}" autocomplete="tel" aria-describedby="setup-phone-hint" required><p class="portal-hint" id="setup-phone-hint">Enter exactly 10 digits, starting with 6, 7, 8, or 9.</p></div>
        <div class="portal-field"><label for="setup-password">Admin password</label><input id="setup-password" name="password" type="password" minlength="8" maxlength="200" pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,}" autocomplete="new-password" aria-describedby="setup-password-hint" required><p class="portal-hint" id="setup-password-hint">At least 8 characters, including uppercase, lowercase, a number, and a special character.</p></div>
        <div class="portal-message" data-portal-feedback hidden role="status"></div>
        <button class="portal-button" type="submit">Create Super Admin</button>
      </form>`;
      const form = root.querySelector("[data-admin-setup]");
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        if (!form.reportValidity()) return;
        const values = new FormData(form);
        const button = form.querySelector('button[type="submit"]');
        setFeedback("", "info");
        setBusy(button, true, "Creating account…");
        try {
          const result = await post("/api/setup-admin.php", {
            displayName: values.get("displayName"),
            email: values.get("email"),
            phone: values.get("phone"),
            password: values.get("password"),
          });
          form.hidden = true;
          stateBox.insertAdjacentHTML("afterbegin", messageMarkup(result.message || "Admin account created. Sign in to continue.", "success"));
        } catch (error) {
          setFeedback(error.message, "error");
          setBusy(button, false);
        }
      });
    } catch (error) {
      stateBox.innerHTML = `${messageMarkup(error.message, "error")}${installationChecksMarkup(error.details?.checks)}`;
    }
  }

  function metricMarkup(value, label) {
    return `<div class="portal-stat"><strong>${Number(value) || 0}</strong><span>${escapeHtml(label)}</span></div>`;
  }

  function renderMetrics() {
    const summary = state.dashboard?.summary || {};
    const metrics = root.querySelector("[data-admin-metrics]");
    if (!metrics) return;
    metrics.innerHTML = [
      metricMarkup(summary.students, "Student accounts"),
      metricMarkup(summary.pendingRegistrations, "Registrations to review"),
      metricMarkup(summary.feesDue, "Fees not marked paid"),
      metricMarkup(summary.newInquiries, "New enquiries"),
    ].join("");
  }

  function adminShell(displayName) {
    document.title = "Admin Dashboard | Yuitor Smart Classes";
    return `<div class="portal-shell">
      <div class="portal-heading">
        <div><p class="portal-kicker">Yuitor Smart Classes · Admin portal</p><h1>Admin dashboard</h1><p class="portal-subtitle">Review registrations, student fee details and public enquiries in one place.</p></div>
        <div class="portal-actions"><a class="portal-button portal-button--small" href="/erp/yt-ctrl-94x2-gate">Open Full ERP Console</a><span class="portal-muted">Signed in as ${escapeHtml(displayName)}</span><button class="portal-button portal-button--quiet portal-button--small" type="button" data-portal-logout>Sign out</button></div>
      </div>
      <div class="portal-metrics" data-admin-metrics>${metricMarkup(0, "Loading…")}</div>
      <div class="portal-tabs" role="tablist" aria-label="Admin dashboard sections">
        <button class="portal-tab" type="button" role="tab" data-admin-view="students" aria-selected="true">Students &amp; fees</button>
        <button class="portal-tab" type="button" role="tab" data-admin-view="inquiries" aria-selected="false">Website enquiries</button>
        <button class="portal-tab" type="button" role="tab" data-admin-view="email" aria-selected="false">Email students</button>
        <button class="portal-tab" type="button" role="tab" data-admin-view="festivals" aria-selected="false">Festivals &amp; calendar</button>
      </div>
      <div data-admin-feedback class="portal-message" hidden role="status"></div>
      <div data-admin-content class="portal-card portal-table-card"><div class="portal-empty">Loading portal records…</div></div>
    </div>`;
  }

  function bindLogout() {
    const button = root.querySelector("[data-portal-logout]");
    if (!button) return;
    button.addEventListener("click", async () => {
      setBusy(button, true, "Signing out…");
      try {
        await post("/api/auth.php?action=logout", {});
        state.csrfToken = "";
        window.location.assign("/admin/login.php");
      } catch (error) {
        setFeedback(error.message, "error", "[data-admin-feedback]");
        setBusy(button, false);
      }
    });
  }

  function setAdminView(view) {
    state.view = view;
    state.selectedStudentId = null;
    root.querySelectorAll("[data-admin-view]").forEach((tab) => {
      tab.setAttribute("aria-selected", tab.dataset.adminView === view ? "true" : "false");
    });
    renderAdminContent();
  }

  function studentSearchMatches(student, query) {
    if (!query) return true;
    const haystack = [
      student.full_name,
      student.email,
      student.phone,
      student.class_level,
      student.selected_subject,
      student.fee_status,
      student.registration_status,
    ].join(" ").toLowerCase();
    return haystack.includes(query.toLowerCase());
  }

  function renderStudentRows(query = "") {
    const data = state.dashboard?.students || [];
    const students = data.filter((student) => studentSearchMatches(student, query));
    if (!students.length) {
      return `<tr><td colspan="9" class="portal-empty">${data.length ? "No students match this search." : "No student registrations yet."}</td></tr>`;
    }
    return students.map((student) => `<tr>
      <td><span class="portal-cell-title">${escapeHtml(student.full_name)}</span><span class="portal-cell-sub">${escapeHtml(student.email)}</span></td>
      <td>${escapeHtml(student.phone)}</td>
      <td>${escapeHtml(student.class_level)}</td>
      <td>${escapeHtml(student.selected_subject)}</td>
      <td>${Number(student.course_duration_months)} months</td>
      <td>${escapeHtml(formattedDate(student.admission_date))}</td>
      <td>${statusBadge(student.fee_status)}</td>
      <td>${statusBadge(student.registration_status)}${Number(student.is_active) ? "" : `<span class="portal-cell-sub">Account disabled</span>`}</td>
      <td><button class="portal-button portal-button--quiet portal-button--small" type="button" data-student-id="${Number(student.id)}">Manage</button></td>
    </tr>`).join("");
  }

  function renderStudentsList() {
    const content = root.querySelector("[data-admin-content]");
    if (!content) return;
    content.innerHTML = `<div class="portal-toolbar" style="padding:16px 16px 0">
      <input type="search" data-student-search aria-label="Search student records" placeholder="Search name, email, phone, subject…">
      <div class="portal-toolbar-actions"><span class="portal-muted">${(state.dashboard?.students || []).length} student record(s)</span></div>
    </div>
    <div class="portal-table-scroll"><table class="portal-table">
      <thead><tr><th>Student</th><th>Phone</th><th>Class / course</th><th>Selected subject</th><th>Duration</th><th>Admission date</th><th>Fee status</th><th>Account status</th><th>Profile</th></tr></thead>
      <tbody data-student-rows>${renderStudentRows()}</tbody>
    </table></div>`;
    const search = content.querySelector("[data-student-search]");
    search.addEventListener("input", () => {
      const rows = content.querySelector("[data-student-rows]");
      if (rows) rows.innerHTML = renderStudentRows(search.value.trim());
    });
  }

  function selectOptions(items, selected) {
    return items.map(([value, label]) =>
      `<option value="${escapeHtml(value)}"${String(selected) === String(value) ? " selected" : ""}>${escapeHtml(label)}</option>`,
    ).join("");
  }

  function renderStudentProfile(student, notice = "") {
    const content = root.querySelector("[data-admin-content]");
    if (!content) return;
    content.innerHTML = `<div class="portal-profile">
      <div class="portal-profile-head">
        <div><h2>${escapeHtml(student.full_name)}</h2><p>Student record · created ${escapeHtml(formattedDate(student.created_at, "date unavailable"))}</p></div>
        <button class="portal-button portal-button--quiet portal-button--small" type="button" data-back-to-students>← All students</button>
      </div>
      ${notice ? messageMarkup(notice, "success") : ""}
      <div class="portal-personal-grid">
        ${detail("Email", student.email)}
        ${detail("Phone", student.phone)}
        ${detail("Current class / course", student.class_level)}
      </div>
      <h3 class="portal-section-title">Course, admission &amp; fee details</h3>
      <form class="portal-form" data-student-profile-form>
        <input type="hidden" name="id" value="${Number(student.id)}">
        <div class="portal-form-grid">
          <div class="portal-field"><label for="profile-subject">Selected subject</label><input id="profile-subject" name="selectedSubject" maxlength="120" value="${escapeHtml(student.selected_subject)}" required></div>
          <div class="portal-field"><label for="profile-class">Class / course</label><input id="profile-class" name="classLevel" maxlength="60" value="${escapeHtml(student.class_level)}" required></div>
          <div class="portal-field"><label for="profile-duration">Course duration (months)</label><input id="profile-duration" name="courseDurationMonths" type="number" min="1" max="60" value="${Number(student.course_duration_months)}" required></div>
          <div class="portal-field"><label for="profile-admission">Admission date</label><input id="profile-admission" name="admissionDate" type="date" value="${escapeHtml(student.admission_date || "")}"><p class="portal-hint">Leave blank until admission is confirmed.</p></div>
          <div class="portal-field"><label for="profile-fee-status">Fee status</label><select id="profile-fee-status" name="feeStatus" required>${selectOptions([["pending", "Pending"], ["partial", "Partial"], ["paid", "Paid"], ["overdue", "Overdue"]], student.fee_status)}</select></div>
          <div class="portal-field"><label for="profile-next-due">Next fee due date</label><input id="profile-next-due" name="nextFeeDue" type="date" value="${escapeHtml(student.next_fee_due || "")}"><p class="portal-hint">The student sees an automatic reminder based on this date.</p></div>
          <div class="portal-field"><label for="profile-registration">Registration status</label><select id="profile-registration" name="registrationStatus" required>${selectOptions([["pending", "Pending review"], ["active", "Active"], ["completed", "Completed"], ["inactive", "Inactive"]], student.registration_status)}</select></div>
          <div class="portal-field"><label for="profile-fee-note">Custom fee reminder (optional)</label><textarea id="profile-fee-note" name="feeAlertNote" maxlength="300" placeholder="Shown instead of the automatic reminder">${escapeHtml(student.fee_alert_note || "")}</textarea></div>
        </div>
        <label class="portal-field-label"><input name="isActive" type="checkbox"${Number(student.is_active) ? " checked" : ""}> Student account can sign in</label>
        <div class="portal-message" data-portal-feedback hidden role="status"></div>
        <div class="portal-actions"><button class="portal-button" type="submit">Save student profile</button><span class="portal-hint">Changes update the student's portal immediately.</span></div>
      </form>
      <div class="portal-divider"></div>
      <div class="portal-alert"><strong>Reminder currently shown to the student</strong>${escapeHtml(student.fee_alert || "Fee reminder will be calculated after saving.")}</div>
    </div>`;

    content.querySelector("[data-back-to-students]").addEventListener("click", () => {
      state.selectedStudentId = null;
      renderStudentsList();
    });

    const form = content.querySelector("[data-student-profile-form]");
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const values = new FormData(form);
      const button = form.querySelector('button[type="submit"]');
      setFeedback("", "info", "[data-portal-feedback]");
      setBusy(button, true, "Saving…");
      try {
        const result = await post("/api/admin.php?action=update-student", {
          id: Number(values.get("id")),
          selectedSubject: values.get("selectedSubject"),
          classLevel: values.get("classLevel"),
          courseDurationMonths: Number(values.get("courseDurationMonths")),
          admissionDate: values.get("admissionDate"),
          feeStatus: values.get("feeStatus"),
          nextFeeDue: values.get("nextFeeDue"),
          feeAlertNote: values.get("feeAlertNote"),
          registrationStatus: values.get("registrationStatus"),
          isActive: form.elements.isActive.checked,
        });
        const updated = result.student;
        state.dashboard.students = (state.dashboard.students || []).map((item) =>
          Number(item.id) === Number(updated.id) ? updated : item,
        );
        renderMetrics();
        renderStudentProfile(updated, "Profile saved. The student portal now shows these details.");
      } catch (error) {
        setFeedback(error.message, "error", "[data-portal-feedback]");
        setBusy(button, false);
      }
    });
  }

  function renderInquiries() {
    const content = root.querySelector("[data-admin-content]");
    if (!content) return;
    const inquiries = state.dashboard?.inquiries || [];
    if (!inquiries.length) {
      content.innerHTML = `<div class="portal-empty">No website enquiries have been received yet.</div>`;
      return;
    }
    content.innerHTML = `<div class="portal-toolbar" style="padding:16px 16px 0"><span class="portal-muted">${inquiries.length} enquiry record(s)</span><span class="portal-hint">New contact-form submissions appear here as soon as they are saved.</span></div>
      <div class="portal-table-scroll"><table class="portal-table" style="min-width:980px">
        <thead><tr><th>Visitor</th><th>Phone / email</th><th>Course</th><th>Message</th><th>Received</th><th>Follow-up status</th></tr></thead>
        <tbody>${inquiries.map((inquiry) => `<tr>
          <td><span class="portal-cell-title">${escapeHtml(inquiry.name)}</span></td>
          <td>${escapeHtml(inquiry.phone)}${inquiry.email ? `<span class="portal-cell-sub">${escapeHtml(inquiry.email)}</span>` : ""}</td>
          <td>${escapeHtml(inquiry.course)}</td>
          <td><span class="portal-cell-message">${escapeHtml(inquiry.message || "—")}</span></td>
          <td>${escapeHtml(formattedDate(inquiry.received_at, "date unavailable"))}</td>
          <td><select class="portal-inquiry-status" data-inquiry-id="${Number(inquiry.id)}" aria-label="Follow-up status for ${escapeHtml(inquiry.name)}">${selectOptions([["new", "New"], ["contacted", "Contacted"], ["converted", "Converted"], ["closed", "Closed"]], inquiry.status)}</select></td>
        </tr>`).join("")}</tbody>
      </table></div>`;
    content.querySelectorAll("[data-inquiry-id]").forEach((select) => {
      select.addEventListener("change", async () => {
        select.disabled = true;
        try {
          await post("/api/admin.php?action=update-inquiry", {
            id: Number(select.dataset.inquiryId),
            status: select.value,
          });
          await loadDashboard(true);
          setFeedback("Enquiry status updated.", "success", "[data-admin-feedback]");
        } catch (error) {
          setFeedback(error.message, "error", "[data-admin-feedback]");
          select.disabled = false;
        }
      });
    });
  }

  function renderEmailComposer() {
    const content = root.querySelector("[data-admin-content]");
    if (!content) return;
    const students = (state.dashboard?.students || []).filter((student) => String(student.email || "").trim());
    if (!students.length) {
      content.innerHTML = `<div class="portal-empty">No student email addresses are available yet.</div>`;
      return;
    }
    content.innerHTML = `<div class="portal-profile">
      <h2 class="portal-section-title">Send an email to students</h2>
      <p class="portal-hint">Choose up to 100 recipients. Each student receives an individual message, so other students’ email addresses are not exposed.</p>
      <form class="portal-form" data-student-email-form>
        <div class="portal-email-recipient-header">
          <label class="portal-field-label"><input type="checkbox" data-email-select-all> Select all ${students.length} students with email addresses</label>
          <span class="portal-muted" data-email-selected-count>0 selected</span>
        </div>
        <div class="portal-email-recipient-list">
          ${students.map((student) => `<label class="portal-email-recipient">
            <input type="checkbox" name="studentIds" value="${Number(student.id)}">
            <span><strong>${escapeHtml(student.full_name)}</strong><span>${escapeHtml(student.email)}</span></span>
          </label>`).join("")}
        </div>
        <div class="portal-field"><label for="student-email-subject">Subject</label><input id="student-email-subject" name="subject" maxlength="180" required></div>
        <div class="portal-field"><label for="student-email-message">Message</label><textarea id="student-email-message" name="message" maxlength="6000" rows="7" required></textarea></div>
        <div class="portal-message" data-email-feedback hidden role="status"></div>
        <div class="portal-actions"><button class="portal-button" type="submit">Send email</button><span class="portal-hint">Sender: no-reply@yuitor.com</span></div>
      </form>
    </div>`;

    const form = content.querySelector("[data-student-email-form]");
    const selectAll = form.querySelector("[data-email-select-all]");
    const selectedCount = form.querySelector("[data-email-selected-count]");
    const recipientBoxes = [...form.querySelectorAll('input[name="studentIds"]')];
    const updateRecipientCount = () => {
      const checked = recipientBoxes.filter((checkbox) => checkbox.checked).length;
      selectedCount.textContent = `${checked} selected`;
      selectAll.checked = checked === recipientBoxes.length;
      selectAll.indeterminate = checked > 0 && checked < recipientBoxes.length;
    };
    selectAll.addEventListener("change", () => {
      recipientBoxes.forEach((checkbox) => { checkbox.checked = selectAll.checked; });
      updateRecipientCount();
    });
    recipientBoxes.forEach((checkbox) => checkbox.addEventListener("change", updateRecipientCount));

    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const studentIds = recipientBoxes.filter((checkbox) => checkbox.checked).map((checkbox) => Number(checkbox.value));
      if (studentIds.length < 1 || studentIds.length > 100) {
        setFeedback("Select between 1 and 100 students.", "error", "[data-email-feedback]");
        return;
      }
      if (!form.reportValidity()) return;
      const values = new FormData(form);
      const button = form.querySelector('button[type="submit"]');
      setFeedback("", "info", "[data-email-feedback]");
      setBusy(button, true, "Sending…");
      try {
        const result = await post("/api/admin.php?action=send-student-email", {
          studentIds,
          subject: values.get("subject"),
          message: values.get("message"),
        });
        setFeedback(result.message || "Email delivery finished.", result.failed > 0 ? "error" : "success", "[data-email-feedback]");
        setBusy(button, false);
      } catch (error) {
        setFeedback(error.message, "error", "[data-email-feedback]");
        setBusy(button, false);
      }
    });
  }

  async function saveFestivalConfig(nextConfig, successNotice) {
    const result = await post("/api/admin.php?action=save-festival-config", nextConfig);
    state.festivalConfig = result.config;
    state.previewFestivalId = null;
    window.dispatchEvent(new CustomEvent("yuitor:festival-config-updated", { detail: result.config }));
    setFeedback(successNotice || result.message || "Festival settings saved.", "success", "[data-admin-feedback]");
    renderFestivalsManager();
  }

  async function restoreAutomaticFestivalDefaults(clearOverrides = false) {
    const result = await post("/api/admin.php?action=restore-festival-defaults", { clearOverrides });
    state.festivalConfig = result.config;
    state.previewFestivalId = null;
    state.editingFestivalId = null;
    window.dispatchEvent(new CustomEvent("yuitor:festival-config-updated", { detail: result.config }));
    setFeedback(result.message || "Automatic Indian festival calendar restored.", "success", "[data-admin-feedback]");
    renderFestivalsManager();
  }

  function renderFestivalsManager() {
    const content = root.querySelector("[data-admin-content]");
    if (!content) return;
    const engine = window.YuitorFestivalEngine;
    if (!engine) {
      content.innerHTML = `<div class="portal-empty">Festival calendar engine is still loading…</div>`;
      return;
    }

    const cfg = state.festivalConfig || { ...engine.DEFAULT_ADMIN_CONFIG };
    const resolution = engine.resolveFestivalState(cfg, new Date());
    const festivals = engine.INDIAN_FESTIVALS_2026_2030 || [];
    const activeOcc = resolution.activeOccurrence;
    const activeName = activeOcc ? activeOcc.festival.name : "Standard Yuitor Academic Theme (No active festival)";
    const years = engine.SUPPORTED_YEARS || [2026, 2027, 2028, 2029, 2030];
    const traditions = ["All", "Hindu", "Muslim", "Sikh", "Christian", "National", "Regional"];

    const filteredFestivals = festivals.filter((fest) => {
      if (state.festivalFilterTradition !== "All" && fest.tradition !== state.festivalFilterTradition) return false;
      if (state.festivalSearch) {
        const hay = `${fest.name} ${fest.tradition} ${fest.calendarSystem} ${fest.regionalNote}`.toLowerCase();
        if (!hay.includes(state.festivalSearch.toLowerCase())) return false;
      }
      return true;
    });

    const editingFest = state.editingFestivalId ? festivals.find((f) => f.id === state.editingFestivalId) : null;
    const editingOverride = editingFest ? (cfg.overrides || {})[editingFest.id] || {} : {};
    const editingWindow = editingFest ? engine.getFestivalWindow(editingFest, state.festivalFilterYear, editingOverride) : null;

    content.innerHTML = `<div class="portal-profile">
      <div class="yf-admin-grid">
        <div class="yf-admin-panel">
          <h3>India Standard Time (IST) Status</h3>
          <p class="portal-hint" style="margin-bottom:8px">Current IST: <strong>${escapeHtml(resolution.istNow.formattedDate)} · ${escapeHtml(resolution.istNow.formattedTime)}</strong></p>
          <p class="portal-hint" style="margin-bottom:8px">Active Theme: <strong>${escapeHtml(activeName)}</strong></p>
          <p class="portal-hint">${activeOcc ? escapeHtml(activeOcc.effectiveGreetingTitle) : "Festival greeting banner is automatically hidden when outside festival dates."}</p>
        </div>

        <div class="yf-admin-panel">
          <h3>Theme Mode Control</h3>
          <div class="yf-mode-group">
            <button type="button" class="yf-chip-btn ${cfg.mode === "automatic" ? "is-active" : ""}" data-fest-mode="automatic">Automatic (IST)</button>
            <button type="button" class="yf-chip-btn ${cfg.mode === "manual" ? "is-active" : ""}" data-fest-mode="manual">Manual Override</button>
            <button type="button" class="yf-chip-btn ${cfg.mode === "disabled" ? "is-active" : ""}" data-fest-mode="disabled">Disable Themes</button>
          </div>
          <div class="portal-actions">
            <button type="button" class="portal-button portal-button--small" data-fest-restore="false">Restore automatic settings</button>
            <button type="button" class="portal-button portal-button--quiet portal-button--small" data-fest-restore="true">Reset custom edits &amp; restore</button>
          </div>
        </div>

        <div class="yf-admin-panel">
          <h3>Date Simulator (2026–2030)</h3>
          <p class="portal-hint" style="margin-bottom:8px">Test automatic IST theme switching on any date or preview Diwali live.</p>
          <div class="portal-actions" style="margin-bottom:10px">
            <input type="date" min="2026-01-01" max="2030-12-31" value="${escapeHtml(cfg.simulatedDateIST || "")}" data-fest-sim-date aria-label="Simulate IST date" style="min-height:36px;padding:6px 10px;border-radius:8px;border:1px solid var(--brand-line,#dbe6ef)">
            <button type="button" class="portal-button portal-button--small" data-fest-apply-sim>Test Date</button>
            <button type="button" class="portal-button portal-button--quiet portal-button--small" data-fest-clear-sim>Real Today</button>
          </div>
          <div class="portal-actions">
            <a class="portal-text-link" href="/?festival=${escapeHtml(activeOcc ? activeOcc.festival.id : "diwali")}" target="_blank" rel="noopener">Open website preview ↗</a>
          </div>
        </div>
      </div>

      <h3 class="portal-section-title">Upcoming Indian Festivals (from ${escapeHtml(resolution.istNow.formattedDate)})</h3>
      <div class="yf-upcoming-strip">
        ${(resolution.upcomingOccurrences || []).slice(0, 6).map((occ) => `
          <div class="yf-upcoming-item">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:4px">
              <strong>${escapeHtml(occ.festival.name)}</strong>
              <span class="portal-status">${occ.daysUntil === 0 ? "Today (IST)" : occ.daysUntil === 1 ? "Tomorrow" : `In ${occ.daysUntil}d`}</span>
            </div>
            <div class="portal-hint">${escapeHtml(formattedDate(occ.primaryDate))} · ${escapeHtml(occ.festival.tradition)}${occ.festival.moonSightingDependent ? " · Moon sighting ±1d" : ""}</div>
          </div>
        `).join("")}
      </div>

      ${editingFest ? `<div class="yf-editor-box" data-fest-editor>
        <div class="portal-profile-head" style="margin-bottom:14px">
          <div>
            <h3 style="margin:0">Edit Greeting &amp; Dates — ${escapeHtml(editingFest.name)} (${state.festivalFilterYear})</h3>
            <p class="portal-hint">Customize the automatic greeting message or adjust festival start/end dates (e.g., for moon sighting or regional confirmation).</p>
          </div>
          <button type="button" class="portal-button portal-button--quiet portal-button--small" data-fest-close-edit>Close editor</button>
        </div>
        <form class="portal-form" data-fest-edit-form>
          <input type="hidden" name="festivalId" value="${escapeHtml(editingFest.id)}">
          <div class="portal-form-grid">
            <div class="portal-field">
              <label for="fest-edit-title">Custom Greeting Title</label>
              <input id="fest-edit-title" name="customGreetingTitle" maxlength="180" value="${escapeHtml(editingOverride.customGreetingTitle || "")}" placeholder="${escapeHtml(editingFest.theme.greetingTitle)}">
            </div>
            <div class="portal-field">
              <label for="fest-edit-sub">Custom Greeting Subtitle</label>
              <input id="fest-edit-sub" name="customGreetingSubtitle" maxlength="320" value="${escapeHtml(editingOverride.customGreetingSubtitle || "")}" placeholder="${escapeHtml(editingFest.theme.greetingSubtitle)}">
            </div>
            <div class="portal-field">
              <label for="fest-edit-start">Custom Start Date (${state.festivalFilterYear})</label>
              <input id="fest-edit-start" name="customStartDate" type="date" value="${escapeHtml(editingOverride.customStartDate || "")}">
              <p class="portal-hint">Default window: ${escapeHtml(editingWindow.startDate)} to ${escapeHtml(editingWindow.endDate)}</p>
            </div>
            <div class="portal-field">
              <label for="fest-edit-end">Custom End Date (${state.festivalFilterYear})</label>
              <input id="fest-edit-end" name="customEndDate" type="date" value="${escapeHtml(editingOverride.customEndDate || "")}">
            </div>
          </div>
          <div class="portal-actions">
            <button type="submit" class="portal-button portal-button--small">Save greeting &amp; dates</button>
            <button type="button" class="portal-button portal-button--quiet portal-button--small" data-fest-reset-one="${escapeHtml(editingFest.id)}">Reset this festival to default</button>
          </div>
        </form>
      </div>` : ""}

      <div class="portal-toolbar" style="margin-top:8px">
        <div class="portal-actions">
          ${years.map((y) => `<button type="button" class="yf-chip-btn ${Number(state.festivalFilterYear) === y ? "is-active" : ""}" data-fest-year="${y}">${y}</button>`).join("")}
          <select aria-label="Filter by tradition" data-fest-tradition style="min-height:36px;padding:6px 10px;border-radius:8px;border:1px solid var(--brand-line,#dbe6ef)">
            ${traditions.map((tr) => `<option value="${escapeHtml(tr)}"${state.festivalFilterTradition === tr ? " selected" : ""}>${escapeHtml(tr === "All" ? "All traditions" : tr)}</option>`).join("")}
          </select>
        </div>
        <input type="search" data-fest-search aria-label="Search festivals" value="${escapeHtml(state.festivalSearch)}" placeholder="Search Diwali, Holi, Eid, Christmas…">
      </div>

      <div class="portal-table-scroll">
        <table class="portal-table">
          <thead>
            <tr>
              <th>Festival</th>
              <th>Theme</th>
              <th>Tradition &amp; Calendar</th>
              <th>${state.festivalFilterYear} Date &amp; Window</th>
              <th>Greeting Message</th>
              <th>Controls</th>
            </tr>
          </thead>
          <tbody>
            ${filteredFestivals.map((fest) => {
              const ov = (cfg.overrides || {})[fest.id] || {};
              const win = engine.getFestivalWindow(fest, state.festivalFilterYear, ov);
              const isManualActive = cfg.mode === "manual" && cfg.manualFestivalId === fest.id;
              const isAutoActive = activeOcc && activeOcc.festival.id === fest.id;
              return `<tr>
                <td>
                  <span class="portal-cell-title">${escapeHtml(fest.name)}</span>
                  ${fest.moonSightingDependent ? `<span class="portal-cell-sub">Moon-sighting dependent (±1 day)</span>` : ""}
                </td>
                <td>
                  <span class="yf-swatch-dots" title="Theme colors">
                    ${(fest.theme.swatchColors || []).map((c) => `<span class="yf-swatch-dot" style="background:${escapeHtml(c)}"></span>`).join("")}
                  </span>
                </td>
                <td>
                  <span>${escapeHtml(fest.tradition)}</span>
                  <span class="portal-cell-sub">${escapeHtml(fest.calendarSystem)}</span>
                </td>
                <td>
                  <strong>${escapeHtml(formattedDate(win.primaryDate))}</strong>
                  <span class="portal-cell-sub">${escapeHtml(win.startDate)} → ${escapeHtml(win.endDate)}${(ov.customStartDate || ov.customEndDate) ? " (Custom)" : ""}</span>
                </td>
                <td>
                  <span>${escapeHtml(ov.customGreetingTitle || fest.theme.greetingTitle)}</span>
                  <span class="portal-cell-sub">${escapeHtml(ov.customGreetingSubtitle || fest.theme.greetingSubtitle)}</span>
                </td>
                <td>
                  <div class="portal-actions">
                    <button type="button" class="portal-button portal-button--quiet portal-button--small" data-fest-preview="${escapeHtml(fest.id)}">Preview</button>
                    <button type="button" class="portal-button portal-button--small" data-fest-activate="${escapeHtml(fest.id)}">${isManualActive ? "Active" : isAutoActive ? "Active (Auto)" : "Activate"}</button>
                    <button type="button" class="portal-button portal-button--quiet portal-button--small" data-fest-edit="${escapeHtml(fest.id)}">Edit</button>
                  </div>
                </td>
              </tr>`;
            }).join("")}
          </tbody>
        </table>
      </div>
    </div>`;

    // Bind controls cleanly
    content.querySelectorAll("[data-fest-mode]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const nextMode = btn.dataset.festMode;
        const nextCfg = {
          ...cfg,
          mode: nextMode,
          manualFestivalId: nextMode === "manual" ? (cfg.manualFestivalId || "diwali") : cfg.manualFestivalId,
        };
        try {
          await saveFestivalConfig(nextCfg, `Festival mode switched to ${nextMode}.`);
        } catch (err) {
          setFeedback(err.message, "error", "[data-admin-feedback]");
        }
      });
    });

    content.querySelectorAll("[data-fest-restore]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await restoreAutomaticFestivalDefaults(btn.dataset.festRestore === "true");
        } catch (err) {
          setFeedback(err.message, "error", "[data-admin-feedback]");
        }
      });
    });

    content.querySelector("[data-fest-apply-sim]")?.addEventListener("click", async () => {
      const val = content.querySelector("[data-fest-sim-date]")?.value || "";
      try {
        await saveFestivalConfig({ ...cfg, mode: "automatic", simulatedDateIST: val || null }, val ? `Simulating IST date ${val}.` : "Cleared simulated date.");
      } catch (err) {
        setFeedback(err.message, "error", "[data-admin-feedback]");
      }
    });

    content.querySelector("[data-fest-clear-sim]")?.addEventListener("click", async () => {
      try {
        await saveFestivalConfig({ ...cfg, mode: "automatic", simulatedDateIST: null, manualFestivalId: null }, "Restored real today IST date.");
      } catch (err) {
        setFeedback(err.message, "error", "[data-admin-feedback]");
      }
    });

    content.querySelectorAll("[data-fest-year]").forEach((btn) => {
      btn.addEventListener("click", () => {
        state.festivalFilterYear = Number(btn.dataset.festYear);
        renderFestivalsManager();
      });
    });

    content.querySelector("[data-fest-tradition]")?.addEventListener("change", (ev) => {
      state.festivalFilterTradition = ev.target.value;
      renderFestivalsManager();
    });

    const searchInput = content.querySelector("[data-fest-search]");
    if (searchInput) {
      searchInput.addEventListener("input", () => {
        state.festivalSearch = searchInput.value;
        const pos = searchInput.selectionStart;
        renderFestivalsManager();
        const nextInput = root.querySelector("[data-fest-search]");
        if (nextInput) {
          nextInput.focus();
          if (typeof pos === "number") nextInput.setSelectionRange(pos, pos);
        }
      });
    }

    content.querySelectorAll("[data-fest-preview]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const festId = btn.dataset.festPreview;
        state.previewFestivalId = festId;
        window.YuitorFestivalController?.setTransientConfig({
          ...cfg,
          mode: "manual",
          manualFestivalId: festId,
        });
        setFeedback(`Previewing "${festId}" theme live across the site. Click "Restore automatic settings" or reload to exit preview.`, "info", "[data-admin-feedback]");
      });
    });

    content.querySelectorAll("[data-fest-activate]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const festId = btn.dataset.festActivate;
        try {
          await saveFestivalConfig({ ...cfg, mode: "manual", manualFestivalId: festId }, `Manually activated festival theme: ${festId}.`);
        } catch (err) {
          setFeedback(err.message, "error", "[data-admin-feedback]");
        }
      });
    });

    content.querySelectorAll("[data-fest-edit]").forEach((btn) => {
      btn.addEventListener("click", () => {
        state.editingFestivalId = btn.dataset.festEdit;
        renderFestivalsManager();
      });
    });

    content.querySelector("[data-fest-close-edit]")?.addEventListener("click", () => {
      state.editingFestivalId = null;
      renderFestivalsManager();
    });

    content.querySelector("[data-fest-reset-one]")?.addEventListener("click", async (ev) => {
      const festId = ev.currentTarget.dataset.festResetOne;
      const nextOverrides = { ...(cfg.overrides || {}) };
      delete nextOverrides[festId];
      try {
        state.editingFestivalId = null;
        await saveFestivalConfig({ ...cfg, overrides: nextOverrides }, `Reset custom settings for ${festId}.`);
      } catch (err) {
        setFeedback(err.message, "error", "[data-admin-feedback]");
      }
    });

    const editForm = content.querySelector("[data-fest-edit-form]");
    if (editForm) {
      editForm.addEventListener("submit", async (ev) => {
        ev.preventDefault();
        const fd = new FormData(editForm);
        const festId = String(fd.get("festivalId") || "");
        const nextEntry = {};
        const title = String(fd.get("customGreetingTitle") || "").trim();
        const sub = String(fd.get("customGreetingSubtitle") || "").trim();
        const start = String(fd.get("customStartDate") || "").trim();
        const end = String(fd.get("customEndDate") || "").trim();
        if (title) nextEntry.customGreetingTitle = title;
        if (sub) nextEntry.customGreetingSubtitle = sub;
        if (start) nextEntry.customStartDate = start;
        if (end) nextEntry.customEndDate = end;
        const nextOverrides = { ...(cfg.overrides || {}) };
        if (Object.keys(nextEntry).length > 0) nextOverrides[festId] = nextEntry;
        else delete nextOverrides[festId];
        try {
          state.editingFestivalId = null;
          await saveFestivalConfig({ ...cfg, overrides: nextOverrides }, `Saved custom greeting & dates for ${festId}.`);
        } catch (err) {
          setFeedback(err.message, "error", "[data-admin-feedback]");
        }
      });
    }
  }

  function renderAdminContent() {
    if (state.selectedStudentId && state.dashboard) {
      const selected = (state.dashboard.students || []).find(
        (student) => Number(student.id) === Number(state.selectedStudentId),
      );
      if (selected) {
        renderStudentProfile(selected);
        return;
      }
      state.selectedStudentId = null;
    }
    if (state.view === "inquiries") renderInquiries();
    else if (state.view === "email") renderEmailComposer();
    else if (state.view === "festivals") renderFestivalsManager();
    else renderStudentsList();
  }

  async function loadDashboard(silent = false) {
    try {
      const [result, festRes] = await Promise.all([
        api("/api/admin.php?action=dashboard"),
        api("/api/admin.php?action=festival-config").catch(() => null),
      ]);
      state.dashboard = result;
      if (festRes && festRes.config) {
        state.festivalConfig = festRes.config;
      }
      renderMetrics();
      renderAdminContent();
      if (!silent) setFeedback("", "info", "[data-admin-feedback]");
    } catch (error) {
      if (!state.dashboard) {
        const content = root.querySelector("[data-admin-content]");
        if (content) content.innerHTML = `<div class="portal-empty">${escapeHtml(error.message)}</div>`;
      } else {
        setFeedback(error.message, "error", "[data-admin-feedback]");
      }
    }
  }

  async function renderAdmin(user) {
    setPortalMain(adminShell(user.display_name));
    bindLogout();
    root.querySelectorAll("[data-admin-view]").forEach((tab) => {
      tab.addEventListener("click", () => setAdminView(tab.dataset.adminView));
    });
    const content = root.querySelector("[data-admin-content]");
    if (content) {
      content.addEventListener("click", (event) => {
        const button = event.target.closest("[data-student-id]");
        if (!button) return;
        const student = (state.dashboard?.students || []).find(
          (item) => Number(item.id) === Number(button.dataset.studentId),
        );
        if (student) {
          state.selectedStudentId = Number(student.id);
          renderStudentProfile(student);
        }
      });
    }
    const refresh = document.createElement("button");
    refresh.type = "button";
    refresh.className = "portal-button portal-button--quiet portal-button--small";
    refresh.textContent = "Refresh records";
    refresh.setAttribute("data-refresh-records", "");
    const actions = root.querySelector(".portal-heading .portal-actions");
    if (actions) actions.insertBefore(refresh, actions.firstChild);
    refresh.addEventListener("click", () => loadDashboard());
    await loadDashboard();
    if (state.refreshTimer) window.clearInterval(state.refreshTimer);
    state.refreshTimer = window.setInterval(() => loadDashboard(true), 30000);
  }

  function studentShell(student) {
    const registrationLabel = labelText(student.registration_status);
    const feeStatus = labelText(student.fee_status);
    document.title = "Student Dashboard | Yuitor Smart Classes";
    return `<div class="portal-shell">
      <div class="portal-heading">
        <div><p class="portal-kicker">Yuitor Smart Classes · Customer / Student portal</p><h1>Hello, ${escapeHtml(student.full_name)}</h1><p class="portal-subtitle">Your course, admission and fee details are shown below. If something needs correction, contact the centre.</p></div>
        <div class="portal-actions">${statusBadge(student.registration_status, registrationLabel)}<button class="portal-button portal-button--quiet portal-button--small" type="button" data-portal-logout>Sign out</button></div>
      </div>
      ${student.registration_status === "pending" ? `<div class="portal-message">Your registration is received and pending confirmation. Admission date and fee schedule will appear after the centre updates your profile.</div>` : ""}
      <div class="portal-alert"><strong>Fee reminder</strong>${escapeHtml(student.fee_alert || "Please contact the centre for your fee schedule.")}</div>
      <div class="portal-student-grid">
        ${detail("Fee status", feeStatus)}
        ${detail("Admission date", formattedDate(student.admission_date))}
        ${detail("Selected subject", student.selected_subject)}
        ${detail("Course duration", `${Number(student.course_duration_months)} months`)}
        ${detail("Class / course", student.class_level)}
        ${detail("Next fee due", formattedDate(student.next_fee_due))}
      </div>
      <div class="portal-card portal-profile">
        <h2 class="portal-section-title">Your account details</h2>
        <div class="portal-personal-grid">
          ${detail("Student name", student.full_name)}
          ${detail("Email", student.email)}
          ${detail("Phone", student.phone)}
        </div>
        <details>
          <summary class="portal-text-link" style="cursor:pointer">Change password</summary>
          <form class="portal-form" data-change-password style="max-width:520px;margin-top:18px">
            <div class="portal-field"><label for="current-password">Current password</label><input id="current-password" name="currentPassword" type="password" autocomplete="current-password" required></div>
            <div class="portal-field"><label for="new-password">New password</label><input id="new-password" name="newPassword" type="password" minlength="12" autocomplete="new-password" required><p class="portal-hint">Use at least 12 characters.</p></div>
            <div class="portal-field"><label for="confirm-password">Confirm new password</label><input id="confirm-password" name="confirmPassword" type="password" minlength="12" autocomplete="new-password" required></div>
            <div class="portal-message" data-portal-feedback hidden role="status"></div>
            <button class="portal-button" type="submit">Update password</button>
          </form>
        </details>
      </div>
      <p class="portal-hint" style="margin-top:16px">For fee or admission corrections, visit the <a href="/contact" class="portal-text-link">Contact page</a>.</p>
    </div>`;
  }

  async function renderStudentDashboard(user) {
    setPortalMain(`<div class="portal-shell"><div class="portal-empty">Loading your student profile…</div></div>`);
    try {
      const result = await api("/api/student.php");
      const student = result.student;
      setPortalMain(studentShell(student));
      bindLogout();
      const form = root.querySelector("[data-change-password]");
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const values = new FormData(form);
        if (values.get("newPassword") !== values.get("confirmPassword")) {
          setFeedback("The new password and confirmation do not match.", "error");
          return;
        }
        const button = form.querySelector('button[type="submit"]');
        setFeedback("", "info");
        setBusy(button, true, "Updating…");
        try {
          const updated = await post("/api/student.php?action=change-password", {
            currentPassword: values.get("currentPassword"),
            newPassword: values.get("newPassword"),
          });
          state.csrfToken = updated.csrfToken || "";
          form.reset();
          setFeedback("Password updated successfully.", "success");
          setBusy(button, false);
        } catch (error) {
          setFeedback(error.message, "error");
          setBusy(button, false);
        }
      });
    } catch (error) {
      setPortalMain(`<div class="portal-shell">${messageMarkup(error.message, "error")}<a class="portal-button" href="/student/login.php">Return to student sign in</a></div>`);
    }
  }

  function renderRegistration() {
    document.title = "Student Registration | Yuitor Smart Classes";
    setPortalMain(`<div class="portal-shell">
      <div class="portal-login-card portal-card">
        <p class="portal-kicker">Yuitor Smart Classes · Student registration</p>
        <div class="portal-heading"><h1>Register as a student</h1><p class="portal-subtitle">Your registration is saved for the centre to review. Admission date and fee status remain pending until an admin confirms them.</p></div>
        <div class="portal-message" data-register-feedback hidden role="status"></div>
        <form class="portal-form" data-student-register>
          <div class="portal-form-grid">
            <div class="portal-field"><label for="register-name">Student full name</label><input id="register-name" name="fullName" maxlength="120" autocomplete="name" required></div>
            <div class="portal-field"><label for="register-phone">Phone number</label><input id="register-phone" name="phone" type="tel" maxlength="24" autocomplete="tel" required></div>
            <div class="portal-field"><label for="register-email">Email address (used to sign in)</label><input id="register-email" name="email" type="email" maxlength="254" autocomplete="email" required></div>
            <div class="portal-field"><label for="register-class">Class / course</label><input id="register-class" name="classLevel" maxlength="60" placeholder="e.g. Class 10, JEE, NEET" required></div>
            <div class="portal-field"><label for="register-subject">Selected subject</label><input id="register-subject" name="selectedSubject" maxlength="120" list="yuitor-subject-options" placeholder="e.g. Mathematics, Physics, Coding" required><datalist id="yuitor-subject-options"><option>Mathematics</option><option>Physics</option><option>Chemistry</option><option>Biology</option><option>English</option><option>Computer Science</option><option>JEE Preparation</option><option>NEET Preparation</option><option>CUET Preparation</option><option>Spoken English</option></datalist></div>
            <div class="portal-field"><label for="register-duration">Course duration (months)</label><input id="register-duration" name="courseDurationMonths" type="number" min="1" max="60" value="6" required></div>
            <div class="portal-field"><label for="register-password">Create password</label><input id="register-password" name="password" type="password" minlength="12" maxlength="200" autocomplete="new-password" required><p class="portal-hint">At least 12 characters.</p></div>
            <div class="portal-field"><label for="register-confirm-password">Confirm password</label><input id="register-confirm-password" name="confirmPassword" type="password" minlength="12" maxlength="200" autocomplete="new-password" required></div>
          </div>
          <div class="portal-honeypot" aria-hidden="true"><label for="register-website">Leave this field empty</label><input id="register-website" name="website" tabindex="-1" autocomplete="off"></div>
          <div class="portal-message" data-register-feedback hidden role="status"></div>
          <button class="portal-button" type="submit">Submit registration</button>
        </form>
        <div class="portal-inline-links"><a href="/student/login.php">Already registered? Sign in</a><a href="/contact">Contact the centre</a></div>
      </div>
    </div>`);

    const form = root.querySelector("[data-student-register]");
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const values = new FormData(form);
      if (values.get("password") !== values.get("confirmPassword")) {
        setFeedback("The password and confirmation do not match.", "error", "[data-register-feedback]");
        return;
      }
      const button = form.querySelector('button[type="submit"]');
      setFeedback("", "info", "[data-register-feedback]");
      setBusy(button, true, "Submitting…");
      try {
        const result = await post("/api/register.php", {
          fullName: values.get("fullName"),
          email: values.get("email"),
          phone: values.get("phone"),
          classLevel: values.get("classLevel"),
          selectedSubject: values.get("selectedSubject"),
          courseDurationMonths: Number(values.get("courseDurationMonths")),
          password: values.get("password"),
          website: values.get("website"),
        });
        form.reset();
        setFeedback(result.message || "Registration received.", "success", "[data-register-feedback]");
        setBusy(button, false);
      } catch (error) {
        setFeedback(error.message, "error", "[data-register-feedback]");
        setBusy(button, false);
      }
    });
  }

  async function startPortal(path) {
    if (path === "/student/register.php") {
      renderRegistration();
      return;
    }
    if (path === "/admin/setup.php") {
      await renderSetup();
      return;
    }

    let user = null;
    let authError = "";
    try {
      const result = await api("/api/auth.php?action=me");
      user = result.user || null;
      state.csrfToken = result.csrfToken || "";
    } catch (error) {
      authError = error.message;
    }

    if (path.startsWith("/admin")) {
      if (path.endsWith("/login.php")) {
        if (user?.role === "admin") {
          window.location.replace("/admin/");
          return;
        }
        await renderLogin("admin", authError);
        return;
      }
      if (user?.role === "admin") {
        await renderAdmin(user);
        return;
      }
      await renderLogin("admin", user ? "You are signed in as a student. Use the Student portal instead." : authError);
      return;
    }

    if (path.endsWith("/login.php")) {
      if (user?.role === "student") {
        window.location.replace("/student/");
        return;
      }
      await renderLogin("student", authError);
      return;
    }
    if (user?.role === "student") {
      await renderStudentDashboard(user);
      return;
    }
    await renderLogin("student", user ? "You are signed in as an admin. Use the Admin portal instead." : authError);
  }

  function boot() {
    const path = window.location.pathname.replace(/\/+$/, "") || "/";
    const isPortal = path.startsWith("/admin") || path.startsWith("/student");
    if (!isPortal) return;

    const mount = () => {
      const main = getMain();
      const header = root.querySelector(".yu-shared-header");
      const footer = root.querySelector(".yu-shared-footer");
      const notFoundPageReady = main?.textContent?.includes("404 Page Not Found");
      if (!main || !header || !footer || !notFoundPageReady || main.dataset.yuPortalMounted === "true") return false;
      main.classList.add("portal-main");
      main.dataset.yuPortalMounted = "true";
      startPortal(path);
      return true;
    };

    if (mount()) return;
    const observer = new MutationObserver(() => {
      if (mount()) observer.disconnect();
    });
    observer.observe(root, { childList: true, subtree: true });
    window.setTimeout(() => observer.disconnect(), 20000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
