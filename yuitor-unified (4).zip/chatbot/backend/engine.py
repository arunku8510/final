"""Core chatbot engine: rate limiting, sanitization, security check, typo/Hinglish normalization,
SQLite FTS5 retrieval over 100k+ Q&A pairs, sports GK/live-score handler, and safe fallback."""
from __future__ import annotations

import difflib
import json
import os
import re
import sqlite3
import threading
import time
import urllib.parse
import urllib.request
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

from backend.security import REFUSAL_MESSAGE, is_security_violation

MAX_MESSAGE_LEN = 300

# Domain vocabulary used for automatic fuzzy typo correction
DOMAIN_VOCAB: tuple[str, ...] = (
    "admission", "admissions", "apply", "address", "attendance", "batch", "batches",
    "banking", "board", "cancel", "cancellation", "cash", "cbse", "certificate",
    "certificates", "class", "classes", "coding", "coaching", "complaint", "complaints",
    "computer", "contact", "course", "courses", "cuet", "demo", "discount", "discounts",
    "document", "documents", "doubt", "eligibility", "eligible", "email", "emi",
    "english", "enroll", "enrollment", "exam", "exams", "facilities", "facility",
    "faculty", "fee", "fees", "fullstack", "holiday", "holidays", "hours", "icse",
    "inquiry", "installment", "installments", "jee", "location", "login", "mail",
    "material", "mock", "monthly", "muradnagar", "nda", "neet", "notes", "number",
    "offer", "offers", "offline", "online", "open", "parent", "payment", "payments",
    "phone", "policy", "policies", "privacy", "python", "receipt", "refund",
    "register", "registration", "result", "results", "rule", "rules", "scholarship",
    "seat", "seats", "spoken", "ssc", "student", "sunday", "syllabus", "teacher",
    "terms", "test", "time", "timing", "timings", "tuition", "up", "upi", "verify",
    "web", "website", "whatsapp", "yearly", "yuitor",
    "kaise", "kitni", "kitna", "kaha", "kahan", "kab", "milega", "milegi", "chahiye",
    "batao", "bataiye", "jaankari", "sampark", "daakhila", "fees", "chhutti",
)

TYPO_AND_SYNONYM_MAP: dict[str, str] = {
    "admision": "admission", "admsn": "admission", "admisn": "admission", "admisson": "admission",
    "admit": "admission", "enroll": "admission", "enrol": "admission", "join": "admission",
    "kese": "kaise", "kase": "kaise", "kaese": "kaise", "kaisa": "kaise", "how": "kaise",
    "kitni": "kitni", "ktna": "kitna", "ktni": "kitni", "kitna": "kitni",
    "fess": "fee", "fe": "fee", "feez": "fee", "fees": "fee", "shulk": "fee", "charge": "fee", "charges": "fee", "cost": "fee", "price": "fee",
    "refnd": "refund", "refand": "refund", "rifund": "refund", "refundd": "refund", "wapas": "refund", "wapsi": "refund",
    "cancle": "cancel", "kancel": "cancel", "cancell": "cancel", "cancellation": "cancel",
    "timng": "timing", "tyming": "timing", "timig": "timing", "samay": "timing", "hours": "timing", "schedule": "timing",
    "locashun": "location", "lokation": "location", "adres": "address", "adrs": "address", "addres": "address", "pata": "address", "kahan": "address", "kaha": "address",
    "cntact": "contact", "contct": "contact", "numbr": "number", "no": "number", "phn": "phone", "mob": "phone", "mobile": "phone", "call": "phone",
    "scholrshp": "scholarship", "scolarship": "scholarship", "skolarship": "scholarship",
    "documnts": "documents", "documnt": "documents", "documet": "documents", "docs": "documents", "dastavez": "documents", "kagaz": "documents",
    "certifcate": "certificate", "certficate": "certificate", "sartificate": "certificate",
    "instlment": "installment", "instalment": "installment", "installments": "installment", "kist": "installment",
    "computr": "computer", "compter": "computer", "pc": "computer",
    "englsh": "english", "inglish": "english", "spkn": "spoken",
    "codng": "coding", "koding": "coding", "programing": "coding",
    "pythn": "python", "py": "python",
    "paymnt": "payment", "pay": "payment", "bhugtan": "payment",
    "holidy": "holiday", "holidays": "holiday", "chutti": "holiday", "chhutti": "holiday", "chhutiyan": "holiday",
    "complnt": "complaint", "complan": "complaint", "shikayat": "complaint", "shikayt": "complaint",
    "eligibilty": "eligibility", "eligiblity": "eligibility", "yogyata": "eligibility",
    "facilty": "facilities", "facilites": "facilities", "suvidha": "facilities",
    "privcy": "privacy", "niyam": "rules", "rule": "rules", "term": "terms",
    "discnt": "discount", "disbount": "discount", "discunt": "discount", "descount": "discount", "chhoot": "discount", "waver": "waiver", "offr": "offer", "offers": "offer",
    "h": "hai", "ha": "hai", "kro": "karo", "krna": "karna", "btao": "batao",
    "saari": "all", "sabhi": "all", "poori": "all", "atoz": "all",
    "5th": "5", "6th": "6", "7th": "7", "8th": "8", "9th": "9", "10th": "10", "11th": "11", "12th": "12",
    "v": "5", "vi": "6", "vii": "7", "viii": "8", "ix": "9", "x": "10", "xi": "11", "xii": "12",
    "tenth": "10", "twelfth": "12", "eleventh": "11", "ninth": "9", "eighth": "8", "seventh": "7", "sixth": "6", "fifth": "5",
    "kaksha": "class", "cls": "class", "std": "class",
    "isc": "icse", "upboard": "up board",
    "mern": "fullstack",
    "subjects": "subjects", "subject": "subjects",
    "topics": "topics", "curriculum": "curriculum",
    "covered": "covered", "annual": "annual yearly",
    "doubt": "doubt", "doubts": "doubt", "material": "material", "notes": "notes",
}

DEVANAGARI_TO_EN: tuple[tuple[str, str], ...] = (
    ("फीस", "fee"), ("शुल्क", "fee"), ("किस्त", "installment"), ("ईएमआई", "emi"),
    ("एडमिशन", "admission"), ("दाखिला", "admission"), ("प्रवेश", "admission"),
    ("रिफंड", "refund"), ("वापसी", "refund"), ("वापस", "refund"),
    ("कैंसल", "cancel"), ("रद्द", "cancel"),
    ("टाइमिंग", "timing"), ("टाइम", "timing"), ("समय", "timing"),
    ("पता", "address"), ("लोकेशन", "address"), ("एड्रेस", "address"), ("कहाँ", "address"),
    ("संपर्क", "contact"), ("फोन", "phone"), ("नंबर", "phone"), ("व्हाट्सएप", "whatsapp"),
    ("ईमेल", "email"), ("मेल", "email"),
    ("छुट्टी", "holiday"), ("रविवार", "sunday"), ("संडे", "sunday"),
    ("दस्तावेज", "documents"), ("कागजात", "documents"), ("डॉक्यूमेंट", "documents"),
    ("योग्यता", "eligibility"),
    ("कोर्स", "course"), ("कक्षा", "class"), ("क्लास", "class"), ("बैच", "batch"),
    ("स्कॉलरशिप", "scholarship"), ("छात्रवृत्ति", "scholarship"), ("छूट", "discount"), ("ऑफर", "offer"),
    ("सर्टिफिकेट", "certificate"), ("प्रमाणपत्र", "certificate"),
    ("शिकायत", "complaint"), ("समस्या", "complaint"),
    ("प्राइवेसी", "privacy"), ("गोपनीयता", "privacy"),
    ("नियम", "rules"), ("शर्तें", "terms"),
    ("सुविधा", "facilities"), ("सुविधाएं", "facilities"),
    ("पेमेंट", "payment"), ("भुगतान", "payment"), ("यूपीआई", "upi"),
    ("कंप्यूटर", "computer"), ("अंग्रेजी", "english"), ("स्पोकन", "spoken"), ("कोडिंग", "coding"),
    ("ऑनलाइन", "online"), ("डेमो", "demo"), ("लॉगिन", "login"), ("रजिस्ट्रेशन", "registration"),
    ("नमस्ते", "namaste hello"), ("नमस्कार", "namaste hello"), ("धन्यवाद", "thanks"),
    ("क्रिकेट", "cricket"), ("मैच", "match"), ("स्कोर", "score"), ("फुटबॉल", "football"), ("आईपीएल", "ipl"),
    ("कितनी", "kitni"), ("कितना", "kitna"), ("कैसे", "kaise"), ("क्या", "kya"), ("कब", "kab"),
)

ENTITY_KEYWORDS: tuple[str, ...] = (
    "5", "6", "7", "8", "9", "10", "11", "12",
    "cbse", "icse", "neet", "jee", "cuet", "nda", "ssc", "banking",
    "computer", "english", "coding", "python", "fullstack", "aiml", "web",
    "crash", "basic", "advanced", "up", "full", "stack", "react", "node", "machine", "learning", "ai",
)

INTENT_KEYWORDS: tuple[str, ...] = (
    "fee", "installment", "emi", "discount", "scholarship", "offer", "contact", "phone",
    "email", "whatsapp", "address", "location", "timing", "holiday", "sunday", "admission",
    "documents", "eligibility", "course", "batch", "refund", "cancel", "payment", "upi",
    "certificate", "complaint", "privacy", "terms", "rules", "facilities", "demo", "login",
    "registration", "test", "syllabus", "subjects", "topics", "curriculum", "covered", "teacher", "doubt", "material",
)

STOP_WORDS: set[str] = {
    "a", "an", "the", "is", "are", "was", "were", "am", "in", "on", "at", "to", "for",
    "of", "by", "and", "or", "with", "from", "this", "that", "what", "which", "who",
    "please", "tell", "me", "give", "know", "want", "need", "do", "does", "can", "i",
    "you", "your", "my", "about", "hai", "hain", "ho", "ka", "ki", "ke", "ko", "se",
    "me", "mein", "par", "pe", "kya", "hota", "hoti", "milega", "milegi", "kar",
    "karein", "karna", "hai?", "batao", "bataiye", "bata", "sir", "mam", "ji",
}

SPORTS_KEYWORDS: set[str] = {
    "cricket", "football", "soccer", "ipl", "t20", "odi", "world cup", "virat", "kohli",
    "rohit", "dhoni", "sachin", "bcci", "icc", "fifa", "messi", "ronaldo", "cricbuzz",
    "espncricinfo", "wicket", "innings", "runs", "century", "live score", "score", "match",
}


def sanitize_input(text: str) -> str:
    """Strip HTML tags, control chars, and extra whitespace."""
    s = re.sub(r"<[^>]*>", " ", text or "")
    s = "".join(ch for ch in s if ch == "\n" or ch == "\t" or ord(ch) >= 32)
    return re.sub(r"\s+", " ", s).strip()


def normalize_query(text: str) -> str:
    """Normalize English, Hindi Devanagari, Hinglish & typos into clean search tokens."""
    s = sanitize_input(text).lower()
    for hi_word, en_word in DEVANAGARI_TO_EN:
        if hi_word in s:
            s = s + " " + en_word
    # Separate letters and digits like "class10" -> "class 10"
    s = re.sub(r"([a-z])(\d)", r"\1 \2", s)
    s = re.sub(r"(\d)([a-z])", r"\1 \2", s)
    # Collapse repeated consecutive letters (e.g., feeees -> fees, hellooo -> hello)
    s = re.sub(r"([a-z])\1{2,}", r"\1\1", s)
    raw_tokens = re.findall(r"[a-z0-9\u0900-\u097F]+", s)
    out: list[str] = []
    for tok in raw_tokens:
        if tok in TYPO_AND_SYNONYM_MAP:
            out.extend(TYPO_AND_SYNONYM_MAP[tok].split())
            continue
        # Handle simple singular/plural or missed typos with difflib
        if tok.isalpha() and len(tok) >= 5 and tok not in DOMAIN_VOCAB and tok not in STOP_WORDS and tok not in SPORTS_KEYWORDS:
            close = difflib.get_close_matches(tok, DOMAIN_VOCAB, n=1, cutoff=0.82)
            if close:
                mapped = TYPO_AND_SYNONYM_MAP.get(close[0], close[0])
                out.extend(mapped.split())
                continue
        out.append(tok)
    # Deduplicate preserving order
    seen: set[str] = set()
    uniq: list[str] = []
    for t in out:
        if t not in seen:
            seen.add(t)
            uniq.append(t)
    return " ".join(uniq)


class SlidingWindowRateLimiter:
    def __init__(self, max_requests: int = 30, window_seconds: int = 60) -> None:
        self.max_requests = max(1, max_requests)
        self.window_seconds = max(1, window_seconds)
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, client_key: str) -> tuple[bool, int]:
        now = time.monotonic()
        cutoff = now - self.window_seconds
        with self._lock:
            q = self._hits[client_key]
            while q and q[0] < cutoff:
                q.popleft()
            if len(q) >= self.max_requests:
                retry_after = max(1, int(self.window_seconds - (now - q[0])))
                return False, retry_after
            q.append(now)
            return True, 0


def build_sqlite_fts_index(jsonl_path: Path, sqlite_path: Path) -> int:
    """Build SQLite FTS5 search database from dataset.jsonl for fast 100k+ lookup."""
    if not jsonl_path.is_file():
        raise FileNotFoundError(f"Dataset file not found: {jsonl_path}")

    tmp_path = sqlite_path.with_suffix(".sqlite.tmp")
    if tmp_path.exists():
        tmp_path.unlink()

    conn = sqlite3.connect(str(tmp_path))
    conn.execute("PRAGMA journal_mode=OFF")
    conn.execute("PRAGMA synchronous=OFF")
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute(
        """
        CREATE TABLE kb_items (
            id INTEGER PRIMARY KEY,
            category TEXT NOT NULL,
            question TEXT NOT NULL,
            norm_q TEXT NOT NULL,
            answer TEXT NOT NULL,
            language TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE VIRTUAL TABLE kb_fts USING fts5(
            norm_q,
            category,
            content='kb_items',
            content_rowid='id',
            tokenize='unicode61'
        )
        """
    )

    batch: list[tuple[int, str, str, str, str, str]] = []
    count = 0
    with jsonl_path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            count += 1
            q_text = row["question"]
            norm_q = row.get("norm_q") or normalize_query(q_text)
            batch.append((int(row["id"]), row["category"], q_text, norm_q, row["answer"], row["language"]))
            if len(batch) >= 5000:
                conn.executemany(
                    "INSERT INTO kb_items (id, category, question, norm_q, answer, language) VALUES (?, ?, ?, ?, ?, ?)",
                    batch,
                )
                batch.clear()
        if batch:
            conn.executemany(
                "INSERT INTO kb_items (id, category, question, norm_q, answer, language) VALUES (?, ?, ?, ?, ?, ?)",
                batch,
            )

    conn.execute("INSERT INTO kb_fts(kb_fts) VALUES('rebuild')")
    conn.commit()
    conn.close()
    tmp_path.replace(sqlite_path)
    return count


class ChatbotEngine:
    def __init__(
        self,
        base_dir: Path | None = None,
        rate_limit_max: int | None = None,
        rate_limit_window: int | None = None,
    ) -> None:
        self.base_dir = base_dir or Path(__file__).resolve().parent.parent
        cfg_path = Path(os.getenv("BUSINESS_CONFIG_PATH", str(self.base_dir / "business_config.json")))
        if not cfg_path.is_absolute():
            cfg_path = self.base_dir / cfg_path
        with cfg_path.open("r", encoding="utf-8") as f:
            self.biz: dict[str, Any] = json.load(f)

        self.jsonl_path = Path(os.getenv("KB_JSONL_PATH", str(self.base_dir / "data" / "dataset.jsonl")))
        if not self.jsonl_path.is_absolute():
            self.jsonl_path = self.base_dir / self.jsonl_path

        self.sqlite_path = Path(os.getenv("KB_SQLITE_PATH", str(self.base_dir / "data" / "kb.sqlite")))
        if not self.sqlite_path.is_absolute():
            self.sqlite_path = self.base_dir / self.sqlite_path

        if not self.sqlite_path.is_file() and self.jsonl_path.is_file():
            build_sqlite_fts_index(self.jsonl_path, self.sqlite_path)

        self.sports_api_key = os.getenv("SPORTS_API_KEY", "").strip()
        self.sports_api_url = os.getenv("SPORTS_API_URL", "").strip()

        rl_max = rate_limit_max if rate_limit_max is not None else int(os.getenv("RATE_LIMIT_MAX", "30"))
        rl_win = rate_limit_window if rate_limit_window is not None else int(os.getenv("RATE_LIMIT_WINDOW", "60"))
        self.limiter = SlidingWindowRateLimiter(rl_max, rl_win)
        self._local = threading.local()

    def _get_conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(f"file:{self.sqlite_path}?mode=ro", uri=True, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return conn

    def stats(self) -> dict[str, Any]:
        conn = self._get_conn()
        total = conn.execute("SELECT COUNT(*) FROM kb_items").fetchone()[0]
        cats = conn.execute("SELECT COUNT(DISTINCT category) FROM kb_items").fetchone()[0]
        return {"entries": total, "categories": cats, "business": self.biz["name"]}

    def fallback_reply(self) -> str:
        return f"Is baare mein pakki jaankari ke liye {self.biz['phone']} par sampark karein. (Email: {self.biz['email']})"

    def _handle_sports(self, message: str, norm: str) -> dict[str, Any] | None:
        toks = set(norm.split())
        low = message.lower()
        is_sports = bool(toks & SPORTS_KEYWORDS) or any(k in low for k in ("world cup", "live score", "cricket match", "football match", "ipl"))
        # Avoid hijacking business queries like "admission test score" or "scholarship test"
        if not is_sports or (toks & {"yuitor", "admission", "scholarship", "fee", "batch", "class", "coaching"}):
            return None

        wants_live = any(w in low for w in ("live", "score", "aaj ka", "today", "abhi", "chal raha", "kiska match", "kitne run", "who won today"))
        steer = f"Waise agar aapko {self.biz['name']} ke courses, fees ya admission ke baare mein jaankari chahiye toh zaroor poochein!"

        if wants_live and self.sports_api_key and self.sports_api_url:
            try:
                url = f"{self.sports_api_url}?apikey={urllib.parse.quote(self.sports_api_key)}"
                req = urllib.request.Request(url, headers={"User-Agent": "YuitorSupportBot/1.0"})
                with urllib.request.urlopen(req, timeout=4) as resp:
                    payload = json.loads(resp.read().decode("utf-8", errors="ignore"))
                matches = payload.get("data") or []
                if isinstance(matches, list) and matches:
                    top = matches[0]
                    name = top.get("name", "Live Match")
                    status = top.get("status", "In progress")
                    return {
                        "reply": f"Live update ({name}): {status}. {steer}",
                        "category": "sports_live",
                        "confidence": 0.9,
                        "blocked": False,
                    }
            except Exception:
                pass

        if wants_live:
            reply = (
                "Live match scores har minute badalte rehte hain, isliye main exact live score guess nahi karta. "
                f"Real-time score ke liye kripya Cricbuzz ya ESPNcricinfo check karein. {steer}"
            )
            return {"reply": reply, "category": "sports_live", "confidence": 0.9, "blocked": False}

        # General cricket/football GK via KB if present, else polite GK summary
        if "cricket" in toks or "ipl" in toks or "virat" in toks or "rohit" in toks or "dhoni" in toks or "icc" in toks:
            reply = (
                "Cricket ek 11-players per team khela jaane wala sport hai jiske 3 main formats hain: Test, ODI (50 overs), aur T20 (20 overs). "
                "IPL India ki premier T20 league hai aur ICC international cricket govern karta hai. "
                f"Live scores ke liye Cricbuzz/ESPNcricinfo dekhein. {steer}"
            )
            return {"reply": reply, "category": "sports_gk", "confidence": 0.88, "blocked": False}

        if "football" in toks or "soccer" in toks or "fifa" in toks or "messi" in toks or "ronaldo" in toks:
            reply = (
                "Football 90 minutes ka team sport hai (11 players per team) jise FIFA globally govern karta hai aur FIFA World Cup har 4 saal mein hota hai. "
                f"Live scores ke liye ESPN ya Cricbuzz/official apps dekhein. {steer}"
            )
            return {"reply": reply, "category": "sports_gk", "confidence": 0.88, "blocked": False}

        reply = (
            "Live match scores aur schedules har minute update hote hain — real-time scores ke liye Cricbuzz ya ESPNcricinfo dekhein. "
            f"{steer}"
        )
        return {"reply": reply, "category": "sports_gk", "confidence": 0.82, "blocked": False}

    def _handle_atoz_and_discounts(self, cleaned: str, norm: str) -> dict[str, Any] | None:
        low = cleaned.lower()
        toks = set(norm.split())
        asks_atoz = bool(re.search(r"(a\s*to\s*z|a-z|all fees|all courses fee|complete fee|full fee|sabhi fee|saari fee)", low)) or (
            "all" in toks and "fee" in toks and not (toks & set(ENTITY_KEYWORDS))
        )
        if asks_atoz:
            reply = (
                "Yuitor Smart Classes — Complete A-to-Z Fee Structure & Discounts:\n"
                "• Classes 5–6: CBSE ₹1,000/mo (₹10,200/yr) | UP Board ₹900/mo (₹9,200/yr) | ICSE ₹1,200/mo (₹12,200/yr)\n"
                "• Classes 7–8: CBSE ₹1,100/mo (₹11,200/yr) | UP Board ₹1,000/mo (₹10,200/yr) | ICSE ₹1,300/mo (₹13,300/yr)\n"
                "• Classes 9–10: CBSE ₹1,400/mo (₹14,300/yr) | UP Board ₹1,200/mo (₹12,200/yr) | ICSE ₹1,500/mo (₹15,300/yr)\n"
                "• Classes 11–12: CBSE ₹1,700/mo (₹17,300/yr) | UP Board ₹1,500/mo (₹15,300/yr) | ICSE/ISC ₹1,800/mo (₹18,300/yr)\n"
                "• Exams: NEET Full ₹2,400/mo (₹24,500/yr) | NEET Crash ₹3,000/mo | JEE Full ₹2,400/mo (₹24,500/yr) | JEE Crash ₹3,000/mo | CUET ₹2,000/mo | NDA ₹2,200/mo | SSC/Banking ₹1,800/mo\n"
                "• Skill Courses: Computer ₹1,200–₹1,800/mo | Spoken English ₹1,500–₹2,200/mo | Coding Basic/Adv ₹800–₹1,200/mo | Web Dev ₹1,700/mo | Python ₹2,100/mo | Full Stack ₹3,000/mo | AI & ML ₹2,500/mo\n"
                "• Discounts: ~15% Yearly savings + Scholarship Test (/scholarship, Every Sunday 10 AM, Free Reg): Rank 1 = 50% OFF, Rank 2–5 = 30% OFF, Rank 6–10 = 20% OFF, Rank 11–20 = 10% OFF.\n"
                f"Check: {self.biz['website']}/fee-calculator | Call: {self.biz['phone']} ({self.biz['email']})"
            )
            return {"reply": reply, "category": "fee", "confidence": 0.99, "blocked": False}

        asks_discount_only = bool(toks & {"discount", "scholarship", "offer", "waiver"}) and not (toks & set(ENTITY_KEYWORDS))
        if asks_discount_only:
            return {
                "reply": (
                    f"{self.biz['discounts_offers']} "
                    f"100% 7-day refund ({self.biz['website']}/refund) bhi uplabdh hai. Call: {self.biz['phone']}"
                ),
                "category": "discounts",
                "confidence": 0.98,
                "blocked": False,
            }
        return None

    def answer(self, raw_message: str, client_ip: str = "127.0.0.1") -> tuple[int, dict[str, Any]]:
        allowed, retry_after = self.limiter.allow(client_ip)
        if not allowed:
            return 429, {
                "reply": f"Bahut tez messages bheje gaye hain. Kripya {retry_after} second baad try karein.",
                "category": "rate_limit",
                "confidence": 0.0,
                "blocked": False,
            }

        cleaned = sanitize_input(raw_message)
        if not cleaned:
            return 400, {
                "reply": "Kripya apna sawaal likhein (1 se 300 characters ke beech).",
                "category": "validation_error",
                "confidence": 0.0,
                "blocked": False,
            }
        if len(cleaned) > MAX_MESSAGE_LEN:
            return 400, {
                "reply": f"Message {MAX_MESSAGE_LEN} characters se kam rakhein.",
                "category": "validation_error",
                "confidence": 0.0,
                "blocked": False,
            }

        # 1. STRICT PRE-ANSWER SECURITY LAYER
        violated, _reason = is_security_violation(cleaned)
        if violated:
            return 200, {
                "reply": REFUSAL_MESSAGE,
                "category": "security_refusal",
                "confidence": 1.0,
                "blocked": True,
            }

        norm = normalize_query(cleaned)
        if not norm:
            return 200, {
                "reply": self.fallback_reply(),
                "category": "fallback",
                "confidence": 0.0,
                "blocked": False,
            }

        # 2. SPORTS / MATCH / GENERAL KNOWLEDGE
        sports_res = self._handle_sports(cleaned, norm)
        if sports_res is not None:
            return 200, sports_res

        # 2.5 COMPLETE A-TO-Z FEES & RANK-WISE DISCOUNTS
        atoz_res = self._handle_atoz_and_discounts(cleaned, norm)
        if atoz_res is not None:
            return 200, atoz_res

        # 3. FAST SQLITE FTS5 RETRIEVAL OVER 100K+ ENTRIES
        tokens = [t for t in norm.split() if len(t) >= 1]
        meaningful = [t for t in tokens if t not in STOP_WORDS and (len(t) >= 2 or t.isdigit())]
        if not meaningful:
            meaningful = tokens

        # Build safe FTS query using sanitized alphanumeric/Devanagari tokens
        fts_tokens = [re.sub(r"[^\w\u0900-\u097F]", "", t) for t in meaningful]
        fts_tokens = [t for t in fts_tokens if t]
        if not fts_tokens:
            return 200, {
                "reply": self.fallback_reply(),
                "category": "fallback",
                "confidence": 0.0,
                "blocked": False,
            }

        conn = self._get_conn()
        candidates: list[sqlite3.Row] = []
        seen_ids: set[int] = set()

        # Pass A: strict AND over up to 5 highest-signal tokens (entities/intents first)
        prioritized = [t for t in fts_tokens if t in ENTITY_KEYWORDS or t in INTENT_KEYWORDS]
        and_terms = (prioritized + [t for t in fts_tokens if t not in prioritized])[:5]
        if len(and_terms) >= 2:
            and_q = " AND ".join(f'"{t}"' for t in and_terms)
            for r in conn.execute(
                """
                SELECT kb_items.id, kb_items.category, kb_items.question, kb_items.norm_q, kb_items.answer,
                       bm25(kb_fts) AS rank
                FROM kb_fts
                JOIN kb_items ON kb_items.id = kb_fts.rowid
                WHERE kb_fts MATCH ?
                ORDER BY rank
                LIMIT 25
                """,
                (and_q,),
            ):
                if r["id"] not in seen_ids:
                    seen_ids.add(r["id"])
                    candidates.append(r)

        # Pass A2: if strict multi-term AND had few hits, try entity+intent pair
        if len(candidates) < 5 and len(prioritized) >= 2:
            pair_q = " AND ".join(f'"{t}"' for t in prioritized[:2])
            for r in conn.execute(
                """
                SELECT kb_items.id, kb_items.category, kb_items.question, kb_items.norm_q, kb_items.answer,
                       bm25(kb_fts) AS rank
                FROM kb_fts
                JOIN kb_items ON kb_items.id = kb_fts.rowid
                WHERE kb_fts MATCH ?
                ORDER BY rank
                LIMIT 20
                """,
                (pair_q,),
            ):
                if r["id"] not in seen_ids:
                    seen_ids.add(r["id"])
                    candidates.append(r)

        # Pass B: broader OR search ONLY when AND passes returned fewer than 5 candidates
        if len(candidates) < 5:
            or_terms = (prioritized + [t for t in fts_tokens if t not in prioritized])[:5]
            or_q = " OR ".join(f'"{t}"' for t in or_terms)
            for r in conn.execute(
                """
                SELECT kb_items.id, kb_items.category, kb_items.question, kb_items.norm_q, kb_items.answer,
                       bm25(kb_fts) AS rank
                FROM kb_fts
                JOIN kb_items ON kb_items.id = kb_fts.rowid
                WHERE kb_fts MATCH ?
                ORDER BY rank
                LIMIT 25
                """,
                (or_q,),
            ):
                if r["id"] not in seen_ids:
                    seen_ids.add(r["id"])
                    candidates.append(r)

        if not candidates:
            return 200, {
                "reply": self.fallback_reply(),
                "category": "fallback",
                "confidence": 0.0,
                "blocked": False,
            }

        q_set = set(meaningful)
        q_entities = {t for t in meaningful if t in ENTITY_KEYWORDS}
        q_intents = {t for t in meaningful if t in INTENT_KEYWORDS}
        if q_entities and "fee" in q_intents:
            q_intents.discard("discount")

        best_row = None
        best_score = 0.0
        for row in candidates:
            c_tokens = [t for t in row["norm_q"].split() if t not in STOP_WORDS and (len(t) >= 2 or t.isdigit())]
            c_set = set(c_tokens) or set(row["norm_q"].split())
            if not c_set:
                continue

            overlap = len(q_set & c_set)
            recall = overlap / max(1, len(q_set))
            jaccard = overlap / max(1, len(q_set | c_set))
            seq_sim = difflib.SequenceMatcher(None, norm, row["norm_q"]).ratio()

            c_entities = {t for t in c_set if t in ENTITY_KEYWORDS}
            c_intents = {t for t in c_set if t in INTENT_KEYWORDS}

            entity_score = 0.0
            if q_entities:
                if q_entities <= c_entities:
                    entity_score = 0.25
                elif q_entities & c_entities:
                    entity_score = 0.05
                else:
                    entity_score = -0.35
                # Penalize extra mismatched class numbers (e.g. asked Class 10, matched Class 5)
                q_nums = {t for t in q_entities if t.isdigit()}
                c_nums = {t for t in c_entities if t.isdigit()}
                if q_nums and c_nums and not (q_nums & c_nums):
                    entity_score -= 0.45
                q_boards = q_entities & {"cbse", "icse", "up"}
                c_boards = c_entities & {"cbse", "icse", "up"}
                if q_boards and c_boards and not (q_boards & c_boards):
                    entity_score -= 0.45

            intent_score = 0.0
            if q_intents:
                if q_intents & c_intents or any(i in row["category"] for i in q_intents):
                    intent_score = 0.20
                else:
                    intent_score = -0.15

            score = (0.42 * recall) + (0.20 * jaccard) + (0.18 * seq_sim) + entity_score + intent_score
            if score > best_score:
                best_score = score
                best_row = row

        # Confidence gate: refuse to guess on out-of-scope / ambiguous gibberish
        if best_row is None or best_score < 0.40:
            return 200, {
                "reply": self.fallback_reply(),
                "category": "fallback",
                "confidence": round(max(0.0, best_score), 3),
                "blocked": False,
            }

        return 200, {
            "reply": best_row["answer"],
            "category": best_row["category"],
            "confidence": round(min(1.0, best_score), 3),
            "blocked": False,
        }
