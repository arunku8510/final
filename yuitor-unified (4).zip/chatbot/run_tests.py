"""Automated accuracy, security, input-validation, and rate-limit test runner."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from backend.engine import ChatbotEngine  # noqa: E402
from backend.security import REFUSAL_MESSAGE  # noqa: E402


def main() -> int:
    tests_path = BASE_DIR / "data" / "tests.jsonl"
    if not tests_path.exists():
        print("ERROR: data/tests.jsonl not found. Run generate_dataset.py first.")
        return 1

    engine = ChatbotEngine(base_dir=BASE_DIR)
    print(f"Loaded KB stats: {engine.stats()}")

    tests = [json.loads(line) for line in tests_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    func_tests = [t for t in tests if t["type"] != "security"]
    sec_tests = [t for t in tests if t["type"] == "security"]

    func_pass = 0
    sec_pass = 0
    func_failures: list[dict] = []
    sec_failures: list[dict] = []

    t0 = time.perf_counter()

    for idx, t in enumerate(func_tests):
        code, resp = engine.answer(t["question"], client_ip=f"10.0.{idx // 200}.{idx % 200}")
        reply_low = resp["reply"].lower()
        ok = (
            code == 200
            and not resp.get("blocked", False)
            and (bool(t.get("expected_any")) and any(exp.lower() in reply_low for exp in t["expected_any"]))
        )
        if ok:
            func_pass += 1
        elif len(func_failures) < 20:
            func_failures.append({
                "id": t.get("id", idx),
                "type": t["type"],
                "question": t["question"],
                "expected": t.get("expected_any"),
                "got_category": resp.get("category"),
                "got_conf": resp.get("confidence"),
                "got_reply": resp["reply"][:140],
            })

    for idx, t in enumerate(sec_tests):
        code, resp = engine.answer(t["question"], client_ip=f"10.1.{idx // 200}.{idx % 200}")
        ok = (
            code == 200
            and resp.get("blocked") is True
            and resp.get("reply") == REFUSAL_MESSAGE
        )
        if ok:
            sec_pass += 1
        elif len(sec_failures) < 20:
            sec_failures.append({
                "id": t.get("id", idx),
                "question": t["question"],
                "got_blocked": resp.get("blocked"),
                "got_reply": resp.get("reply", "")[:120],
            })

    # Guardrail unit checks (length cap, XSS sanitization, empty message, rate limiting)
    guard_checks = []
    c_empty, _ = engine.answer("   ", client_ip="10.9.0.1")
    guard_checks.append(("empty_rejected_400", c_empty == 400))

    c_long, _ = engine.answer("a" * 301, client_ip="10.9.0.2")
    guard_checks.append(("over_300_chars_rejected_400", c_long == 400))

    c_xss, r_xss = engine.answer("<script>alert(1)</script> fee kitni h", client_ip="10.9.0.3")
    guard_checks.append(("xss_sanitized_and_answered", c_xss == 200 and "<script" not in r_xss["reply"].lower()))

    rl_codes = [engine.answer("fee kitni h", client_ip="10.9.0.99")[0] for _ in range(engine.limiter.max_requests + 2)]
    guard_checks.append(("rate_limit_enforced_429", rl_codes[-1] == 429 and rl_codes[0] == 200))

    elapsed = time.perf_counter() - t0
    func_acc = (func_pass / max(1, len(func_tests))) * 100.0
    sec_acc = (sec_pass / max(1, len(sec_tests))) * 100.0
    guards_ok = all(ok for _, ok in guard_checks)

    print("\n================ TEST RESULTS ================")
    print(f"Functional Accuracy : {func_pass}/{len(func_tests)} ({func_acc:.2f}%)")
    print(f"Security Refusal    : {sec_pass}/{len(sec_tests)} ({sec_acc:.2f}%)")
    print(f"Guardrail Checks    : {sum(1 for _, o in guard_checks if o)}/{len(guard_checks)} -> {guard_checks}")
    print(f"Total Runtime       : {elapsed:.2f}s (~{(elapsed / max(1, len(tests))) * 1000:.2f} ms/query)")
    print("==============================================")

    if func_failures:
        print("\nSample Functional Failures:")
        for f in func_failures:
            print(f"  - [{f.get('id', '?')}] Q={f['question']!r} | got=({f['got_category']}, {f['got_conf']}) {f['got_reply']!r}")
    if sec_failures:
        print("\nSecurity Failures (CRITICAL):")
        for f in sec_failures:
            print(f"  - [{f.get('id', '?')}] Q={f['question']!r} | blocked={f['got_blocked']} reply={f['got_reply']!r}")

    if sec_pass < len(sec_tests) or func_acc < 95.0 or not guards_ok:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
