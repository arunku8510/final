(function () {
  "use strict";

  var scriptEl =
    document.currentScript ||
    document.querySelector('script[src*="chatbot-widget"]');

  var API_URL =
    (scriptEl && scriptEl.getAttribute("data-api")) ||
    "http://localhost:8000/chat";
  var BOT_TITLE =
    (scriptEl && scriptEl.getAttribute("data-title")) ||
    "Yuitor Smart AI";
  var SUBTITLE =
    (scriptEl && scriptEl.getAttribute("data-subtitle")) ||
    "Hindi • English • Hinglish";
  var MAX_LEN = 300;

  var QUICK_REPLIES = [
    { label: "All Fees (A-Z)", query: "A to Z fee structure batao" },
    { label: "Discounts & Scholarship", query: "Kitna discount aur scholarship milta hai?" },
    { label: "Admission", query: "Admission process kya hai?" },
    { label: "Contact", query: "Contact number aur address batao" }
  ];

  function injectStyles() {
    if (document.getElementById("yt-cb-styles")) return;
    var style = document.createElement("style");
    style.id = "yt-cb-styles";
    style.textContent = [
      ".yt-cb-root, .yt-cb-root * { box-sizing: border-box; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }",
      ".yt-cb-launcher { position: fixed; right: 20px; bottom: 20px; z-index: 2147483000; display: inline-flex; align-items: center; gap: 10px; background: #0f3d2e; color: #ffffff; border: 2px solid #165b44; border-radius: 999px; padding: 12px 18px; font-size: 14px; font-weight: 600; cursor: pointer; box-shadow: 0 12px 30px rgba(15, 61, 46, 0.28); transition: transform 0.16s ease, background-color 0.16s ease; }",
      ".yt-cb-launcher:hover { background: #14533f; transform: translateY(-2px); }",
      ".yt-cb-launcher:focus-visible, .yt-cb-btn:focus-visible, .yt-cb-chip:focus-visible, .yt-cb-input:focus-visible { outline: 3px solid #f59e0b; outline-offset: 2px; }",
      ".yt-cb-panel { position: fixed; right: 20px; bottom: 84px; z-index: 2147483001; width: 375px; max-width: calc(100vw - 24px); height: 540px; max-height: calc(100vh - 110px); background: #ffffff; border: 1px solid #d1d5db; border-radius: 16px; box-shadow: 0 22px 48px rgba(15, 23, 42, 0.24); display: none; flex-direction: column; overflow: hidden; }",
      ".yt-cb-panel.is-open { display: flex; }",
      ".yt-cb-header { background: #0f3d2e; color: #ffffff; padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; gap: 12px; }",
      ".yt-cb-title { margin: 0; font-size: 15px; font-weight: 700; line-height: 1.25; }",
      ".yt-cb-sub { margin: 2px 0 0; font-size: 12px; color: #cbd5e1; }",
      ".yt-cb-close { background: rgba(255,255,255,0.14); color: #ffffff; border: none; border-radius: 8px; width: 32px; height: 32px; font-size: 18px; line-height: 1; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }",
      ".yt-cb-close:hover { background: rgba(255,255,255,0.24); }",
      ".yt-cb-messages { flex: 1; overflow-y: auto; padding: 14px; background: #f8fafc; display: flex; flex-direction: column; gap: 10px; }",
      ".yt-cb-msg { max-width: 86%; padding: 10px 13px; border-radius: 12px; font-size: 13.5px; line-height: 1.5; white-space: pre-wrap; word-break: break-word; }",
      ".yt-cb-msg.bot { align-self: flex-start; background: #ffffff; color: #0f172a; border: 1px solid #e2e8f0; border-bottom-left-radius: 4px; }",
      ".yt-cb-msg.user { align-self: flex-end; background: #0f3d2e; color: #ffffff; border-bottom-right-radius: 4px; }",
      ".yt-cb-msg.bot a { color: #0f5132; font-weight: 600; text-decoration: underline; }",
      ".yt-cb-typing { align-self: flex-start; display: inline-flex; align-items: center; gap: 5px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 10px 14px; font-size: 12.5px; color: #475569; }",
      ".yt-cb-dot { width: 6px; height: 6px; border-radius: 50%; background: #0f3d2e; opacity: 0.4; animation: yt-cb-bounce 1.2s infinite ease-in-out; }",
      ".yt-cb-dot:nth-child(2) { animation-delay: 0.2s; }",
      ".yt-cb-dot:nth-child(3) { animation-delay: 0.4s; }",
      "@keyframes yt-cb-bounce { 0%, 80%, 100% { transform: scale(0.75); opacity: 0.35; } 40% { transform: scale(1.15); opacity: 1; } }",
      ".yt-cb-quick { padding: 8px 12px; background: #ffffff; border-top: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; gap: 6px; }",
      ".yt-cb-chip { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; border-radius: 8px; padding: 6px 10px; font-size: 12px; font-weight: 600; cursor: pointer; }",
      ".yt-cb-chip:hover { background: #d1fae5; }",
      ".yt-cb-form { padding: 10px 12px; background: #ffffff; border-top: 1px solid #e2e8f0; }",
      ".yt-cb-input-row { display: flex; gap: 8px; align-items: center; }",
      ".yt-cb-input { flex: 1; border: 1px solid #cbd5e1; border-radius: 10px; padding: 9px 12px; font-size: 13.5px; color: #0f172a; background: #ffffff; }",
      ".yt-cb-btn { background: #0f3d2e; color: #ffffff; border: none; border-radius: 10px; padding: 9px 14px; font-size: 13.5px; font-weight: 600; cursor: pointer; }",
      ".yt-cb-btn:disabled { opacity: 0.55; cursor: not-allowed; }",
      ".yt-cb-meta { margin-top: 5px; display: flex; justify-content: space-between; font-size: 11px; color: #64748b; }",
      "@media (max-width: 480px) { .yt-cb-panel { right: 8px; left: 8px; bottom: 76px; width: auto; max-width: none; height: 74vh; max-height: calc(100vh - 90px); } .yt-cb-launcher { right: 12px; bottom: 12px; } }"
    ].join("\n");
    document.head.appendChild(style);
  }

  function renderSafeText(container, text) {
    var urlRegex = /(https?:\/\/[^\s]+)/g;
    var parts = String(text || "").split(urlRegex);
    for (var i = 0; i < parts.length; i++) {
      var part = parts[i];
      if (!part) continue;
      if (/^https?:\/\/[^\s]+$/.test(part)) {
        var a = document.createElement("a");
        a.href = part;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        a.textContent = part;
        container.appendChild(a);
      } else {
        container.appendChild(document.createTextNode(part));
      }
    }
  }

  function initWidget() {
    if (document.getElementById("yt-cb-root")) return;
    injectStyles();

    var root = document.createElement("div");
    root.id = "yt-cb-root";
    root.className = "yt-cb-root";

    var launcher = document.createElement("button");
    launcher.type = "button";
    launcher.className = "yt-cb-launcher";
    launcher.setAttribute("aria-expanded", "false");
    launcher.setAttribute("aria-controls", "yt-cb-panel");
    launcher.setAttribute("aria-label", "Open Yuitor Smart AI chat");
    launcher.textContent = "Yuitor Smart AI";

    var panel = document.createElement("section");
    panel.id = "yt-cb-panel";
    panel.className = "yt-cb-panel";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", BOT_TITLE);
    panel.setAttribute("aria-hidden", "true");

    var header = document.createElement("header");
    header.className = "yt-cb-header";

    var titleWrap = document.createElement("div");
    var titleEl = document.createElement("h2");
    titleEl.className = "yt-cb-title";
    titleEl.textContent = BOT_TITLE;
    var subEl = document.createElement("p");
    subEl.className = "yt-cb-sub";
    subEl.textContent = SUBTITLE;
    titleWrap.appendChild(titleEl);
    titleWrap.appendChild(subEl);

    var closeBtn = document.createElement("button");
    closeBtn.type = "button";
    closeBtn.className = "yt-cb-close";
    closeBtn.setAttribute("aria-label", "Close chat");
    closeBtn.textContent = "×";

    header.appendChild(titleWrap);
    header.appendChild(closeBtn);

    var messagesEl = document.createElement("div");
    messagesEl.className = "yt-cb-messages";
    messagesEl.setAttribute("role", "log");
    messagesEl.setAttribute("aria-live", "polite");
    messagesEl.setAttribute("aria-relevant", "additions");

    var quickEl = document.createElement("div");
    quickEl.className = "yt-cb-quick";
    quickEl.setAttribute("aria-label", "Quick reply shortcuts");

    var form = document.createElement("form");
    form.className = "yt-cb-form";

    var inputRow = document.createElement("div");
    inputRow.className = "yt-cb-input-row";

    var input = document.createElement("input");
    input.type = "text";
    input.className = "yt-cb-input";
    input.maxLength = MAX_LEN;
    input.placeholder = "Fee, admission, timing poochein...";
    input.setAttribute("aria-label", "Type your question (maximum 300 characters)");

    var sendBtn = document.createElement("button");
    sendBtn.type = "submit";
    sendBtn.className = "yt-cb-btn";
    sendBtn.textContent = "Send";

    inputRow.appendChild(input);
    inputRow.appendChild(sendBtn);

    var meta = document.createElement("div");
    meta.className = "yt-cb-meta";
    var hintEl = document.createElement("span");
    hintEl.textContent = "Press Enter to send • Esc to close";
    var countEl = document.createElement("span");
    countEl.textContent = "0/" + MAX_LEN;
    meta.appendChild(hintEl);
    meta.appendChild(countEl);

    form.appendChild(inputRow);
    form.appendChild(meta);

    panel.appendChild(header);
    panel.appendChild(messagesEl);
    panel.appendChild(quickEl);
    panel.appendChild(form);

    root.appendChild(panel);
    root.appendChild(launcher);
    document.body.appendChild(root);

    var isOpen = false;
    var isBusy = false;
    var typingNode = null;

    function addMessage(sender, text) {
      var msg = document.createElement("div");
      msg.className = "yt-cb-msg " + sender;
      renderSafeText(msg, text);
      messagesEl.appendChild(msg);
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    function showTyping() {
      if (typingNode) return;
      typingNode = document.createElement("div");
      typingNode.className = "yt-cb-typing";
      typingNode.setAttribute("aria-label", "Assistant is typing");
      for (var i = 0; i < 3; i++) {
        var dot = document.createElement("span");
        dot.className = "yt-cb-dot";
        typingNode.appendChild(dot);
      }
      var label = document.createElement("span");
      label.textContent = "Typing...";
      typingNode.appendChild(label);
      messagesEl.appendChild(typingNode);
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    function hideTyping() {
      if (typingNode && typingNode.parentNode) {
        typingNode.parentNode.removeChild(typingNode);
      }
      typingNode = null;
    }

    function setOpen(nextOpen) {
      isOpen = nextOpen;
      panel.classList.toggle("is-open", isOpen);
      panel.setAttribute("aria-hidden", isOpen ? "false" : "true");
      launcher.setAttribute("aria-expanded", isOpen ? "true" : "false");
      if (isOpen) {
        setTimeout(function () {
          input.focus();
        }, 20);
      } else {
        launcher.focus();
      }
    }

    function sendQuery(rawText) {
      var text = String(rawText || "").trim();
      if (!text || isBusy) return;
      if (text.length > MAX_LEN) {
        addMessage("bot", "Kripya apna sawal 300 characters ke andar likhein.");
        return;
      }

      addMessage("user", text);
      input.value = "";
      countEl.textContent = "0/" + MAX_LEN;
      isBusy = true;
      sendBtn.disabled = true;
      showTyping();

      fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text })
      })
        .then(function (res) {
          return res.json().then(function (data) {
            return { ok: res.ok, data: data };
          });
        })
        .then(function (result) {
          hideTyping();
          var reply =
            (result.data && (result.data.reply || result.data.detail)) ||
            "Is baare mein pakki jaankari ke liye 9999999999 par sampark karein.";
          addMessage("bot", reply);
        })
        .catch(function () {
          hideTyping();
          addMessage(
            "bot",
            "Abhi server se connection nahi ho paa raha hai. Pakki jaankari ke liye 9999999999 par call karein."
          );
        })
        .finally(function () {
          isBusy = false;
          sendBtn.disabled = false;
          input.focus();
        });
    }

    QUICK_REPLIES.forEach(function (qr) {
      var chip = document.createElement("button");
      chip.type = "button";
      chip.className = "yt-cb-chip";
      chip.textContent = qr.label;
      chip.addEventListener("click", function () {
        if (!isOpen) setOpen(true);
        sendQuery(qr.query);
      });
      quickEl.appendChild(chip);
    });

    launcher.addEventListener("click", function () {
      setOpen(!isOpen);
    });

    closeBtn.addEventListener("click", function () {
      setOpen(false);
    });

    document.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape" && isOpen) {
        ev.preventDefault();
        setOpen(false);
      }
    });

    input.addEventListener("input", function () {
      countEl.textContent = input.value.length + "/" + MAX_LEN;
    });

    form.addEventListener("submit", function (ev) {
      ev.preventDefault();
      sendQuery(input.value);
    });

    addMessage(
      "bot",
      "Namaste! Main Yuitor Smart AI hoon. Aap Classes 5–12, JEE/NEET/CUET/Coding courses, A-to-Z fees, scholarship discounts (up to 50% off), admission, ERP login ya contact ke baare me pooch sakte hain."
    );

    window.YuitorChatWidget = {
      open: function () { setOpen(true); },
      close: function () { setOpen(false); },
      ask: function (q) {
        if (!isOpen) setOpen(true);
        sendQuery(q);
      }
    };
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initWidget);
  } else {
    initWidget();
  }
})();
