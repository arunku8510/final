(function () {
  "use strict";

  const REF_STORAGE_KEY = "yuitor_ref_code";

  function esc(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function inr(val) {
    return "₹" + Math.round(Number(val || 0)).toLocaleString("en-IN");
  }

  async function reqJson(url, opts = {}) {
    const headers = { ...(opts.headers || {}) };
    let body = opts.body;
    if (body && typeof body === "object" && !(body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(body);
    }
    const resp = await fetch(url, {
      method: opts.method || "GET",
      credentials: "same-origin",
      headers,
      body
    });
    const text = await resp.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = { raw: text };
    }
    if (!resp.ok) {
      const err = new Error(data?.error || `Request failed (${resp.status})`);
      err.status = resp.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  function statusTag(status) {
    const s = String(status || "").toLowerCase();
    let cls = "portal-status";
    if (["paid", "rewarded", "qualified", "approved", "verified", "active"].includes(s)) cls += " portal-status--paid";
    else if (["rejected", "reversed", "disqualified", "frozen", "failed", "refunded"].includes(s)) cls += " portal-status--overdue";
    else if (["pending", "under_review", "processing", "registered", "in_progress", "pending_verification"].includes(s)) cls += " portal-status--pending";
    return `<span class="${cls}">${esc(s.replace(/_/g, " "))}</span>`;
  }

  // ==================== REFERRAL URL CAPTURE ====================
  function getStoredReferralCode() {
    try {
      const sp = new URLSearchParams(window.location.search);
      const qCode = (sp.get("ref") || "").trim().toUpperCase();
      if (qCode) {
        localStorage.setItem(REF_STORAGE_KEY, qCode);
        return qCode;
      }
      const m = window.location.pathname.match(/^\/ref\/([A-Za-z0-9_-]+)/);
      if (m && m[1]) {
        const pathCode = m[1].toUpperCase();
        localStorage.setItem(REF_STORAGE_KEY, pathCode);
        return pathCode;
      }
      return (localStorage.getItem(REF_STORAGE_KEY) || "").toUpperCase();
    } catch {
      return "";
    }
  }

  function initReferralCapture() {
    getStoredReferralCode();
  }

  // ==================== SHOPPING CART & DRAWER ====================
  let cartCache = { items: [], count: 0, subtotal: 0, discountAmount: 0, totalAmount: 0 };
  let activeCouponCode = "";
  let drawerEl = null;

  async function refreshCart(coupon = activeCouponCode) {
    try {
      const qs = coupon ? `?coupon=${encodeURIComponent(coupon)}` : "";
      cartCache = await reqJson(`/api/cart${qs}`);
      updateCartFab();
      return cartCache;
    } catch {
      return cartCache;
    }
  }

  function updateCartFab() {
    const isAdminGate = Boolean(window.__YU_ADMIN_GATE__);
    const path = window.location.pathname || "/";
    const onPublicOrStudent =
      !isAdminGate &&
      !path.startsWith("/teacher") &&
      !path.startsWith("/parent") &&
      !path.startsWith("/staff");

    let fab = document.querySelector("[data-yu-cart-fab]");
    if (!onPublicOrStudent) {
      if (fab) fab.hidden = true;
      return;
    }
    if (!fab) {
      fab = document.createElement("button");
      fab.type = "button";
      fab.className = "yu-cart-fab";
      fab.setAttribute("data-yu-cart-fab", "1");
      fab.addEventListener("click", () => openCartDrawer());
      document.body.appendChild(fab);
    }
    const count = Number(cartCache?.count || 0);
    if (count > 0 || path === "/courses" || path === "/cart") {
      fab.hidden = false;
      fab.innerHTML = `<span>Cart (${count})</span>${count > 0 ? `<span class="yu-addon-num">· ${inr(cartCache.totalAmount)}</span>` : ""}`;
    } else {
      fab.hidden = true;
    }
  }

  async function addToCartAndOpen(courseId, plan = "monthly", batchId = null) {
    const res = await reqJson("/api/cart/items", {
      method: "POST",
      body: { courseId: Number(courseId), plan, batchId: batchId || null }
    });
    if (res.cart) {
      cartCache = res.cart;
      updateCartFab();
    } else {
      await refreshCart();
    }
    await openCartDrawer();
  }

  async function openCartDrawer() {
    if (!drawerEl) {
      drawerEl = document.createElement("div");
      drawerEl.className = "yu-cart-drawer-backdrop";
      drawerEl.hidden = true;
      drawerEl.addEventListener("click", (e) => {
        if (e.target === drawerEl) drawerEl.hidden = true;
      });
      document.body.appendChild(drawerEl);
    }
    await refreshCart(activeCouponCode);
    await drawCartDrawer();
    drawerEl.hidden = false;
  }

  async function drawCartDrawer() {
    if (!drawerEl) return;
    let me = null;
    try {
      me = await reqJson("/api/auth/me");
    } catch {
      me = null;
    }
    const isApprovedStudent = Boolean(me?.authenticated && me?.user?.role === "student" && me?.user?.verification_status === "approved");
    let payCfg = { razorpayEnabled: false, keyId: "" };
    try {
      payCfg = await reqJson("/api/payments/config");
    } catch {
      // ignore
    }

    const itemsHtml =
      cartCache.items.length === 0
        ? `<div style="padding:28px 10px;text-align:center;color:#475569;">
             <p style="margin:0 0 12px;font-weight:600;">Your course cart is empty.</p>
             <a href="/courses" class="portal-button portal-button--small" style="display:inline-flex;text-decoration:none;">Browse Courses</a>
           </div>`
        : cartCache.items
            .map(
              (it) => `
            <div class="yu-cart-item-card">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;">
                <div>
                  <strong style="font-size:15px;">${esc(it.title)}</strong>
                  <div style="font-size:12px;color:#475569;margin-top:2px;">${esc(it.category)} · ${esc(it.board)}${it.batchName ? " · Batch: " + esc(it.batchName) : ""}</div>
                </div>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cart-del="${it.id}" aria-label="Remove course">Remove</button>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
                <select data-cart-plan="${it.id}" style="padding:6px 10px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;">
                  <option value="monthly"${it.plan === "monthly" ? " selected" : ""}>Monthly (${inr(it.monthlyFee)}/mo)</option>
                  <option value="yearly"${it.plan === "yearly" ? " selected" : ""}>Yearly (${inr(it.yearlyFee)}/yr)</option>
                </select>
                <strong class="yu-addon-num" style="font-size:15px;">${inr(it.unitPrice)}</strong>
              </div>
            </div>`
            )
            .join("");

    drawerEl.innerHTML = `
      <div class="yu-cart-drawer" role="dialog" aria-label="Shopping Cart">
        <div class="yu-cart-drawer-head">
          <div>
            <strong style="font-size:16px;">Course Cart (${cartCache.count})</strong>
            <div style="font-size:12px;color:#475569;">Multi-course enrollment &amp; fee checkout</div>
          </div>
          <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cart-close>Close</button>
        </div>
        <div class="yu-cart-drawer-body">
          ${itemsHtml}
          ${
            cartCache.items.length > 0
              ? `
            <form data-cart-coupon-form style="display:flex;gap:8px;margin-top:4px;">
              <input name="coupon" placeholder="Coupon code (optional)" value="${esc(activeCouponCode)}" style="flex:1;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;">
              <button type="submit" class="portal-button portal-button--small portal-button--quiet">Apply</button>
            </form>
            ${cartCache.couponError ? `<div class="portal-message portal-message--error">${esc(cartCache.couponError)}</div>` : ""}
            ${cartCache.couponApplied ? `<div class="portal-message portal-message--success">Coupon ${esc(cartCache.couponApplied.code)} applied: -${inr(cartCache.discountAmount)}</div>` : ""}
          `
              : ""
          }
        </div>
        ${
          cartCache.items.length > 0
            ? `
          <div class="yu-cart-drawer-foot">
            <div style="display:flex;justify-content:space-between;font-size:13px;color:#475569;margin-bottom:4px;">
              <span>Subtotal</span><span class="yu-addon-num">${inr(cartCache.subtotal)}</span>
            </div>
            ${
              cartCache.discountAmount > 0
                ? `<div style="display:flex;justify-content:space-between;font-size:13px;color:#15803d;margin-bottom:4px;"><span>Discount</span><span class="yu-addon-num">-${inr(cartCache.discountAmount)}</span></div>`
                : ""
            }
            <div style="display:flex;justify-content:space-between;font-size:16px;font-weight:750;margin-bottom:12px;">
              <span>Total Payable</span><span class="yu-addon-num">${inr(cartCache.totalAmount)}</span>
            </div>
            <div data-cart-checkout-fb class="portal-message" hidden style="margin-bottom:10px;"></div>
            ${
              isApprovedStudent
                ? `
              <form data-cart-checkout-form style="display:flex;flex-direction:column;gap:8px;">
                <select name="paymentMethod" style="padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;">
                  ${payCfg.razorpayEnabled ? `<option value="gateway">Online Payment Gateway (Razorpay)</option>` : ""}
                  <option value="upi">UPI Transfer (Submit UTR)</option>
                  <option value="cash">Pay Cash at Coaching Desk</option>
                </select>
                <input name="utrReference" placeholder="UPI UTR / Desk Receipt Reference (if UPI/Cash)" style="padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;">
                <div style="display:flex;gap:8px;">
                  <button type="submit" class="portal-button" style="flex:1;">Complete Checkout (${inr(cartCache.totalAmount)})</button>
                  <button type="button" class="portal-button portal-button--quiet" data-cart-clear>Clear</button>
                </div>
              </form>
            `
                : `
              <div style="font-size:13px;color:#475569;margin-bottom:10px;">Sign in or register as a Student to complete enrollment &amp; payment. Your cart items are saved.</div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <a href="/login" class="portal-button" style="flex:1;text-align:center;text-decoration:none;">Sign In to Checkout</a>
                <a href="/register/student" class="portal-button portal-button--quiet" style="flex:1;text-align:center;text-decoration:none;">Register Student</a>
              </div>
            `
            }
          </div>
        `
            : ""
        }
      </div>`;

    drawerEl.querySelector("[data-cart-close]")?.addEventListener("click", () => {
      drawerEl.hidden = true;
    });
    drawerEl.querySelector("[data-cart-clear]")?.addEventListener("click", async () => {
      await reqJson("/api/cart/clear", { method: "POST" });
      await refreshCart();
      await drawCartDrawer();
    });
    drawerEl.querySelectorAll("[data-cart-del]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        await reqJson(`/api/cart/items/${btn.getAttribute("data-cart-del")}`, { method: "DELETE" });
        await refreshCart();
        await drawCartDrawer();
      });
    });
    drawerEl.querySelectorAll("[data-cart-plan]").forEach((sel) => {
      sel.addEventListener("change", async () => {
        await reqJson(`/api/cart/items/${sel.getAttribute("data-cart-plan")}`, {
          method: "PATCH",
          body: { plan: sel.value, couponCode: activeCouponCode }
        });
        await refreshCart();
        await drawCartDrawer();
      });
    });
    drawerEl.querySelector("[data-cart-coupon-form]")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      activeCouponCode = String(new FormData(e.target).get("coupon") || "").trim().toUpperCase();
      await refreshCart(activeCouponCode);
      await drawCartDrawer();
    });
    drawerEl.querySelector("[data-cart-checkout-form]")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const method = String(fd.get("paymentMethod") || "upi");
      const utr = String(fd.get("utrReference") || "").trim();
      const fb = drawerEl.querySelector("[data-cart-checkout-fb]");
      const btn = e.target.querySelector('button[type="submit"]');
      if (btn) btn.disabled = true;
      try {
        let gwPayload = {};
        if (method === "gateway" && payCfg.razorpayEnabled) {
          if (typeof window.Razorpay !== "function") {
            await new Promise((resLoad, rejLoad) => {
              const s = document.createElement("script");
              s.src = "https://checkout.razorpay.com/v1/checkout.js";
              s.onload = () => resLoad();
              s.onerror = () => rejLoad(new Error("Unable to load Razorpay Checkout SDK."));
              document.head.appendChild(s);
            });
          }
          const ord = await reqJson("/api/cart/checkout/create-order", {
            method: "POST",
            body: { couponCode: activeCouponCode }
          });
          const gwRes = await new Promise((resolve, reject) => {
            const rzp = new window.Razorpay({
              key: ord.keyId || payCfg.keyId,
              amount: ord.amount,
              currency: ord.currency || "INR",
              name: "Yuitor Smart Classes",
              description: `Multi-Course Enrollment (${cartCache.count} courses)`,
              order_id: ord.orderId,
              handler: (resp) => resolve(resp),
              modal: { ondismiss: () => reject(new Error("Payment window closed before completion.")) }
            });
            rzp.open();
          });
          gwPayload = {
            gatewayOrderId: gwRes.razorpay_order_id,
            gatewayPaymentId: gwRes.razorpay_payment_id,
            gatewaySignature: gwRes.razorpay_signature
          };
        }
        const done = await reqJson("/api/cart/checkout/complete", {
          method: "POST",
          body: {
            paymentMethod: method,
            utrReference: utr,
            couponCode: activeCouponCode,
            ...gwPayload
          }
        });
        await refreshCart("");
        activeCouponCode = "";
        fb.className = "portal-message portal-message--success";
        fb.textContent = done.message || `Order ${done.orderCode} completed!`;
        fb.hidden = false;
        setTimeout(() => drawCartDrawer(), 1200);
      } catch (err) {
        fb.className = "portal-message portal-message--error";
        fb.textContent = err.message || "Checkout failed.";
        fb.hidden = false;
        if (btn) btn.disabled = false;
      }
    });
  }

  // ==================== STUDENT & TEACHER REFERRALS + WALLET TABS ====================
  async function renderUserReferralsTab(container, role) {
    container.innerHTML = `<div class="portal-card portal-profile"><p class="portal-hint">Loading referral rewards &amp; offers...</p></div>`;
    let notice = "";
    let noticeErr = "";
    const load = async () => {
      try {
        const data = await reqJson("/api/referrals/me");
        const { profile, offer, milestones, campaigns, referrals, share, settings } = data;
        const termsLines = String(settings.termsAndConditions || "")
          .split(/\\n|\r?\n+/)
          .map((l) => l.trim())
          .filter(Boolean);

        container.innerHTML = `
          ${noticeErr ? `<div class="portal-message portal-message--error" style="margin-bottom:12px;">${esc(noticeErr)}</div>` : ""}
          ${notice ? `<div class="portal-message portal-message--success" style="margin-bottom:12px;">${esc(notice)}</div>` : ""}

          <div class="yu-ref-hero">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-start;gap:12px;">
              <div>
                <p class="portal-kicker" style="margin:0 0 4px;">${role === "teacher" ? "Faculty" : "Student"} Referral Program</p>
                <h2 style="margin:0;font-size:20px;">${esc(offer.headline)}</h2>
              </div>
              <div style="text-align:right;">
                <span class="portal-hint" style="display:block;">Qualified Referrals</span>
                <strong class="yu-addon-num" style="font-size:22px;">${Number(profile.qualified_referrals || 0)}</strong>
              </div>
            </div>
            <div class="yu-progress-track"><div class="yu-progress-fill" style="width:${Number(offer.progressPercent || 0)}%;"></div></div>
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:10px;font-size:13px;color:var(--pt-muted);">
              <span>Unlocked so far: <strong class="yu-addon-num">${inr(offer.unlockedAmount)}</strong></span>
              <span>${offer.nextMilestone ? `Next target: <strong class="yu-addon-num">${inr(offer.nextTargetAmount)}</strong> (+${inr(offer.nextAdditionalGain)} more when ${offer.remainingReferrals} more qualify)` : "Maximum tier unlocked!"}</span>
            </div>

            <div class="yu-ref-code-row">
              <div class="yu-ref-code-box" data-ref-code-display>${esc(share.referralCode)}</div>
              <button type="button" class="portal-button portal-button--small" data-copy-ref-code="${esc(share.referralCode)}">Copy Code</button>
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-copy-ref-link="${esc(share.shareUrl)}">Copy Referral Link</button>
              <a href="${esc(share.whatsappShareUrl)}" target="_blank" rel="noopener noreferrer" class="portal-button portal-button--small" style="background:#16a34a;border-color:#16a34a;text-decoration:none;">Share on WhatsApp</a>
            </div>
          </div>

          <div class="yu-addon-grid-4" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong class="yu-addon-num">${Number(profile.total_referrals || 0)}</strong><span>Total Invites</span></div></div>
            <div class="portal-stat"><div><strong class="yu-addon-num">${Number(profile.qualified_referrals || 0)}</strong><span>Qualified (${settings.requiredFeeMonths} Mo Paid)</span></div></div>
            <div class="portal-stat"><div><strong class="yu-addon-num">${Number(profile.pending_referrals || 0)}</strong><span>In Progress</span></div></div>
            <div class="portal-stat"><div><strong class="yu-addon-num">${inr(profile.total_rewards_credited)}</strong><span>Rewards Credited</span></div></div>
          </div>

          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Cumulative Milestone Rewards</h3>
            <p class="portal-hint" style="margin-top:0;">When you unlock a new milestone, only the additional difference is credited to your wallet.</p>
            <div class="yu-milestone-strip">
              ${milestones
                .map((m, idx) => {
                  const unlocked = Number(profile.qualified_referrals || 0) >= Number(m.qualified_count);
                  const isNext = offer.nextMilestone && Number(offer.nextMilestone.qualified_count) === Number(m.qualified_count);
                  const prevAmt = idx > 0 ? Number(milestones[idx - 1].cumulative_reward || 0) : 0;
                  const diffAmt = Math.max(0, Number(m.cumulative_reward) - prevAmt);
                  return `
                    <div class="yu-milestone-step ${unlocked ? "is-unlocked" : ""} ${isNext ? "is-next" : ""}">
                      <div style="font-size:12px;color:var(--pt-muted);">${esc(m.qualified_count)} Qualified</div>
                      <strong class="yu-addon-num" style="font-size:18px;display:block;margin:2px 0;">${inr(m.cumulative_reward)}</strong>
                      <div style="font-size:12px;color:var(--pt-muted);">+${inr(diffAmt)} gain · ${unlocked ? "Unlocked" : isNext ? "Next Goal" : "Locked"}</div>
                    </div>`;
                })
                .join("")}
            </div>
          </div>

          ${
            campaigns.length > 0
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                  <h3 class="portal-section-title">Active Special Offers &amp; Campaigns</h3>
                  <div class="yu-addon-grid-2">
                    ${campaigns
                      .map(
                        (c) => `
                      <div class="portal-detail">
                        <strong>${esc(c.title)} · +${inr(c.bonus_amount)} Bonus</strong>
                        <div style="font-size:13px;color:var(--pt-muted);margin-top:4px;">${esc(c.description)}</div>
                        <span style="margin-top:4px;display:block;">Target: ${Number(c.min_qualified_referrals)} qualified referral(s)${c.ends_at ? " · Ends " + esc(c.ends_at.slice(0, 10)) : ""}</span>
                      </div>`
                      )
                      .join("")}
                  </div>
                </div>`
              : ""
          }

          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">
              Referral History &amp; ${settings.requiredFeeMonths}-Month Fee Eligibility Tracker (${referrals.length})
            </div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Referred Student</th><th>1-Mo / 2-Mo / 3-Mo Fee Progress</th><th>Verified Fees</th><th>Reward Status</th><th>Credited</th></tr></thead>
              <tbody>
                ${
                  referrals
                    .map(
                      (r) => `
                  <tr>
                    <td>
                      <strong>${esc(r.referred_name)}</strong>
                      <span class="portal-cell-sub">${esc(r.referred_phone || "")} · Joined ${esc(String(r.created_at || "").slice(0, 10))}</span>
                    </td>
                    <td>
                      <div class="yu-months-bar">
                        <span class="yu-month-seg ${r.month1_paid ? "is-paid" : ""}">M1</span>
                        <span class="yu-month-seg ${r.month2_paid ? "is-paid" : ""}">M2</span>
                        <span class="yu-month-seg ${r.month3_paid ? "is-paid" : ""}">M3</span>
                      </div>
                      <span class="portal-cell-sub">${r.paid_months_count}/${r.required_months} verified month(s)</span>
                    </td>
                    <td class="yu-addon-num">${inr(r.verified_fees_total)}</td>
                    <td>${statusTag(r.status)}</td>
                    <td class="yu-addon-num">${r.reward_amount_credited > 0 ? inr(r.reward_amount_credited) : r.status === "qualified" || r.status === "rewarded" ? "Milestone Tier" : `Est. ${inr(r.pending_estimated_reward)} pending`}</td>
                  </tr>`
                    )
                    .join("") || `<tr><td colspan="5" class="portal-empty">No referrals registered yet. Share your link to begin earning rewards.</td></tr>`
                }
              </tbody>
            </table></div>
          </div>

          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Referral Terms &amp; 3-Month Fee Eligibility Rules</h3>
            <ol class="yu-terms-list">
              ${termsLines.map((line) => `<li>${esc(line.replace(/^\d+\.\s*/, ""))}</li>`).join("")}
            </ol>
          </div>`;

        container.querySelector("[data-copy-ref-code]")?.addEventListener("click", async (e) => {
          const text = e.currentTarget.getAttribute("data-copy-ref-code");
          await navigator.clipboard?.writeText(text).catch(() => {});
          notice = `Referral code ${text} copied!`;
          noticeErr = "";
          load();
        });
        container.querySelector("[data-copy-ref-link]")?.addEventListener("click", async (e) => {
          const text = e.currentTarget.getAttribute("data-copy-ref-link");
          await navigator.clipboard?.writeText(text).catch(() => {});
          notice = "Referral invite link copied to clipboard!";
          noticeErr = "";
          load();
        });
      } catch (err) {
        container.innerHTML = `<div class="portal-message portal-message--error">${esc(err.message)}</div>`;
      }
    };
    await load();
  }

  async function renderUserWalletTab(container, role) {
    container.innerHTML = `<div class="portal-card portal-profile"><p class="portal-hint">Loading wallet balance &amp; transactions...</p></div>`;
    let notice = "";
    let noticeErr = "";
    let filterType = "";
    let filterSearch = "";
    let wMethod = "upi";

    const load = async () => {
      try {
        const qs = new URLSearchParams();
        if (filterType) qs.set("txType", filterType);
        if (filterSearch) qs.set("search", filterSearch);
        const data = await reqJson(`/api/wallet/me?${qs.toString()}`);
        const { wallet, transactions, withdrawals, rules } = data;
        const isFrozen = Number(wallet.is_frozen) === 1;

        container.innerHTML = `
          ${noticeErr ? `<div class="portal-message portal-message--error" style="margin-bottom:12px;">${esc(noticeErr)}</div>` : ""}
          ${notice ? `<div class="portal-message portal-message--success" style="margin-bottom:12px;">${esc(notice)}</div>` : ""}
          ${isFrozen ? `<div class="portal-message portal-message--error" style="margin-bottom:12px;">Wallet Frozen: ${esc(wallet.freeze_reason || "Contact Yuitor Admin Desk.")}</div>` : ""}

          <div class="yu-addon-grid-4" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong class="yu-addon-num">${inr(wallet.available_balance)}</strong><span>Available Balance</span></div></div>
            <div class="portal-stat"><div><strong class="yu-addon-num">${inr(wallet.pending_rewards)}</strong><span>Pending Rewards</span></div></div>
            <div class="portal-stat"><div><strong class="yu-addon-num">${inr(wallet.total_earnings)}</strong><span>Total Earnings</span></div></div>
            <div class="portal-stat"><div><strong class="yu-addon-num">${inr(wallet.withdrawn_amount)}</strong><span>Withdrawn Amount</span></div></div>
          </div>

          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;">
              <div>
                <h3 class="portal-section-title" style="margin-bottom:2px;">Request Wallet Withdrawal (${role === "teacher" ? "Teacher" : "Student"} Wallet)</h3>
                <span class="portal-hint">Referral Rewards Credited: <strong class="yu-addon-num">${inr(wallet.referral_rewards_total)}</strong> · Hold in Processing: <strong class="yu-addon-num">${inr(wallet.pending_withdrawal_hold)}</strong> · Min Limit: <strong class="yu-addon-num">${inr(rules.minWithdrawalAmount)}</strong></span>
              </div>
            </div>
            <form class="portal-form" data-wallet-withdraw-form>
              <div class="portal-form-grid">
                <div class="portal-field">
                  <label>Payout Method *</label>
                  <select name="payoutMethod" data-wdr-method>
                    <option value="upi"${wMethod === "upi" ? " selected" : ""}>UPI Transfer</option>
                    <option value="bank"${wMethod === "bank" ? " selected" : ""}>Bank Transfer (IMPS/NEFT)</option>
                  </select>
                </div>
                <div class="portal-field">
                  <label>Withdrawal Amount (INR) *</label>
                  <input name="amount" type="number" min="${rules.minWithdrawalAmount}" max="${Math.max(rules.minWithdrawalAmount, Number(wallet.available_balance || 0))}" required placeholder="Min ₹${rules.minWithdrawalAmount}">
                </div>
                ${
                  wMethod === "upi"
                    ? `<div class="portal-field"><label>UPI ID *</label><input name="upiId" required placeholder="yourname@okaxis"></div>`
                    : `
                  <div class="portal-field"><label>Account Holder Name *</label><input name="accountHolderName" required placeholder="Full Name"></div>
                  <div class="portal-field"><label>Bank Name *</label><input name="bankName" required placeholder="State Bank of India"></div>
                  <div class="portal-field"><label>Account Number *</label><input name="accountNumber" required placeholder="9-18 digit account number"></div>
                  <div class="portal-field"><label>IFSC Code *</label><input name="ifscCode" required placeholder="SBIN0001234" style="text-transform:uppercase;"></div>
                `
                }
              </div>
              <button type="submit" class="portal-button portal-button--small" ${isFrozen || Number(wallet.available_balance) < Number(rules.minWithdrawalAmount) ? "disabled" : ""}>
                ${rules.requireAdminApproval ? "Submit Withdrawal Request (Admin Approval)" : "Withdraw Now"}
              </button>
            </form>
          </div>

          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;border-bottom:1px solid var(--pt-border);display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;">
              <strong>Transaction History (${transactions.length})</strong>
              <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <select data-wtx-filter-type style="min-height:36px;">
                  <option value="">All Types</option>
                  <option value="credit"${filterType === "credit" ? " selected" : ""}>Credits Only</option>
                  <option value="debit"${filterType === "debit" ? " selected" : ""}>Debits Only</option>
                </select>
                <input data-wtx-search placeholder="Search Tx ID or description..." value="${esc(filterSearch)}" style="min-height:36px;">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-wtx-apply>Filter</button>
              </div>
            </div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Transaction ID</th><th>Date</th><th>Description</th><th>Credit</th><th>Debit</th><th>Status</th><th>Balance</th></tr></thead>
              <tbody>
                ${
                  transactions
                    .map(
                      (tx) => `
                  <tr>
                    <td><strong>${esc(tx.tx_code)}</strong><span class="portal-cell-sub">${esc(tx.category.replace(/_/g, " "))}</span></td>
                    <td>${esc(String(tx.created_at || "").slice(0, 10))}</td>
                    <td>${esc(tx.description)}</td>
                    <td class="yu-addon-num" style="color:#15803d;font-weight:700;">${tx.credit_amount > 0 ? `+${inr(tx.credit_amount)}` : "-"}</td>
                    <td class="yu-addon-num" style="color:#b91c1c;font-weight:700;">${tx.debit_amount > 0 ? `-${inr(tx.debit_amount)}` : "-"}</td>
                    <td>${statusTag(tx.status)}</td>
                    <td class="yu-addon-num"><strong>${inr(tx.remaining_balance)}</strong></td>
                  </tr>`
                    )
                    .join("") || `<tr><td colspan="7" class="portal-empty">No wallet transactions yet.</td></tr>`
                }
              </tbody>
            </table></div>
          </div>

          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Withdrawal History (${withdrawals.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Request Code</th><th>Date</th><th>Method &amp; Details</th><th>Amount</th><th>Status</th><th>Payout Ref / Note</th></tr></thead>
              <tbody>
                ${
                  withdrawals
                    .map(
                      (w) => `
                  <tr>
                    <td><strong>${esc(w.request_code)}</strong></td>
                    <td>${esc(String(w.created_at || "").slice(0, 10))}</td>
                    <td>${esc(w.payout_method.toUpperCase())} · ${esc(w.upi_id || `${w.bank_name} (••••${String(w.account_number || "").slice(-4)})`)}</td>
                    <td class="yu-addon-num"><strong>${inr(w.amount)}</strong></td>
                    <td>${statusTag(w.status)}</td>
                    <td>${esc(w.payout_reference || w.admin_note || "-")}</td>
                  </tr>`
                    )
                    .join("") || `<tr><td colspan="6" class="portal-empty">No withdrawal requests submitted yet.</td></tr>`
                }
              </tbody>
            </table></div>
          </div>`;

        container.querySelector("[data-wdr-method]")?.addEventListener("change", (e) => {
          wMethod = e.target.value;
          load();
        });
        container.querySelector("[data-wtx-apply]")?.addEventListener("click", () => {
          filterType = container.querySelector("[data-wtx-filter-type]")?.value || "";
          filterSearch = container.querySelector("[data-wtx-search]")?.value || "";
          load();
        });
        container.querySelector("[data-wallet-withdraw-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const body = Object.fromEntries(new FormData(e.target).entries());
          body.amount = Number(body.amount);
          try {
            const res = await reqJson("/api/wallet/withdraw", { method: "POST", body });
            notice = `Withdrawal request ${res.request?.request_code || ""} submitted (${res.request?.status})!`;
            noticeErr = "";
          } catch (err) {
            noticeErr = err.message;
            notice = "";
          }
          load();
        });
      } catch (err) {
        container.innerHTML = `<div class="portal-message portal-message--error">${esc(err.message)}</div>`;
      }
    };
    await load();
  }

  // ==================== ADMIN GLOBAL SEARCH (CTRL+K) ====================
  let gSearchModal = null;
  let gSearchKeyBound = false;

  function mountAdminGlobalSearch(topbarRightEl, { adminApiUrl, onNavigate }) {
    if (!topbarRightEl) return;
    if (!topbarRightEl.querySelector("[data-yu-gsearch-btn]")) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "yu-gsearch-trigger";
      btn.setAttribute("data-yu-gsearch-btn", "1");
      btn.setAttribute("title", "Global Search (Ctrl+K / Cmd+K)");
      btn.innerHTML = `<span>Search</span><span class="yu-gsearch-label-long">Pages, Users, Codes...</span><span class="yu-gsearch-kbd">Ctrl+K</span>`;
      btn.addEventListener("click", () => openGlobalSearch({ adminApiUrl, onNavigate }));
      topbarRightEl.prepend(btn);
    }
    if (!gSearchKeyBound) {
      gSearchKeyBound = true;
      window.addEventListener("keydown", (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
          if (window.__YU_ADMIN_GATE__) {
            e.preventDefault();
            openGlobalSearch({ adminApiUrl, onNavigate });
          }
        }
      });
    }
  }

  async function openGlobalSearch({ adminApiUrl, onNavigate }) {
    if (!gSearchModal) {
      gSearchModal = document.createElement("div");
      gSearchModal.className = "yu-gsearch-backdrop";
      gSearchModal.hidden = true;
      gSearchModal.addEventListener("click", (e) => {
        if (e.target === gSearchModal) gSearchModal.hidden = true;
      });
      document.body.appendChild(gSearchModal);
    }
    const isDark = document.querySelector("#root main.portal-main")?.classList.contains("portal-dark");
    let query = "";
    let category = "all";
    let limit = 8;
    let prefs = { recentSearches: [], recentPages: [], pinnedPages: [], frequentSettings: [] };
    try {
      prefs = await reqJson(adminApiUrl("/search-preferences"));
    } catch {
      // non-fatal
    }

    const categories = ["all", "Pages", "Settings", "Students", "Teachers", "Referrals", "Wallets", "Withdrawals", "Payments", "Courses", "Inquiries"];
    let searchTimer = 0;
    let currentData = { totalHits: 0, groups: {}, suggestions: [], noResultHint: "" };

    const renderModal = () => {
      const hasQuery = query.trim().length > 0;
      let resultsHtml = "";

      if (!hasQuery) {
        resultsHtml = `
          ${
            prefs.pinnedPages?.length
              ? `<div><div class="yu-gsearch-group-title">Pinned Pages</div>${prefs.pinnedPages
                  .map(
                    (p) =>
                      `<button type="button" class="yu-gsearch-item" data-gs-nav='${esc(JSON.stringify({ tab: p.tab, navKey: p.navKey, title: p.title, id: p.id }))}'><div><strong>${esc(p.title)}</strong></div><span class="yu-gsearch-item-meta">Pinned</span></button>`
                  )
                  .join("")}</div>`
              : ""
          }
          ${
            prefs.recentSearches?.length
              ? `<div><div class="yu-gsearch-group-title">Recent Searches</div><div style="display:flex;flex-wrap:wrap;gap:6px;">${prefs.recentSearches
                  .map(
                    (s) =>
                      `<button type="button" class="yu-gsearch-cat-btn" data-gs-q="${esc(s)}">${esc(s)}</button>`
                  )
                  .join("")}</div></div>`
              : ""
          }
          ${
            prefs.recentPages?.length
              ? `<div><div class="yu-gsearch-group-title">Recently Visited</div>${prefs.recentPages
                  .map(
                    (p) =>
                      `<button type="button" class="yu-gsearch-item" data-gs-nav='${esc(JSON.stringify({ tab: p.tab, navKey: p.navKey, role: p.role, title: p.title, id: p.id }))}'><div><strong>${esc(p.title)}</strong></div><span class="yu-gsearch-item-meta">Recent</span></button>`
                  )
                  .join("")}</div>`
              : ""
          }
          <div>
            <div class="yu-gsearch-group-title">Quick Admin Features</div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:6px;">
              ${(currentData.suggestions || [
                { id: "marketing-referrals", title: "Referrals, Milestones & Offers", nav: { tab: "referrals", navKey: "marketing-referrals" } },
                { id: "finance-wallets", title: "Student & Teacher Wallets", nav: { tab: "wallets", navKey: "finance-wallets" } },
                { id: "finance-withdrawals", title: "Withdrawal Requests Queue", nav: { tab: "withdrawals", navKey: "finance-withdrawals" } },
                { id: "reports-referrals", title: "Referral & Wallet Analytics", nav: { tab: "referral_reports", navKey: "reports-referrals" } }
              ])
                .map(
                  (s) =>
                    `<button type="button" class="yu-gsearch-item" data-gs-nav='${esc(JSON.stringify({ ...(s.nav || {}), title: s.title, id: s.id }))}'><div><strong>${esc(s.title)}</strong></div><span class="yu-gsearch-item-meta">Open</span></button>`
                )
                .join("")}
            </div>
          </div>`;
      } else if (currentData.totalHits === 0) {
        resultsHtml = `
          <div style="padding:18px 8px;text-align:center;">
            <p style="margin:0 0 12px;color:var(--pt-muted);">${esc(currentData.noResultHint || `No matches found for "${query}".`)}</p>
            <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:6px;">
              ${(currentData.suggestions || [])
                .map(
                  (s) =>
                    `<button type="button" class="yu-gsearch-cat-btn" data-gs-nav='${esc(JSON.stringify({ tab: s.tab, navKey: s.navKey, role: s.role, title: s.title, id: s.id }))}'>${esc(s.title)}</button>`
                )
                .join("")}
            </div>
          </div>`;
      } else {
        resultsHtml = Object.entries(currentData.groups || {})
          .map(
            ([groupName, grp]) => `
            <div>
              <div class="yu-gsearch-group-title">${esc(groupName)} (${grp.total})</div>
              ${(grp.items || [])
                .map(
                  (it) => `
                <button type="button" class="yu-gsearch-item" data-gs-nav='${esc(JSON.stringify({ ...(it.nav || {}), title: it.title, id: it.id }))}'>
                  <div>
                    <strong style="display:block;font-size:14px;">${esc(it.title)}</strong>
                    <span style="font-size:12px;color:var(--pt-muted);">${esc(it.subtitle || "")}</span>
                  </div>
                  <span class="yu-gsearch-item-meta">${esc(it.meta || "")}</span>
                </button>`
                )
                .join("")}
            </div>`
          )
          .join("");
        resultsHtml += `<div style="display:flex;justify-content:flex-end;"><button type="button" class="yu-gsearch-cat-btn" data-gs-more>Load more per category</button></div>`;
      }

      const bodyEl = gSearchModal.querySelector("[data-gs-results]");
      if (bodyEl) {
        bodyEl.innerHTML = resultsHtml;
        bindModalActions();
      }
    };

    const runSearch = async () => {
      if (!query.trim()) {
        currentData = { totalHits: 0, groups: {}, suggestions: [] };
        renderModal();
        return;
      }
      try {
        currentData = await reqJson(
          adminApiUrl(`/global-search?q=${encodeURIComponent(query)}&category=${encodeURIComponent(category)}&limit=${limit}`)
        );
      } catch {
        currentData = { totalHits: 0, groups: {}, noResultHint: "Search unavailable right now." };
      }
      renderModal();
    };

    gSearchModal.innerHTML = `
      <div class="yu-gsearch-modal ${isDark ? "is-dark" : ""}" role="dialog" aria-label="Admin Global Search">
        <div class="yu-gsearch-input-wrap">
          <input class="yu-gsearch-input" data-gs-input placeholder="Search features, students, teachers, referral codes, wallets, invoices, settings..." autofocus>
          <button type="button" class="yu-gsearch-cat-btn" data-gs-close>Esc</button>
        </div>
        <div class="yu-gsearch-cats">
          ${categories
            .map(
              (c) => `<button type="button" class="yu-gsearch-cat-btn ${category === c ? "is-active" : ""}" data-gs-cat="${esc(c)}">${esc(c === "all" ? "All Categories" : c)}</button>`
            )
            .join("")}
        </div>
        <div class="yu-gsearch-results" data-gs-results></div>
      </div>`;

    const bindModalActions = () => {
      gSearchModal.querySelectorAll("[data-gs-q]").forEach((b) => {
        b.addEventListener("click", () => {
          query = b.getAttribute("data-gs-q") || "";
          const inp = gSearchModal.querySelector("[data-gs-input]");
          if (inp) inp.value = query;
          runSearch();
        });
      });
      gSearchModal.querySelectorAll("[data-gs-nav]").forEach((b) => {
        b.addEventListener("click", async () => {
          const target = JSON.parse(b.getAttribute("data-gs-nav") || "{}");
          if (query.trim()) {
            reqJson(adminApiUrl("/search-preferences"), { method: "POST", body: { addSearch: query.trim() } }).catch(() => {});
          }
          if (target.title) {
            reqJson(adminApiUrl("/search-preferences"), {
              method: "POST",
              body: { recordPage: { id: target.id || target.tab, title: target.title, tab: target.tab, navKey: target.navKey, role: target.role } }
            }).catch(() => {});
          }
          gSearchModal.hidden = true;
          onNavigate?.(target);
        });
      });
      gSearchModal.querySelector("[data-gs-more]")?.addEventListener("click", () => {
        limit = Math.min(25, limit + 8);
        runSearch();
      });
    };

    gSearchModal.querySelector("[data-gs-close]")?.addEventListener("click", () => {
      gSearchModal.hidden = true;
    });
    gSearchModal.querySelectorAll("[data-gs-cat]").forEach((b) => {
      b.addEventListener("click", () => {
        category = b.getAttribute("data-gs-cat") || "all";
        gSearchModal.querySelectorAll("[data-gs-cat]").forEach((x) => x.classList.toggle("is-active", x === b));
        runSearch();
      });
    });

    const inputEl = gSearchModal.querySelector("[data-gs-input]");
    inputEl?.addEventListener("input", () => {
      query = inputEl.value;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(runSearch, 180);
    });
    inputEl?.addEventListener("keydown", (e) => {
      if (e.key === "Escape") gSearchModal.hidden = true;
      if (e.key === "Enter") {
        const firstBtn = gSearchModal.querySelector("[data-gs-nav]");
        if (firstBtn) firstBtn.click();
      }
    });

    gSearchModal.hidden = false;
    renderModal();
    setTimeout(() => inputEl?.focus(), 20);
  }

  // ==================== ADMIN MANAGEMENT PAGES ====================
  async function renderAdminReferralsPage(container, { adminApiUrl, initialSearch = "" }) {
    let notice = "";
    let errMsg = "";
    let statusFilter = "all";
    let roleFilter = "all";
    let searchFilter = initialSearch;

    const draw = async () => {
      const qs = new URLSearchParams({ status: statusFilter, role: roleFilter });
      if (searchFilter) qs.set("search", searchFilter);
      const data = await reqJson(adminApiUrl(`/referrals?${qs.toString()}`));
      const { settings, milestones, campaigns, referrals } = data;

      container.innerHTML = `
        ${errMsg ? `<div class="portal-message portal-message--error" style="margin-bottom:12px;">${esc(errMsg)}</div>` : ""}
        ${notice ? `<div class="portal-message portal-message--success" style="margin-bottom:12px;">${esc(notice)}</div>` : ""}

        <div class="portal-card portal-profile" style="margin-bottom:16px;">
          <h3 class="portal-section-title">Referral &amp; Wallet Global Rules</h3>
          <form class="portal-form" data-adm-ref-settings>
            <div class="portal-form-grid">
              <div class="portal-field"><label>Required Verified Fee Months *</label><input name="required_fee_months" type="number" min="1" max="24" value="${Number(settings.required_fee_months || 3)}"></div>
              <div class="portal-field"><label>Yearly Plan Months Credit</label><input name="yearly_plan_months_credit" type="number" min="1" max="12" value="${Number(settings.yearly_plan_months_credit || 12)}"></div>
              <div class="portal-field"><label>Min Withdrawal Limit (INR) *</label><input name="min_withdrawal_amount" type="number" min="1" value="${Number(settings.min_withdrawal_amount || 200)}"></div>
              <div class="portal-field"><label>Max Withdrawal Per Request</label><input name="max_withdrawal_amount" type="number" min="1" value="${Number(settings.max_withdrawal_amount || 50000)}"></div>
            </div>
            <div style="display:flex;flex-wrap:wrap;gap:14px;margin:10px 0;">
              <label><input type="checkbox" name="referrals_enabled" ${settings.referrals_enabled ? "checked" : ""}> Referrals Active</label>
              <label><input type="checkbox" name="allow_student_referrals" ${settings.allow_student_referrals ? "checked" : ""}> Student Referrals</label>
              <label><input type="checkbox" name="allow_teacher_referrals" ${settings.allow_teacher_referrals ? "checked" : ""}> Teacher Referrals</label>
              <label><input type="checkbox" name="require_admin_approval" ${settings.require_admin_approval ? "checked" : ""}> Admin Approval for Withdrawals</label>
              <label><input type="checkbox" name="prevent_duplicate_withdrawals" ${settings.prevent_duplicate_withdrawals ? "checked" : ""}> Block Duplicate Pending Withdrawals</label>
              <label><input type="checkbox" name="notify_email" ${settings.notify_email ? "checked" : ""}> Email Alerts</label>
              <label><input type="checkbox" name="notify_whatsapp" ${settings.notify_whatsapp ? "checked" : ""}> WhatsApp Alerts</label>
            </div>
            <div class="portal-field"><label>Referral Terms &amp; Conditions</label><textarea name="terms_and_conditions" rows="4">${esc(settings.terms_and_conditions || "")}</textarea></div>
            <button type="submit" class="portal-button portal-button--small">Save Referral &amp; Withdrawal Settings</button>
          </form>
        </div>

        <div class="yu-addon-grid-2" style="margin-bottom:16px;">
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Cumulative Milestone Tiers</h3>
            <form class="portal-form" data-adm-milestone-add style="margin-bottom:12px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Qualified Referrals</label><input name="qualifiedCount" type="number" min="1" required placeholder="e.g. 6"></div>
                <div class="portal-field"><label>Cumulative Reward (INR)</label><input name="cumulativeReward" type="number" min="0" required placeholder="e.g. 3500"></div>
                <div class="portal-field"><label>Title</label><input name="title" placeholder="Platinum Ambassador"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Save / Update Tier</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Qualified</th><th>Cumulative ₹</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
                ${milestones
                  .map(
                    (m) => `
                  <tr>
                    <td><strong>${m.qualified_count}</strong></td>
                    <td><input type="number" data-ms-amt="${m.id}" value="${m.cumulative_reward}" style="width:90px;"></td>
                    <td>${statusTag(m.is_active ? "active" : "suspended")}</td>
                    <td>
                      <button type="button" class="portal-button portal-button--small portal-button--quiet" data-ms-save="${m.id}">Save</button>
                      <button type="button" class="portal-button portal-button--small portal-button--quiet" data-ms-del="${m.id}">Delete</button>
                    </td>
                  </tr>`
                  )
                  .join("")}
              </tbody>
            </table></div>
          </div>

          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Referral Offer Campaigns (${campaigns.length})</h3>
            <form class="portal-form" data-adm-camp-add style="margin-bottom:12px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Campaign Title *</label><input name="title" required placeholder="Diwali Bonus Offer"></div>
                <div class="portal-field"><label>Target Role</label><select name="targetRole"><option value="all">Students &amp; Teachers</option><option value="student">Students Only</option><option value="teacher">Teachers Only</option></select></div>
                <div class="portal-field"><label>Extra Bonus (INR)</label><input name="bonusAmount" type="number" min="0" value="250"></div>
                <div class="portal-field"><label>Min Qualified Referrals</label><input name="minQualifiedReferrals" type="number" min="1" value="2"></div>
                <div class="portal-field"><label>Start Date (Optional)</label><input name="startsAt" type="date"></div>
                <div class="portal-field"><label>End Date (Optional)</label><input name="endsAt" type="date"></div>
              </div>
              <div class="portal-field"><label>Description</label><input name="description" placeholder="Extra bonus on qualifying referrals"></div>
              <button type="submit" class="portal-button portal-button--small">Launch Campaign</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Campaign</th><th>Bonus</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
                ${campaigns
                  .map(
                    (c) => `
                  <tr>
                    <td><strong>${esc(c.title)}</strong><span class="portal-cell-sub">${esc(c.target_role)} · Min ${c.min_qualified_referrals}</span></td>
                    <td class="yu-addon-num">${inr(c.bonus_amount)}</td>
                    <td>${statusTag(c.is_active ? "active" : "paused")}</td>
                    <td>
                      <button type="button" class="portal-button portal-button--small portal-button--quiet" data-camp-toggle="${c.id}" data-camp-active="${c.is_active ? 1 : 0}">${c.is_active ? "Pause" : "Activate"}</button>
                      <button type="button" class="portal-button portal-button--small portal-button--quiet" data-camp-del="${c.id}">Delete</button>
                    </td>
                  </tr>`
                  )
                  .join("") || `<tr><td colspan="4" class="portal-empty">No referral campaigns created yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
        </div>

        <div class="portal-card portal-table-card">
          <div style="padding:14px 16px;border-bottom:1px solid var(--pt-border);display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;">
            <strong>Referral &amp; 3-Month Fee Progress Monitor (${referrals.length})</strong>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <select data-ref-f-status>
                <option value="all">All Statuses</option>
                ${["registered", "in_progress", "qualified", "rewarded", "reversed", "disqualified"]
                  .map((s) => `<option value="${s}"${statusFilter === s ? " selected" : ""}>${s}</option>`)
                  .join("")}
              </select>
              <select data-ref-f-role>
                <option value="all">All Roles</option>
                <option value="student"${roleFilter === "student" ? " selected" : ""}>Students</option>
                <option value="teacher"${roleFilter === "teacher" ? " selected" : ""}>Teachers</option>
              </select>
              <input data-ref-f-search placeholder="Code / Name / Phone..." value="${esc(searchFilter)}">
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-ref-f-btn>Filter</button>
            </div>
          </div>
          <div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Referrer</th><th>Referred Student</th><th>3-Month Progress</th><th>Status</th><th>Credited</th><th>Actions</th></tr></thead>
            <tbody>
              ${
                referrals
                  .map(
                    (r) => `
                <tr>
                  <td><strong>${esc(r.referrer_name)}</strong><span class="portal-cell-sub">${esc(r.referrer_role)} · ${esc(r.referral_code_used)}</span></td>
                  <td><strong>${esc(r.referred_name)}</strong><span class="portal-cell-sub">${esc(r.referred_phone)} · ${esc(r.referred_account_status)}</span></td>
                  <td>
                    <div class="yu-months-bar">
                      <span class="yu-month-seg ${r.month1_paid ? "is-paid" : ""}">M1</span>
                      <span class="yu-month-seg ${r.month2_paid ? "is-paid" : ""}">M2</span>
                      <span class="yu-month-seg ${r.month3_paid ? "is-paid" : ""}">M3</span>
                    </div>
                    <span class="portal-cell-sub">${r.paid_months_count}/${r.required_months} mo · Verified ${inr(r.verified_fees_total)}</span>
                  </td>
                  <td>${statusTag(r.status)}</td>
                  <td class="yu-addon-num">${inr(r.reward_amount_credited)}</td>
                  <td>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-ref-recompute="${r.id}">Recalculate</button>
                    ${r.status !== "disqualified" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-ref-disq="${r.id}">Disqualify</button>` : ""}
                  </td>
                </tr>`
                  )
                  .join("") || `<tr><td colspan="6" class="portal-empty">No referral records matching filter.</td></tr>`
              }
            </tbody>
          </table></div>
        </div>`;

      const run = async (fn, okMsg) => {
        try {
          await fn();
          notice = okMsg;
          errMsg = "";
        } catch (err) {
          errMsg = err.message;
          notice = "";
        }
        draw();
      };

      container.querySelector("[data-adm-ref-settings]")?.addEventListener("submit", (e) => {
        e.preventDefault();
        const f = e.target;
        const fd = new FormData(f);
        const body = {
          required_fee_months: Number(fd.get("required_fee_months")),
          yearly_plan_months_credit: Number(fd.get("yearly_plan_months_credit")),
          min_withdrawal_amount: Number(fd.get("min_withdrawal_amount")),
          max_withdrawal_amount: Number(fd.get("max_withdrawal_amount")),
          terms_and_conditions: fd.get("terms_and_conditions"),
          referrals_enabled: f.querySelector('[name="referrals_enabled"]').checked,
          allow_student_referrals: f.querySelector('[name="allow_student_referrals"]').checked,
          allow_teacher_referrals: f.querySelector('[name="allow_teacher_referrals"]').checked,
          require_admin_approval: f.querySelector('[name="require_admin_approval"]').checked,
          prevent_duplicate_withdrawals: f.querySelector('[name="prevent_duplicate_withdrawals"]').checked,
          notify_email: f.querySelector('[name="notify_email"]').checked,
          notify_whatsapp: f.querySelector('[name="notify_whatsapp"]').checked
        };
        run(() => reqJson(adminApiUrl("/referral-settings"), { method: "PUT", body }), "Referral settings updated.");
      });

      container.querySelector("[data-adm-milestone-add]")?.addEventListener("submit", (e) => {
        e.preventDefault();
        run(
          () => reqJson(adminApiUrl("/referral-milestones"), { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) }),
          "Milestone saved."
        );
      });
      container.querySelectorAll("[data-ms-save]").forEach((b) => {
        b.addEventListener("click", () => {
          const id = b.getAttribute("data-ms-save");
          const amt = Number(container.querySelector(`[data-ms-amt="${id}"]`)?.value || 0);
          run(() => reqJson(adminApiUrl(`/referral-milestones/${id}`), { method: "PUT", body: { cumulativeReward: amt } }), "Milestone updated.");
        });
      });
      container.querySelectorAll("[data-ms-del]").forEach((b) => {
        b.addEventListener("click", () => run(() => reqJson(adminApiUrl(`/referral-milestones/${b.getAttribute("data-ms-del")}`), { method: "DELETE" }), "Milestone deleted."));
      });
      container.querySelector("[data-adm-camp-add]")?.addEventListener("submit", (e) => {
        e.preventDefault();
        run(() => reqJson(adminApiUrl("/referral-campaigns"), { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) }), "Referral campaign launched.");
      });
      container.querySelectorAll("[data-camp-toggle]").forEach((b) => {
        b.addEventListener("click", () => {
          const id = b.getAttribute("data-camp-toggle");
          const nextActive = b.getAttribute("data-camp-active") !== "1";
          run(() => reqJson(adminApiUrl(`/referral-campaigns/${id}`), { method: "PATCH", body: { isActive: nextActive } }), "Campaign status updated.");
        });
      });
      container.querySelectorAll("[data-camp-del]").forEach((b) => {
        b.addEventListener("click", () => run(() => reqJson(adminApiUrl(`/referral-campaigns/${b.getAttribute("data-camp-del")}`), { method: "DELETE" }), "Campaign deleted."));
      });
      container.querySelector("[data-ref-f-btn]")?.addEventListener("click", () => {
        statusFilter = container.querySelector("[data-ref-f-status]")?.value || "all";
        roleFilter = container.querySelector("[data-ref-f-role]")?.value || "all";
        searchFilter = container.querySelector("[data-ref-f-search]")?.value || "";
        draw();
      });
      container.querySelectorAll("[data-ref-recompute]").forEach((b) => {
        b.addEventListener("click", () => run(() => reqJson(adminApiUrl(`/referrals/${b.getAttribute("data-ref-recompute")}/recompute`), { method: "POST" }), "3-Month fee progress & milestone recalculated."));
      });
      container.querySelectorAll("[data-ref-disq]").forEach((b) => {
        b.addEventListener("click", () => run(() => reqJson(adminApiUrl(`/referrals/${b.getAttribute("data-ref-disq")}/disqualify`), { method: "POST", body: { reason: "Admin audit disqualification" } }), "Referral marked disqualified."));
      });
    };
    await draw();
  }

  async function renderAdminWalletsPage(container, { adminApiUrl }) {
    let typeFilter = "all";
    let searchFilter = "";
    let selectedLedger = null;
    let notice = "";
    let errMsg = "";

    const draw = async () => {
      const qs = new URLSearchParams({ type: typeFilter });
      if (searchFilter) qs.set("search", searchFilter);
      const data = await reqJson(adminApiUrl(`/wallets?${qs.toString()}`));
      const wallets = data.wallets || [];

      container.innerHTML = `
        ${errMsg ? `<div class="portal-message portal-message--error" style="margin-bottom:12px;">${esc(errMsg)}</div>` : ""}
        ${notice ? `<div class="portal-message portal-message--success" style="margin-bottom:12px;">${esc(notice)}</div>` : ""}

        ${
          selectedLedger
            ? `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;">
              <div>
                <h3 class="portal-section-title" style="margin:0;">Wallet Ledger: ${esc(selectedLedger.user?.full_name)} (${esc(selectedLedger.wallet?.wallet_type)})</h3>
                <span class="portal-hint">Available: <strong class="yu-addon-num">${inr(selectedLedger.wallet?.available_balance)}</strong> · Hold: <strong class="yu-addon-num">${inr(selectedLedger.wallet?.pending_withdrawal_hold)}</strong></span>
              </div>
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-w-close-ledger>Back to All Wallets</button>
            </div>
            <form class="portal-form" data-w-adjust-form="${selectedLedger.user.id}" style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Adjustment Type</label><select name="mode"><option value="credit">Credit (+)</option><option value="debit">Debit (-)</option></select></div>
                <div class="portal-field"><label>Amount (INR) *</label><input name="amount" type="number" min="1" required></div>
                <div class="portal-field"><label>Audit Reason *</label><input name="reason" required minlength="4" placeholder="Bonus / Correction reason"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Apply Manual Adjustment</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Tx Code</th><th>Date</th><th>Description</th><th>Credit</th><th>Debit</th><th>Status</th><th>Balance</th></tr></thead>
              <tbody>
                ${(selectedLedger.transactions || [])
                  .map(
                    (tx) => `
                  <tr>
                    <td><strong>${esc(tx.tx_code)}</strong></td>
                    <td>${esc(String(tx.created_at || "").slice(0, 10))}</td>
                    <td>${esc(tx.description)}</td>
                    <td class="yu-addon-num">${tx.credit_amount > 0 ? `+${inr(tx.credit_amount)}` : "-"}</td>
                    <td class="yu-addon-num">${tx.debit_amount > 0 ? `-${inr(tx.debit_amount)}` : "-"}</td>
                    <td>${statusTag(tx.status)}</td>
                    <td class="yu-addon-num">${inr(tx.remaining_balance)}</td>
                  </tr>`
                  )
                  .join("") || `<tr><td colspan="7" class="portal-empty">No transactions in ledger.</td></tr>`}
              </tbody>
            </table></div>
          </div>`
            : ""
        }

        <div class="portal-card portal-table-card">
          <div style="padding:14px 16px;border-bottom:1px solid var(--pt-border);display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;">
            <strong>Student &amp; Teacher Wallets (${wallets.length})</strong>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <select data-w-f-type>
                <option value="all">All Wallets</option>
                <option value="student"${typeFilter === "student" ? " selected" : ""}>Student Wallets</option>
                <option value="teacher"${typeFilter === "teacher" ? " selected" : ""}>Teacher Wallets</option>
              </select>
              <input data-w-f-search placeholder="Name, Phone, Referral Code..." value="${esc(searchFilter)}">
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-w-f-btn>Filter</button>
            </div>
          </div>
          <div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>User</th><th>Wallet Type</th><th>Available</th><th>Pending Rewards</th><th>Total Earned</th><th>Withdrawn</th><th>State</th><th>Actions</th></tr></thead>
            <tbody>
              ${
                wallets
                  .map(
                    (w) => `
                <tr>
                  <td><strong>${esc(w.full_name)}</strong><span class="portal-cell-sub">${esc(w.phone)} · ${esc(w.referral_code || "-")}</span></td>
                  <td>${esc(w.wallet_type)}</td>
                  <td class="yu-addon-num"><strong>${inr(w.available_balance)}</strong></td>
                  <td class="yu-addon-num">${inr(w.pending_rewards)}</td>
                  <td class="yu-addon-num">${inr(w.total_earnings)}</td>
                  <td class="yu-addon-num">${inr(w.withdrawn_amount)}</td>
                  <td>${statusTag(w.is_frozen ? "frozen" : "active")}</td>
                  <td>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-w-open="${w.user_id}">Ledger / Adjust</button>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-w-freeze="${w.user_id}" data-w-isfrozen="${w.is_frozen ? 1 : 0}">${w.is_frozen ? "Unfreeze" : "Freeze"}</button>
                  </td>
                </tr>`
                  )
                  .join("") || `<tr><td colspan="8" class="portal-empty">No wallets created yet.</td></tr>`
              }
            </tbody>
          </table></div>
        </div>`;

      container.querySelector("[data-w-f-btn]")?.addEventListener("click", () => {
        typeFilter = container.querySelector("[data-w-f-type]")?.value || "all";
        searchFilter = container.querySelector("[data-w-f-search]")?.value || "";
        draw();
      });
      container.querySelector("[data-w-close-ledger]")?.addEventListener("click", () => {
        selectedLedger = null;
        draw();
      });
      container.querySelectorAll("[data-w-open]").forEach((b) => {
        b.addEventListener("click", async () => {
          selectedLedger = await reqJson(adminApiUrl(`/wallets/${b.getAttribute("data-w-open")}/ledger`));
          draw();
        });
      });
      container.querySelectorAll("[data-w-freeze]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = b.getAttribute("data-w-freeze");
          const freeze = b.getAttribute("data-w-isfrozen") !== "1";
          await reqJson(adminApiUrl(`/wallets/${uid}/freeze`), {
            method: "POST",
            body: { freeze, reason: freeze ? "Frozen by Admin" : "" }
          });
          notice = freeze ? "Wallet frozen." : "Wallet unfrozen.";
          draw();
        });
      });
      container.querySelector("[data-w-adjust-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const uid = e.target.getAttribute("data-w-adjust-form");
        const body = Object.fromEntries(new FormData(e.target).entries());
        try {
          await reqJson(adminApiUrl(`/wallets/${uid}/adjust`), { method: "POST", body });
          selectedLedger = await reqJson(adminApiUrl(`/wallets/${uid}/ledger`));
          notice = "Wallet balance adjusted and audited.";
          errMsg = "";
        } catch (err) {
          errMsg = err.message;
        }
        draw();
      });
    };
    await draw();
  }

  async function renderAdminWithdrawalsPage(container, { adminApiUrl }) {
    let statusFilter = "all";
    let roleFilter = "all";
    let notice = "";
    let errMsg = "";

    const draw = async () => {
      const qs = new URLSearchParams({ status: statusFilter, role: roleFilter });
      const data = await reqJson(adminApiUrl(`/withdrawals?${qs.toString()}`));
      const rows = data.withdrawals || [];

      container.innerHTML = `
        ${errMsg ? `<div class="portal-message portal-message--error" style="margin-bottom:12px;">${esc(errMsg)}</div>` : ""}
        ${notice ? `<div class="portal-message portal-message--success" style="margin-bottom:12px;">${esc(notice)}</div>` : ""}
        <div class="portal-card portal-table-card">
          <div style="padding:14px 16px;border-bottom:1px solid var(--pt-border);display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;">
            <strong>Withdrawal Approval &amp; Payout Queue (${rows.length})</strong>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <select data-wdr-f-status>
                <option value="all">All Statuses</option>
                ${["pending", "under_review", "approved", "processing", "paid", "rejected"]
                  .map((s) => `<option value="${s}"${statusFilter === s ? " selected" : ""}>${s.replace("_", " ")}</option>`)
                  .join("")}
              </select>
              <select data-wdr-f-role>
                <option value="all">All Roles</option>
                <option value="student"${roleFilter === "student" ? " selected" : ""}>Student</option>
                <option value="teacher"${roleFilter === "teacher" ? " selected" : ""}>Teacher</option>
              </select>
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-wdr-f-btn>Filter</button>
            </div>
          </div>
          <div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Request</th><th>User</th><th>Payout Account</th><th>Amount</th><th>Status</th><th>Update / Payout Ref</th></tr></thead>
            <tbody>
              ${
                rows
                  .map((w) => {
                    const isClosed = w.status === "paid" || w.status === "rejected";
                    const nextMap = {
                      pending: ["under_review", "approved", "processing", "paid", "rejected"],
                      under_review: ["approved", "processing", "paid", "rejected"],
                      approved: ["processing", "paid", "rejected"],
                      processing: ["paid", "rejected"]
                    };
                    const choices = nextMap[w.status] || [];
                    return `
                  <tr>
                    <td><strong>${esc(w.request_code)}</strong><span class="portal-cell-sub">${esc(String(w.created_at || "").slice(0, 10))}</span></td>
                    <td><strong>${esc(w.full_name)}</strong><span class="portal-cell-sub">${esc(w.user_role)} · ${esc(w.phone)}</span></td>
                    <td>${w.payout_method === "upi" ? `UPI: <strong>${esc(w.upi_id)}</strong>` : `${esc(w.bank_name)} · ${esc(w.account_holder_name)}<span class="portal-cell-sub">Acc: ${esc(w.account_number)} · IFSC: ${esc(w.ifsc_code)}</span>`}</td>
                    <td class="yu-addon-num"><strong>${inr(w.amount)}</strong></td>
                    <td>${statusTag(w.status)}</td>
                    <td>
                      ${
                        isClosed
                          ? `<span class="portal-hint">${esc(w.payout_reference || w.admin_note || "Finalized")}</span>`
                          : `<form class="portal-form" data-wdr-act="${w.id}" style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
                              <select name="status" style="min-height:34px;">${choices.map((c) => `<option value="${c}">${c.replace("_", " ")}</option>`).join("")}</select>
                              <input name="payoutReference" placeholder="UTR / Ref" value="${esc(w.payout_reference || "")}" style="width:110px;min-height:34px;">
                              <input name="adminNote" placeholder="Note" value="${esc(w.admin_note || "")}" style="width:110px;min-height:34px;">
                              <button type="submit" class="portal-button portal-button--small">Update</button>
                            </form>`
                      }
                    </td>
                  </tr>`;
                  })
                  .join("") || `<tr><td colspan="6" class="portal-empty">No withdrawal requests match filters.</td></tr>`
              }
            </tbody>
          </table></div>
        </div>`;

      container.querySelector("[data-wdr-f-btn]")?.addEventListener("click", () => {
        statusFilter = container.querySelector("[data-wdr-f-status]")?.value || "all";
        roleFilter = container.querySelector("[data-wdr-f-role]")?.value || "all";
        draw();
      });
      container.querySelectorAll("[data-wdr-act]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          const id = f.getAttribute("data-wdr-act");
          const body = Object.fromEntries(new FormData(f).entries());
          try {
            await reqJson(adminApiUrl(`/withdrawals/${id}/status`), { method: "POST", body });
            notice = `Withdrawal #${id} updated to "${body.status}".`;
            errMsg = "";
          } catch (err) {
            errMsg = err.message;
          }
          draw();
        });
      });
    };
    await draw();
  }

  async function renderAdminReferralReportsPage(container, { adminApiUrl }) {
    let fromDate = "";
    let toDate = "";
    let roleFilter = "all";

    const draw = async () => {
      const qs = new URLSearchParams({ role: roleFilter });
      if (fromDate) qs.set("from", fromDate);
      if (toDate) qs.set("to", toDate);
      const rep = await reqJson(adminApiUrl(`/analytics/referrals-wallets?${qs.toString()}`));
      const s = rep.summary || {};

      container.innerHTML = `
        <div class="portal-card portal-profile yu-no-print" style="margin-bottom:16px;">
          <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;">
            <div>
              <h3 class="portal-section-title" style="margin:0;">Referral, Wallet &amp; Payout Analytics</h3>
              <span class="portal-hint">Date-wise, monthly &amp; yearly financial insights with multi-format exports.</span>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <a href="${esc(adminApiUrl("/analytics/referrals-wallets/export?format=csv"))}" class="portal-button portal-button--small portal-button--quiet" style="text-decoration:none;">Export CSV</a>
              <a href="${esc(adminApiUrl("/analytics/referrals-wallets/export?format=excel"))}" class="portal-button portal-button--small portal-button--quiet" style="text-decoration:none;">Export Excel (.xls)</a>
              <button type="button" class="portal-button portal-button--small" data-rep-print>Print / PDF</button>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:12px;align-items:flex-end;">
            <div class="portal-field"><label>From Date</label><input type="date" data-rep-from value="${esc(fromDate)}"></div>
            <div class="portal-field"><label>To Date</label><input type="date" data-rep-to value="${esc(toDate)}"></div>
            <div class="portal-field"><label>Role</label><select data-rep-role><option value="all">All</option><option value="student"${roleFilter === "student" ? " selected" : ""}>Student</option><option value="teacher"${roleFilter === "teacher" ? " selected" : ""}>Teacher</option></select></div>
            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-rep-apply>Apply Filters</button>
          </div>
        </div>

        <div class="yu-addon-grid-4" style="margin-bottom:16px;">
          <div class="portal-stat"><div><strong class="yu-addon-num">${s.totalReferrals || 0}</strong><span>Total Referrals</span></div></div>
          <div class="portal-stat"><div><strong class="yu-addon-num">${s.qualifiedReferrals || 0}</strong><span>Qualified (3+ Mo)</span></div></div>
          <div class="portal-stat"><div><strong class="yu-addon-num">${s.pendingReferrals || 0}</strong><span>Pending Progress</span></div></div>
          <div class="portal-stat"><div><strong class="yu-addon-num">${inr(s.rewardsDistributed)}</strong><span>Rewards Distributed</span></div></div>
        </div>

        <div class="yu-addon-grid-2" style="margin-bottom:16px;">
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Wallet Balances (Student vs Teacher)</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Type</th><th>Wallets</th><th>Available</th><th>Pending</th><th>Withdrawn</th></tr></thead>
              <tbody>
                ${(rep.walletBreakdown || [])
                  .map(
                    (w) => `
                  <tr>
                    <td><strong>${esc(w.wallet_type)}</strong></td>
                    <td class="yu-addon-num">${w.walletCount}</td>
                    <td class="yu-addon-num">${inr(w.availableTotal)}</td>
                    <td class="yu-addon-num">${inr(w.pendingRewardsTotal)}</td>
                    <td class="yu-addon-num">${inr(w.withdrawnTotal)}</td>
                  </tr>`
                  )
                  .join("") || `<tr><td colspan="5" class="portal-empty">No wallet data yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>

          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Monthly Payout Summary</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Month</th><th>Payouts</th><th>Total Paid</th></tr></thead>
              <tbody>
                ${(rep.monthlyPayouts || [])
                  .map(
                    (p) => `
                  <tr><td><strong>${esc(p.month)}</strong></td><td class="yu-addon-num">${p.payoutCount}</td><td class="yu-addon-num">${inr(p.paidAmount)}</td></tr>`
                  )
                  .join("") || `<tr><td colspan="3" class="portal-empty">No paid withdrawals recorded yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
        </div>

        <div class="portal-card portal-table-card">
          <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Top Referrers Leaderboard</div>
          <div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Referrer</th><th>Code</th><th>Qualified</th><th>Total</th><th>Rewards Credited</th><th>Wallet Balance</th></tr></thead>
            <tbody>
              ${(rep.topReferrers || [])
                .map(
                  (t) => `
                <tr>
                  <td><strong>${esc(t.full_name)}</strong><span class="portal-cell-sub">${esc(t.role)} · ${esc(t.phone)}</span></td>
                  <td>${esc(t.referral_code)}</td>
                  <td class="yu-addon-num">${t.qualified_referrals}</td>
                  <td class="yu-addon-num">${t.total_referrals}</td>
                  <td class="yu-addon-num">${inr(t.total_rewards_credited)}</td>
                  <td class="yu-addon-num">${inr(t.available_balance || 0)}</td>
                </tr>`
                )
                .join("") || `<tr><td colspan="6" class="portal-empty">No referrer profiles yet.</td></tr>`}
            </tbody>
          </table></div>
        </div>`;

      container.querySelector("[data-rep-apply]")?.addEventListener("click", () => {
        fromDate = container.querySelector("[data-rep-from]")?.value || "";
        toDate = container.querySelector("[data-rep-to]")?.value || "";
        roleFilter = container.querySelector("[data-rep-role]")?.value || "all";
        draw();
      });
      container.querySelector("[data-rep-print]")?.addEventListener("click", () => window.print());
    };
    await draw();
  }

  // ==================== REGISTRATION & ROUTE INIT ====================
  window.YuitorAddons = {
    initReferralCapture,
    getStoredReferralCode,
    refreshCart,
    addToCartAndOpen,
    openCartDrawer,
    renderUserReferralsTab,
    renderUserWalletTab,
    mountAdminGlobalSearch,
    openGlobalSearch,
    renderAdminReferralsPage,
    renderAdminWalletsPage,
    renderAdminWithdrawalsPage,
    renderAdminReferralReportsPage
  };

  initReferralCapture();
  const startup = async () => {
    await refreshCart();
    try {
      if (new URLSearchParams(window.location.search).get("openCart") === "1") {
        openCartDrawer();
      }
    } catch {
      // ignore
    }
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => { startup(); }, { once: true });
  } else {
    startup();
  }
})();
