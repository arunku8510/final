(() => {
  "use strict";
  const origin = "https://yuitor.com";
  const defaultImage = `${origin}/opengraph-yuitor.jpg`;

  fetch("/assets/route-metadata.json")
    .then((response) => {
      if (!response.ok) throw new Error("Route metadata is unavailable");
      return response.json();
    })
    .then((routes) => {
      const ensureMeta = (selector, attributes, value) => {
        let node = document.head.querySelector(selector);
        if (!node) {
          node = document.createElement("meta");
          Object.entries(attributes).forEach(([key, val]) => node.setAttribute(key, val));
          document.head.appendChild(node);
        }
        node.setAttribute("content", value);
      };
      function update() {
        const path = decodeURI(location.pathname).replace(/\/+$/, "") || "/";
        const meta = routes[path] || routes["/"];
        const canonical = `${origin}${path === "/" ? "/" : path}`;
        const isPrivate = /^\/(admin|student|teacher|erp|login|register|unsubscribe)/.test(path);
        document.title = meta.title;
        ensureMeta('meta[name="description"]', { name: "description" }, meta.description);
        ensureMeta(
          'meta[name="robots"]',
          { name: "robots" },
          isPrivate ? "noindex, nofollow" : "index, follow, max-image-preview:large",
        );
        ensureMeta('meta[property="og:title"]', { property: "og:title" }, meta.title);
        ensureMeta('meta[property="og:description"]', { property: "og:description" }, meta.description);
        ensureMeta('meta[property="og:url"]', { property: "og:url" }, canonical);
        ensureMeta('meta[property="og:image"]', { property: "og:image" }, defaultImage);
        ensureMeta('meta[property="og:type"]', { property: "og:type" }, path.startsWith("/blog/") ? "article" : "website");
        ensureMeta('meta[name="twitter:card"]', { name: "twitter:card" }, "summary_large_image");
        ensureMeta('meta[name="twitter:title"]', { name: "twitter:title" }, meta.title);
        ensureMeta('meta[name="twitter:description"]', { name: "twitter:description" }, meta.description);
        ensureMeta('meta[name="twitter:image"]', { name: "twitter:image" }, defaultImage);
        let link = document.head.querySelector('link[rel="canonical"]');
        if (!link) {
          link = document.createElement("link");
          link.rel = "canonical";
          document.head.appendChild(link);
        }
        link.href = canonical;

        let bc = document.head.querySelector('script[data-yu-breadcrumb-ld]');
        if (isPrivate) {
          if (bc) bc.remove();
        } else {
          if (!bc) {
            bc = document.createElement("script");
            bc.type = "application/ld+json";
            bc.setAttribute("data-yu-breadcrumb-ld", "true");
            document.head.appendChild(bc);
          }
          const parts = path === "/" ? [] : path.split("/").filter(Boolean);
          const itemListElement = [
            { "@type": "ListItem", position: 1, name: "Home", item: `${origin}/` },
            ...parts.map((seg, i) => ({
              "@type": "ListItem",
              position: i + 2,
              name: i === parts.length - 1 ? meta.title.split("|")[0].trim() : decodeURIComponent(seg),
              item: `${origin}/${parts.slice(0, i + 1).join("/")}`,
            })),
          ];
          bc.textContent = JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement,
          });
        }
      }
      const originalPush = history.pushState;
      history.pushState = function (...args) {
        originalPush.apply(this, args);
        update();
      };
      const originalReplace = history.replaceState;
      history.replaceState = function (...args) {
        originalReplace.apply(this, args);
        update();
      };
      addEventListener("popstate", update);
      update();
    })
    .catch(() => {
      // Static route shells provide crawler metadata even if the runtime map fails.
    });
})();
