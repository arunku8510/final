(() => {
  "use strict";
  if (document.getElementById("yu-ai-guide-root")) return;

  const SHREYA_INTRO =
    "Hello! My name is Shreya, and I am Yuitor Smart Classes’ Smart AI Assistant. How can I help you?";

  let conversationId = sessionStorage.getItem("yuitor_shreya_conv_id") || "";
  let visitorId = sessionStorage.getItem("yuitor_visitor_id") || "";
  if (!visitorId) {
    visitorId = "v-" + Math.random().toString(36).slice(2, 10);
    sessionStorage.setItem("yuitor_visitor_id", visitorId);
  }

  let busy = false;
  let currentRating = 5;

  const root = document.createElement("div");
  root.id = "yu-ai-guide-root";
  root.style.cssText =
    "position:fixed;bottom:92px;right:20px;z-index:9999;font-family:system-ui,-apple-system,sans-serif;";

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.id = "yu-smart-ai-toggle";
  toggle.textContent = "Ask Shreya";
  toggle.style.cssText =
    "background:#0f172a;color:#fff;border:2px solid #12a1a1;padding:11px 18px;border-radius:999px;font-weight:700;font-size:14px;cursor:pointer;box-shadow:0 10px 25px rgba(15,23,42,.28);";

  const box = document.createElement("div");
  box.hidden = true;
  box.style.cssText =
    "width:360px;max-width:calc(100vw - 32px);background:#fff;border:1px solid #cbd9e6;border-radius:16px;box-shadow:0 18px 40px rgba(15,23,42,.24);overflow:hidden;margin-bottom:10px;";

  box.innerHTML = `
    <div style="background:#0f172a;color:#fff;padding:12px 14px;display:flex;justify-content:space-between;align-items:center;gap:8px;">
      <div>
        <div style="font-weight:700;font-size:14.5px;">Shreya · Yuitor Smart AI</div>
        <div style="font-size:11px;color:#78d3d3;">Courses, Admissions, Classes &amp; Support</div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <button type="button" id="yu-chat-info-btn" style="background:#1e293b;color:#cbd5e1;border:0;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer;">Info</button>
        <button type="button" id="yu-chat-rate-btn" style="background:#1e293b;color:#cbd5e1;border:0;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer;">Rate</button>
        <button type="button" id="yu-chat-close" style="background:none;border:0;color:#fff;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
      </div>
    </div>
    <div id="yu-chat-contact" hidden style="padding:10px;background:#f8fafc;border-bottom:1px solid #e2e8f0;display:grid;gap:6px;font-size:12px;">
      <input id="yu-v-name" type="text" placeholder="Your name (optional)" style="padding:6px 8px;border:1px solid #cbd9e6;border-radius:8px;font-size:12px;">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
        <input id="yu-v-phone" type="tel" placeholder="Mobile (optional)" style="padding:6px 8px;border:1px solid #cbd9e6;border-radius:8px;font-size:12px;">
        <input id="yu-v-email" type="email" placeholder="Email (optional)" style="padding:6px 8px;border:1px solid #cbd9e6;border-radius:8px;font-size:12px;">
      </div>
    </div>
    <form id="yu-chat-rate" hidden style="padding:10px;background:#eff6ff;border-bottom:1px solid #bfdbfe;display:grid;gap:6px;font-size:12px;">
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <strong style="color:#0f172a;">Rate Shreya</strong>
        <div id="yu-stars" style="display:flex;gap:4px;"></div>
      </div>
      <input id="yu-fb-text" type="text" placeholder="Optional feedback..." style="padding:6px 8px;border:1px solid #cbd9e6;border-radius:8px;font-size:12px;">
      <button type="submit" style="background:#0f172a;color:#fff;border:0;padding:6px 10px;border-radius:8px;font-weight:600;cursor:pointer;">Save Feedback</button>
    </form>
    <div id="yu-chat-msgs" style="height:280px;overflow-y:auto;padding:12px;background:#f5f9fc;display:flex;flex-direction:column;gap:8px;font-size:13px;line-height:1.48;"></div>
    <form id="yu-chat-form" style="display:flex;gap:6px;padding:10px;border-top:1px solid #dbe6ef;background:#fff;">
      <input id="yu-chat-in" type="text" maxlength="500" required placeholder="Ask in English or Hindi..." style="flex:1;padding:8px 10px;border:1px solid #cbd9e6;border-radius:10px;font-size:13px;">
      <button type="submit" style="background:#12a1a1;color:#fff;border:0;padding:8px 14px;border-radius:10px;font-weight:700;cursor:pointer;">Send</button>
    </form>
  `;

  root.append(box, toggle);
  document.body.appendChild(root);

  const msgsEl = box.querySelector("#yu-chat-msgs");
  const form = box.querySelector("#yu-chat-form");
  const input = box.querySelector("#yu-chat-in");
  const closeBtn = box.querySelector("#yu-chat-close");
  const infoBtn = box.querySelector("#yu-chat-info-btn");
  const rateBtn = box.querySelector("#yu-chat-rate-btn");
  const contactPanel = box.querySelector("#yu-chat-contact");
  const rateForm = box.querySelector("#yu-chat-rate");
  const starsWrap = box.querySelector("#yu-stars");

  function renderMessages(list) {
    msgsEl.innerHTML = "";
    const items = Array.isArray(list) && list.length
      ? list
      : [{ sender: "assistant", message: SHREYA_INTRO }];
    for (const m of items) {
      const div = document.createElement("div");
      const isUser = m.sender === "user";
      div.style.cssText = isUser
        ? "align-self:flex-end;background:#0f172a;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;"
        : "align-self:flex-start;background:#fff;border:1px solid #dbe6ef;color:#0f172a;padding:9px 11px;border-radius:12px;max-width:90%;white-space:pre-line;";
      div.textContent = m.message;
      msgsEl.appendChild(div);
    }
    msgsEl.scrollTop = msgsEl.scrollHeight;
  }

  function renderStars() {
    starsWrap.innerHTML = "";
    for (let i = 1; i <= 5; i++) {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = i <= currentRating ? "★" : "☆";
      b.style.cssText = `background:none;border:0;font-size:16px;cursor:pointer;color:${i <= currentRating ? "#d97706" : "#94a3b8"};padding:0 2px;`;
      b.addEventListener("click", () => {
        currentRating = i;
        renderStars();
      });
      starsWrap.appendChild(b);
    }
  }
  renderStars();
  renderMessages([{ sender: "assistant", message: SHREYA_INTRO }]);

  async function ensureSession() {
    try {
      const res = await fetch("/api/public/chatbot/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId, visitorId }),
      });
      if (!res.ok) return;
      const data = await res.json();
      if (data?.conversation?.id) {
        conversationId = data.conversation.id;
        sessionStorage.setItem("yuitor_shreya_conv_id", conversationId);
      }
      if (Array.isArray(data?.messages)) {
        renderMessages(data.messages);
      }
    } catch {
      // Keep default intro visible
    }
  }

  async function sendMessage(text) {
    const clean = String(text || "").trim();
    if (!clean || busy) return;
    busy = true;
    input.disabled = true;

    const uBubble = document.createElement("div");
    uBubble.style.cssText =
      "align-self:flex-end;background:#0f172a;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;";
    uBubble.textContent = clean;
    msgsEl.appendChild(uBubble);

    const typing = document.createElement("div");
    typing.style.cssText =
      "align-self:flex-start;background:#fff;border:1px solid #dbe6ef;color:#64748b;padding:7px 11px;border-radius:12px;font-size:12px;";
    typing.textContent = "Shreya is typing...";
    msgsEl.appendChild(typing);
    msgsEl.scrollTop = msgsEl.scrollHeight;
    input.value = "";

    try {
      if (!conversationId) await ensureSession();
      const res = await fetch("/api/public/chatbot/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId,
          message: clean,
          visitorName: box.querySelector("#yu-v-name").value.trim() || undefined,
          visitorPhone: box.querySelector("#yu-v-phone").value.trim() || undefined,
          visitorEmail: box.querySelector("#yu-v-email").value.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (Array.isArray(data?.messages)) {
        renderMessages(data.messages);
      } else if (data?.reply) {
        typing.textContent = data.reply;
        typing.style.color = "#0f172a";
      } else {
        typing.textContent =
          data?.error || "Unable to connect right now. Please call +91 78-2728-9292.";
      }
    } catch {
      typing.textContent = "Connection error. Call or WhatsApp +91 78-2728-9292.";
    } finally {
      busy = false;
      input.disabled = false;
      input.focus();
    }
  }

  toggle.addEventListener("click", () => {
    box.hidden = !box.hidden;
    if (!box.hidden) {
      ensureSession();
      input.focus();
    }
  });
  closeBtn.addEventListener("click", () => {
    box.hidden = true;
  });
  infoBtn.addEventListener("click", () => {
    contactPanel.hidden = !contactPanel.hidden;
    contactPanel.style.display = contactPanel.hidden ? "none" : "grid";
  });
  rateBtn.addEventListener("click", () => {
    rateForm.hidden = !rateForm.hidden;
    rateForm.style.display = rateForm.hidden ? "none" : "grid";
  });
  rateForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!conversationId) await ensureSession();
    await fetch("/api/public/chatbot/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        conversationId,
        rating: currentRating,
        feedback: box.querySelector("#yu-fb-text").value.trim(),
        resolved: currentRating >= 4,
      }),
    });
    rateForm.hidden = true;
    rateForm.style.display = "none";
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendMessage(input.value);
  });
})();
