import assert from "node:assert/strict";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import crypto from "node:crypto";
import bcrypt from "bcryptjs";

process.env.YUITOR_NO_LISTEN = "1";
process.env.NODE_ENV = "test";

function signTestSession(sid) {
  const secret = String(process.env.SESSION_SECRET || "").trim();
  const sig = crypto.createHmac("sha256", secret).update(sid).digest("hex");
  return `${sid}.${sig}`;
}

const { createApp } = await import("../server.js");

function request(port, method, urlPath, { body = null, headers = {}, cookie = "" } = {}) {
  return new Promise((resolve, reject) => {
    const payload = body && typeof body === "object" ? JSON.stringify(body) : body;
    const reqHeaders = {
      Origin: `http://127.0.0.1:${port}`,
      Referer: `http://127.0.0.1:${port}/`,
      ...headers
    };
    if (cookie) reqHeaders.Cookie = cookie;
    if (payload && !reqHeaders["Content-Type"]) {
      reqHeaders["Content-Type"] = "application/json";
      reqHeaders["Content-Length"] = Buffer.byteLength(payload);
    }
    const req = http.request({ hostname: "127.0.0.1", port, path: urlPath, method, headers: reqHeaders }, (res) => {
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => {
        const buf = Buffer.concat(chunks);
        const text = buf.toString("utf8");
        let json = null;
        try {
          json = JSON.parse(text);
        } catch {
          // non-json response (PDF/CSV/HTML)
        }
        resolve({ status: res.statusCode, headers: res.headers, text, buf, json });
      });
    });
    req.on("error", reject);
    if (payload) req.write(payload);
    req.end();
  });
}

function mergeCookies(existing, setCookieHeaders = []) {
  const map = new Map();
  for (const part of String(existing || "").split(";")) {
    const idx = part.indexOf("=");
    if (idx > 0) map.set(part.slice(0, idx).trim(), part.slice(idx + 1).trim());
  }
  for (const sc of setCookieHeaders || []) {
    const first = String(sc).split(";")[0];
    const idx = first.indexOf("=");
    if (idx > 0) map.set(first.slice(0, idx).trim(), first.slice(idx + 1).trim());
  }
  return [...map.entries()].map(([k, v]) => `${k}=${v}`).join("; ");
}

function getCookieVal(cookieStr, name) {
  const m = String(cookieStr || "").match(new RegExp(`(?:^|;\\s*)${name}=([^;]+)`));
  return m ? decodeURIComponent(m[1]) : "";
}

const { app, db } = createApp();
const server = await new Promise((resolve) => {
  const s = app.listen(0, "127.0.0.1", () => resolve(s));
});
const port = server.address().port;

const results = [];
const record = (name, ok, detail = "") => {
  results.push({ name, ok, detail });
  if (!ok) throw new Error(`FAIL [${name}]: ${detail}`);
};

const tag = Date.now().toString(36);
const testStartIso = new Date().toISOString();
let createdLeadId = null;
let createdStudentId = null;
let createdPaymentId = null;
let createdExamId = null;
let createdSlotId = null;
let createdDoubtId = null;
let adminSessionId = null;
let studentSessionId = null;
let createdTempAdminId = null;

try {
  // 1. Health & Version Check
  const health = await request(port, "GET", "/api/health");
  record("Health & v3.0.0", health.status === 200 && health.json?.version === "3.0.0", `version=${health.json?.version}`);
  let adminCookie = mergeCookies("", health.headers["set-cookie"]);
  const csrfToken = getCookieVal(adminCookie, "yu_csrf");
  const adminSlugRow = db.prepare("SELECT value FROM system_settings WHERE key = 'ADMIN_PATH'").get();
  const adminSlug = adminSlugRow?.value || process.env.ADMIN_PATH;
  assert.ok(adminSlug, "Admin gate slug must exist");

  // Create isolated test session for existing super_admin (or temporary admin if fresh pre-installer DB)
  let adminUser = db.prepare("SELECT id, email FROM users WHERE role IN ('super_admin','admin') ORDER BY id ASC LIMIT 1").get();
  if (!adminUser) {
    const hash = bcrypt.hashSync(`SmokeAdm#${tag}`, 8);
    const nowIso = new Date().toISOString();
    const ins = db
      .prepare(`INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at) VALUES ('super_admin', 'Smoke Admin', ?, '9999999900', ?, 1, 'approved', 1, 0, ?, ?, ?)`)
      .run(`smoke-admin-${tag}@yuitor.test`, hash, `smoke_unsub_${tag}`, nowIso, nowIso);
    createdTempAdminId = Number(ins.lastInsertRowid);
    adminUser = { id: createdTempAdminId, email: `smoke-admin-${tag}@yuitor.test` };
  }
  assert.ok(adminUser, "Admin user must exist");
  adminSessionId = crypto.randomBytes(24).toString("hex");
  const nowEpoch = Math.floor(Date.now() / 1000);
  db.prepare(`INSERT INTO sessions (id, user_id, expires_at, created_at, last_seen_at) VALUES (?, ?, ?, ?, ?)`).run(
    adminSessionId,
    adminUser.id,
    nowEpoch + 3600,
    nowEpoch,
    nowEpoch
  );
  adminCookie = mergeCookies(adminCookie, [`yu_session=${signTestSession(adminSessionId)}`]);
  const adminHdrs = { "X-CSRF-Token": csrfToken };

  // 2. Permissions Check (unauthenticated blocked)
  const unauth = await request(port, "GET", `/api/${adminSlug}/crm/dashboard`);
  record("Admin RBAC Guard", unauth.status === 401 || unauth.status === 403, `status=${unauth.status}`);

  // 3. Smart Admin Dashboard & Founder Report
  const dash = await request(port, "GET", `/api/${adminSlug}/crm/dashboard`, { cookie: adminCookie });
  record("Smart Dashboard & KPIs", dash.status === 200 && dash.json?.kpi && dash.json?.config, `status=${dash.status} body=${dash.text.slice(0, 160)}`);
  const fRep = await request(port, "POST", `/api/${adminSlug}/crm/founder-report/generate`, { cookie: adminCookie, headers: adminHdrs, body: { reportType: "founder_8pm" } });
  record("Founder Daily Report", fRep.status === 200 && Boolean(fRep.json?.summaryText), `status=${fRep.status}`);

  // 4. Inquiry Creation, Duplicate Block & 1-Click Conversion
  const leadPhone = `98${String(Date.now()).slice(-8)}`;
  const leadRes = await request(port, "POST", `/api/${adminSlug}/crm/leads`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { name: `Smoke Student ${tag}`, phone: leadPhone, classOrCourse: "Class 12 JEE", source: "walk_in_qr", demoDate: "2026-11-25" }
  });
  record("Lead Create & Score", leadRes.status === 201 && leadRes.json?.leadScore >= 70, `score=${leadRes.json?.leadScore}`);
  createdLeadId = leadRes.json.id;

  const dupLead = await request(port, "POST", `/api/${adminSlug}/crm/leads`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { name: "Dup Student", phone: leadPhone, classOrCourse: "Class 12" }
  });
  record("Lead Duplicate Phone Block", dupLead.status === 409 && dupLead.json?.duplicate === true, `status=${dupLead.status}`);

  const conv = await request(port, "POST", `/api/${adminSlug}/crm/leads/${createdLeadId}/convert`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: {}
  });
  record("1-Click Lead -> Student Convert", conv.status === 201 && Number(conv.json?.studentId) > 0, `studentId=${conv.json?.studentId}`);
  createdStudentId = conv.json.studentId;

  // 5. Monthly Fee Generation (Idempotent), Quick Fee Collect & Duplicate Payment Prevention
  const gen1 = await request(port, "POST", `/api/${adminSlug}/crm/fee-desk/generate-monthly`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { billingMonth: "2099-01", studentIds: [createdStudentId] }
  });
  const gen2 = await request(port, "POST", `/api/${adminSlug}/crm/fee-desk/generate-monthly`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { billingMonth: "2099-01", studentIds: [createdStudentId] }
  });
  record("Monthly Fee Idempotent Gen", gen1.json?.created === 1 && gen2.json?.created === 0 && gen2.json?.skipped === 1, `gen1=${gen1.json?.created}, gen2=${gen2.json?.skipped}`);

  const idemKey = `smoke-pay-${tag}`;
  const pay1 = await request(port, "POST", `/api/${adminSlug}/crm/fee-desk/collect`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { studentId: createdStudentId, amount: 1400, paymentMethod: "upi", utrReference: `UTR${tag}`, idempotencyKey: idemKey }
  });
  const pay2 = await request(port, "POST", `/api/${adminSlug}/crm/fee-desk/collect`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { studentId: createdStudentId, amount: 1400, paymentMethod: "upi", utrReference: `UTR${tag}`, idempotencyKey: idemKey }
  });
  record("Quick Fee Collect & Duplicate Block", pay1.status === 201 && pay2.status === 409 && Boolean(pay1.json?.whatsappReceiptUrl), `pay1=${pay1.status}, pay2=${pay2.status}`);
  createdPaymentId = pay1.json.paymentId;

  // 6. Branded PDFs (Binary %PDF-1.4 + HTML Print Sheet with Yuitor Logo & QR)
  const rcptPdf = await request(port, "GET", `/api/${adminSlug}/crm/pdf/receipt/${createdPaymentId}?format=pdf`, { cookie: adminCookie });
  const idHtml = await request(port, "GET", `/api/${adminSlug}/crm/pdf/id-card/${createdStudentId}`, { cookie: adminCookie });
  const rptPdf = await request(port, "GET", `/api/${adminSlug}/crm/pdf/report-card/${createdStudentId}?format=pdf`, { cookie: adminCookie });
  record("Printable PDFs (Receipt, QR ID, Report)", rcptPdf.text.startsWith("%PDF-1.4") && idHtml.text.includes("<svg") && idHtml.text.includes("yuitor-smart-classes-logo") && rptPdf.text.startsWith("%PDF-1.4"), "All 3 PDF/HTML docs valid");

  // 7. Attendance + Absent Alert + WhatsApp Link + QR Scan
  const courseId = db.prepare("SELECT id FROM courses ORDER BY id ASC LIMIT 1").get().id;
  const attRes = await request(port, "POST", `/api/${adminSlug}/crm/attendance/batch-submit`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { courseId, date: "2099-01-15", entries: [{ studentId: createdStudentId, status: "absent" }] }
  });
  record("Batch Attendance & Absent WhatsApp", attRes.status === 200 && attRes.json?.absentCount === 1 && attRes.json?.absentees?.[0]?.whatsappUrl?.startsWith("https://wa.me/"), `absentees=${attRes.json?.absentCount}`);

  // 8. CSV Bulk Import Preview & Export
  const csvPrev = await request(port, "POST", `/api/${adminSlug}/crm/bulk/import-preview`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { entity: "students", csvText: `full_name,phone\nPreview One,9700000001\nDup Lead,${leadPhone}\nBad Row,123` }
  });
  const csvExp = await request(port, "GET", `/api/${adminSlug}/crm/bulk/export/fee_register`, { cookie: adminCookie });
  record("CSV Preview & Accounting Export", csvPrev.json?.validCount === 1 && csvPrev.json?.duplicateCount === 1 && csvPrev.json?.errorCount === 1 && csvExp.status === 200, `valid=${csvPrev.json?.validCount}`);

  // 9. Live Class Clash Check + CBT Exam + Student Login Submission + Doubt Counter
  const live1 = await request(port, "POST", `/api/${adminSlug}/crm/live-classes`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { courseId, dayOfWeek: "Sunday", startTime: "07:00", endTime: "08:00", subjectName: "Physics", roomName: `Room-${tag}`, mode: "hybrid", meetingUrl: "https://meet.google.com/abc-defg-hij", meetingPlatform: "google_meet" }
  });
  createdSlotId = live1.json?.id;
  const liveClash = await request(port, "POST", `/api/${adminSlug}/crm/live-classes`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { courseId, dayOfWeek: "Sunday", startTime: "07:30", endTime: "08:30", subjectName: "Maths", roomName: `Room-${tag}`, mode: "offline" }
  });
  record("Live Class & Clash Detection", live1.status === 201 && liveClash.status === 409, `live1=${live1.status}, clash=${liveClash.status}`);

  const cbtCreate = await request(port, "POST", `/api/${adminSlug}/crm/cbt/exams`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: {
      courseId,
      title: `Smoke CBT ${tag}`,
      positiveMarks: 4,
      negativeMarks: 1,
      durationMinutes: 20,
      questionsCsv: "question,option_a,option_b,option_c,option_d,correct_answer,topic\n2+2=?,3,4,5,6,4,Algebra\nUnit of Force?,Joule,Newton,Watt,Ohm,Newton,Mechanics"
    }
  });
  createdExamId = cbtCreate.json?.id;

  // Create student session to test Student Portal APIs
  studentSessionId = crypto.randomBytes(24).toString("hex");
  db.prepare(`INSERT INTO sessions (id, user_id, expires_at, created_at, last_seen_at) VALUES (?, ?, ?, ?, ?)`).run(
    studentSessionId,
    createdStudentId,
    nowEpoch + 3600,
    nowEpoch,
    nowEpoch
  );
  const stuCookie = mergeCookies(`yu_csrf=${csrfToken}`, [`yu_session=${signTestSession(studentSessionId)}`]);
  const cbtSub = await request(port, "POST", `/api/student/crm/cbt/${createdExamId}/submit`, {
    cookie: stuCookie,
    headers: adminHdrs,
    body: { answers: { 1: "4", 2: "Joule" } }
  });
  record("Student CBT (+4/-1, Rank, %ile)", cbtSub.status === 201 && cbtSub.json?.score === 3 && cbtSub.json?.rank === 1, `score=${cbtSub.json?.score}`);

  const doubtRes = await request(port, "POST", `/api/student/crm/doubts`, {
    cookie: stuCookie,
    headers: adminHdrs,
    body: { subjectName: "Physics", chapterName: "Mechanics", questionText: "How does friction depend on normal force?" }
  });
  createdDoubtId = doubtRes.json?.id;
  record("Student Doubt Counter (12h SLA)", doubtRes.status === 201 && Boolean(doubtRes.json?.slaDueAt), `doubtId=${createdDoubtId}`);

  // 10. Automation Switch Toggle & Central Scheduler Trigger
  const toggleOn = await request(port, "PATCH", `/api/${adminSlug}/crm/automation/config`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { quiet_hours_enabled: 1, max_auto_messages_per_day: 3 }
  });
  const schedRun = await request(port, "POST", `/api/${adminSlug}/crm/automation/scheduler/run`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { jobName: "queue_and_sla" }
  });
  record("Automation Config & IST Scheduler", toggleOn.status === 200 && schedRun.status === 200 && schedRun.json?.timezone === "Asia/Kolkata", `tz=${schedRun.json?.timezone}`);

  // 11. Role-Separated Student Exit, Left/Alumni Archive & 1-Click Rejoin
  const stuExitRes = await request(port, "POST", `/api/${adminSlug}/crm/exits/student/${createdStudentId}`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { exitCategory: "dropped_out", exitReason: "Smoke test relocation", duesAction: "waive_off", settlementNote: "Full waiver" }
  });
  const stuExitId = stuExitRes.json?.exitId;
  const stuExitsList = await request(port, "GET", `/api/${adminSlug}/crm/exits?role=student`, { cookie: adminCookie });
  const stuRejoinRes = await request(port, "POST", `/api/${adminSlug}/crm/exits/${stuExitId}/rejoin`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { rejoinNote: "Smoke rejoin", restoreBatch: true }
  });
  record(
    "Student 1-Click Exit -> Alumni -> Rejoin",
    (stuExitRes.status === 200 || stuExitRes.status === 201) && Boolean(stuExitId) && stuExitsList.status === 200 && stuRejoinRes.status === 200 && stuRejoinRes.json?.ok === true,
    `exitId=${stuExitId}, restored=${stuRejoinRes.json?.batchesRestored}`
  );

  // 12. Separate Teacher & Staff Exits + Leaves Auto-Substitute Overview
  const tchExits = await request(port, "GET", `/api/${adminSlug}/crm/exits?role=teacher`, { cookie: adminCookie });
  const stfExits = await request(port, "GET", `/api/${adminSlug}/crm/exits?role=staff`, { cookie: adminCookie });
  const lvOverview = await request(port, "GET", `/api/${adminSlug}/crm/leaves/overview`, { cookie: adminCookie });
  record(
    "Teacher/Staff Separate Exits & Leave Auto-Sub API",
    tchExits.status === 200 && stfExits.status === 200 && lvOverview.status === 200 && Array.isArray(lvOverview.json?.leaves),
    `teachers=${tchExits.json?.activeMembers?.length}, staff=${stfExits.json?.activeMembers?.length}`
  );

  // 13. Anonymous Student Feedback + Teacher Portal Phone Masking & Redaction
  let tempTeacherId = null;
  let teacherSessionId = null;
  const existingTeacher = db
    .prepare(
      `SELECT u.id FROM users u JOIN teacher_profiles tp ON tp.user_id = u.id
       WHERE u.role = 'teacher' AND u.is_active = 1 AND tp.resume_status = 'verified' AND tp.resume_url != '' ORDER BY u.id ASC LIMIT 1`
    )
    .get();
  let testTeacherId = existingTeacher?.id;
  if (!testTeacherId) {
    const tHash = bcrypt.hashSync(`SmokeTch#${tag}`, 8);
    const nowIso = new Date().toISOString();
    const tIns = db
      .prepare(`INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at) VALUES ('teacher', 'Smoke Faculty', ?, '9876543298', ?, 1, 'approved', 1, 0, ?, ?, ?)`)
      .run(`smoke-teacher-${tag}@yuitor.test`, tHash, `smoke_tch_unsub_${tag}`, nowIso, nowIso);
    testTeacherId = Number(tIns.lastInsertRowid);
    db.prepare(`INSERT OR REPLACE INTO teacher_profiles (user_id, qualification, experience_years, subjects_json, resume_url, resume_filename, resume_status) VALUES (?, 'M.Sc', 5, '["Physics","Maths"]', '/uploads/resumes/verified-smoke.pdf', 'verified-smoke.pdf', 'verified')`).run(testTeacherId);
    tempTeacherId = testTeacherId;
  }
  // Verify exit revoked old student session, then issue a fresh post-rejoin session for feedback test
  assert.equal(db.prepare(`SELECT COUNT(*) AS c FROM sessions WHERE id = ?`).get(studentSessionId).c, 0, "Exit must revoke active sessions");
  studentSessionId = crypto.randomBytes(24).toString("hex");
  db.prepare(`INSERT INTO sessions (id, user_id, expires_at, created_at, last_seen_at) VALUES (?, ?, ?, ?, ?)`).run(
    studentSessionId,
    createdStudentId,
    nowEpoch + 3600,
    nowEpoch,
    nowEpoch
  );
  const stuCookiePostRejoin = mergeCookies(`yu_csrf=${csrfToken}`, [`yu_session=${signTestSession(studentSessionId)}`]);

  const fbPost = await request(port, "POST", `/api/student/crm/feedback`, {
    cookie: stuCookiePostRejoin,
    headers: adminHdrs,
    body: {
      teacherId: testTeacherId,
      subjectName: "Physics",
      topicUnclear: "Kinematics Graphs",
      rating: 4,
      clarityRating: 4,
      paceTag: "too_fast",
      feedbackText: "Please revise slope graphs once more.",
      isAnonymous: true
    }
  });
  const fbAdmin = await request(port, "GET", `/api/${adminSlug}/crm/feedback/overview`, { cookie: adminCookie });
  teacherSessionId = crypto.randomBytes(24).toString("hex");
  db.prepare(`INSERT INTO sessions (id, user_id, expires_at, created_at, last_seen_at) VALUES (?, ?, ?, ?, ?)`).run(
    teacherSessionId,
    testTeacherId,
    nowEpoch + 3600,
    nowEpoch,
    nowEpoch
  );
  const tchCookie = mergeCookies(`yu_csrf=${csrfToken}`, [`yu_session=${signTestSession(teacherSessionId)}`]);
  const tchHub = await request(port, "GET", `/api/teacher/crm/hub`, { cookie: tchCookie });
  const tchDash = await request(port, "GET", `/api/teacher/dashboard`, { cookie: tchCookie });
  const fbItem = (tchHub.json?.feedbackSummary?.items || []).find((f) => f.topic_unclear === "Kinematics Graphs");
  record(
    "Anonymous Student Feedback & Teacher Redaction",
    fbPost.status === 201 && fbAdmin.status === 200 && Boolean(fbItem) && fbItem.student_display === "Anonymous Student" && !fbItem.student_id,
    `feedbackId=${fbPost.json?.id}, fbAdmin=${fbAdmin.status}, tchHub=${tchHub.status}, body=${String(tchHub.text || "").slice(0, 140)}`
  );
  record(
    "Teacher Anti-Poaching Phone Masking Guard",
    tchHub.status === 200 && tchDash.status === 200 && tchHub.json?.phoneMaskingEnabled === true && tchDash.json?.phoneMaskingEnabled === true,
    `masking=${tchHub.json?.phoneMaskingEnabled}`
  );

  // 14. Automatic Birthday Wishing (Idempotent Once/Year) + Role-Wise Welcome Mail + Student Celebration Banner API
  const istToday = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  const todayDob = `2010-${istToday.slice(5)}`;
  const dobSave = await request(port, "POST", `/api/${adminSlug}/crm/celebrations/dob/${createdStudentId}`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: { dob: todayDob }
  });
  const celebOverview = await request(port, "GET", `/api/${adminSlug}/crm/celebrations/overview`, { cookie: adminCookie });
  const inTodayList = (celebOverview.json?.todayBirthdays || []).some((m) => Number(m.id) === Number(createdStudentId));
  const bdayWish1 = await request(port, "POST", `/api/${adminSlug}/crm/celebrations/birthday-wish/${createdStudentId}`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: {}
  });
  const bdayWish2 = await request(port, "POST", `/api/${adminSlug}/crm/celebrations/birthday-wish/${createdStudentId}`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: {}
  });
  const stuCeleb = await request(port, "GET", `/api/portal/crm/celebration-status`, { cookie: stuCookiePostRejoin });
  record(
    "Birthday Wishing (Today IST Match, Idempotent & Portal Banner)",
    dobSave.status === 200 && inTodayList && bdayWish1.status === 200 && bdayWish1.json?.wished === 1 && bdayWish2.json?.wished === 0 && bdayWish2.json?.alreadyWished === 1 && stuCeleb.status === 200 && stuCeleb.json?.isBirthdayToday === true,
    `dob=${todayDob}, wish1=${bdayWish1.json?.wished}, wish2Already=${bdayWish2.json?.alreadyWished}, banner=${stuCeleb.json?.isBirthdayToday}`
  );

  const welcomeSend = await request(port, "POST", `/api/${adminSlug}/crm/celebrations/welcome-mail/${createdStudentId}`, {
    cookie: adminCookie,
    headers: adminHdrs,
    body: {}
  });
  record(
    "Role-Wise New Joining Welcome Kit Email API",
    welcomeSend.status === 200 && welcomeSend.json?.ok === true && welcomeSend.json?.role === "student",
    `role=${welcomeSend.json?.role}, status=${welcomeSend.json?.emailStatus}`
  );

  // Clean extra synthetic teacher/feedback/exit records before summary
  if (teacherSessionId) db.prepare("DELETE FROM sessions WHERE id = ?").run(teacherSessionId);
  if (fbPost.json?.id) db.prepare("DELETE FROM crm_student_feedback WHERE id = ?").run(fbPost.json.id);
  if (stuExitId) db.prepare("DELETE FROM crm_member_exits WHERE id = ?").run(stuExitId);
  if (tempTeacherId) db.prepare("DELETE FROM users WHERE id = ?").run(tempTeacherId);

  console.log("\n=== YUITOR CRM v2.5.0 SMOKE TEST SUMMARY ===");
  for (const r of results) {
    console.log(`PASS | ${r.name} (${r.detail})`);
  }
  console.log(`ALL ${results.length}/${results.length} E2E CHECKS PASSED.`);
} catch (err) {
  console.error("SMOKE TEST FAILED:", err?.stack || err);
  process.exitCode = 1;
} finally {
  // Clean up synthetic smoke-test rows so real DB stays pristine
  try {
    if (adminSessionId) db.prepare("DELETE FROM sessions WHERE id = ?").run(adminSessionId);
    if (studentSessionId) db.prepare("DELETE FROM sessions WHERE id = ?").run(studentSessionId);
    if (createdDoubtId) db.prepare("DELETE FROM crm_doubts WHERE id = ?").run(createdDoubtId);
    if (createdExamId) db.prepare("DELETE FROM quizzes WHERE id = ?").run(createdExamId);
    if (createdSlotId) db.prepare("DELETE FROM timetable_slots WHERE id = ?").run(createdSlotId);
    if (createdStudentId) {
      db.prepare("DELETE FROM payments WHERE student_id = ?").run(createdStudentId);
      db.prepare("DELETE FROM fee_records WHERE student_id = ?").run(createdStudentId);
      db.prepare("DELETE FROM attendance WHERE student_id = ?").run(createdStudentId);
      db.prepare("DELETE FROM quiz_attempts WHERE student_id = ?").run(createdStudentId);
      db.prepare("DELETE FROM crm_member_exits WHERE user_id = ?").run(createdStudentId);
      db.prepare("DELETE FROM crm_student_feedback WHERE student_id = ?").run(createdStudentId);
      db.prepare("DELETE FROM crm_celebration_logs WHERE user_id = ?").run(createdStudentId);
      db.prepare("DELETE FROM notifications WHERE user_id = ?").run(createdStudentId);
      db.prepare("DELETE FROM crm_message_consent WHERE user_id = ?").run(createdStudentId);
      db.prepare("DELETE FROM users WHERE id = ?").run(createdStudentId);
    }
    if (createdLeadId) {
      db.prepare("DELETE FROM crm_lead_activities WHERE inquiry_id = ?").run(createdLeadId);
      db.prepare("DELETE FROM inquiries WHERE id = ?").run(createdLeadId);
    }
    if (createdStudentId) {
      db.prepare("DELETE FROM crm_attendance_alerts WHERE student_id = ?").run(createdStudentId);
    }
    db.prepare("DELETE FROM crm_exception_inbox WHERE created_at >= ?").run(testStartIso);
    db.prepare("DELETE FROM crm_job_queue WHERE created_at >= ?").run(testStartIso);
    db.prepare("DELETE FROM crm_automation_events WHERE created_at >= ?").run(testStartIso);
    db.prepare("DELETE FROM crm_daily_reports WHERE created_at >= ?").run(testStartIso);
    if (createdTempAdminId) db.prepare("DELETE FROM users WHERE id = ?").run(createdTempAdminId);
  } catch {
    // ignore cleanup errors
  }
  server.close();
  process.exit(process.exitCode || 0);
}
