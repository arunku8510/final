import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import {
  CLASS_FEE_PLANS,
  BILLING_CYCLES,
  calculateClassFeePlan,
  calculateComboDiscount,
} from "./fee-plans.mjs";
import { ensureV31Schema, computeStudentCrossSellState, getIstDateKey } from "./v31-engine.mjs";
import {
  ensureV32Schema,
  syncIndividualClassCoursesAndBatches,
  getV32Settings,
  updateV32Settings,
  validateMediaUploadBuffer,
  checkAndConsumeAiDailyQuota,
  activateStudentOnVerifiedPayment,
  runAbandonedCartReminderSweep,
  runPlanExpiryRenewalSweep,
  buildClassWiseFinanceReport,
  exportClassFinanceReport,
  buildTeacherMonthlyPayoutLog,
  buildWhatsAppTemplates,
  gradeQuickQuiz,
  createV32Certificate,
  renderQrCertificateHtml,
  generateSampleNotesPdfBuffer,
  MAX_SHREYA_UPLOAD_BYTES,
} from "./v32-engine.mjs";
import {
  addOrUpdateCartItem,
  getCartDetails,
  mergeGuestCartToUser,
} from "./cart-service.mjs";
import {
  answerFromOfficialKnowledge,
  detectClassAddToCartCta,
  captureShreyaLeadIfRelevant,
  buildShreyaSystemInstruction,
} from "./shreya-guard.mjs";

function createV32TestDb() {
  const db = new DatabaseSync(":memory:");
  db.exec(`
    CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT,
      role TEXT NOT NULL,
      password_hash TEXT DEFAULT '',
      verification_status TEXT DEFAULT 'approved',
      is_active INTEGER DEFAULT 1,
      mobile_verified INTEGER DEFAULT 1,
      referral_code TEXT DEFAULT '',
      avatar_url TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE student_profiles (
      user_id INTEGER PRIMARY KEY,
      roll_number TEXT,
      class_level TEXT,
      board TEXT DEFAULT 'CBSE',
      course_duration_months INTEGER DEFAULT 12,
      enrollment_status TEXT DEFAULT 'pending',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE teacher_profiles (
      user_id INTEGER PRIMARY KEY,
      qualification TEXT DEFAULT 'M.Sc',
      experience_years INTEGER DEFAULT 4,
      salary_monthly INTEGER DEFAULT 18000
    );
    CREATE TABLE courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE,
      category TEXT DEFAULT 'School Foundation',
      class_range TEXT DEFAULT '',
      board TEXT DEFAULT 'CBSE / UP Board',
      description TEXT DEFAULT '',
      duration_months INTEGER DEFAULT 12,
      monthly_fee INTEGER DEFAULT 800,
      yearly_fee INTEGER DEFAULT 8640,
      thumbnail_url TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      code TEXT,
      course_id INTEGER,
      branch_id INTEGER,
      teacher_id INTEGER,
      seat_limit INTEGER DEFAULT 30,
      total_seats INTEGER DEFAULT 30,
      class_name TEXT DEFAULT '',
      duration TEXT DEFAULT '12 Months',
      schedule_days TEXT DEFAULT 'Mon-Sat',
      start_time TEXT DEFAULT '04:00 PM',
      end_time TEXT DEFAULT '05:30 PM',
      start_date TEXT DEFAULT '2026-04-01',
      room_name TEXT DEFAULT 'Room 1',
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE enrollments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      course_id INTEGER NOT NULL,
      batch_id INTEGER,
      plan TEXT DEFAULT '1m',
      status TEXT DEFAULT 'pending',
      started_at TEXT,
      expires_at TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER,
      course_id INTEGER,
      enrollment_id INTEGER,
      plan TEXT DEFAULT '1m',
      base_amount INTEGER DEFAULT 0,
      discount_amount INTEGER DEFAULT 0,
      amount INTEGER DEFAULT 0,
      payment_method TEXT DEFAULT 'razorpay',
      verification_status TEXT DEFAULT 'pending',
      invoice_number TEXT,
      receipt_number TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE cart_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      guest_token TEXT,
      course_id INTEGER NOT NULL,
      batch_id INTEGER,
      plan TEXT DEFAULT '1m',
      price_snapshot INTEGER DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE coupons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      discount_type TEXT DEFAULT 'percent',
      discount_value INTEGER DEFAULT 10,
      min_amount INTEGER DEFAULT 0,
      max_discount INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      valid_from TEXT,
      valid_to TEXT,
      usage_limit INTEGER DEFAULT 0,
      used_count INTEGER DEFAULT 0
    );
    CREATE TABLE fee_installments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER,
      course_id INTEGER,
      amount INTEGER DEFAULT 0,
      paid_amount INTEGER DEFAULT 0,
      status TEXT DEFAULT 'pending',
      due_date TEXT,
      receipt_number TEXT,
      paid_at TEXT
    );
    CREATE TABLE inquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      phone TEXT,
      email TEXT,
      class_or_course TEXT,
      course_interest TEXT,
      message TEXT,
      source TEXT DEFAULT 'website',
      status TEXT DEFAULT 'new',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      body TEXT DEFAULT '',
      badge_text TEXT DEFAULT '',
      link_url TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE crm_study_materials (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER,
      title TEXT NOT NULL,
      subject_name TEXT DEFAULT 'General',
      chapter_name TEXT DEFAULT '',
      material_type TEXT DEFAULT 'notes',
      description TEXT DEFAULT '',
      file_url TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE crm_doubts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER,
      course_id INTEGER,
      subject_name TEXT,
      title TEXT,
      question_text TEXT,
      status TEXT DEFAULT 'open',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE crm_teacher_salary_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacher_id INTEGER,
      salary_month TEXT,
      base_salary INTEGER DEFAULT 0,
      bonus_amount INTEGER DEFAULT 0,
      deduction_amount INTEGER DEFAULT 0,
      net_salary INTEGER DEFAULT 0,
      status TEXT DEFAULT 'pending'
    );
    CREATE TABLE attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_id INTEGER,
      student_id INTEGER,
      attendance_date TEXT,
      status TEXT DEFAULT 'present',
      marked_by INTEGER
    );
    CREATE TABLE referrals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      referrer_user_id INTEGER,
      referred_student_id INTEGER,
      status TEXT DEFAULT 'qualified',
      reward_amount INTEGER DEFAULT 200,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE branches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      city TEXT DEFAULT 'Muradnagar',
      address TEXT DEFAULT 'Trimurti Vihar',
      phone TEXT DEFAULT '+91 78-2728-9292',
      is_active INTEGER DEFAULT 1
    );
    CREATE TABLE audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_user_id INTEGER,
      target_user_id INTEGER,
      action TEXT,
      details TEXT,
      ip_address TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);
  ensureV31Schema(db);
  ensureV32Schema(db);
  syncIndividualClassCoursesAndBatches(db);
  return db;
}

test("v3.2 Exact Class 6th-12th fee structure & 1/3/6/9/12m cycles with 10% Yearly OFF", () => {
  assert.equal(CLASS_FEE_PLANS.length, 7);
  assert.deepEqual(
    BILLING_CYCLES.map((c) => c.months),
    [1, 3, 6, 9, 12]
  );

  const expectedMonthly = { 6: 600, 7: 650, 8: 700, 9: 750, 10: 800, 11: 850, 12: 900 };
  for (const [clsStr, monthly] of Object.entries(expectedMonthly)) {
    const cls = Number(clsStr);
    const m1 = calculateClassFeePlan(cls, "1m");
    const m3 = calculateClassFeePlan(cls, "3m");
    const m6 = calculateClassFeePlan(cls, "6m");
    const m9 = calculateClassFeePlan(cls, "9m");
    const y12 = calculateClassFeePlan(cls, "yearly");

    assert.equal(m1.totalPayable, monthly);
    assert.equal(m3.totalPayable, monthly * 3);
    assert.equal(m6.totalPayable, monthly * 6);
    assert.equal(m9.totalPayable, monthly * 9);

    const gross = monthly * 12;
    const expectedSaved = Math.round(gross * 0.1);
    assert.equal(y12.subtotal, gross);
    assert.equal(y12.discountAmount, expectedSaved);
    assert.equal(y12.totalPayable, gross - expectedSaved);
  }
});

test("v3.2 Multi-Subject Combo & Sibling Discount server-side calculation", () => {
  assert.equal(calculateComboDiscount(2000, 1, { enabled: true, percent: 10, isSibling: false }).discountAmount, 0);
  const combo2 = calculateComboDiscount(2000, 2, { enabled: true, percent: 10, isSibling: false });
  assert.equal(combo2.discountAmount, 200);
  const sibling1 = calculateComboDiscount(2000, 1, { enabled: true, percent: 10, isSibling: true });
  assert.equal(sibling1.discountAmount, 200);
  const disabled = calculateComboDiscount(2000, 3, { enabled: false, percent: 10, isSibling: true });
  assert.equal(disabled.discountAmount, 0);
});

test("v3.2 Cart supports 1/3/6/9/12m, guest cart merge, combo discount, coupon & strict Master Switch cross-sell", () => {
  const db = createV32TestDb();
  const c10 = db.prepare("SELECT id FROM courses WHERE slug = 'class-10-coaching'").get();
  const c12 = db.prepare("SELECT id FROM courses WHERE slug = 'class-12-coaching'").get();
  assert.ok(c10 && c12, "Individual Class 10th and Class 12th courses must exist");

  db.prepare("INSERT INTO coupons (code, discount_type, discount_value, is_active) VALUES ('SCHOLAR100', 'flat', 100, 1)").run();

  // Guest adds 2 classes (Class 10th yearly + Class 12th 3m)
  const guestToken = "guest-tok-v32";
  addOrUpdateCartItem(db, { guestToken, courseId: c10.id, plan: "yearly" });
  addOrUpdateCartItem(db, { guestToken, courseId: c12.id, plan: "3m" });

  // Enable combo discount at 5%
  updateV32Settings(db, { comboDiscountEnabled: true, comboDiscountPercent: 5 });

  // Cross-sell Master Switch OFF -> zero cross-sell discount
  db.prepare("UPDATE v31_cross_sell_settings SET master_switch = 0 WHERE id = 1").run();
  const csOff = computeStudentCrossSellState(db, 999);
  assert.equal(csOff.eligible, false);
  assert.equal(csOff.reason, "master_switch_off");

  // Guest registers -> merge cart
  const ins = db
    .prepare("INSERT INTO users (full_name, email, phone, role, verification_status, is_active) VALUES ('Riya Verma', 'riya@example.com', '9876543210', 'student', 'pending_approval', 1)")
    .run();
  const stuId = Number(ins.lastInsertRowid);
  mergeGuestCartToUser(db, stuId, guestToken);

  // Without coupon -> automatic multi-subject combo discount applies (5% of 11340 = 567)
  const cartNoCoupon = getCartDetails(db, { userId: stuId });
  assert.equal(cartNoCoupon.count, 2);
  assert.equal(cartNoCoupon.subtotal, 8640 + 2700);
  assert.equal(cartNoCoupon.yearlySavingsTotal, 960);
  assert.equal(cartNoCoupon.comboDiscountApplied?.applied, true);
  assert.equal(cartNoCoupon.comboDiscountApplied?.discountAmount, Math.round(11340 * 0.05));
  assert.equal(cartNoCoupon.totalAmount, 11340 - cartNoCoupon.comboDiscountApplied.discountAmount);

  // With valid scholarship coupon -> server-verified coupon applies cleanly
  const cartWithCoupon = getCartDetails(db, { userId: stuId, couponCode: "SCHOLAR100" });
  assert.equal(cartWithCoupon.couponApplied?.code, "SCHOLAR100");
  assert.equal(cartWithCoupon.discountAmount, 100);
  assert.equal(cartWithCoupon.totalAmount, 11240);
});

test("v3.2 Auto-Activation on verified payment updates student, enrollment & emits receipt/batch slip", async () => {
  const db = createV32TestDb();
  const c8 = db.prepare("SELECT id FROM courses WHERE slug = 'class-8-coaching'").get();
  const b8 = db.prepare("SELECT id FROM batches WHERE course_id = ? LIMIT 1").get(c8.id);

  const stuId = Number(
    db
      .prepare("INSERT INTO users (full_name, email, phone, role, verification_status, is_active) VALUES ('Kabir Singh', 'kabir@example.com', '9811122233', 'student', 'pending_approval', 1)")
      .run().lastInsertRowid
  );
  db.prepare("INSERT INTO student_profiles (user_id, roll_number, class_level, enrollment_status) VALUES (?, 'YTR-801', 'Class 8th', 'pending')").run(stuId);

  const enrId = Number(
    db
      .prepare("INSERT INTO enrollments (student_id, course_id, batch_id, plan, status) VALUES (?, ?, ?, '6m', 'pending')")
      .run(stuId, c8.id, b8.id).lastInsertRowid
  );
  const payId = Number(
    db
      .prepare("INSERT INTO payments (student_id, course_id, enrollment_id, plan, amount, verification_status, receipt_number) VALUES (?, ?, ?, '6m', 4200, 'verified', 'REC-V32-1')")
      .run(stuId, c8.id, enrId).lastInsertRowid
  );

  const sentEmails = [];
  const res = await activateStudentOnVerifiedPayment(
    db,
    {
      sendEmailDirect: async (payload) => {
        sentEmails.push(payload);
        return { ok: true };
      },
    },
    { studentId: stuId, paymentIds: [payId], receiptNumber: "REC-V32-1", totalAmount: 4200 }
  );

  assert.equal(res.activated, true);
  assert.equal(res.batchSlips.length, 1);
  const stu = db.prepare("SELECT verification_status, is_active FROM users WHERE id = ?").get(stuId);
  assert.equal(stu.verification_status, "approved");
  assert.equal(stu.is_active, 1);
  const enr = db.prepare("SELECT status FROM enrollments WHERE id = ?").get(enrId);
  assert.equal(enr.status, "active");
  assert.equal(sentEmails.length, 1);
  assert.match(sentEmails[0].subject, /Fee Receipt/i);
});

test("v3.2 Magic-byte & 5 MB media upload validation blocks oversized, spoofed & dangerous files", () => {
  const validPng = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d]);
  const validJpg = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01]);
  const validPdf = Buffer.from("%PDF-1.4\n1 0 obj\n<<>>\nendobj\n");

  assert.equal(validateMediaUploadBuffer(validPng, "q1.png", "image/png").ok, true);
  assert.equal(validateMediaUploadBuffer(validJpg, "q2.jpg", "image/jpeg").ok, true);
  assert.equal(validateMediaUploadBuffer(validPdf, "paper.pdf", "application/pdf").ok, true);

  // Spoofed executable disguised as .jpg
  const fakeJpg = Buffer.from("<?php system($_GET['c']); ?>");
  assert.equal(validateMediaUploadBuffer(fakeJpg, "shell.jpg", "image/jpeg").ok, false);

  // Double extension blocked
  assert.equal(validateMediaUploadBuffer(validJpg, "payload.php.jpg", "image/jpeg").ok, false);

  // SVG blocked
  assert.equal(validateMediaUploadBuffer(Buffer.from("<svg onload=alert(1)>"), "x.svg", "image/svg+xml").ok, false);

  // Strictly > 5 MB rejected
  const oversized = Buffer.alloc(MAX_SHREYA_UPLOAD_BYTES + 10, 0xff);
  oversized[0] = 0xff;
  oversized[1] = 0xd8;
  oversized[2] = 0xff;
  assert.equal(validateMediaUploadBuffer(oversized, "big.jpg", "image/jpeg").ok, false);
});

test("v3.2 Shreya AI daily quota (Guest 5q/2u vs Active Student configurable), short prompt & lead capture", () => {
  const db = createV32TestDb();
  const vKey = "guest-ip-1";

  // Guest allowed 5 questions, 6th blocked
  for (let i = 0; i < 5; i++) {
    const q = checkAndConsumeAiDailyQuota(db, { visitorKey: vKey, isUpload: false });
    assert.equal(q.allowed, true);
  }
  const q6 = checkAndConsumeAiDailyQuota(db, { visitorKey: vKey, isUpload: false });
  assert.equal(q6.allowed, false);

  // Guest upload quota: max 2/day
  const vKey2 = "guest-ip-2";
  assert.equal(checkAndConsumeAiDailyQuota(db, { visitorKey: vKey2, isUpload: true }).allowed, true);
  assert.equal(checkAndConsumeAiDailyQuota(db, { visitorKey: vKey2, isUpload: true }).allowed, true);
  assert.equal(checkAndConsumeAiDailyQuota(db, { visitorKey: vKey2, isUpload: true }).allowed, false);

  // Strict short & same-language prompt check + Class 10th fees & CTA
  const sysPrompt = buildShreyaSystemInstruction("Knowledge", "", {});
  assert.match(sysPrompt, /SHORT.*PRECISE|SHORT/i);
  assert.match(sysPrompt, /SAME LANGUAGE/i);

  const cta = detectClassAddToCartCta("Class 10th ki monthly fees kitni hai?", db);
  assert.ok(cta && cta.classNumber === 10 && cta.monthlyFee === 800);

  const ans = answerFromOfficialKnowledge("Class 10th fees kitni hai?", [], db);
  assert.ok(ans && /800/.test(ans.reply), "Shreya must return exact Class 10th ₹800/month fee");

  const lead = captureShreyaLeadIfRelevant(db, {
    conversationId: "conv-101",
    message: "Class 10th admission fees? Mera number 9876501234 hai",
    classNumber: 10,
  });
  assert.equal(lead?.created, true);
  // Deduplicated on same conversation (updates instead of duplicating row)
  const lead2 = captureShreyaLeadIfRelevant(db, {
    conversationId: "conv-101",
    message: "Class 10th fees?",
    classNumber: 10,
  });
  assert.equal(lead2?.updated, true);
  assert.equal(db.prepare("SELECT COUNT(*) AS c FROM inquiries").get().c, 1);
});

test("v3.2 Abandoned cart & 7d/2d plan expiry renewal reminders are duplicate-protected", async () => {
  const db = createV32TestDb();
  const c9 = db.prepare("SELECT id FROM courses WHERE slug = 'class-9-coaching'").get();
  const stuId = Number(
    db
      .prepare("INSERT INTO users (full_name, email, phone, role, verification_status, is_active) VALUES ('Meera Nair', 'meera@example.com', '9800001122', 'student', 'approved', 1)")
      .run().lastInsertRowid
  );

  // Create cart item older than 2 hours
  const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
  db.prepare("INSERT INTO cart_items (user_id, course_id, plan, price_snapshot, created_at, updated_at) VALUES (?, ?, '3m', 2250, ?, ?)").run(
    stuId,
    c9.id,
    twoHoursAgo,
    twoHoursAgo
  );

  let mails = 0;
  const fakeDeps = { sendEmail: async () => { mails++; return { ok: true }; } };

  const firstCartSweep = await runAbandonedCartReminderSweep(db, fakeDeps, { minAgeMinutes: 60 });
  assert.equal(firstCartSweep.sent, 1);
  const secondCartSweep = await runAbandonedCartReminderSweep(db, fakeDeps, { minAgeMinutes: 60 });
  assert.equal(secondCartSweep.sent, 0, "Duplicate abandoned cart reminder must be suppressed");

  // Enrollment expiring in exactly 7 IST days
  const in7Days = getIstDateKey(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000));
  db.prepare("INSERT INTO enrollments (student_id, course_id, plan, status, expires_at) VALUES (?, ?, '1m', 'active', ?)").run(
    stuId,
    c9.id,
    in7Days
  );

  const r1 = await runPlanExpiryRenewalSweep(db, fakeDeps);
  assert.equal(r1.sent, 1);
  const r2 = await runPlanExpiryRenewalSweep(db, fakeDeps);
  assert.equal(r2.sent, 0, "Duplicate 7-day renewal reminder must be suppressed");
});

test("v3.2 Finance report, formula-safe CSV export, Teacher payout log, WhatsApp templates, Quick Quiz & QR Certs", () => {
  const db = createV32TestDb();
  const report = buildClassWiseFinanceReport(db);
  assert.equal(report.rows.length, 7);

  const exported = exportClassFinanceReport(db, "csv");
  assert.match(exported.body, /Class 6th/);
  assert.match(exported.body, /Class 12th/);

  // Quick quiz grading (5 questions)
  const quizRes = gradeQuickQuiz(10, [0, 1, 2, 3, 0]);
  assert.equal(quizRes.total, 5);
  assert.equal(quizRes.monthlyFee, 800);

  // WhatsApp templates
  const templates = buildWhatsAppTemplates({ studentName: "Rohan", className: "Class 10th", amountDue: 800 });
  assert.equal(templates.length, 4);
  assert.ok(templates.some((t) => t.id === "fee_reminder" && t.text.includes("800")));

  // Sample PDF buffer has valid %PDF header
  const pdfBuf = generateSampleNotesPdfBuffer(10);
  assert.equal(pdfBuf.subarray(0, 4).toString("utf8"), "%PDF");

  // QR-Verified Certificate creation + HTML rendering
  const cert = createV32Certificate(db, {
    studentName: "Ananya Verma",
    classLabel: "Class 10th",
    certType: "topper",
    rankOrScore: "Rank 1 · 98%",
  });
  assert.match(cert.certificate_code, /^YTR-CERT-/);
  const html = renderQrCertificateHtml(cert, { baseUrl: "https://yuitor.com" });
  assert.match(html, /Ananya Verma/);
  assert.match(html, /<svg/i, "Printable QR certificate must include embedded QR SVG");

  // Teacher payout log runs cleanly
  const payouts = buildTeacherMonthlyPayoutLog(db);
  assert.ok(Array.isArray(payouts));
});
