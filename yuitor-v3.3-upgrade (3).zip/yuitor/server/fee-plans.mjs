// Canonical Class-Wise Fee Structure & Billing Cycles — Yuitor Smart Classes v3.2
// Single source of truth shared across backend routes, cart, invoices, AI assistant, and unit tests.

export const BILLING_CYCLES = [
  { id: "1m", label: "1 Month", shortLabel: "1m", months: 1, discountPercent: 0 },
  { id: "3m", label: "3 Months", shortLabel: "3m", months: 3, discountPercent: 0 },
  { id: "6m", label: "6 Months", shortLabel: "6m", months: 6, discountPercent: 0 },
  { id: "9m", label: "9 Months", shortLabel: "9m", months: 9, discountPercent: 0 },
  { id: "yearly", label: "12 Months (Yearly · 10% OFF)", shortLabel: "12m (10% OFF)", months: 12, discountPercent: 10 },
];

export const CLASS_FEE_PLANS = [
  { classNumber: 6, classLabel: "Class 6th", slug: "class-6", monthly: 600, m1: 600, m3: 1800, m6: 3600, m9: 5400, yearlyGross: 7200, yearlySavings: 720, yearlyTotal: 6480 },
  { classNumber: 7, classLabel: "Class 7th", slug: "class-7", monthly: 650, m1: 650, m3: 1950, m6: 3900, m9: 5850, yearlyGross: 7800, yearlySavings: 780, yearlyTotal: 7020 },
  { classNumber: 8, classLabel: "Class 8th", slug: "class-8", monthly: 700, m1: 700, m3: 2100, m6: 4200, m9: 6300, yearlyGross: 8400, yearlySavings: 840, yearlyTotal: 7560 },
  { classNumber: 9, classLabel: "Class 9th", slug: "class-9", monthly: 750, m1: 750, m3: 2250, m6: 4500, m9: 6750, yearlyGross: 9000, yearlySavings: 900, yearlyTotal: 8100 },
  { classNumber: 10, classLabel: "Class 10th", slug: "class-10", monthly: 800, m1: 800, m3: 2400, m6: 4800, m9: 7200, yearlyGross: 9600, yearlySavings: 960, yearlyTotal: 8640 },
  { classNumber: 11, classLabel: "Class 11th", slug: "class-11", monthly: 850, m1: 850, m3: 2550, m6: 5100, m9: 7650, yearlyGross: 10200, yearlySavings: 1020, yearlyTotal: 9180 },
  { classNumber: 12, classLabel: "Class 12th", slug: "class-12", monthly: 900, m1: 900, m3: 2700, m6: 5400, m9: 8100, yearlyGross: 10800, yearlySavings: 1080, yearlyTotal: 9720 },
];

export const INDIVIDUAL_CLASS_LABELS = CLASS_FEE_PLANS.map((p) => p.classLabel);

export function parseClassNumberFromLabel(raw) {
  if (typeof raw === "number" && Number.isFinite(raw)) {
    const n = Math.round(raw);
    return n >= 6 && n <= 12 ? n : null;
  }
  const s = String(raw || "").trim();
  if (!s) return null;
  const match = s.match(/\b(1[0-2]|[6-9])(?:th)?\b/i);
  if (match) {
    const n = Number(match[1]);
    if (n >= 6 && n <= 12) return n;
  }
  return null;
}

export function normalizeBillingCycle(raw) {
  const s = String(raw || "1m").trim().toLowerCase();
  if (s === "1m" || s === "1" || s === "monthly" || s === "1 month") return "1m";
  if (s === "3m" || s === "3" || s === "quarterly" || s === "3 months") return "3m";
  if (s === "6m" || s === "6" || s === "half-yearly" || s === "6 months") return "6m";
  if (s === "9m" || s === "9" || s === "9 months") return "9m";
  if (s === "yearly" || s === "12m" || s === "12" || s === "annual" || s === "lump-sum" || s === "12 months") return "yearly";
  return "1m";
}

export function getBillingCycleMeta(cycleInput = "1m") {
  const cycleId = normalizeBillingCycle(cycleInput);
  return BILLING_CYCLES.find((c) => c.id === cycleId) || BILLING_CYCLES[0];
}

export function getClassFeePlan(classInput) {
  const parsed = parseClassNumberFromLabel(classInput);
  if (parsed === null) return null;
  return CLASS_FEE_PLANS.find((p) => p.classNumber === parsed) || null;
}

export function calculateClassFeePlan(classInput, cycleInput = "1m") {
  const parsed = parseClassNumberFromLabel(classInput);
  const classNumber = parsed ?? 10;
  const plan = CLASS_FEE_PLANS.find((p) => p.classNumber === classNumber) || CLASS_FEE_PLANS[4];
  const cycleMeta = getBillingCycleMeta(cycleInput);

  const subtotal = plan.monthly * cycleMeta.months;
  const discountAmount = cycleMeta.discountPercent > 0 ? Math.round((subtotal * cycleMeta.discountPercent) / 100) : 0;
  const totalPayable = subtotal - discountAmount;

  return {
    classNumber: plan.classNumber,
    classLabel: plan.classLabel,
    cycle: cycleMeta.id,
    cycleLabel: cycleMeta.label,
    months: cycleMeta.months,
    monthlyRate: plan.monthly,
    subtotal,
    discountPercent: cycleMeta.discountPercent,
    discountAmount,
    savings: discountAmount,
    totalPayable,
  };
}

/**
 * Server-side pricing calculator for ANY course (Class 6th–12th or Competitive/Skill) across 1/3/6/9/12m.
 * For Class 6th–12th courses, canonical monthly rate is enforced from CLASS_FEE_PLANS.
 */
export function calculateCourseCyclePrice(course, cycleInput = "1m") {
  const cycleMeta = getBillingCycleMeta(cycleInput);
  const detectedClass =
    parseClassNumberFromLabel(course?.class_range) ??
    parseClassNumberFromLabel(course?.title) ??
    parseClassNumberFromLabel(course?.slug);

  const isIndividualSchoolClass =
    detectedClass !== null &&
    !/neet|jee|cuet|nda|ssc|banking|coding|computer|spoken/i.test(String(course?.title || "")) &&
    !/\d+\s*[-–]\s*\d+/.test(String(course?.class_range || ""));

  const canonical = isIndividualSchoolClass ? getClassFeePlan(detectedClass) : null;
  const monthlyRate = canonical ? canonical.monthly : Math.max(0, Number(course?.monthly_fee || 0));

  const grossSubtotal = monthlyRate * cycleMeta.months;
  let yearlySavings = 0;
  let finalPrice = grossSubtotal;

  if (cycleMeta.id === "yearly") {
    yearlySavings = Math.round((grossSubtotal * cycleMeta.discountPercent) / 100);
    finalPrice = grossSubtotal - yearlySavings;
  }

  const payable = Math.max(0, finalPrice);
  return {
    cycle: cycleMeta.id,
    cycleLabel: cycleMeta.label,
    label: cycleMeta.label,
    months: cycleMeta.months,
    monthlyRate,
    grossSubtotal,
    grossTotal: grossSubtotal,
    yearlyDiscountPercent: cycleMeta.discountPercent,
    yearlySavings,
    finalPrice: payable,
    totalPayable: payable,
    classNumber: canonical ? canonical.classNumber : null,
  };
}

/**
 * Pure server-side Multi-Subject Combo / Sibling Discount calculator.
 */
export function calculateComboDiscount(subtotal, itemCount, { enabled = false, percent = 10, isSibling = false } = {}) {
  const cleanSubtotal = Math.max(0, Number(subtotal || 0));
  const cleanCount = Math.max(0, Number(itemCount || 0));
  const cleanPercent = Math.min(50, Math.max(0, Number(percent || 0)));
  if (!enabled || cleanSubtotal <= 0 || cleanPercent <= 0) {
    return { applied: false, discountPercent: 0, discountAmount: 0, reason: "" };
  }
  if (cleanCount >= 2 || isSibling) {
    const discountAmount = Math.round((cleanSubtotal * cleanPercent) / 100);
    return {
      applied: discountAmount > 0,
      discountPercent: cleanPercent,
      discountAmount,
      reason: isSibling && cleanCount < 2 ? "Sibling Discount" : `Multi-Subject Combo (${cleanCount} courses)`,
    };
  }
  return { applied: false, discountPercent: 0, discountAmount: 0, reason: "" };
}
