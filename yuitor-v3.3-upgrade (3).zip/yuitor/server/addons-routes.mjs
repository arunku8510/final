import crypto from "node:crypto";
import { Router } from "express";
import {
  getActiveMilestones,
  getAllMilestones,
  getReferralSettings,
  nowIso,
  runInImmediateTx
} from "./addons-db.mjs";
import {
  addOrUpdateCartItem,
  clearCart,
  createCartCheckoutBatch,
  getCartDetails,
  removeCartItem,
  updateCartItemPlanOrBatch
} from "./cart-service.mjs";
import {
  getAdminSearchPreferences,
  searchAdminWorkspace,
  updateAdminSearchPreferences
} from "./global-search.mjs";
import {
  getActiveCampaignsForRole,
  getReferralAnalyticsReport,
  getUserReferralDashboard,
  recomputeReferralForStudent
} from "./referral-engine.mjs";
import { buildSpreadsheetXml, rowsToCsv } from "./referral-math.mjs";
import {
  creditWalletImmutable,
  debitWalletImmutable,
  getWalletDashboardData,
  requestWithdrawal,
  transitionWithdrawalStatus
} from "./wallet-service.mjs";

const GUEST_CART_COOKIE = "ytr_cart_id";

function getOrCreateGuestToken(req, res) {
  const existing = String(req.cookies?.[GUEST_CART_COOKIE] || "").trim();
  if (/^[a-zA-Z0-9_-]{12,64}$/.test(existing)) return existing;
  const fresh = crypto.randomBytes(16).toString("hex");
  const isHttps = Boolean(req.secure || (req.app?.get("trust proxy") && String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim() === "https"));
  res.cookie(GUEST_CART_COOKIE, fresh, {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: 30 * 24 * 60 * 60 * 1000
  });
  return fresh;
}

export function createAddonsUserRouter(db, deps) {
  const router = Router();
  const {
    getSessionContext,
    writeAuditLog,
    clientIp,
    validateBatchCapacity,
    verifyRazorpaySignature,
    SETTING_DEFINITIONS
  } = deps;

  // Public Referral Rules & Active Milestones (for landing / registration badge / T&C)
  router.get("/public/referral-config", (_req, res) => {
    const settings = getReferralSettings(db);
    const milestones = getActiveMilestones(db);
    const campaigns = getActiveCampaignsForRole(db, "all");
    res.json({
      referralsEnabled: Number(settings.referrals_enabled) === 1,
      requiredFeeMonths: Number(settings.required_fee_months || 3),
      minWithdrawalAmount: Number(settings.min_withdrawal_amount || 200),
      termsAndConditions: settings.terms_and_conditions || "",
      milestones,
      campaigns
    });
  });

  router.get("/public/referral-code/:code", (req, res) => {
    const code = String(req.params.code || "").trim().toUpperCase();
    const row = db
      .prepare(
        `SELECT rp.referral_code, rp.role, u.full_name
         FROM referral_profiles rp
         JOIN users u ON u.id = rp.user_id
         WHERE UPPER(rp.referral_code) = ? AND u.is_active = 1
         LIMIT 1`
      )
      .get(code);
    if (!row) {
      res.status(404).json({ valid: false, error: "Referral code not found." });
      return;
    }
    res.json({ valid: true, code: row.referral_code, referrerName: row.full_name, referrerRole: row.role });
  });

  // Shopping Cart API (works for guests & logged-in students seamlessly)
  router.get("/cart", (req, res) => {
    const ctx = getSessionContext(db, req);
    const userId = ctx?.user?.id || null;
    const guestToken = String(req.cookies?.[GUEST_CART_COOKIE] || "");
    const couponCode = String(req.query?.coupon || "");
    const isSibling = String(req.query?.sibling || "") === "1" || String(req.query?.sibling || "") === "true";
    const details = getCartDetails(db, { userId, guestToken, couponCode, isSibling });
    res.json(details);
  });

  router.post("/cart/items", (req, res) => {
    const ctx = getSessionContext(db, req);
    const userId = ctx?.user?.id || null;
    const guestToken = userId ? String(req.cookies?.[GUEST_CART_COOKIE] || "") : getOrCreateGuestToken(req, res);
    try {
      const added = addOrUpdateCartItem(db, {
        userId,
        guestToken,
        courseId: req.body?.courseId,
        plan: req.body?.plan || "1m",
        batchId: req.body?.batchId || null,
        subjectLabel: req.body?.subjectLabel || ""
      });
      const cart = getCartDetails(db, {
        userId,
        guestToken,
        couponCode: String(req.body?.couponCode || ""),
        isSibling: Boolean(req.body?.isSibling)
      });
      res.status(201).json({ ...added, cart });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Unable to add course to cart." });
    }
  });

  router.patch("/cart/items/:id", (req, res) => {
    const ctx = getSessionContext(db, req);
    const userId = ctx?.user?.id || null;
    const guestToken = String(req.cookies?.[GUEST_CART_COOKIE] || "");
    try {
      updateCartItemPlanOrBatch(db, {
        userId,
        guestToken,
        itemId: req.params.id,
        plan: req.body?.plan,
        batchId: req.body?.batchId
      });
      const cart = getCartDetails(db, {
        userId,
        guestToken,
        couponCode: req.body?.couponCode || "",
        isSibling: Boolean(req.body?.isSibling)
      });
      res.json({ updated: true, cart });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Unable to update cart item." });
    }
  });

  router.delete("/cart/items/:id", (req, res) => {
    const ctx = getSessionContext(db, req);
    const userId = ctx?.user?.id || null;
    const guestToken = String(req.cookies?.[GUEST_CART_COOKIE] || "");
    try {
      removeCartItem(db, { userId, guestToken, itemId: req.params.id });
      const cart = getCartDetails(db, { userId, guestToken });
      res.json({ deleted: true, cart });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Unable to remove item." });
    }
  });

  router.post("/cart/clear", (req, res) => {
    const ctx = getSessionContext(db, req);
    const userId = ctx?.user?.id || null;
    const guestToken = String(req.cookies?.[GUEST_CART_COOKIE] || "");
    clearCart(db, { userId, guestToken });
    res.json({ cleared: true, cart: { items: [], count: 0, subtotal: 0, discountAmount: 0, totalAmount: 0 } });
  });

  router.post("/cart/checkout/create-order", async (req, res) => {
    const ctx = getSessionContext(db, req);
    const blocked = new Set(["suspended", "terminated", "deleted", "rejected"]);
    if (!ctx || ctx.user.role !== "student" || blocked.has(String(ctx.user.verification_status || "").toLowerCase())) {
      res.status(403).json({ error: "Student sign-in (or Quick Register inside Cart) is required to pay via Gateway." });
      return;
    }
    const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
    const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
    if (!keyId || !keySecret) {
      res.status(503).json({ error: "Razorpay credentials are not configured on the server yet." });
      return;
    }
    const guestToken = String(req.cookies?.[GUEST_CART_COOKIE] || "");
    const cart = getCartDetails(db, {
      userId: ctx.user.id,
      guestToken,
      couponCode: String(req.body?.couponCode || ""),
      isSibling: Boolean(req.body?.isSibling)
    });
    if (cart.items.length === 0) {
      res.status(400).json({ error: "Your cart is empty." });
      return;
    }
    if (cart.couponError) {
      res.status(400).json({ error: cart.couponError });
      return;
    }
    const finalAmt = Math.max(1, cart.totalAmount);
    try {
      const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
      const resp = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: finalAmt * 100,
          currency: "INR",
          receipt: `ytr_cart_${ctx.user.id}_${Date.now()}`.slice(0, 40),
          notes: { studentId: String(ctx.user.id), itemCount: String(cart.items.length), checkoutType: "cart" }
        }),
        signal: AbortSignal.timeout(12e3)
      });
      const order = await resp.json();
      if (!resp.ok || !order?.id) {
        res.status(502).json({ error: order?.error?.description || "Unable to create Razorpay order." });
        return;
      }
      db.prepare(
        `INSERT OR REPLACE INTO cart_gateway_orders (gateway_order_id, student_id, expected_amount, coupon_code, status, created_at)
         VALUES (?, ?, ?, ?, 'created', ?)`
      ).run(order.id, ctx.user.id, finalAmt, String(req.body?.couponCode || "").trim().toUpperCase(), new Date().toISOString());
      res.json({ orderId: order.id, amount: order.amount, currency: order.currency, keyId, cart });
    } catch (err) {
      res.status(502).json({ error: err?.message || "Razorpay order creation failed." });
    }
  });

  router.post("/cart/checkout/complete", async (req, res) => {
    const ctx = getSessionContext(db, req);
    const blocked = new Set(["suspended", "terminated", "deleted", "rejected"]);
    if (!ctx || ctx.user.role !== "student" || blocked.has(String(ctx.user.verification_status || "").toLowerCase())) {
      res.status(403).json({ error: "Student sign-in (or Quick Register inside Cart) is required to complete checkout." });
      return;
    }
    const guestToken = String(req.cookies?.[GUEST_CART_COOKIE] || "");
    const couponCode = String(req.body?.couponCode || "");
    const isSibling = Boolean(req.body?.isSibling);
    const paymentMethod = ["upi", "cash", "gateway"].includes(req.body?.paymentMethod) ? req.body.paymentMethod : "upi";
    const utrReference = String(req.body?.utrReference || "").trim().slice(0, 80);
    const gOrder = String(req.body?.gatewayOrderId || "").trim().slice(0, 100);
    const gPay = String(req.body?.gatewayPaymentId || "").trim().slice(0, 100);
    const gSig = String(req.body?.gatewaySignature || "").trim().slice(0, 200);

    const cart = getCartDetails(db, { userId: ctx.user.id, guestToken, couponCode, isSibling });
    if (cart.couponError) {
      res.status(400).json({ error: cart.couponError });
      return;
    }

    let isGatewayVerified = false;
    if (paymentMethod === "gateway") {
      const rzpSecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
      if (rzpSecret && (gOrder || gPay || gSig)) {
        if (!gOrder || !gPay || !gSig || !verifyRazorpaySignature(gOrder, gPay, gSig, rzpSecret)) {
          res.status(400).json({ error: "Payment gateway signature verification failed." });
          return;
        }
        const dupPay = db.prepare("SELECT id FROM payments WHERE gateway_payment_id = ? LIMIT 1").get(gPay);
        if (dupPay) {
          res.status(409).json({ error: "This Razorpay payment has already been processed." });
          return;
        }
        const serverOrder = db
          .prepare("SELECT * FROM cart_gateway_orders WHERE gateway_order_id = ? AND student_id = ? LIMIT 1")
          .get(gOrder, ctx.user.id);
        if (!serverOrder) {
          res.status(400).json({ error: "Gateway order ID does not match a server-created cart order for this student." });
          return;
        }
        if (serverOrder.status === "verified") {
          res.status(409).json({ error: "This cart order has already been completed." });
          return;
        }
        if (Number(serverOrder.expected_amount) !== Number(cart.totalAmount)) {
          res.status(400).json({ error: "Cart total changed since order creation. Please create a fresh payment order." });
          return;
        }
        db.prepare(
          "UPDATE cart_gateway_orders SET status = 'verified', gateway_payment_id = ?, completed_at = ? WHERE gateway_order_id = ?"
        ).run(gPay, new Date().toISOString(), gOrder);
        isGatewayVerified = true;
      }
    }

    try {
      const outcome = createCartCheckoutBatch({
        db,
        student: ctx.user,
        cart,
        paymentMethod,
        utrReference,
        gatewayOrderId: gOrder,
        gatewayPaymentId: gPay,
        gatewaySignature: gSig,
        isGatewayVerified,
        validateBatchCapacityFn: validateBatchCapacity,
        writeAuditLogFn: writeAuditLog,
        ipAddress: clientIp(req)
      });

      let activation = null;
      if (outcome.verificationStatus === "verified") {
        const { activateStudentOnVerifiedPayment } = await import("./v32-engine.mjs");
        activation = await activateStudentOnVerifiedPayment(db, deps, {
          studentId: ctx.user.id,
          paymentIds: outcome.createdPaymentIds,
          orderCode: outcome.orderCode,
          receiptNumber: outcome.receiptNumber,
          totalAmount: outcome.totalAmount,
          courseTitles: outcome.courseTitles || []
        });
        await recomputeReferralForStudent(
          db,
          ctx.user.id,
          { eventType: "payment_verified", paymentId: outcome.createdPaymentIds[0], note: `Cart order ${outcome.orderCode} verified` },
          deps
        );
      }

      res.status(201).json({
        checkedOut: true,
        ...outcome,
        accountActivated: Boolean(activation?.activated),
        batchSlips: activation?.batchSlips || [],
        receiptSlipUrl: outcome.createdPaymentIds?.[0] ? `/api/student/receipt-slip/${outcome.createdPaymentIds[0]}` : "",
        message:
          outcome.verificationStatus === "verified"
            ? `Order ${outcome.orderCode} verified! Your Student Account & ${outcome.itemCount} course(s) are now ACTIVE. Official Receipt & Batch Slip issued.`
            : `Order ${outcome.orderCode} submitted for ${outcome.itemCount} course(s). Pending Admin fee verification (auto-activates immediately upon approval).`
      });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Cart checkout failed." });
    }
  });

  // Authenticated Student & Teacher Referral + Wallet Endpoints
  const requireStudentOrTeacher = (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || (ctx.user.role !== "student" && ctx.user.role !== "teacher")) {
      res.status(403).json({ error: "Student or Teacher authentication required." });
      return null;
    }
    if (ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Account verification/approval required." });
      return null;
    }
    return ctx;
  };

  router.get("/referrals/me", (req, res) => {
    const ctx = requireStudentOrTeacher(req, res);
    if (!ctx) return;
    const data = getUserReferralDashboard(db, ctx.user.id, ctx.user.role);
    res.json(data);
  });

  router.get("/wallet/me", (req, res) => {
    const ctx = requireStudentOrTeacher(req, res);
    if (!ctx) return;
    const data = getWalletDashboardData(db, ctx.user.id, ctx.user.role, {
      txType: req.query?.txType || "",
      status: req.query?.status || "",
      search: req.query?.search || "",
      limit: req.query?.limit || 50,
      offset: req.query?.offset || 0
    });
    res.json(data);
  });

  router.post("/wallet/withdraw", async (req, res) => {
    const ctx = requireStudentOrTeacher(req, res);
    if (!ctx) return;
    try {
      const result = requestWithdrawal(db, {
        userId: ctx.user.id,
        userRole: ctx.user.role,
        amount: req.body?.amount,
        payoutMethod: req.body?.payoutMethod,
        upiId: req.body?.upiId,
        accountHolderName: req.body?.accountHolderName,
        bankName: req.body?.bankName,
        accountNumber: req.body?.accountNumber,
        ifscCode: req.body?.ifscCode
      });
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: result.request.id,
        targetName: result.request.request_code,
        action: "withdrawal_requested",
        details: `₹${result.request.amount} via ${result.request.payout_method.toUpperCase()} (${result.request.status})`,
        ipAddress: clientIp(req)
      });
      db.prepare(
        "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
      ).run(
        `New Wallet Withdrawal Request (${result.request.request_code})`,
        `${ctx.user.full_name} (${ctx.user.role}) requested ₹${result.request.amount} via ${result.request.payout_method.toUpperCase()}.`,
        nowIso()
      );
      res.status(201).json({ requested: true, ...result });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Withdrawal request failed." });
    }
  });

  // Expose safe setting definitions lookup if needed by admin search
  router.get("/public/referral-ping", (_req, res) => {
    res.json({ ok: true, defsCount: Array.isArray(SETTING_DEFINITIONS) ? SETTING_DEFINITIONS.length : 0 });
  });

  return router;
}

export function createAddonsAdminRouter(db, deps) {
  const router = Router();
  const { getSessionContext, writeAuditLog, clientIp, SETTING_DEFINITIONS } = deps;

  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || (ctx.user.role !== "admin" && ctx.user.role !== "super_admin")) {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    req.ctx = ctx;
    next();
  });

  // Admin Referral Overview, Milestones, Campaigns, Rules & 3-Month Progress Table
  router.get("/referrals", (req, res) => {
    const status = String(req.query?.status || "all");
    const role = String(req.query?.role || "all");
    const search = String(req.query?.search || "").trim();

    const where = ["1=1"];
    const params = [];
    if (status && status !== "all") {
      where.push("r.status = ?");
      params.push(status);
    }
    if (role === "student" || role === "teacher") {
      where.push("r.referrer_role = ?");
      params.push(role);
    }
    if (search) {
      const q = `%${search}%`;
      where.push("(r.referral_code_used LIKE ? OR u1.full_name LIKE ? OR u2.full_name LIKE ? OR u2.phone LIKE ?)");
      params.push(q, q, q, q);
    }

    const referrals = db
      .prepare(
        `SELECT r.*,
                u1.full_name AS referrer_name, u1.email AS referrer_email, u1.phone AS referrer_phone,
                u2.full_name AS referred_name, u2.email AS referred_email, u2.phone AS referred_phone,
                u2.verification_status AS referred_account_status
         FROM referrals r
         JOIN users u1 ON u1.id = r.referrer_user_id
         JOIN users u2 ON u2.id = r.referred_user_id
         WHERE ${where.join(" AND ")}
         ORDER BY r.id DESC
         LIMIT 250`
      )
      .all(...params);

    const settings = getReferralSettings(db);
    const milestones = getAllMilestones(db);
    const campaigns = db.prepare("SELECT * FROM referral_campaigns ORDER BY id DESC").all();

    res.json({ settings, milestones, campaigns, referrals });
  });

  router.put("/referral-settings", (req, res) => {
    const b = req.body || {};
    const now = nowIso();
    const cur = getReferralSettings(db);
    const requiredMonths = Math.min(24, Math.max(1, Number(b.required_fee_months ?? cur.required_fee_months)));
    const yearlyCredits = Math.min(12, Math.max(1, Number(b.yearly_plan_months_credit ?? cur.yearly_plan_months_credit)));
    const minWdr = Math.max(1, Number(b.min_withdrawal_amount ?? cur.min_withdrawal_amount));
    const maxWdr = Math.max(minWdr, Number(b.max_withdrawal_amount ?? cur.max_withdrawal_amount));

    db.prepare(
      `UPDATE referral_settings SET
         referrals_enabled = ?,
         allow_student_referrals = ?,
         allow_teacher_referrals = ?,
         allow_self_referral = ?,
         required_fee_months = ?,
         yearly_plan_months_credit = ?,
         min_withdrawal_amount = ?,
         max_withdrawal_amount = ?,
         require_admin_approval = ?,
         prevent_duplicate_withdrawals = ?,
         notify_in_app = ?,
         notify_email = ?,
         notify_sms = ?,
         notify_whatsapp = ?,
         terms_and_conditions = ?,
         updated_at = ?,
         updated_by = ?
       WHERE id = 1`
    ).run(
      b.referrals_enabled !== undefined ? (b.referrals_enabled ? 1 : 0) : cur.referrals_enabled,
      b.allow_student_referrals !== undefined ? (b.allow_student_referrals ? 1 : 0) : cur.allow_student_referrals,
      b.allow_teacher_referrals !== undefined ? (b.allow_teacher_referrals ? 1 : 0) : cur.allow_teacher_referrals,
      b.allow_self_referral !== undefined ? (b.allow_self_referral ? 1 : 0) : cur.allow_self_referral,
      requiredMonths,
      yearlyCredits,
      minWdr,
      maxWdr,
      b.require_admin_approval !== undefined ? (b.require_admin_approval ? 1 : 0) : cur.require_admin_approval,
      b.prevent_duplicate_withdrawals !== undefined ? (b.prevent_duplicate_withdrawals ? 1 : 0) : cur.prevent_duplicate_withdrawals,
      b.notify_in_app !== undefined ? (b.notify_in_app ? 1 : 0) : cur.notify_in_app,
      b.notify_email !== undefined ? (b.notify_email ? 1 : 0) : cur.notify_email,
      b.notify_sms !== undefined ? (b.notify_sms ? 1 : 0) : cur.notify_sms,
      b.notify_whatsapp !== undefined ? (b.notify_whatsapp ? 1 : 0) : cur.notify_whatsapp,
      String(b.terms_and_conditions ?? cur.terms_and_conditions).slice(0, 6000),
      now,
      req.ctx.user.id
    );

    writeAuditLog(db, {
      actorId: req.ctx.user.id,
      actorName: req.ctx.user.full_name,
      targetId: 1,
      targetName: "referral_settings",
      action: "referral_settings_updated",
      details: `Months=${requiredMonths}, MinWdr=₹${minWdr}, Approval=${b.require_admin_approval ?? cur.require_admin_approval}`,
      ipAddress: clientIp(req)
    });

    res.json({ updated: true, settings: getReferralSettings(db) });
  });

  router.post("/referral-milestones", (req, res) => {
    const qCount = Math.max(1, Math.floor(Number(req.body?.qualifiedCount || 0)));
    const reward = Math.max(0, Math.round(Number(req.body?.cumulativeReward || 0)));
    const title = String(req.body?.title || `Milestone ${qCount}`).trim().slice(0, 80);
    const badge = String(req.body?.badgeLabel || `${qCount} Referrals`).trim().slice(0, 40);
    const now = nowIso();
    try {
      db.prepare(
        `INSERT INTO referral_milestones (qualified_count, cumulative_reward, title, badge_label, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, 1, ?, ?)
         ON CONFLICT(qualified_count) DO UPDATE SET
           cumulative_reward = excluded.cumulative_reward,
           title = excluded.title,
           badge_label = excluded.badge_label,
           is_active = 1,
           updated_at = excluded.updated_at`
      ).run(qCount, reward, title, badge, now, now);
      res.status(201).json({ saved: true, milestones: getAllMilestones(db) });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Failed to save milestone." });
    }
  });

  router.put("/referral-milestones/:id", (req, res) => {
    const id = Number(req.params.id);
    const cur = db.prepare("SELECT * FROM referral_milestones WHERE id = ?").get(id);
    if (!cur) {
      res.status(404).json({ error: "Milestone not found." });
      return;
    }
    const reward = Math.max(0, Math.round(Number(req.body?.cumulativeReward ?? cur.cumulative_reward)));
    const title = String(req.body?.title ?? cur.title).trim().slice(0, 80);
    const badge = String(req.body?.badgeLabel ?? cur.badge_label).trim().slice(0, 40);
    const isActive = req.body?.isActive !== undefined ? (req.body.isActive ? 1 : 0) : cur.is_active;
    db.prepare(
      "UPDATE referral_milestones SET cumulative_reward = ?, title = ?, badge_label = ?, is_active = ?, updated_at = ? WHERE id = ?"
    ).run(reward, title, badge, isActive, nowIso(), id);
    res.json({ updated: true, milestones: getAllMilestones(db) });
  });

  router.delete("/referral-milestones/:id", (req, res) => {
    db.prepare("DELETE FROM referral_milestones WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true, milestones: getAllMilestones(db) });
  });

  router.post("/referral-campaigns", (req, res) => {
    const title = String(req.body?.title || "").trim().slice(0, 120);
    if (title.length < 3) {
      res.status(400).json({ error: "Campaign title is required." });
      return;
    }
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO referral_campaigns (
           title, description, target_role, bonus_amount, min_qualified_referrals, banner_cta,
           starts_at, ends_at, is_active, created_by, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`
      )
      .run(
        title,
        String(req.body?.description || "").trim().slice(0, 500),
        ["all", "student", "teacher"].includes(req.body?.targetRole) ? req.body.targetRole : "all",
        Math.max(0, Math.round(Number(req.body?.bonusAmount || 0))),
        Math.max(1, Math.floor(Number(req.body?.minQualifiedReferrals || 1))),
        String(req.body?.bannerCta || "Share Referral Link").trim().slice(0, 60),
        String(req.body?.startsAt || "").trim(),
        String(req.body?.endsAt || "").trim(),
        req.ctx.user.id,
        now,
        now
      );
    res.status(201).json({ created: true, id: Number(ins.lastInsertRowid) });
  });

  router.patch("/referral-campaigns/:id", (req, res) => {
    const id = Number(req.params.id);
    const cur = db.prepare("SELECT * FROM referral_campaigns WHERE id = ?").get(id);
    if (!cur) {
      res.status(404).json({ error: "Campaign not found." });
      return;
    }
    db.prepare(
      `UPDATE referral_campaigns SET
         title = ?, description = ?, target_role = ?, bonus_amount = ?,
         min_qualified_referrals = ?, starts_at = ?, ends_at = ?, is_active = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      String(req.body?.title ?? cur.title).trim().slice(0, 120),
      String(req.body?.description ?? cur.description).trim().slice(0, 500),
      ["all", "student", "teacher"].includes(req.body?.targetRole) ? req.body.targetRole : cur.target_role,
      Math.max(0, Math.round(Number(req.body?.bonusAmount ?? cur.bonus_amount))),
      Math.max(1, Math.floor(Number(req.body?.minQualifiedReferrals ?? cur.min_qualified_referrals))),
      req.body?.startsAt !== undefined ? String(req.body.startsAt || "").trim() : cur.starts_at,
      req.body?.endsAt !== undefined ? String(req.body.endsAt || "").trim() : cur.ends_at,
      req.body?.isActive !== undefined ? (req.body.isActive ? 1 : 0) : cur.is_active,
      nowIso(),
      id
    );
    res.json({ updated: true });
  });

  router.delete("/referral-campaigns/:id", (req, res) => {
    db.prepare("DELETE FROM referral_campaigns WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });

  router.post("/referrals/:id/recompute", async (req, res) => {
    const refRow = db.prepare("SELECT * FROM referrals WHERE id = ?").get(Number(req.params.id));
    if (!refRow) {
      res.status(404).json({ error: "Referral record not found." });
      return;
    }
    const result = await recomputeReferralForStudent(
      db,
      refRow.referred_user_id,
      { eventType: "manual_recompute", actorId: req.ctx.user.id, note: "Admin manual recalculation" },
      deps
    );
    res.json({ recomputed: true, result });
  });

  router.post("/referrals/:id/disqualify", (req, res) => {
    const id = Number(req.params.id);
    const reason = String(req.body?.reason || "Disqualified by Admin audit").trim().slice(0, 250);
    const refRow = db.prepare("SELECT * FROM referrals WHERE id = ?").get(id);
    if (!refRow) {
      res.status(404).json({ error: "Referral record not found." });
      return;
    }
    db.prepare("UPDATE referrals SET status = 'disqualified', disqualification_reason = ?, pending_estimated_reward = 0, updated_at = ? WHERE id = ?").run(
      reason,
      nowIso(),
      id
    );
    writeAuditLog(db, {
      actorId: req.ctx.user.id,
      actorName: req.ctx.user.full_name,
      targetId: refRow.referrer_user_id,
      targetName: `Referral #${id}`,
      action: "referral_disqualified",
      details: reason,
      ipAddress: clientIp(req)
    });
    res.json({ disqualified: true });
  });

  // Wallets & Withdrawals Administration
  router.get("/wallets", (req, res) => {
    const walletType = String(req.query?.type || "all");
    const search = String(req.query?.search || "").trim();
    const where = ["1=1"];
    const params = [];
    if (walletType === "student" || walletType === "teacher") {
      where.push("w.wallet_type = ?");
      params.push(walletType);
    }
    if (search) {
      const q = `%${search}%`;
      where.push("(u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR COALESCE(rp.referral_code, '') LIKE ?)");
      params.push(q, q, q, q);
    }

    const wallets = db
      .prepare(
        `SELECT w.*, u.full_name, u.email, u.phone, rp.referral_code, rp.qualified_referrals
         FROM wallets w
         JOIN users u ON u.id = w.user_id
         LEFT JOIN referral_profiles rp ON rp.user_id = w.user_id
         WHERE ${where.join(" AND ")}
         ORDER BY w.available_balance DESC, w.id DESC
         LIMIT 200`
      )
      .all(...params);
    res.json({ wallets });
  });

  router.get("/wallets/:userId/ledger", (req, res) => {
    const uid = Number(req.params.userId);
    const user = db.prepare("SELECT id, full_name, role, email, phone FROM users WHERE id = ?").get(uid);
    if (!user) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    const data = getWalletDashboardData(db, uid, user.role, { limit: 200 });
    res.json({ user, ...data });
  });

  router.post("/wallets/:userId/adjust", (req, res) => {
    const uid = Number(req.params.userId);
    const user = db.prepare("SELECT id, full_name, role FROM users WHERE id = ?").get(uid);
    if (!user || (user.role !== "student" && user.role !== "teacher")) {
      res.status(404).json({ error: "Student or Teacher account not found." });
      return;
    }
    const mode = req.body?.mode === "debit" ? "debit" : "credit";
    const amount = Math.round(Number(req.body?.amount || 0));
    const reason = String(req.body?.reason || "").trim().slice(0, 300);
    if (amount <= 0) {
      res.status(400).json({ error: "Adjustment amount must be greater than ₹0." });
      return;
    }
    if (reason.length < 4) {
      res.status(400).json({ error: "Please enter a clear adjustment reason (min 4 chars)." });
      return;
    }

    try {
      let out;
      if (mode === "credit") {
        out = creditWalletImmutable(db, {
          userId: uid,
          walletType: user.role,
          amount,
          category: "admin_credit",
          referenceType: "admin_adjustment",
          referenceId: String(req.ctx.user.id),
          description: `Admin Credit: ${reason}`,
          actorId: req.ctx.user.id
        });
      } else {
        out = debitWalletImmutable(db, {
          userId: uid,
          walletType: user.role,
          amount,
          category: "admin_debit",
          referenceType: "admin_adjustment",
          referenceId: String(req.ctx.user.id),
          description: `Admin Debit: ${reason}`,
          actorId: req.ctx.user.id,
          requireAvailable: true
        });
      }
      writeAuditLog(db, {
        actorId: req.ctx.user.id,
        actorName: req.ctx.user.full_name,
        targetId: uid,
        targetName: user.full_name,
        action: `wallet_manual_${mode}`,
        details: `₹${amount} (${reason})`,
        ipAddress: clientIp(req)
      });
      res.json({ adjusted: true, ...out });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Wallet adjustment failed." });
    }
  });

  router.post("/wallets/:userId/freeze", (req, res) => {
    const uid = Number(req.params.userId);
    const freeze = Boolean(req.body?.freeze);
    const reason = String(req.body?.reason || "").trim().slice(0, 250);
    const wallet = db.prepare("SELECT * FROM wallets WHERE user_id = ?").get(uid);
    if (!wallet) {
      res.status(404).json({ error: "Wallet not found." });
      return;
    }
    db.prepare("UPDATE wallets SET is_frozen = ?, freeze_reason = ?, updated_at = ? WHERE id = ?").run(
      freeze ? 1 : 0,
      freeze ? reason || "Frozen by Admin" : "",
      nowIso(),
      wallet.id
    );
    writeAuditLog(db, {
      actorId: req.ctx.user.id,
      actorName: req.ctx.user.full_name,
      targetId: uid,
      targetName: `Wallet #${wallet.id}`,
      action: freeze ? "wallet_frozen" : "wallet_unfrozen",
      details: reason || (freeze ? "Frozen" : "Unfrozen"),
      ipAddress: clientIp(req)
    });
    res.json({ updated: true, isFrozen: freeze });
  });

  router.get("/withdrawals", (req, res) => {
    const status = String(req.query?.status || "all");
    const role = String(req.query?.role || "all");
    const where = ["1=1"];
    const params = [];
    if (status && status !== "all") {
      where.push("wr.status = ?");
      params.push(status);
    }
    if (role === "student" || role === "teacher") {
      where.push("wr.user_role = ?");
      params.push(role);
    }
    const withdrawals = db
      .prepare(
        `SELECT wr.*, u.full_name, u.email, u.phone, w.available_balance
         FROM withdrawal_requests wr
         JOIN users u ON u.id = wr.user_id
         LEFT JOIN wallets w ON w.id = wr.wallet_id
         WHERE ${where.join(" AND ")}
         ORDER BY CASE WHEN wr.status = 'pending' THEN 0 WHEN wr.status IN ('under_review', 'approved', 'processing') THEN 1 ELSE 2 END, wr.id DESC
         LIMIT 250`
      )
      .all(...params);
    res.json({ withdrawals });
  });

  router.post("/withdrawals/:id/status", async (req, res) => {
    try {
      const result = transitionWithdrawalStatus(db, {
        withdrawalId: Number(req.params.id),
        nextStatus: req.body?.status,
        adminId: req.ctx.user.id,
        adminNote: req.body?.adminNote || "",
        payoutReference: req.body?.payoutReference || ""
      });
      writeAuditLog(db, {
        actorId: req.ctx.user.id,
        actorName: req.ctx.user.full_name,
        targetId: result.request.user_id,
        targetName: result.request.request_code,
        action: `withdrawal_${result.request.status}`,
        details: `₹${result.request.amount} -> ${result.request.status}${result.request.payout_reference ? ` (${result.request.payout_reference})` : ""}`,
        ipAddress: clientIp(req)
      });
      db.prepare(
        "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
      ).run(
        result.request.user_id,
        `Withdrawal ${result.request.status.replace("_", " ").toUpperCase()} (${result.request.request_code})`,
        `Your withdrawal request of ₹${result.request.amount} is now "${result.request.status}".${result.request.admin_note ? ` Note: ${result.request.admin_note}` : ""}${result.request.payout_reference ? ` Ref: ${result.request.payout_reference}` : ""}`,
        nowIso()
      );
      res.json({ updated: true, ...result });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Status transition failed." });
    }
  });

  // Global Search & User Preferences
  router.get("/global-search", (req, res) => {
    const out = searchAdminWorkspace(db, {
      query: req.query?.q || "",
      category: req.query?.category || "all",
      limit: req.query?.limit || 8,
      offset: req.query?.offset || 0,
      settingDefinitions: SETTING_DEFINITIONS || []
    });
    res.json(out);
  });

  router.get("/search-preferences", (req, res) => {
    res.json(getAdminSearchPreferences(db, req.ctx.user.id));
  });

  router.post("/search-preferences", (req, res) => {
    const updated = updateAdminSearchPreferences(db, req.ctx.user.id, req.body || {});
    res.json(updated);
  });

  // Analytics & Multi-Format Export (CSV + Excel SpreadsheetML)
  router.get("/analytics/referrals-wallets", (req, res) => {
    const report = getReferralAnalyticsReport(db, {
      fromDate: req.query?.from || "",
      toDate: req.query?.to || "",
      role: req.query?.role || "all"
    });
    res.json(report);
  });

  router.get("/analytics/referrals-wallets/export", (req, res) => {
    const format = String(req.query?.format || "csv").toLowerCase();
    const refRows = db
      .prepare(
        `SELECT r.id, r.referral_code_used, u1.full_name AS referrer, r.referrer_role,
                u2.full_name AS referred_student, r.status, r.paid_months_count, r.required_months,
                r.verified_fees_total, r.reward_amount_credited, r.created_at
         FROM referrals r
         JOIN users u1 ON u1.id = r.referrer_user_id
         JOIN users u2 ON u2.id = r.referred_user_id
         ORDER BY r.id DESC`
      )
      .all();

    const wdrRows = db
      .prepare(
        `SELECT wr.request_code, u.full_name, wr.user_role, wr.amount, wr.payout_method,
                wr.upi_id, wr.bank_name, wr.status, wr.payout_reference, wr.created_at, wr.paid_at
         FROM withdrawal_requests wr
         JOIN users u ON u.id = wr.user_id
         ORDER BY wr.id DESC`
      )
      .all();

    if (format === "excel" || format === "xls") {
      const xml = buildSpreadsheetXml([
        {
          name: "Referrals",
          headers: ["ID", "Code", "Referrer", "Role", "Referred Student", "Status", "Paid Months", "Required Months", "Verified Fees", "Reward Credited", "Registered At"],
          rows: refRows.map((r) => [
            r.id,
            r.referral_code_used,
            r.referrer,
            r.referrer_role,
            r.referred_student,
            r.status,
            r.paid_months_count,
            r.required_months,
            r.verified_fees_total,
            r.reward_amount_credited,
            r.created_at
          ])
        },
        {
          name: "Withdrawals",
          headers: ["Request Code", "User", "Role", "Amount", "Method", "UPI ID", "Bank", "Status", "Payout Ref", "Requested At", "Paid At"],
          rows: wdrRows.map((w) => [
            w.request_code,
            w.full_name,
            w.user_role,
            w.amount,
            w.payout_method,
            w.upi_id,
            w.bank_name,
            w.status,
            w.payout_reference,
            w.created_at,
            w.paid_at || ""
          ])
        }
      ]);
      res.setHeader("Content-Type", "application/vnd.ms-excel; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="yuitor-referrals-wallets-${nowIso().slice(0, 10)}.xls"`);
      res.send(xml);
      return;
    }

    const csv = rowsToCsv(
      ["ID", "Code", "Referrer", "Role", "Referred Student", "Status", "Paid Months", "Required Months", "Verified Fees (INR)", "Reward Credited (INR)", "Registered At"],
      refRows.map((r) => [
        r.id,
        r.referral_code_used,
        r.referrer,
        r.referrer_role,
        r.referred_student,
        r.status,
        r.paid_months_count,
        r.required_months,
        r.verified_fees_total,
        r.reward_amount_credited,
        r.created_at
      ])
    );
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="yuitor-referrals-report-${nowIso().slice(0, 10)}.csv"`);
    res.send(csv);
  });

  // Unused import guard cleanup helper check
  void runInImmediateTx;

  return router;
}
