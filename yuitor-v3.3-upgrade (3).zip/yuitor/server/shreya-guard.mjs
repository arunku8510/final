/**
 * Ask Shreya AI Assistant — v3.2 Short, Same-Language, Grounded Knowledge & Security Guard
 *
 * Upgraded for v3.2:
 * 1. Exact Class 6th–12th individual fees synced from server/fee-plans.mjs (₹600–₹900/month, 10% OFF on Yearly).
 * 2. Strict SHORT & SAME-LANGUAGE prompt constitution (only answer what was asked, zero filler/repetition).
 * 3. Smart Lead Capture into existing `inquiries` table + direct Add-to-Cart CTA detection.
 * 4. Strict anti-leak security guard for admin URLs, credentials, OTPs, secrets, DB, and other users' data.
 */

import { CLASS_FEE_PLANS, calculateClassFeePlan, parseClassNumberFromLabel } from "./fee-plans.mjs";

export const SHREYA_OFFICIAL_INTRO =
  "Hi! I'm Shreya, Yuitor Smart Classes AI Assistant. Ask me about Class 6th–12th fees, batches, admissions, or upload a study question (max 5 MB).";

export const OFFICIAL_19_COURSES = [
  ...CLASS_FEE_PLANS.map((p) => ({
    group: "Classes 6th–12th",
    title: `${p.classLabel} Coaching`,
    path: `/class-${p.classNumber}`,
    fee: `₹${p.monthly}/month (Yearly 12m: ₹${p.yearlyTotal.toLocaleString("en-IN")} — 10% OFF, save ₹${p.yearlySavings})`,
  })),
  { group: "Boards", title: "CBSE Board Coaching", path: "/board/cbse", fee: "₹600–₹900/month (Class 6th–12th exact class-wise fee)" },
  { group: "Boards", title: "UP Board Coaching", path: "/course/up-board-coaching", fee: "₹600–₹900/month (Hindi & English medium)" },
  { group: "Boards", title: "ICSE Coaching", path: "/course/icse-coaching", fee: "₹600–₹900/month (Class 6th–12th)" },
  { group: "Boards", title: "State Board Coaching", path: "/course/state-board-coaching", fee: "₹600–₹900/month" },
  { group: "Competitive Exams", title: "NEET Coaching", path: "/course/neet-coaching", fee: "₹1,800/month (10% OFF on Yearly)" },
  { group: "Competitive Exams", title: "JEE Coaching", path: "/course/jee-coaching", fee: "₹1,800/month (10% OFF on Yearly)" },
  { group: "Competitive Exams", title: "CUET Coaching", path: "/course/cuet-coaching", fee: "₹1,200/month" },
  { group: "Competitive Exams", title: "NDA Coaching", path: "/course/nda-coaching", fee: "₹1,500/month" },
  { group: "Competitive Exams", title: "SSC Coaching", path: "/course/ssc-coaching", fee: "₹1,000/month" },
  { group: "Competitive Exams", title: "Banking Coaching", path: "/course/banking-coaching", fee: "₹1,000/month" },
  { group: "Skill Courses", title: "Computer Classes", path: "/course/computer-classes", fee: "₹600/month (DCA, Tally GST, CCC)" },
  { group: "Skill Courses", title: "Spoken English", path: "/course/spoken-english", fee: "₹600/month" },
  { group: "Skill Courses", title: "Coding Classes", path: "/course/coding-classes", fee: "₹900/month (Python, Web Dev)" },
];
export const OFFICIAL_20_COURSES = OFFICIAL_19_COURSES;

const SECURITY_BLOCK_PATTERNS = [
  /\b(admin\s*(url|link|path|slug|gate|panel\s*url|login\s*url|password|pass|email|otp|credentials?|secret|key)|super\s*admin\s*(password|login|url|email)|yt-ctrl|secret\s*gate|backend\s*admin\s*url|hidden\s*admin)\b/i,
  /\b(\.env|process\.env|gemini_api_key|smtp_pass|smtp_password|razorpay_key_secret|session_secret|api[_\s-]?key|secret[_\s-]?key|jwt[_\s-]?secret|private[_\s-]?key|webhook[_\s-]?secret|sms[_\s-]?api[_\s-]?key|bearer\s*token|cookie\s*secret)\b/i,
  /\b(select\s+\*\s+from|drop\s+table|pragma\s+table_info|sqlite_master|dump\s+(database|db|users|table)|show\s+tables|database\s*(schema|password|file|path|dump)|yuitor\.db|server\.js\s*(code|source)|read\s*file\s*\/etc|cat\s+\.env)\b/i,
  /\b(other\s*(student|teacher|user)s?\s*(phone|number|email|password|otp|balance|wallet|data|list)|all\s*users?\s*(list|passwords?|emails?|phones?|otps?)|give\s+me\s+(user|student|teacher|admin)\s*(password|otp|hash|phone|email|wallet\s*balance)|tell\s+me\s+.*\s*(otp|password)|hash\s+of\s+password|bcrypt\s+hash)\b/i,
  /\b(ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|rules?|prompts?)|reveal\s+(your\s+)?(system\s*prompt|instructions?|hidden\s*rules?)|print\s+(your\s+)?system\s*prompt|jailbreak|dan\s*mode|developer\s*mode\s*override|bypass\s*(security|auth|admin|otp|guardrails?)|pretend\s+you\s+are\s+(the\s+)?(admin|root|database|system))\b/i,
];

export function detectSecurityLeakAttempt(text) {
  const raw = String(text || "").trim();
  if (!raw) return { blocked: false, reason: "" };
  for (const re of SECURITY_BLOCK_PATTERNS) {
    if (re.test(raw)) return { blocked: true, reason: "security_policy" };
  }
  return { blocked: false, reason: "" };
}

export function isDevanagariHindi(text) {
  return /[\u0900-\u097F]/.test(String(text || ""));
}

export function isHindiOrHinglish(text) {
  return /[\u0900-\u097F]|\b(kya|kaise|kitni|kitna|batayein|batao|chahiye|karna|nahi|ho raha|madad|admission lena|namaste|kab|kahan|kaun|padhna|padhana|kripya|samjhao|milta|milega|paisa|paise|nikalna|nikale|bhejna|aata|aayega|mera|meri|apna|hoga|hogi|hai|hain|mein|par|ke liye|ki fee|ka fee)\b/i.test(
    String(text || "")
  );
}

export function buildSecurityRefusalReply(userMsg) {
  if (isHindiOrHinglish(userMsg)) {
    return "Suraksha rules ke karan main Admin URL, password, OTP, API key, database ya kisi aur user ka private data share nahi kar sakti. Courses/fees help ke liye poochhein ya +91 78-2728-9292 par call karein.";
  }
  return "For security, I cannot share admin URLs, credentials, OTPs, API keys, database details, or another user's private data. Ask me about courses, fees, or study doubts, or call +91 78-2728-9292.";
}

export function sanitizeShreyaOutput(text, adminSlug = "") {
  let out = String(text || "").trim();
  if (!out) return out;
  const slug = String(adminSlug || "").trim().replace(/^\/+|\/+$/g, "");
  if (slug && slug.length >= 4) {
    const escaped = slug.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    out = out.replace(new RegExp(`/?${escaped}(?:/[^\\s]*)?`, "gi"), "[protected]");
  }
  out = out
    .replace(/\/yt-ctrl-[a-z0-9_-]+(?:\/[^\s]*)?/gi, "[protected]")
    .replace(/\b(AIza[0-9A-Za-z\-_]{20,}|rzp_(?:live|test)_[0-9A-Za-z]+|sk-[0-9A-Za-z]{20,})\b/g, "[redacted]")
    .replace(/\b(GEMINI_API_KEY|SMTP_PASS|RAZORPAY_KEY_SECRET|SESSION_SECRET)\s*[:=]\s*\S+/gi, "$1=[redacted]")
    .replace(/\bSELECT\s+\*\s+FROM\s+\w+/gi, "[restricted]");
  return out;
}

/**
 * Detects if a message asks about a specific Class 6th–12th and returns a direct Add-to-Cart CTA payload.
 */
export function detectClassAddToCartCta(text, db) {
  const clsNum = parseClassNumberFromLabel(text);
  if (!clsNum) return null;
  const fee = calculateClassFeePlan(clsNum, "1m");
  const yearly = calculateClassFeePlan(clsNum, "yearly");
  let courseId = null;
  let courseTitle = `${fee.classLabel} Coaching`;
  if (db) {
    try {
      const slug = `class-${clsNum}-coaching`;
      const row = db
        .prepare("SELECT id, title FROM courses WHERE (slug = ? OR LOWER(class_range) = ?) AND is_active = 1 LIMIT 1")
        .get(slug, fee.classLabel.toLowerCase());
      if (row) {
        courseId = Number(row.id);
        courseTitle = row.title;
      }
    } catch {
      // ignore
    }
  }
  return {
    type: "add_to_cart",
    classNumber: clsNum,
    classLabel: fee.classLabel,
    courseId,
    courseTitle,
    monthlyFee: fee.monthlyRate,
    yearlyFee: yearly.totalPayable,
    yearlySavings: yearly.yearlySavings,
    label: `Add ${fee.classLabel} (₹${fee.monthlyRate}/mo) to Cart`,
  };
}

/**
 * Smart Lead Capture: saves fee/class enquiries cleanly into existing `inquiries` table (duplicate-protected per conversation).
 */
export function captureShreyaLeadIfRelevant(db, { conversationId = "", message = "", visitorName = "", visitorPhone = "", visitorEmail = "", classNumber = null } = {}) {
  if (!db) return null;
  const raw = String(message || "").trim();
  const isFeeOrAdmission = /\b(fee|fees|price|charge|admission|join|batch|enroll|kitni|kitna|daakhila|class\s*(?:6|7|8|9|10|11|12)|6th|7th|8th|9th|10th|11th|12th)\b/i.test(raw);
  if (!isFeeOrAdmission && !classNumber) return null;

  const phoneMatch = raw.match(/\b([6-9]\d{9})\b/);
  const emailMatch = raw.match(/\b([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b/);
  const phone = String(visitorPhone || (phoneMatch ? phoneMatch[1] : "")).replace(/\D/g, "").slice(-10);
  const email = String(visitorEmail || (emailMatch ? emailMatch[1] : "")).trim().toLowerCase();
  const classLabel = classNumber ? `Class ${classNumber}th` : "Class 6th–12th Inquiry";
  const leadName = String(visitorName || "Shreya Chat Visitor").trim().slice(0, 80);
  const tag = conversationId ? `[Shreya:${String(conversationId).slice(0, 24)}]` : "";

  try {
    if (tag) {
      const exists = db.prepare("SELECT id FROM inquiries WHERE message LIKE ? LIMIT 1").get(`%${tag}%`);
      if (exists) {
        if (phone || email) {
          db.prepare("UPDATE inquiries SET phone = CASE WHEN phone = '' THEN ? ELSE phone END, email = CASE WHEN email = '' THEN ? ELSE email END WHERE id = ?").run(
            phone,
            email,
            exists.id
          );
        }
        return { inquiryId: Number(exists.id), updated: true };
      }
    }
    const ins = db
      .prepare(
        `INSERT INTO inquiries (name, phone, email, class_or_course, message, status, created_at)
         VALUES (?, ?, ?, ?, ?, 'new', ?)`
      )
      .run(
        leadName,
        phone || "Chat Lead",
        email || "",
        classLabel,
        `${tag} ${raw.slice(0, 260)}`.trim(),
        new Date().toISOString()
      );
    return { inquiryId: Number(ins.lastInsertRowid), created: true };
  } catch {
    return null;
  }
}

export function getPublicReferralSnapshot(db) {
  let settings = null;
  let milestones = [];
  let campaigns = [];
  try {
    settings = db.prepare("SELECT * FROM referral_settings WHERE id = 1").get();
  } catch {
    settings = null;
  }
  try {
    milestones = db
      .prepare("SELECT qualified_count, cumulative_reward, title, badge_label FROM referral_milestones WHERE is_active = 1 ORDER BY qualified_count ASC")
      .all();
  } catch {
    milestones = [];
  }
  try {
    campaigns = db
      .prepare("SELECT title, target_role, bonus_amount, ends_at FROM referral_campaigns WHERE is_active = 1 ORDER BY id DESC LIMIT 5")
      .all();
  } catch {
    campaigns = [];
  }

  return {
    enabled: settings ? Number(settings.referrals_enabled ?? 1) === 1 : true,
    requiredPaidMonths: Number(settings?.required_fee_months || 3),
    minWithdrawalAmount: Number(settings?.min_withdrawal_amount || 200),
    maxWithdrawalAmount: Number(settings?.max_withdrawal_amount || 50000),
    studentWithdrawalAllowed: settings ? Number(settings.allow_student_referrals ?? 1) === 1 : true,
    teacherWithdrawalAllowed: settings ? Number(settings.allow_teacher_referrals ?? 1) === 1 : true,
    requireAdminApproval: settings ? Number(settings.require_admin_approval ?? 1) === 1 : true,
    milestones,
    campaigns,
  };
}

export function buildFullWebsiteKnowledgeContext(db, getDepartmentEmails) {
  const ref = getPublicReferralSnapshot(db);
  const dept = typeof getDepartmentEmails === "function"
    ? getDepartmentEmails()
    : {
        admission: "inquiry@yuitor.com",
        inquiry: "inquiry@yuitor.com",
        support: "inquiry@yuitor.com",
        fee: "inquiry@yuitor.com",
        career: "inquiry@yuitor.com",
        complain: "Complaints@yuitor.com",
        refund: "inquiry@yuitor.com",
      };

  const classFeeLines = CLASS_FEE_PLANS.map(
    (p) => `- ${p.classLabel}: ₹${p.monthly}/month | 3m ₹${p.monthly * 3} | 6m ₹${p.monthly * 6} | 9m ₹${p.monthly * 9} | 12m Yearly ₹${p.yearlyTotal} (10% OFF, save ₹${p.yearlySavings})`
  ).join("\n");

  return `YUITOR SMART CLASSES (MURADNAGAR) — "Ek Kadam Safalta Ki Our" — OFFICIAL FACTS:
- Campus: Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, UP | Phone/WhatsApp: +91 78-2728-9292 | Email: ${dept.inquiry} | Complaints: ${dept.complain}
- EXACT INDIVIDUAL CLASS FEES (SINGLE SOURCE OF TRUTH — NO COMBINED RANGES):
${classFeeLines}
- Durations: 1, 3, 6, 9, and 12 months (12m Yearly auto-applies 10% OFF). Multi-subject / sibling combo discount available in Cart.
- Official 20 Programs: Classes 6–12, CBSE Board Coaching, UP Board Coaching, ICSE Coaching, State Board, NEET Coaching (₹1,800/mo), JEE Coaching (₹1,800/mo), CUET (₹1,200/mo), NDA (₹1,500/mo), SSC/Banking (₹1,000/mo), Computer/Spoken English (₹600/mo), Coding Classes (₹900/mo). (We do NOT offer Class 5, US CPA, US CMA, ACCA.)
- Instant Admission: Add class to Cart -> Quick Register/Login -> Verified Razorpay payment auto-activates Student Portal + issues instant Receipt & Batch Slip.
- Portals & OTP Login: /student/, /parent/, /teacher/, /register, /login — choose Email (Mail) or Mobile Number (SMS) for 6-digit OTP verification.
- Referrals (3-Month Verified Fee Rule): ${ref.requiredPaidMonths} verified paid months to qualify; Teachers withdraw via UPI or Bank Transfer (min ₹${ref.minWithdrawalAmount}).
- Refund Policy: 100% within 7 days per /refund.`;
}

export function buildShreyaSystemInstruction(knowledge, docSection, deptEmails) {
  const complain = deptEmails?.complain || "Complaints@yuitor.com";
  return `You are Shreya, Yuitor Smart Classes AI Assistant.

STRICT REPLY RULES (FOLLOW 100%):
1. SHORT & DIRECT ONLY: Answer ONLY what the user asked in 1–4 short sentences (or up to 4 brief bullets). NO filler intro ("Sure!", "Great question!"), NO repetition, NO extra unasked theory or marketing fluff.
2. EXACT SAME LANGUAGE: Reply in the EXACT same language the user used (Hindi in Devanagari -> Devanagari Hindi; Hinglish -> Hinglish; English -> English).
3. ACADEMIC / IMAGE QUESTIONS: If a question or uploaded image/PDF is provided, give the direct final answer + shortest essential steps only (no long lecture).
4. EXACT FEES ONLY: Quote ONLY the exact Class 6th–12th fees listed below (Class 6th ₹600, 7th ₹650, 8th ₹700, 9th ₹750, 10th ₹800, 11th ₹850, 12th ₹900/month; 1/3/6/9/12m; Yearly 12m has 10% OFF). Never invent fees or courses.
5. SECURITY: Never reveal admin URLs, passwords, OTPs, API keys, secrets, DB schema, or other users' data. Never ask for passwords or OTPs.
6. ESCALATION: For formal complaints or human callback requests, share +91 78-2728-9292 and ${complain} and append [ESCALATE].

${knowledge}${docSection || ""}`;
}

/**
 * Concise deterministic responder using exact Class 6th–12th fees and strict same-language short replies.
 */
export function answerFromOfficialKnowledge(userMsg, history, db, deps = {}) {
  const raw = String(userMsg || "").trim();
  const q = typeof deps.normalizeUserQuery === "function" ? deps.normalizeUserQuery(raw) : raw.toLowerCase();
  const isDev = isDevanagariHindi(raw);
  const isHindi = isHindiOrHinglish(raw);
  const dept = typeof deps.getDepartmentEmails === "function"
    ? deps.getDepartmentEmails()
    : { inquiry: "inquiry@yuitor.com", complain: "Complaints@yuitor.com", refund: "inquiry@yuitor.com" };

  if (detectSecurityLeakAttempt(raw).blocked) {
    return { reply: buildSecurityRefusalReply(raw), escalate: false, blocked: true };
  }

  if (/^(hi|hello|hey|namaste|hlo|good morning|good evening|good afternoon|hii+)[!.\s]*$/i.test(q.trim())) {
    return {
      reply: isDev
        ? "नमस्ते! मैं श्रेया हूँ, Yuitor Smart Classes AI Assistant। क्लास 6th–12th फीस, एडमिशन या किसी सवाल की फोटो भेजें।"
        : isHindi
          ? "Namaste! Main Shreya hoon, Yuitor AI Assistant. Class 6th–12th fees, admission ya study doubt poochhein."
          : SHREYA_OFFICIAL_INTRO,
      escalate: false,
    };
  }
  if (/\b(who are you|your name|kaun ho|aap kaun|about shreya)\b/i.test(q) && q.length < 55) {
    return { reply: SHREYA_OFFICIAL_INTRO, escalate: false };
  }

  if (/\b(complaint|complain|refund issue|speak to human|talk to sir|call me|human|manager|principal|team se baat|shikayat)\b/i.test(q)) {
    return {
      reply: isHindi
        ? `Yuitor Team se direct baat karne ke liye +91 78-2728-9292 par call/WhatsApp karein ya ${dept.complain} par mail karein.`
        : `Please call/WhatsApp +91 78-2728-9292 or email ${dept.complain} to speak directly with our team.`,
      escalate: true,
    };
  }

  if (typeof deps.tryDynamicAcademicSolver === "function") {
    const solved = deps.tryDynamicAcademicSolver(raw, isHindi);
    if (solved) return { reply: solved, escalate: false };
  }
  if (Array.isArray(deps.academicConcepts)) {
    for (const item of deps.academicConcepts) {
      if (item.keys.test(q)) return { reply: item.answer, escalate: false };
    }
  }

  // Exact individual class fee lookup (Class 6th–12th)
  const clsNum = parseClassNumberFromLabel(raw);
  if (clsNum) {
    const plan = calculateClassFeePlan(clsNum, "1m");
    const yearly = calculateClassFeePlan(clsNum, "yearly");
    const reply = isDev
      ? `${plan.classLabel} की फीस ₹${plan.monthlyRate}/महीना है। 1/3/6/9/12 महीने के प्लान उपलब्ध हैं — 12 महीने (Yearly) पर 10% OFF के बाद ₹${yearly.totalPayable.toLocaleString("en-IN")} (₹${yearly.yearlySavings} की बचत)। नीचे से सीधे Add to Cart करें।`
      : isHindi
        ? `${plan.classLabel} ki fee ₹${plan.monthlyRate}/month hai (3m ₹${plan.monthlyRate * 3}, 6m ₹${plan.monthlyRate * 6}, 9m ₹${plan.monthlyRate * 9}). 12m Yearly par 10% OFF ke baad ₹${yearly.totalPayable.toLocaleString("en-IN")} (save ₹${yearly.yearlySavings}). Neeche button se direct Add to Cart karein.`
        : `${plan.classLabel} fee is ₹${plan.monthlyRate}/month (3m ₹${plan.monthlyRate * 3}, 6m ₹${plan.monthlyRate * 6}, 9m ₹${plan.monthlyRate * 9}). 12-month Yearly plan is ₹${yearly.totalPayable.toLocaleString("en-IN")} (10% OFF, save ₹${yearly.yearlySavings}). Use the button below to Add to Cart.`;
    return { reply, escalate: false };
  }

  // General Fees / CBSE Board query (all 7 individual classes)
  if (/\b(fees?|price|charges|kitni|kitna|amount|cbse)\b/i.test(q)) {
    const table = CLASS_FEE_PLANS.map((p) => `${p.classLabel}: ₹${p.monthly}/mo`).join(" | ");
    return {
      reply: isHindi
        ? `CBSE / UP / ICSE Board class-wise monthly fees: ${table}. Durations: 1, 3, 6, 9, 12 months (12m Yearly par 10% OFF). Apni class batayein ya direct Cart mein add karein.`
        : `CBSE / UP / ICSE Board monthly fees: ${table}. Plans: 1, 3, 6, 9, or 12 months (10% OFF on Yearly). Tell me your class to add directly to Cart.`,
      escalate: false,
    };
  }

  if (/\b(referral|refer|payout|withdraw|wallet|commission|milestone)\b/i.test(q)) {
    const ref = getPublicReferralSnapshot(db);
    return {
      reply: isHindi
        ? `Referred student ke ${ref.requiredPaidMonths} months verified fee payment ke baad referral qualify hota hai aur reward Wallet mein milta hai — UPI ya Bank Transfer se withdraw karein (min ₹${ref.minWithdrawalAmount}).`
        : `Referrals qualify after ${ref.requiredPaidMonths} months of verified fee payments; rewards credit to your Wallet and Teachers can withdraw via UPI or Bank Transfer (min ₹${ref.minWithdrawalAmount}).`,
      escalate: false,
    };
  }

  if (/\b(otp|login|sign in|password|forgot password)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "/login par Password ya Email (Mail) / Mobile Number (SMS) OTP se sign in karein. Password reset ke liye 'Forgot Password?' use karein."
        : "Sign in at /login using Password or Email (Mail) / Mobile Number (SMS) OTP, or reset your password via 'Forgot Password?'.",
      escalate: false,
    };
  }

  if (/\b(cart|checkout|razorpay|upi|pay fee|payment|receipt)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Course Cart mein add karein -> Quick Register/Login -> Razorpay verified payment karte hi Student Account, course & instant Receipt + Batch Slip turant active ho jate hain."
        : "Add your class to Cart -> Quick Register/Login -> verified Razorpay payment auto-activates your Student Account, course, and instant Receipt + Batch Slip.",
      escalate: false,
    };
  }

  if (/\b(us cpa|us cma|enrolled agent|acca|class\s*5|5th)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Yeh course Yuitor mein available nahi hai. Hum 20 official programs offer karte hain: Classes 6–12, CBSE/UP/ICSE/State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer, Spoken English aur Coding."
        : "We don't offer that program. Yuitor offers 20 official programs: Classes 6–12, CBSE/UP/ICSE/State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer, Spoken English, and Coding.",
      escalate: false,
    };
  }

  if (/\b(address|location|where|muradnagar|kahan|center|centre)\b/i.test(q)) {
    return {
      reply: "Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, UP. Call/WhatsApp: +91 78-2728-9292.",
      escalate: false,
    };
  }

  if (/\b(contact|phone|number|whatsapp|email|call|helpline)\b/i.test(q)) {
    return {
      reply: "Call/WhatsApp: +91 78-2728-9292 | Email: inquiry@yuitor.com | Complaints: Complaints@yuitor.com.",
      escalate: false,
    };
  }

  if (/\b(demo|trial|timing|batch|schedule|admission|join|enroll)\b/i.test(q)) {
    return {
      reply: isHindi
        ? "Mon–Sat morning & evening batches chalte hain. Direct Cart se join karein ya free demo ke liye /admission bharein (+91 78-2728-9292)."
        : "Morning & evening batches run Mon–Sat. Add your class to Cart to join instantly, or book a free demo at /admission (+91 78-2728-9292).",
      escalate: false,
    };
  }

  if (typeof deps.retrieveRelevantDocumentSnippets === "function") {
    const docSnippets = deps.retrieveRelevantDocumentSnippets(db, raw, 1);
    if (docSnippets.length > 0 && docSnippets[0].score >= 3) {
      const best = docSnippets[0];
      return { reply: best.excerpt.slice(0, 260).trim(), escalate: false };
    }
  }

  return {
    reply: isHindi
      ? "Main Class 6th–12th fees, batches, admission, Cart checkout ya study doubt mein madad kar sakti hoon. Apni class ya sawaal batayein (ya +91 78-2728-9292 par call karein)."
      : "I can help with Class 6th–12th fees, batches, instant Cart admission, or study doubts. Share your class or question, or call +91 78-2728-9292.",
    escalate: (history || []).length > 6,
  };
}
