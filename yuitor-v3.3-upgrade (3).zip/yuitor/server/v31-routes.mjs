import express from "express";
import fs from "node:fs";
import path from "node:path";
import {
  MAIL_THEMES,
  SUSPEND_TERMINATE_REASONS,
  applyMailTheme,
  calculateServerSideCourseCheckout,
  classifyUserStatusTab,
  computeStudentCrossSellState,
  getCrossSellSettings,
  getIstTimestamp,
  getStudentClassFilteredBatches,
  isFutureIstDate,
  logV31Audit,
  markCrossSellPurchased,
  runCrossSellWeeklyDispatch,
  sanitizeMailHtml,
  saveBase64ProfilePhoto,
  sendV31Mail,
} from "./v31-engine.mjs";

function safeParseJsonArray(val) {
  if (Array.isArray(val)) return val;
  if (!val) return [];
  try {
    const parsed = JSON.parse(String(val));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return String(val)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
  }
}

export function createV31AdminRouter(db, deps = {}) {
  const router = express.Router();
  const requireAdmin = deps.requireAdmin || ((_req, _res, next) => next());

  // ── 1. Suspend / Terminate Reasons & Themes metadata ──
  router.get("/v31/meta", requireAdmin, (_req, res) => {
    res.json({
      reasons: SUSPEND_TERMINATE_REASONS,
      themes: Object.values(MAIL_THEMES),
      istNow: getIstTimestamp(),
    });
  });

  // ── 2. Soft-Deleted User Restore (Safety Rule 2) ──
  router.post("/v31/users/:id/restore", requireAdmin, (req, res) => {
    const userId = Number(req.params.id);
    const user = db.prepare("SELECT * FROM users WHERE id = ? LIMIT 1").get(userId);
    if (!user) return res.status(404).json({ error: "User not found." });

    db.prepare(`
      UPDATE users
      SET deleted_at = '', deleted_by = NULL, is_active = 1, verification_status = 'approved', updated_at = datetime('now')
      WHERE id = ?
    `).run(userId);

    logV31Audit(db, {
      actorId: req.auth?.user?.id,
      actorName: req.auth?.user?.full_name || "Admin",
      actorRole: req.auth?.user?.role || "admin",
      action: "user_restored",
      entityType: "user",
      entityId: String(userId),
      summary: `Restored soft-deleted ${user.role} account (${user.full_name})`,
      before: { deleted_at: user.deleted_at, verification_status: user.verification_status },
      after: { deleted_at: "", verification_status: "approved", is_active: 1 },
    });

    return res.json({ ok: true, message: "User restored successfully." });
  });

  // ── 3. Admin Editable Student Details (Change 12) ──
  router.get("/v31/students/:id/details", requireAdmin, (req, res) => {
    const userId = Number(req.params.id);
    const user = db.prepare("SELECT id, full_name, email, phone, photo_url, dob, address, school_name, is_active, verification_status, deleted_at, promo_unsubscribed FROM users WHERE id = ? LIMIT 1").get(userId);
    if (!user) return res.status(404).json({ error: "Student not found." });

    const sp = db.prepare("SELECT * FROM student_profiles WHERE user_id = ? LIMIT 1").get(userId) || {};
    const totalFee = Number(sp.total_fee || 0);
    const paidFee = Number(sp.paid_fee || 0);
    const remainingFee = Math.max(0, totalFee - paidFee);
    const classBatches = getStudentClassFilteredBatches(db, userId);
    const crossSell = computeStudentCrossSellState(db, userId);

    return res.json({
      user,
      details: {
        currentClass: sp.class_level || "",
        enrolledSubjects: safeParseJsonArray(sp.enrolled_subjects_json),
        duration: sp.course_duration || "",
        totalFee,
        paidFee,
        remainingFee,
        subjectAddons: safeParseJsonArray(sp.subject_addons_json),
        address: user.address || sp.address || "",
        schoolName: user.school_name || sp.school_name || "",
        dob: user.dob || sp.dob || "",
        photoUrl: user.photo_url || user.profile_photo || user.avatar_url || "",
      },
      classBatches,
      crossSell,
    });
  });

  router.patch("/v31/students/:id/details", requireAdmin, (req, res) => {
    const userId = Number(req.params.id);
    const user = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'student' LIMIT 1").get(userId);
    if (!user) return res.status(404).json({ error: "Student not found." });

    const beforeSp = db.prepare("SELECT * FROM student_profiles WHERE user_id = ? LIMIT 1").get(userId) || {};
    const body = req.body || {};

    if (body.dob && isFutureIstDate(body.dob)) {
      return res.status(400).json({ error: "Date of Birth cannot be a future date (IST)." });
    }

    const enrolledSubjects = safeParseJsonArray(body.enrolledSubjects ?? body.enrolled_subjects ?? beforeSp.enrolled_subjects_json);
    const subjectAddons = safeParseJsonArray(body.subjectAddons ?? body.subject_addons ?? beforeSp.subject_addons_json);
    const duration = String(body.duration ?? beforeSp.course_duration ?? "").trim();
    const totalFee = Math.max(0, Number(body.totalFee ?? beforeSp.total_fee ?? 0));
    const paidFee = Math.max(0, Number(body.paidFee ?? beforeSp.paid_fee ?? 0));
    const remainingFee = Math.max(0, totalFee - paidFee);
    const address = String(body.address ?? user.address ?? "").trim();
    const schoolName = String(body.schoolName ?? user.school_name ?? "").trim();
    const dob = String(body.dob ?? user.dob ?? "").trim();

    db.prepare(`
      INSERT INTO student_profiles (user_id, enrolled_subjects_json, course_duration, total_fee, paid_fee, remaining_fee, subject_addons_json, address, school_name, dob)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        enrolled_subjects_json = excluded.enrolled_subjects_json,
        course_duration = excluded.course_duration,
        total_fee = excluded.total_fee,
        paid_fee = excluded.paid_fee,
        remaining_fee = excluded.remaining_fee,
        subject_addons_json = excluded.subject_addons_json,
        address = excluded.address,
        school_name = excluded.school_name,
        dob = excluded.dob
    `).run(
      userId,
      JSON.stringify(enrolledSubjects),
      duration,
      totalFee,
      paidFee,
      remainingFee,
      JSON.stringify(subjectAddons),
      address,
      schoolName,
      dob
    );

    db.prepare(`
      UPDATE users SET address = ?, school_name = ?, dob = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(address, schoolName, dob, userId);

    logV31Audit(db, {
      actorId: req.auth?.user?.id,
      actorName: req.auth?.user?.full_name || "Admin",
      actorRole: req.auth?.user?.role || "admin",
      action: "student_details_updated",
      entityType: "student",
      entityId: String(userId),
      summary: `Updated academic & fee details for student ${user.full_name}`,
      before: { total_fee: beforeSp.total_fee, paid_fee: beforeSp.paid_fee, enrolled_subjects: beforeSp.enrolled_subjects_json },
      after: { totalFee, paidFee, remainingFee, enrolledSubjects, subjectAddons, duration },
    });

    return res.json({
      ok: true,
      details: { enrolledSubjects, subjectAddons, duration, totalFee, paidFee, remainingFee, address, schoolName, dob },
    });
  });

  // ── 4. Student Class Change (Change 16 — Confirm + Audit + Immediate Batch/Cross-sell update) ──
  router.post("/v31/students/:id/change-class", requireAdmin, async (req, res) => {
    const userId = Number(req.params.id);
    const newClass = String(req.body?.newClass || req.body?.className || "").trim();
    if (!newClass) return res.status(400).json({ error: "New class is required." });

    const user = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'student' LIMIT 1").get(userId);
    if (!user) return res.status(404).json({ error: "Student not found." });

    const sp = db.prepare("SELECT class_level FROM student_profiles WHERE user_id = ? LIMIT 1").get(userId);
    const oldClass = String(sp?.class_level || "Not Set");

    db.prepare(`
      INSERT INTO student_profiles (user_id, class_level)
      VALUES (?, ?)
      ON CONFLICT(user_id) DO UPDATE SET class_level = excluded.class_level
    `).run(userId, newClass);

    logV31Audit(db, {
      actorId: req.auth?.user?.id,
      actorName: req.auth?.user?.full_name || "Admin",
      actorRole: req.auth?.user?.role || "admin",
      action: "student_class_changed",
      entityType: "student",
      entityId: String(userId),
      summary: `Changed class for ${user.full_name} from "${oldClass}" to "${newClass}"`,
      before: { class_level: oldClass },
      after: { class_level: newClass },
    });

    // Notify student about class change
    if (user.email) {
      await sendV31Mail(db, deps, {
        userId,
        to: user.email,
        templateKey: "class_changed",
        category: "transactional",
        dedupeKey: `class_change:${userId}:${oldClass}->${newClass}:${Date.now()}`,
        vars: {
          name: user.full_name,
          old_class: oldClass,
          new_class: newClass,
        },
      });
    }

    const updatedBatches = getStudentClassFilteredBatches(db, userId);
    const updatedCrossSell = computeStudentCrossSellState(db, userId);

    return res.json({
      ok: true,
      oldClass,
      newClass,
      classBatches: updatedBatches,
      crossSell: updatedCrossSell,
    });
  });

  // ── 5. Admin Editable Teacher Details (Change 13) ──
  router.get("/v31/teachers/:id/details", requireAdmin, (req, res) => {
    const userId = Number(req.params.id);
    const user = db.prepare("SELECT id, full_name, email, phone, photo_url, dob, is_active, verification_status, deleted_at FROM users WHERE id = ? LIMIT 1").get(userId);
    if (!user) return res.status(404).json({ error: "Teacher not found." });

    const tp = db.prepare("SELECT * FROM teacher_profiles WHERE user_id = ? LIMIT 1").get(userId) || {};
    let batchActiveStudents = 0;
    try {
      const cnt = db.prepare(`
        SELECT COUNT(DISTINCT e.student_id) AS c
        FROM enrollments e
        JOIN batches b ON b.id = e.batch_id
        JOIN users u ON u.id = e.student_id
        WHERE b.teacher_id = ? AND u.is_active = 1 AND COALESCE(u.deleted_at, '') = ''
          AND LOWER(COALESCE(u.verification_status, 'approved')) NOT IN ('suspended', 'terminated', 'deleted')
      `).get(userId);
      batchActiveStudents = Number(cnt?.c || 0);
    } catch {
      batchActiveStudents = 0;
    }

    const activeStudentCount = Math.max(Number(tp.active_student_count || 0), batchActiveStudents);
    const totalSeats = Math.max(0, Number(tp.total_seats ?? 30));
    const vacantSeats = Math.max(0, totalSeats - activeStudentCount);

    let referralsCount = Number(tp.referrals_count || 0);
    try {
      const refRow = db.prepare("SELECT COUNT(*) AS c FROM users WHERE referred_by = ?").get(userId);
      referralsCount = Math.max(referralsCount, Number(refRow?.c || 0));
    } catch {
      // ignore if column doesn't exist
    }

    return res.json({
      user,
      details: {
        subjectsTaught: safeParseJsonArray(tp.subjects_taught_json || tp.subjects),
        contractEndDate: tp.contract_end_date || "",
        contractDuration: tp.contract_duration || "",
        totalSeats,
        activeStudentCount,
        vacantSeats,
        seatsFullWarning: vacantSeats === 0,
        referralsCount,
        dob: user.dob || tp.dob || "",
        photoUrl: user.photo_url || "",
      },
    });
  });

  router.patch("/v31/teachers/:id/details", requireAdmin, (req, res) => {
    const userId = Number(req.params.id);
    const user = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'teacher' LIMIT 1").get(userId);
    if (!user) return res.status(404).json({ error: "Teacher not found." });

    const beforeTp = db.prepare("SELECT * FROM teacher_profiles WHERE user_id = ? LIMIT 1").get(userId) || {};
    const body = req.body || {};

    if (body.dob && isFutureIstDate(body.dob)) {
      return res.status(400).json({ error: "Date of Birth cannot be a future date (IST)." });
    }

    const subjectsTaught = safeParseJsonArray(body.subjectsTaught ?? beforeTp.subjects_taught_json);
    const contractEndDate = String(body.contractEndDate ?? beforeTp.contract_end_date ?? "").trim();
    const contractDuration = String(body.contractDuration ?? beforeTp.contract_duration ?? "").trim();
    const totalSeats = Math.max(0, Number(body.totalSeats ?? beforeTp.total_seats ?? 30));
    const activeStudentCount = Math.max(0, Number(body.activeStudentCount ?? beforeTp.active_student_count ?? 0));
    const vacantSeats = Math.max(0, totalSeats - activeStudentCount);
    const referralsCount = Math.max(0, Number(body.referralsCount ?? beforeTp.referrals_count ?? 0));
    const dob = String(body.dob ?? user.dob ?? "").trim();

    db.prepare(`
      INSERT INTO teacher_profiles (user_id, subjects_taught_json, contract_end_date, contract_duration, total_seats, active_student_count, referrals_count, dob)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        subjects_taught_json = excluded.subjects_taught_json,
        contract_end_date = excluded.contract_end_date,
        contract_duration = excluded.contract_duration,
        total_seats = excluded.total_seats,
        active_student_count = excluded.active_student_count,
        referrals_count = excluded.referrals_count,
        dob = excluded.dob
    `).run(
      userId,
      JSON.stringify(subjectsTaught),
      contractEndDate,
      contractDuration,
      totalSeats,
      activeStudentCount,
      referralsCount,
      dob
    );

    db.prepare("UPDATE users SET dob = ?, updated_at = datetime('now') WHERE id = ?").run(dob, userId);

    // Sync total_seats & seat_limit to teacher's active batches if present
    try {
      db.prepare("UPDATE batches SET total_seats = ?, seat_limit = ? WHERE teacher_id = ?").run(totalSeats, totalSeats, userId);
    } catch {
      // ignore
    }

    logV31Audit(db, {
      actorId: req.auth?.user?.id,
      actorName: req.auth?.user?.full_name || "Admin",
      actorRole: req.auth?.user?.role || "admin",
      action: "teacher_details_updated",
      entityType: "teacher",
      entityId: String(userId),
      summary: `Updated teacher details for ${user.full_name} (Seats: ${totalSeats}, Active: ${activeStudentCount}, Vacant: ${vacantSeats})`,
      before: { total_seats: beforeTp.total_seats, active_student_count: beforeTp.active_student_count },
      after: { subjectsTaught, contractEndDate, contractDuration, totalSeats, activeStudentCount, vacantSeats, referralsCount },
    });

    return res.json({
      ok: true,
      details: {
        subjectsTaught,
        contractEndDate,
        contractDuration,
        totalSeats,
        activeStudentCount,
        vacantSeats,
        seatsFullWarning: vacantSeats === 0,
        referralsCount,
        dob,
      },
    });
  });

  // ── 6. Mail Templates CRUD + Live Preview + Send Test + Mail Logs (Change 7) ──
  const MAIL_PLACEHOLDERS = [
    "{{name}}",
    "{{course}}",
    "{{discount}}",
    "{{login_link}}",
    "{{unsubscribe_link}}",
    "{{class_name}}",
    "{{school_name}}",
    "{{reason}}",
    "{{note}}",
    "{{ist_date}}",
  ];
  const SYSTEM_TEMPLATE_KEYS = new Set([
    "student_welcome_admission",
    "teacher_welcome_profile",
    "staff_welcome_profile",
    "account_suspended",
    "account_terminated",
    "account_reactivated",
    "class_changed",
    "fee_invoice_reminder",
    "cross_sell_weekly_offer",
    "general_announcement",
  ]);
  const mapTemplateRow = (t) => ({
    ...t,
    slug: t.template_key,
    html_body: t.body_html,
    is_long_mail: Number(String(t.body_html || "").length > 500 || t.template_key === "general_announcement"),
    is_system: SYSTEM_TEMPLATE_KEYS.has(t.template_key) ? 1 : 0,
  });

  router.get("/v31/mail-templates", requireAdmin, (_req, res) => {
    const templates = db.prepare("SELECT * FROM v31_mail_templates ORDER BY id ASC").all().map(mapTemplateRow);
    const themes = Object.values(MAIL_THEMES).map((th) => ({ ...th, label: th.name }));
    res.json({ templates, themes, placeholders: MAIL_PLACEHOLDERS });
  });

  router.post("/v31/mail-templates", requireAdmin, (req, res) => {
    const body = req.body || {};
    const name = String(body.name || "").trim();
    const subject = String(body.subject || "").trim();
    const rawHtml = String(body.htmlBody || body.body_html || body.bodyHtml || "").trim();
    const themeKey = MAIL_THEMES[body.themeKey || body.theme_key] ? (body.themeKey || body.theme_key) : "yuitor_navy";
    const audience = String(body.audience || body.category || "all").trim();
    const category = body.category === "promotional" || body.category === "cross_sell" ? "promotional" : "transactional";
    if (!name || !subject || !rawHtml) {
      return res.status(400).json({ error: "Template name, subject, and HTML body are required." });
    }
    const cleanHtml = sanitizeMailHtml(rawHtml);
    const keyBase = String(body.template_key || body.slug || name)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_|_$/g, "");
    const templateKey = `${keyBase || "custom"}_${Date.now().toString(36)}`;

    const result = db.prepare(`
      INSERT INTO v31_mail_templates (template_key, name, audience, category, theme_key, subject, body_html, updated_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(templateKey, name, audience, category, themeKey, subject, cleanHtml, req.auth?.user?.id ?? null);

    const created = mapTemplateRow(db.prepare("SELECT * FROM v31_mail_templates WHERE id = ?").get(Number(result.lastInsertRowid)));
    logV31Audit(db, {
      actorId: req.auth?.user?.id,
      actorName: req.auth?.user?.full_name || "Admin",
      action: "mail_template_created",
      entityType: "mail_template",
      entityId: String(created.id),
      summary: `Created mail template "${name}"`,
    });
    return res.status(201).json({ ok: true, id: created.id, template: created });
  });

  router.put("/v31/mail-templates/:id", requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM v31_mail_templates WHERE id = ? LIMIT 1").get(id);
    if (!existing) return res.status(404).json({ error: "Mail template not found." });

    const body = req.body || {};
    const name = String(body.name ?? existing.name).trim();
    const subject = String(body.subject ?? existing.subject).trim();
    const cleanHtml = sanitizeMailHtml(body.htmlBody ?? body.body_html ?? body.bodyHtml ?? existing.body_html);
    const reqTheme = body.themeKey || body.theme_key;
    const themeKey = MAIL_THEMES[reqTheme] ? reqTheme : existing.theme_key;
    const category =
      body.category === "promotional" || body.category === "cross_sell"
        ? "promotional"
        : body.category === "transactional"
          ? "transactional"
          : existing.category;
    const audience = String(body.audience ?? body.category ?? existing.audience).trim();

    db.prepare(`
      UPDATE v31_mail_templates
      SET name = ?, subject = ?, body_html = ?, theme_key = ?, category = ?, audience = ?, updated_by = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(name, subject, cleanHtml, themeKey, category, audience, req.auth?.user?.id ?? null, id);

    const updated = mapTemplateRow(db.prepare("SELECT * FROM v31_mail_templates WHERE id = ?").get(id));
    logV31Audit(db, {
      actorId: req.auth?.user?.id,
      actorName: req.auth?.user?.full_name || "Admin",
      action: "mail_template_updated",
      entityType: "mail_template",
      entityId: String(id),
      summary: `Updated mail template "${name}" (theme: ${themeKey})`,
    });
    return res.json({ ok: true, template: updated });
  });

  router.delete("/v31/mail-templates/:id", requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM v31_mail_templates WHERE id = ? LIMIT 1").get(id);
    if (!existing) return res.status(404).json({ error: "Mail template not found." });
    if (SYSTEM_TEMPLATE_KEYS.has(existing.template_key)) {
      return res.status(400).json({ error: "Built-in system templates cannot be deleted; you can edit them instead." });
    }
    db.prepare("DELETE FROM v31_mail_templates WHERE id = ?").run(id);
    logV31Audit(db, {
      actorId: req.auth?.user?.id,
      actorName: req.auth?.user?.full_name || "Admin",
      action: "mail_template_deleted",
      entityType: "mail_template",
      entityId: String(id),
      summary: `Deleted custom mail template "${existing.name}"`,
    });
    return res.json({ ok: true });
  });

  router.post("/v31/mail-templates/preview", requireAdmin, (req, res) => {
    const body = req.body || {};
    const htmlInput = body.htmlBody ?? body.body_html ?? "";
    const themeKey = body.themeKey || body.theme_key || "yuitor_navy";
    const subject = body.subject || "Preview Mail";
    const category = body.category || "transactional";
    const rendered = applyMailTheme(themeKey, htmlInput, {
      subject,
      unsubscribeLink: category === "promotional" ? "#unsubscribe-preview" : "",
    });
    res.json({ ok: true, sanitizedBody: sanitizeMailHtml(htmlInput), renderedHtml: rendered, themedHtml: rendered });
  });

  const handleTestSend = async (req, res) => {
    const body = req.body || {};
    const target = String(body.to || req.auth?.user?.email || "").trim();
    if (!target) return res.status(400).json({ error: "Test recipient email is required." });

    const result = await sendV31Mail(db, deps, {
      to: target,
      templateKey: body.template_key || body.slug || null,
      subject: body.subject ? `[TEST] ${body.subject}` : "[TEST] Yuitor Mail Template Preview",
      bodyHtml: body.htmlBody || body.body_html || "<p>Test email from Yuitor Mail Templates.</p>",
      themeKey: body.themeKey || body.theme_key || "yuitor_navy",
      category: body.category || "transactional",
      forceResend: true,
      vars: {
        name: "Aarav Sharma (Preview)",
        course: "Class 10 Mathematics Mastery",
        discount: "20",
        class_name: "Class 10",
        school_name: "Delhi Public School",
        reason: "Administrative Verification",
        note: "Sample test note for preview",
      },
    });
    return res.json(result);
  };
  router.post("/v31/mail-templates/send-test", requireAdmin, handleTestSend);
  router.post("/v31/mail-templates/test-send", requireAdmin, handleTestSend);

  router.get("/v31/mail-logs", requireAdmin, (req, res) => {
    const status = String(req.query.status || "all").toLowerCase();
    const limit = Math.min(200, Math.max(10, Number(req.query.limit) || 100));
    const rows = status !== "all"
      ? db.prepare(`
          SELECT l.id, l.user_id, l.to_email, l.subject, l.template_key, l.category, l.theme_key,
                 l.status, l.attempts, l.error_message, l.sent_at_ist, l.created_at,
                 u.full_name AS recipient_name
          FROM v31_mail_logs l
          LEFT JOIN users u ON u.id = l.user_id
          WHERE l.status = ?
          ORDER BY l.id DESC LIMIT ?
        `).all(status, limit)
      : db.prepare(`
          SELECT l.id, l.user_id, l.to_email, l.subject, l.template_key, l.category, l.theme_key,
                 l.status, l.attempts, l.error_message, l.sent_at_ist, l.created_at,
                 u.full_name AS recipient_name
          FROM v31_mail_logs l
          LEFT JOIN users u ON u.id = l.user_id
          ORDER BY l.id DESC LIMIT ?
        `).all(limit);
    const logs = rows.map((r) => ({
      ...r,
      recipient_email: r.to_email,
      mail_type: r.template_key || r.category || "transactional",
      sent_at: r.sent_at_ist || r.created_at,
    }));
    res.json({ logs });
  });

  router.post("/v31/mail-logs/:id/resend", requireAdmin, async (req, res) => {
    const id = Number(req.params.id);
    const log = db.prepare("SELECT * FROM v31_mail_logs WHERE id = ? LIMIT 1").get(id);
    if (!log) return res.status(404).json({ error: "Mail log not found." });

    const result = await sendV31Mail(db, deps, {
      to: log.to_email,
      userId: log.user_id,
      subject: log.subject,
      bodyHtml: log.rendered_html || `<p>${log.subject}</p>`,
      themeKey: log.theme_key || "yuitor_navy",
      category: log.category || "transactional",
      forceResend: true,
    });
    return res.json(result);
  });

  // ── 7. Cross-Sell Settings + Dry-Run Preview + Manual Trigger (Change 14) ──
  router.get("/v31/cross-sell/settings", requireAdmin, (_req, res) => {
    res.json(getCrossSellSettings(db));
  });

  const handleSaveCrossSellSettings = (req, res) => {
    const prev = getCrossSellSettings(db);
    const masterSwitch = req.body?.masterSwitch ? 1 : 0;
    const post4WeekBehavior = req.body?.post4WeekBehavior === "hold_40" ? "hold_40" : "stop";

    db.prepare(`
      UPDATE v31_cross_sell_settings
      SET master_switch = ?, post_4_week_behavior = ?, updated_by = ?, updated_at = datetime('now')
      WHERE id = 1
    `).run(masterSwitch, post4WeekBehavior, req.auth?.user?.id ?? null);

    logV31Audit(db, {
      actorId: req.auth?.user?.id,
      actorName: req.auth?.user?.full_name || "Admin",
      action: "cross_sell_settings_updated",
      entityType: "cross_sell",
      entityId: "1",
      summary: `Cross-Sell Master Switch set to ${masterSwitch ? "ON" : "OFF"}, Post-4-week set to "${post4WeekBehavior}"`,
      before: prev,
      after: { masterSwitch: Boolean(masterSwitch), post4WeekBehavior },
    });

    res.json({ ok: true, ...getCrossSellSettings(db) });
  };
  router.put("/v31/cross-sell/settings", requireAdmin, handleSaveCrossSellSettings);
  router.patch("/v31/cross-sell/settings", requireAdmin, handleSaveCrossSellSettings);

  const handleCrossSellPreview = async (_req, res) => {
    const report = await runCrossSellWeeklyDispatch(db, deps, { dryRun: true });
    res.json({
      ...report,
      totalEligible: report.eligibleCount,
      students: (report.eligibleStudents || []).map((s) => ({
        ...s,
        classLevel: s.className,
        availableCourses: s.courses,
        alreadyMailedThisWeek: s.alreadySentThisWeek,
      })),
    });
  };
  router.get("/v31/cross-sell/preview", requireAdmin, handleCrossSellPreview);
  router.get("/v31/cross-sell/preview-eligible", requireAdmin, handleCrossSellPreview);

  const handleCrossSellDispatch = async (_req, res) => {
    const report = await runCrossSellWeeklyDispatch(db, deps, { dryRun: false });
    res.json({
      ...report,
      skipped: Boolean(report.skippedAll),
      sent: Number(report.sentCount || 0),
      failed: Number(report.failedCount || 0),
      skippedCount: Math.max(0, Number(report.eligibleCount || 0) - Number(report.sentCount || 0) - Number(report.failedCount || 0)),
    });
  };
  router.post("/v31/cross-sell/dispatch-now", requireAdmin, handleCrossSellDispatch);
  router.post("/v31/cross-sell/run-dispatch", requireAdmin, handleCrossSellDispatch);

  // ── 8. IST Audit Log Viewer (Safety Rule 5) ──
  router.get("/v31/audit-logs", requireAdmin, (req, res) => {
    const actionFilter = String(req.query.action || "").trim().toLowerCase();
    const q = String(req.query.q || req.query.search || "").trim().toLowerCase();
    const limit = Math.min(300, Math.max(10, Number(req.query.limit) || 150));

    let rows = db.prepare("SELECT * FROM v31_audit_logs ORDER BY id DESC LIMIT ?").all(limit);
    if (actionFilter && actionFilter !== "all") {
      rows = rows.filter((r) => String(r.action || "").toLowerCase().includes(actionFilter));
    }
    if (q) {
      rows = rows.filter((r) =>
        `${r.actor_name} ${r.action} ${r.entity_type} ${r.entity_id} ${r.summary} ${r.ist_timestamp}`.toLowerCase().includes(q)
      );
    }
    const logs = rows.map((r) => ({
      ...r,
      target_name: `${r.entity_type}${r.entity_id ? ` #${r.entity_id}` : ""}`,
      details: r.summary,
      created_at: r.ist_timestamp || r.created_at,
    }));
    res.json({ logs, serverTimeIst: getIstTimestamp() });
  });

  // ── 9. User Tab Counts Helper ──
  router.get("/v31/users/tab-counts", requireAdmin, (req, res) => {
    const roleFilter = String(req.query.role || "").trim().toLowerCase();
    const users = roleFilter && roleFilter !== "all"
      ? db.prepare("SELECT is_active, verification_status, deleted_at FROM users WHERE LOWER(role) = ?").all(roleFilter)
      : db.prepare("SELECT is_active, verification_status, deleted_at FROM users").all();
    const counts = { active: 0, suspended: 0, terminated: 0, others: 0 };
    for (const u of users) {
      counts[classifyUserStatusTab(u)] += 1;
    }
    res.json({ counts });
  });

  // ── 10. Download Final v3.1 Release ZIP (Admin Authenticated) ──
  router.get("/v31/download-release", requireAdmin, (_req, res) => {
    const zipPath = path.resolve(process.cwd(), "yuitor-smart-classes-v3.1.zip");
    if (!fs.existsSync(zipPath)) {
      return res.status(404).json({ error: "yuitor-smart-classes-v3.1.zip not found." });
    }
    res.setHeader("X-Robots-Tag", "noindex, nofollow");
    return res.download(zipPath, "yuitor-smart-classes-v3.1.zip");
  });

  return router;
}

export function createV31UserRouter(db, deps = {}) {
  const router = express.Router();
  const requireAuth = deps.requireAuth || ((_req, _res, next) => next());

  // ── 1. Post-Registration Profile Details (Change 9) ──
  const handleGetProfile = (req, res) => {
    const userId = Number(req.auth?.user?.id);
    const user = db.prepare(`
      SELECT id, role, full_name, email, phone, photo_url, profile_photo, avatar_url, dob, address, school_name, welcome_mail_sent_at, promo_unsubscribed
      FROM users WHERE id = ? LIMIT 1
    `).get(userId);
    if (!user) return res.status(404).json({ error: "User not found." });

    let currentClass = "";
    if (user.role === "student") {
      const sp = db.prepare("SELECT class_level, school_name, address, dob FROM student_profiles WHERE user_id = ? LIMIT 1").get(userId);
      currentClass = sp?.class_level || "";
      if (!user.school_name && sp?.school_name) user.school_name = sp.school_name;
      if (!user.address && sp?.address) user.address = sp.address;
      if (!user.dob && sp?.dob) user.dob = sp.dob;
    }

    const effectivePhoto = user.photo_url || user.profile_photo || user.avatar_url || "";
    const completed = Boolean(
      user.dob && (user.role !== "student" || (user.address && user.school_name))
    );
    const todayIst = getIstTimestamp().slice(0, 10);

    return res.json({
      todayIst,
      user: {
        id: user.id,
        role: user.role,
        fullName: user.full_name,
        email: user.email,
        photoUrl: effectivePhoto,
        dob: user.dob || "",
        address: user.address || "",
        schoolName: user.school_name || "",
        currentClass,
        completed,
        welcomeMailSent: Boolean(user.welcome_mail_sent_at),
      },
      profile: {
        ...user,
        photo_url: effectivePhoto,
        currentClass,
        completed,
        welcomeMailSent: Boolean(user.welcome_mail_sent_at),
      },
    });
  };
  router.get("/v31/profile", requireAuth, handleGetProfile);
  router.get("/v31/my-profile", requireAuth, handleGetProfile);

  const handleSaveProfile = async (req, res) => {
    const userId = Number(req.auth?.user?.id);
    const user = db.prepare("SELECT * FROM users WHERE id = ? LIMIT 1").get(userId);
    if (!user) return res.status(404).json({ error: "User not found." });

    if (!["student", "teacher", "staff"].includes(user.role)) {
      return res.status(403).json({ error: "Post-registration profile update is for Student, Teacher, and Staff roles." });
    }

    const body = req.body || {};
    const dob = String(body.dob || "").trim();
    if (!dob || !/^\d{4}-\d{2}-\d{2}$/.test(dob)) {
      return res.status(400).json({ error: "Please enter a valid Date of Birth (YYYY-MM-DD)." });
    }
    if (isFutureIstDate(dob)) {
      return res.status(400).json({ error: "Date of Birth cannot be a future date (IST)." });
    }

    let photoUrl = user.photo_url || user.profile_photo || user.avatar_url || "";
    if (body.photoDataUrl) {
      const saved = saveBase64ProfilePhoto(body.photoDataUrl, deps.uploadsDir, userId);
      if (!saved.ok) return res.status(400).json({ error: saved.error });
      photoUrl = saved.photoUrl;
    }

    let address = user.address || "";
    let schoolName = user.school_name || "";
    if (user.role === "student") {
      address = String(body.address || "").trim();
      schoolName = String(body.schoolName || body.school_name || "").trim();
      if (!address || !schoolName) {
        return res.status(400).json({ error: "Address and School Name are required for students." });
      }
      db.prepare(`
        INSERT INTO student_profiles (user_id, address, school_name, dob)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
          address = excluded.address,
          school_name = excluded.school_name,
          dob = excluded.dob
      `).run(userId, address, schoolName, dob);
    } else if (user.role === "teacher") {
      db.prepare(`
        INSERT INTO teacher_profiles (user_id, dob)
        VALUES (?, ?)
        ON CONFLICT(user_id) DO UPDATE SET dob = excluded.dob
      `).run(userId, dob);
    }

    db.prepare(`
      UPDATE users
      SET photo_url = ?, profile_photo = ?, avatar_url = ?, dob = ?, address = ?, school_name = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(photoUrl, photoUrl, photoUrl, dob, address, schoolName, userId);

    // Send 1 detailed welcome mail on FIRST save only!
    let welcomeMailResult = null;
    if (!user.welcome_mail_sent_at && user.email) {
      const tplKey =
        user.role === "student"
          ? "student_welcome_admission"
          : user.role === "teacher"
            ? "teacher_welcome_profile"
            : "staff_welcome_profile";
      const sp = user.role === "student"
        ? db.prepare("SELECT class_level, enrolled_subjects_json FROM student_profiles WHERE user_id = ? LIMIT 1").get(userId)
        : null;

      welcomeMailResult = await sendV31Mail(db, deps, {
        userId,
        to: user.email,
        templateKey: tplKey,
        category: "transactional",
        dedupeKey: `first_profile_welcome:${userId}`,
        vars: {
          name: user.full_name,
          class_name: sp?.class_level || "Assigned Class",
          school_name: schoolName || "N/A",
          course: safeParseJsonArray(sp?.enrolled_subjects_json).join(", ") || "Yuitor Program",
        },
      });

      if (welcomeMailResult?.ok) {
        db.prepare("UPDATE users SET welcome_mail_sent_at = ? WHERE id = ?").run(getIstTimestamp(), userId);
      }
    }

    const sentNow = Boolean(welcomeMailResult?.ok && !welcomeMailResult?.skipped);
    return res.json({
      ok: true,
      photoUrl,
      welcomeMailSentNow: sentNow,
      message: sentNow
        ? "Profile saved! Your official Yuitor welcome confirmation email has been sent."
        : "Profile details saved successfully.",
      profile: {
        photoUrl,
        dob,
        address,
        schoolName,
        welcomeMailSentNow: sentNow,
      },
    });
  };
  router.post("/v31/profile", requireAuth, handleSaveProfile);
  router.post("/v31/my-profile", requireAuth, handleSaveProfile);

  // ── 2. Student Panel Class-Filtered Batch Details (Change 15) & Cross-Sell (Change 14) ──
  router.get("/v31/student/overview", requireAuth, (req, res) => {
    const userId = Number(req.auth?.user?.id);
    if (req.auth?.user?.role !== "student") {
      return res.status(403).json({ error: "Student access required." });
    }
    const classBatches = getStudentClassFilteredBatches(db, userId);
    const crossSell = computeStudentCrossSellState(db, userId);
    return res.json({ classBatches, crossSell });
  });

  // ── 3. Server-Side Tamper-Proof Cross-Sell Quote Check (Change 14) ──
  router.post("/v31/student/checkout-quote", requireAuth, (req, res) => {
    const userId = Number(req.auth?.user?.id);
    const courseId = Number(req.body?.courseId);
    const plan = req.body?.plan === "monthly" ? "monthly" : "yearly";
    const couponCode = String(req.body?.couponCode || "").trim();
    const useCrossSell = req.body?.useCrossSell !== false;
    const course = db.prepare("SELECT id, title, monthly_fee, yearly_fee FROM courses WHERE id = ? LIMIT 1").get(courseId);
    if (!course) return res.status(404).json({ error: "Course not found." });

    const basePrice = plan === "monthly" ? Number(course.monthly_fee || 0) : Number(course.yearly_fee || course.monthly_fee || 0);
    const quote = calculateServerSideCourseCheckout(db, {
      userId,
      courseId,
      basePrice,
      couponCode,
      useCrossSell,
    });
    if (!quote.ok) return res.status(400).json(quote);
    return res.json({ ok: true, courseTitle: course.title, plan, ...quote });
  });

  // ── 4. Student Unsubscribe Promo Toggle (Safety Rule 4) ──
  router.post("/v31/promo-preferences", requireAuth, (req, res) => {
    const userId = Number(req.auth?.user?.id);
    const unsubscribed = req.body?.promoUnsubscribed ? 1 : 0;
    db.prepare("UPDATE users SET promo_unsubscribed = ?, updated_at = datetime('now') WHERE id = ?").run(unsubscribed, userId);
    if (unsubscribed) {
      db.prepare("UPDATE v31_cross_sell_offers SET status = 'unsubscribed', updated_at = datetime('now') WHERE user_id = ?").run(userId);
    }
    return res.json({ ok: true, promoUnsubscribed: Boolean(unsubscribed) });
  });

  // Expose helper to mark purchase if called internally
  router.markCrossSellPurchased = markCrossSellPurchased;
  return router;
}
