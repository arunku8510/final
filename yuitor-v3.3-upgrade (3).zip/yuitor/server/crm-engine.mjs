import crypto from "node:crypto";
import { nowIso, runInImmediateTx } from "./addons-db.mjs";
import { getAutomationConfig } from "./crm-db.mjs";

export const SYSTEM_EVENTS = [
  "lead.created",
  "lead.followup_due",
  "admission.completed",
  "payment.received",
  "payment.overdue",
  "attendance.absent",
  "attendance.submitted",
  "class.started",
  "test.completed",
  "teacher.leave_approved",
  "course.ending"
];

export const FOLLOWUP_CADENCE_MINUTES = [10, 180, 1440, 4320, 10080, 20160];

export function getIstDateParts(date = new Date()) {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    weekday: "long",
    hour12: false
  });
  const parts = Object.fromEntries(fmt.formatToParts(date).map((p) => [p.type, p.value]));
  const hour = Number(parts.hour === "24" ? 0 : parts.hour || 0);
  const minute = Number(parts.minute || 0);
  const day = Number(parts.day || 1);
  return {
    dateStr: `${parts.year}-${parts.month}-${parts.day}`,
    monthStr: `${parts.year}-${parts.month}`,
    year: Number(parts.year),
    month: Number(parts.month),
    day,
    hour,
    minute,
    weekday: parts.weekday || "Monday",
    hm: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`
  };
}

export function isWithinQuietHoursIst(date = new Date(), startHour = 21, endHour = 8) {
  const { hour } = getIstDateParts(date);
  if (startHour === endHour) return false;
  if (startHour > endHour) {
    return hour >= startHour || hour < endHour;
  }
  return hour >= startHour && hour < endHour;
}

export function normalizeIndianPhone(raw) {
  const digits = String(raw ?? "").replace(/\D+/g, "");
  if (digits.length === 12 && digits.startsWith("91")) return digits.slice(2);
  if (digits.length === 11 && digits.startsWith("0")) return digits.slice(1);
  return digits.slice(-10);
}

export function buildWhatsAppClickToChatUrl(phone, message) {
  const ten = normalizeIndianPhone(phone);
  if (ten.length < 10) return "";
  return `https://wa.me/91${ten}?text=${encodeURIComponent(String(message || "").trim())}`;
}

export function renderStandardMessage(templateKey, vars = {}) {
  const name = vars.studentName || vars.name || "Student";
  const amount = Number(vars.amount || 0).toLocaleString("en-IN");
  const course = vars.courseTitle || "coaching";
  const dateStr = vars.date || getIstDateParts().dateStr;
  switch (templateKey) {
    case "fee_reminder":
      return `Namaste, ${name}'s pending coaching fee is ₹${amount}${vars.dueDate ? ` (due ${vars.dueDate})` : ""}. Kindly clear the pending amount.${vars.paymentUrl ? ` Pay online: ${vars.paymentUrl}` : ""} Thank you — Yuitor Smart Institute.`;
    case "absence_alert":
      return `Namaste, ${name} was absent from today's (${dateStr}) coaching class${vars.batchName ? ` (${vars.batchName})` : ""}. Please confirm the reason. — Yuitor Smart Institute.`;
    case "low_attendance_warning":
      return `Namaste, ${name}'s coaching attendance has dropped to ${vars.attendancePercent || 0}% (below ${vars.threshold || 75}%). Regular attendance is important for board & exam results. — Yuitor Smart Institute.`;
    case "lead_welcome":
      return `Namaste ${name}, thank you for contacting Yuitor Smart Institute for ${course}. Our counsellor will connect with you shortly to schedule a free demo class.`;
    case "demo_reminder":
      return `Namaste ${name}, reminder for your Yuitor Smart Institute demo class on ${vars.demoDate || dateStr} ${vars.demoSlot || ""}. We look forward to welcoming you!`;
    case "payment_receipt":
      return `Namaste ${name}, we have received ₹${amount} toward ${course} fees (Receipt ${vars.receiptNo || "Verified"}). Thank you — Yuitor Smart Institute.`;
    case "admission_welcome":
      return `Welcome to Yuitor Smart Institute, ${name}! Your admission is confirmed${vars.rollNumber ? ` (Roll No: ${vars.rollNumber})` : ""}. Sign in to the Student Portal to access your ID Card, timetable, notes, and tests.`;
    case "course_renewal":
      return `Namaste ${name}, your ${course} enrollment completes soon. Renew early to retain your batch seat and scholarship continuity. — Yuitor Smart Institute.`;
    default:
      return vars.message || `Update from Yuitor Smart Institute regarding ${name}.`;
  }
}

export function computeLeadScore(lead = {}) {
  let score = 25;
  const phone = normalizeIndianPhone(lead.phone);
  if (phone.length === 10) score += 15;
  if (String(lead.email || "").includes("@")) score += 8;
  const src = String(lead.source || lead.utm_source || "").toLowerCase();
  if (src.includes("walk") || src.includes("qr") || src.includes("referral")) score += 20;
  else if (src.includes("whatsapp") || src.includes("missed_call") || src.includes("call")) score += 16;
  else if (src.includes("google") || src.includes("facebook") || src.includes("meta")) score += 12;
  else score += 8;

  const target = String(lead.class_or_course || lead.course || "").toLowerCase();
  if (/(jee|neet|cuet|class 10|class 12|10th|12th|ssc|nda)/i.test(target)) score += 15;
  else if (target.trim()) score += 8;

  if (lead.demo_date) score += 15;
  if (String(lead.message || "").trim().length >= 15) score += 7;
  return Math.max(0, Math.min(100, Math.round(score)));
}

export function calculateCbtResult(questions = [], answers = {}, marking = {}) {
  const pos = Number(marking.positiveMarks ?? 4);
  const neg = Number(marking.negativeMarks ?? 1);
  let correct = 0;
  let wrong = 0;
  let unanswered = 0;
  let score = 0;
  const topicStats = new Map();

  questions.forEach((q, idx) => {
    const hasExplicitId = q.id !== undefined && q.id !== null;
    const qId = String(hasExplicitId ? q.id : idx);
    const topic = String(q.topic || q.chapter || q.subject || "General").trim() || "General";
    const chosen = hasExplicitId ? answers[qId] : answers[idx];
    if (!topicStats.has(topic)) topicStats.set(topic, { topic, total: 0, correct: 0, wrong: 0, unanswered: 0 });
    const ts = topicStats.get(topic);
    ts.total += 1;

    if (chosen === undefined || chosen === null || chosen === "") {
      unanswered += 1;
      ts.unanswered += 1;
      return;
    }
    const isCorrect =
      String(chosen).trim().toLowerCase() === String(q.correctAnswer ?? q.correct_index ?? q.answer ?? "").trim().toLowerCase();
    if (isCorrect) {
      correct += 1;
      score += pos;
      ts.correct += 1;
    } else {
      wrong += 1;
      score -= neg;
      ts.wrong += 1;
    }
  });

  const maxMarks = Math.max(1, questions.length * pos);
  const percentage = Number(((Math.max(0, score) / maxMarks) * 100).toFixed(2));
  const topicBreakdown = [...topicStats.values()].map((t) => ({
    ...t,
    accuracy: t.total > 0 ? Math.round((t.correct / t.total) * 100) : 0
  }));
  const weakTopics = topicBreakdown.filter((t) => t.accuracy < 40).map((t) => t.topic);

  return {
    totalQuestions: questions.length,
    correct,
    wrong,
    unanswered,
    score: Number(score.toFixed(2)),
    maxMarks,
    percentage,
    topicBreakdown,
    weakTopics,
    needsRemediation: percentage < 40 || weakTopics.length > 0
  };
}

export function computeRankAndPercentile(allScores = [], targetScore = 0) {
  if (!allScores.length) return { rank: 1, percentile: 100 };
  const sorted = [...allScores].map(Number).sort((a, b) => b - a);
  const higherCount = sorted.filter((s) => s > targetScore).length;
  const rank = higherCount + 1;
  const belowOrEqual = sorted.filter((s) => s <= targetScore).length;
  const percentile = Number(((belowOrEqual / sorted.length) * 100).toFixed(2));
  return { rank, percentile };
}

export function calculateTeacherPayroll(input = {}) {
  const salaryType = String(input.salaryType || "hybrid").toLowerCase();
  const fixedMonthly = Math.max(0, Number(input.fixedMonthly || 0));
  const perClassRate = Math.max(0, Number(input.perClassRate || 0));
  const classesConducted = Math.max(0, Number(input.classesConducted || 0));
  const unpaidLeaveDays = Math.max(0, Number(input.unpaidLeaveDays || 0));
  const incentives = Math.max(0, Number(input.incentives || 0));
  const extraDeductions = Math.max(0, Number(input.deductions || 0));

  let baseAmount = 0;
  if (salaryType === "fixed") baseAmount = fixedMonthly;
  else if (salaryType === "per_class") baseAmount = classesConducted * perClassRate;
  else baseAmount = fixedMonthly + classesConducted * perClassRate;

  const perDayDeduction = fixedMonthly > 0 ? Math.round((fixedMonthly / 30) * unpaidLeaveDays) : 0;
  const totalDeduction = perDayDeduction + extraDeductions;
  const netAmount = Math.max(0, Math.round(baseAmount + incentives - totalDeduction));

  return {
    baseAmount: Math.round(baseAmount),
    bonusAmount: Math.round(incentives),
    deductionAmount: Math.round(totalDeduction),
    netAmount
  };
}

export function calculateStudentRiskScore({ attendancePercent = 100, overdueDays = 0, avgTestPercent = 70, homeworkMissed = 0 } = {}) {
  let score = 0;
  if (attendancePercent < 50) score += 45;
  else if (attendancePercent < 65) score += 32;
  else if (attendancePercent < 75) score += 20;

  if (overdueDays >= 30) score += 25;
  else if (overdueDays >= 15) score += 15;
  else if (overdueDays >= 7) score += 8;

  if (avgTestPercent > 0 && avgTestPercent < 35) score += 25;
  else if (avgTestPercent > 0 && avgTestPercent < 50) score += 15;

  score += Math.min(15, Math.max(0, Number(homeworkMissed || 0)) * 5);
  score = Math.max(0, Math.min(100, Math.round(score)));

  let level = "low";
  if (score >= 70) level = "critical";
  else if (score >= 50) level = "high";
  else if (score >= 25) level = "medium";

  return { riskScore: score, riskLevel: level };
}

export function detectTimetableClash(existingSlots = [], candidate = {}) {
  const toMins = (hhmm) => {
    const [h, m] = String(hhmm || "00:00").split(":").map(Number);
    return (Number.isFinite(h) ? h : 0) * 60 + (Number.isFinite(m) ? m : 0);
  };
  const cStart = toMins(candidate.start_time);
  const cEnd = toMins(candidate.end_time);
  if (cEnd <= cStart) return { clash: true, reason: "End time must be after start time." };

  const cDay = String(candidate.day_of_week || "").trim().toLowerCase();
  const cRoom = String(candidate.room_name || "").trim().toLowerCase();
  const cTeacher = Number(candidate.teacher_id || 0);
  const cBatch = Number(candidate.batch_id || 0);

  for (const s of existingSlots) {
    if (candidate.id && Number(s.id) === Number(candidate.id)) continue;
    if (String(s.day_of_week || "").trim().toLowerCase() !== cDay) continue;
    const sStart = toMins(s.start_time);
    const sEnd = toMins(s.end_time);
    const overlaps = cStart < sEnd && sStart < cEnd;
    if (!overlaps) continue;

    if (cTeacher && Number(s.teacher_id) === cTeacher) {
      return { clash: true, conflictSlotId: s.id, reason: `Teacher already scheduled (${s.start_time}-${s.end_time}).` };
    }
    if (cBatch && Number(s.batch_id) === cBatch) {
      return { clash: true, conflictSlotId: s.id, reason: `Batch already has a class (${s.start_time}-${s.end_time}).` };
    }
    if (cRoom && cRoom !== "online" && String(s.room_name || "").trim().toLowerCase() === cRoom && String(candidate.mode || "offline") !== "online") {
      return { clash: true, conflictSlotId: s.id, reason: `Room "${s.room_name}" is occupied (${s.start_time}-${s.end_time}).` };
    }
  }
  return { clash: false };
}

export function parseCsvRows(csvText = "") {
  const raw = String(csvText || "").replace(/^\uFEFF/, "").trim();
  if (!raw) return { headers: [], rows: [] };
  const lines = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < raw.length; i += 1) {
    const ch = raw[i];
    if (ch === '"') {
      cur += ch;
      if (inQuotes && raw[i + 1] === '"') {
        cur += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if ((ch === "\n" || ch === "\r") && !inQuotes) {
      if (cur.trim()) lines.push(cur);
      cur = "";
    } else {
      cur += ch;
    }
  }
  if (cur.trim()) lines.push(cur);
  if (!lines.length) return { headers: [], rows: [] };

  const splitLine = (line) => {
    const cols = [];
    let cell = "";
    let q = false;
    for (let i = 0; i < line.length; i += 1) {
      const ch = line[i];
      if (ch === '"') {
        if (q && line[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else {
          q = !q;
        }
      } else if (ch === "," && !q) {
        cols.push(cell.trim());
        cell = "";
      } else {
        cell += ch;
      }
    }
    cols.push(cell.trim());
    return cols;
  };

  const headers = splitLine(lines[0]).map((h) => h.toLowerCase().replace(/\s+/g, "_"));
  const rows = lines.slice(1).map((line, index) => {
    const vals = splitLine(line);
    const obj = { _rowNumber: index + 2 };
    headers.forEach((h, i) => {
      obj[h] = vals[i] ?? "";
    });
    return obj;
  });
  return { headers, rows };
}

export function computeCostPerAdmission(spendAmount = 0, admissionsCount = 0) {
  const spend = Math.max(0, Number(spendAmount || 0));
  const adm = Math.max(0, Number(admissionsCount || 0));
  if (adm === 0) return spend > 0 ? spend : 0;
  return Math.round(spend / adm);
}

// ==================== DB-BACKED EVENT BUS, RULE ENGINE, JOB QUEUE & SAFETY ====================

export function createExceptionItem(db, item = {}) {
  const now = nowIso();
  const res = db
    .prepare(
      `INSERT INTO crm_exception_inbox (
        category, severity, title, summary, entity_type, entity_id,
        details_json, status, escalation_level, assigned_to, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, ?, ?)`
    )
    .run(
      String(item.category || "failed_job"),
      ["low", "medium", "high", "critical"].includes(item.severity) ? item.severity : "medium",
      String(item.title || "Action Required").slice(0, 180),
      String(item.summary || "").slice(0, 500),
      String(item.entityType || ""),
      String(item.entityId || ""),
      JSON.stringify(item.details || {}),
      ["system", "staff", "team_lead", "owner"].includes(item.escalationLevel) ? item.escalationLevel : "staff",
      item.assignedTo || null,
      now,
      now
    );
  return Number(res.lastInsertRowid);
}

export function checkMessageSafetyGate(db, { userId = null, phone = "", channel = "email", now = new Date() } = {}) {
  const cfg = getAutomationConfig(db);
  if (Number(cfg.global_kill_switch) === 1) {
    return { allowed: false, reason: "global_kill_switch_active" };
  }
  if (Number(cfg.quiet_hours_enabled) === 1 && isWithinQuietHoursIst(now, cfg.quiet_start_hour, cfg.quiet_end_hour)) {
    return { allowed: false, deferUntilNextMorning: true, reason: "quiet_hours_ist" };
  }

  const normPhone = normalizeIndianPhone(phone);
  const consent = normPhone
    ? db.prepare("SELECT * FROM crm_message_consent WHERE phone = ? LIMIT 1").get(normPhone)
    : userId
      ? db.prepare("SELECT * FROM crm_message_consent WHERE user_id = ? LIMIT 1").get(userId)
      : null;

  if (consent) {
    if (Number(consent.opted_out_all) === 1) return { allowed: false, reason: "recipient_opted_out" };
    if (channel === "whatsapp" && Number(consent.whatsapp_opt_in) === 0) return { allowed: false, reason: "whatsapp_opt_out" };
    if (channel === "sms" && Number(consent.sms_opt_in) === 0) return { allowed: false, reason: "sms_opt_out" };
    if (channel === "email" && Number(consent.email_opt_in) === 0) return { allowed: false, reason: "email_opt_out" };
  }

  // Max automatic messages per student per day (default 3)
  const todayIst = getIstDateParts(now).dateStr;
  const maxPerDay = Math.max(1, Number(cfg.max_auto_messages_per_day || 3));
  let sentToday = 0;
  if (userId) {
    sentToday = Number(
      db
        .prepare(
          `SELECT COUNT(*) AS c FROM alert_dispatch_logs
           WHERE recipient_user_id = ? AND substr(created_at, 1, 10) = ? AND status != 'failed'`
        )
        .get(userId, todayIst)?.c || 0
    );
  } else if (normPhone) {
    sentToday = Number(
      db
        .prepare(
          `SELECT COUNT(*) AS c FROM alert_dispatch_logs
           WHERE recipient_contact LIKE ? AND substr(created_at, 1, 10) = ? AND status != 'failed'`
        )
        .get(`%${normPhone}%`, todayIst)?.c || 0
    );
  }
  if (sentToday >= maxPerDay) {
    return { allowed: false, reason: `daily_cap_reached_${maxPerDay}` };
  }
  return { allowed: true };
}

export function enqueueAutomationJob(db, { jobType, ruleKey = "", idempotencyKey, payload = {}, runAt = nowIso(), maxAttempts = 3 }) {
  const key = String(idempotencyKey || `${jobType}:${crypto.randomUUID()}`);
  const now = nowIso();
  const existing = db.prepare("SELECT id, status FROM crm_job_queue WHERE idempotency_key = ?").get(key);
  if (existing) {
    return { queued: false, duplicate: true, jobId: existing.id, status: existing.status };
  }
  const res = db
    .prepare(
      `INSERT INTO crm_job_queue (
        job_type, rule_key, idempotency_key, payload_json, status,
        attempts, max_attempts, next_run_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'pending', 0, ?, ?, ?, ?)`
    )
    .run(jobType, ruleKey, key, JSON.stringify(payload || {}), Math.max(1, Math.min(5, Number(maxAttempts || 3))), runAt, now, now);
  return { queued: true, duplicate: false, jobId: Number(res.lastInsertRowid), status: "pending" };
}

export function evaluateRuleConditions(conditions = {}, payload = {}) {
  if (!conditions || typeof conditions !== "object") return true;
  if (conditions.belowThreshold && !payload.belowThreshold) return false;
  if (conditions.maxPercent !== undefined && Number(payload.percentage ?? 100) >= Number(conditions.maxPercent)) return false;
  if (conditions.minRiskScore !== undefined && Number(payload.riskScore ?? 0) < Number(conditions.minRiskScore)) return false;
  return true;
}

export function emitSystemEvent(db, eventName, payload = {}, { idempotencyKey = "", entityType = "", entityId = "", dryRun = false } = {}) {
  const cfg = getAutomationConfig(db);
  const now = nowIso();
  const key = idempotencyKey || `${eventName}:${entityType}:${entityId}:${now.slice(0, 16)}`;

  if (!dryRun) {
    const existing = db.prepare("SELECT id FROM crm_automation_events WHERE idempotency_key = ?").get(key);
    if (existing) {
      return { duplicate: true, eventId: existing.id, matchedRules: [], jobsQueued: 0 };
    }
  }

  const rules = db
    .prepare(
      `SELECT * FROM crm_automation_rules
       WHERE event_name = ? AND is_enabled = 1
       ORDER BY priority ASC, id ASC`
    )
    .all(eventName);

  const matched = [];
  let jobsQueued = 0;

  if (Number(cfg.global_kill_switch) === 1 && !dryRun) {
    db.prepare(
      `INSERT INTO crm_automation_events (event_name, idempotency_key, entity_type, entity_id, payload_json, matched_rules, status, created_at)
       VALUES (?, ?, ?, ?, ?, 0, 'blocked_kill_switch', ?)`
    ).run(eventName, key, entityType, String(entityId || ""), JSON.stringify(payload), now);
    return { blockedByKillSwitch: true, matchedRules: [], jobsQueued: 0 };
  }

  for (const r of rules) {
    let conditions = {};
    let actions = [];
    try {
      conditions = JSON.parse(r.conditions_json || "{}");
      actions = JSON.parse(r.actions_json || "[]");
    } catch {
      continue;
    }
    if (!evaluateRuleConditions(conditions, payload)) continue;
    matched.push({ id: r.id, ruleKey: r.rule_key, name: r.name, version: r.version, actions });

    if (!dryRun) {
      for (let i = 0; i < actions.length; i += 1) {
        const act = actions[i];
        const qRes = enqueueAutomationJob(db, {
          jobType: act.type || "enqueue_message",
          ruleKey: r.rule_key,
          idempotencyKey: `${key}:${r.rule_key}:${i}`,
          payload: { ...payload, actionConfig: act, eventName }
        });
        if (qRes.queued) jobsQueued += 1;
      }
      db.prepare(
        `UPDATE crm_automation_rules
         SET execution_count = execution_count + 1, last_executed_at = ?, updated_at = ?
         WHERE id = ?`
      ).run(now, now, r.id);
    }
  }

  let eventId = null;
  if (!dryRun) {
    const ins = db
      .prepare(
        `INSERT INTO crm_automation_events (event_name, idempotency_key, entity_type, entity_id, payload_json, matched_rules, status, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'processed', ?)`
      )
      .run(eventName, key, entityType, String(entityId || ""), JSON.stringify(payload), matched.length, now);
    eventId = Number(ins.lastInsertRowid);
  }

  return { duplicate: false, dryRun, eventId, matchedRules: matched, jobsQueued };
}

export async function dispatchWithFallbackChain(db, deps = {}, msgPayload = {}) {
  const cfg = getAutomationConfig(db);
  const now = nowIso();
  const studentId = msgPayload.studentId || msgPayload.userId || null;
  const recipientName = msgPayload.recipientName || msgPayload.studentName || msgPayload.name || "Parent / Student";
  const phone = normalizeIndianPhone(msgPayload.phone || msgPayload.parentPhone || "");
  const email = String(msgPayload.email || "").trim().toLowerCase();
  const template = msgPayload.template || msgPayload.actionConfig?.template || "general";
  const text = renderStandardMessage(template, msgPayload);

  // Ordered fallback: WhatsApp -> SMS -> Email -> Staff Call Task
  const attemptsLog = [];
  const tryOrder = ["whatsapp", "sms", "email"];

  for (const channel of tryOrder) {
    const gate = checkMessageSafetyGate(db, { userId: studentId, phone, channel });
    if (!gate.allowed) {
      attemptsLog.push({ channel, skipped: true, reason: gate.reason });
      if (gate.deferUntilNextMorning) {
        return { delivered: false, deferred: true, reason: gate.reason, attemptsLog };
      }
      if (gate.reason === "global_kill_switch_active" || gate.reason === "recipient_opted_out" || gate.reason.startsWith("daily_cap_reached")) {
        return { delivered: false, blocked: true, reason: gate.reason, attemptsLog };
      }
      continue;
    }

    try {
      if (channel === "whatsapp" && Number(cfg.whatsapp_api_enabled) === 1 && phone.length === 10 && typeof deps.dispatchWhatsAppMessage === "function") {
        const res = await deps.dispatchWhatsAppMessage({ to: phone, text });
        if (res?.sent || res?.ok) {
          logDispatch(db, "whatsapp", studentId, recipientName, phone, template, text, "sent", JSON.stringify(res));
          return { delivered: true, channel: "whatsapp", attemptsLog };
        }
        attemptsLog.push({ channel: "whatsapp", failed: true, reason: res?.error || "whatsapp_not_configured" });
      } else if (channel === "sms" && Number(cfg.sms_dlt_enabled) === 1 && phone.length === 10 && typeof deps.dispatchSmsMessage === "function") {
        const res = await deps.dispatchSmsMessage({ to: phone, text });
        if (res?.sent || res?.ok) {
          logDispatch(db, "sms", studentId, recipientName, phone, template, text, "sent", JSON.stringify(res));
          return { delivered: true, channel: "sms", attemptsLog };
        }
        attemptsLog.push({ channel: "sms", failed: true, reason: res?.error || "sms_not_configured" });
      } else if (channel === "email" && Number(cfg.email_channel_enabled) === 1 && email.includes("@") && typeof deps.sendTransactionalEmail === "function") {
        const res = await deps.sendTransactionalEmail({
          to: email,
          subject: `Yuitor Smart Institute — ${template.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())}`,
          text,
          html: `<p style="font-family:sans-serif;line-height:1.6">${text.replace(/\n/g, "<br/>")}</p>`
        });
        if (res?.sent || res?.ok) {
          logDispatch(db, "email", studentId, recipientName, email, template, text, "sent", JSON.stringify(res));
          return { delivered: true, channel: "email", attemptsLog };
        }
        attemptsLog.push({ channel: "email", failed: true, reason: res?.error || "smtp_not_configured" });
      } else {
        attemptsLog.push({ channel, skipped: true, reason: "channel_unconfigured_or_missing_contact" });
      }
    } catch (err) {
      attemptsLog.push({ channel, failed: true, reason: String(err?.message || "dispatch_error") });
    }
  }

  // Final fallback: Staff Call Task + Click-to-Chat WhatsApp link saved cleanly (never silently discard)
  const waLink = buildWhatsAppClickToChatUrl(phone, text);
  logDispatch(db, "staff_call_task", studentId, recipientName, phone || email, template, text, "fallback_task", JSON.stringify({ waLink, attemptsLog }));
  db.prepare(
    `INSERT INTO crm_counsellor_tasks (
      task_type, title, description, student_id, inquiry_id, priority, due_date, status, created_at, updated_at
    ) VALUES ('call_fallback', ?, ?, ?, ?, 'medium', ?, 'open', ?, ?)`
  ).run(
    `Call/WhatsApp ${recipientName} (${template.replace(/_/g, " ")})`,
    `${text}${waLink ? `\nWhatsApp: ${waLink}` : ""}`,
    studentId,
    msgPayload.inquiryId || null,
    getIstDateParts().dateStr,
    now,
    now
  );
  return { delivered: true, channel: "staff_call_task", waLink, attemptsLog };
}

function logDispatch(db, channel, userId, name, contact, category, message, status, providerResp) {
  try {
    db.prepare(
      `INSERT INTO alert_dispatch_logs (
        channel, recipient_user_id, recipient_name, recipient_contact, category, message, status, provider_response, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(channel, userId || null, String(name || ""), String(contact || ""), String(category || "automation"), String(message || ""), status, String(providerResp || "").slice(0, 500), nowIso());
  } catch {
    // non-fatal log failure
  }
}

export async function processJobQueueBatch(db, deps = {}, { limit = 25 } = {}) {
  const now = nowIso();
  const jobs = db
    .prepare(
      `SELECT * FROM crm_job_queue
       WHERE status = 'pending' AND next_run_at <= ?
       ORDER BY id ASC LIMIT ?`
    )
    .all(now, limit);

  let completed = 0;
  let failed = 0;
  let deferred = 0;

  for (const job of jobs) {
    const locked = db
      .prepare(`UPDATE crm_job_queue SET status = 'running', locked_at = ?, attempts = attempts + 1, updated_at = ? WHERE id = ? AND status = 'pending'`)
      .run(now, now, job.id);
    if (Number(locked.changes || 0) === 0) continue;

    let payload = {};
    try {
      payload = JSON.parse(job.payload_json || "{}");
    } catch {
      payload = {};
    }

    try {
      let result = { ok: true };
      if (job.job_type === "enqueue_message") {
        result = await dispatchWithFallbackChain(db, deps, payload);
        if (result.deferred) {
          // Reschedule for 08:05 AM IST tomorrow
          const nextMorning = new Date(Date.now() + 60 * 60 * 1000).toISOString();
          db.prepare(
            `UPDATE crm_job_queue SET status = 'pending', attempts = MAX(0, attempts - 1), next_run_at = ?, last_error = ?, updated_at = ? WHERE id = ?`
          ).run(nextMorning, "Deferred due to IST quiet hours", nowIso(), job.id);
          deferred += 1;
          continue;
        }
      } else if (job.job_type === "check_consecutive_absences" && payload.studentId) {
        const cfg = getAutomationConfig(db);
        const daysNeeded = Math.max(2, Number(cfg.consecutive_absent_task_days || 3));
        const recent = db
          .prepare(`SELECT status, att_date FROM attendance WHERE student_id = ? ORDER BY att_date DESC LIMIT ?`)
          .all(payload.studentId, daysNeeded);
        if (recent.length >= daysNeeded && recent.every((r) => r.status === "absent")) {
          const existsTask = db
            .prepare(`SELECT id FROM crm_counsellor_tasks WHERE student_id = ? AND task_type = 'consecutive_absent' AND status IN ('open','in_progress') LIMIT 1`)
            .get(payload.studentId);
          if (!existsTask) {
            db.prepare(
              `INSERT INTO crm_counsellor_tasks (task_type, title, description, student_id, priority, due_date, status, created_at, updated_at)
               VALUES ('consecutive_absent', ?, ?, ?, 'high', ?, 'open', ?, ?)`
            ).run(
              `3+ Consecutive Absences: ${payload.studentName || `Student #${payload.studentId}`}`,
              `Student was absent on ${recent.map((r) => r.att_date).join(", ")}. Call parent immediately.`,
              payload.studentId,
              getIstDateParts().dateStr,
              nowIso(),
              nowIso()
            );
          }
          result = { consecutiveAbsentTaskCreated: true };
        }
      } else if (job.job_type === "ensure_checklist" && payload.studentId) {
        db.prepare(`INSERT OR IGNORE INTO crm_document_checklists (student_id, updated_at) VALUES (?, ?)`).run(payload.studentId, nowIso());
        result = { checklistReady: true };
      } else if (job.job_type === "create_task") {
        db.prepare(
          `INSERT INTO crm_counsellor_tasks (task_type, title, description, student_id, inquiry_id, priority, due_date, status, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?, ?)`
        ).run(
          payload.actionConfig?.taskType || "followup",
          payload.title || `Follow-up: ${payload.name || "Lead"}`,
          payload.summary || "",
          payload.studentId || null,
          payload.inquiryId || null,
          payload.actionConfig?.priority || "high",
          getIstDateParts().dateStr,
          nowIso(),
          nowIso()
        );
      } else if (job.job_type === "create_exception") {
        createExceptionItem(db, {
          category: payload.actionConfig?.category || "sla_breach",
          severity: payload.actionConfig?.severity || "medium",
          title: payload.title || "Automation Exception",
          summary: payload.summary || "",
          entityType: payload.entityType || "inquiry",
          entityId: payload.inquiryId || payload.studentId || "",
          details: payload
        });
      } else if (job.job_type === "schedule_remediation" && payload.studentId) {
        const retestDate = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10);
        const topics = Array.isArray(payload.weakTopics) && payload.weakTopics.length ? payload.weakTopics : ["Core Revision"];
        if (payload.courseId) {
          db.prepare(
            `INSERT INTO crm_study_materials (course_id, batch_id, subject_name, chapter_name, material_type, title, description, created_at)
             VALUES (?, ?, ?, ?, 'practice_set', ?, ?, ?)`
          ).run(
            payload.courseId,
            payload.batchId || null,
            payload.subjectName || "Revision",
            topics.join(", "),
            `Targeted Practice Set: ${topics.slice(0, 2).join(" & ")}`,
            `Auto-generated remediation practice sheet after scoring ${payload.percentage}% in CBT. Re-test scheduled for ${retestDate}.`,
            nowIso()
          );
        }
        db.prepare(
          `INSERT INTO crm_counsellor_tasks (task_type, title, description, student_id, priority, due_date, status, created_at, updated_at)
           VALUES ('retest_remediation', ?, ?, ?, 'medium', ?, 'open', ?, ?)`
        ).run(
          `7-Day Re-Test Scheduled (${payload.studentName || `Student #${payload.studentId}`})`,
          `Weak topics: ${topics.join(", ")}. Score: ${payload.percentage}%. Re-test date: ${retestDate}.`,
          payload.studentId,
          retestDate,
          nowIso(),
          nowIso()
        );
        result = { retestDate, weakTopics: topics };
      } else if (job.job_type === "flag_substitute_needed" && payload.teacherId) {
        createExceptionItem(db, {
          category: "teacher_substitution",
          severity: "high",
          title: `Assign Substitute for ${payload.teacherName || `Teacher #${payload.teacherId}`}`,
          summary: `Leave approved (${payload.fromDate} to ${payload.toDate}). Assign a substitute teacher for scheduled timetable slots.`,
          entityType: "teacher_leave",
          entityId: String(payload.leaveId || payload.teacherId),
          details: payload,
          escalationLevel: "team_lead"
        });
      } else if (job.job_type === "simulate_failure_test") {
        throw new Error(payload.errorMessage || "Simulated transient job error");
      }

      db.prepare(
        `UPDATE crm_job_queue SET status = 'completed', completed_at = ?, result_json = ?, updated_at = ? WHERE id = ?`
      ).run(nowIso(), JSON.stringify(result), nowIso(), job.id);
      completed += 1;
    } catch (err) {
      const nextAttempts = Number(job.attempts || 0) + 1;
      const maxAttempts = Number(job.max_attempts || 3);
      const errMsg = String(err?.message || "Job execution failed").slice(0, 400);
      if (nextAttempts >= maxAttempts) {
        db.prepare(
          `UPDATE crm_job_queue SET status = 'dead_letter', last_error = ?, updated_at = ? WHERE id = ?`
        ).run(errMsg, nowIso(), job.id);
        createExceptionItem(db, {
          category: "failed_job",
          severity: "high",
          title: `Failed Automation Job: ${job.job_type}`,
          summary: `Failed after ${nextAttempts} attempts: ${errMsg}`,
          entityType: "crm_job_queue",
          entityId: String(job.id),
          details: { jobId: job.id, jobType: job.job_type, ruleKey: job.rule_key, error: errMsg },
          escalationLevel: "owner"
        });
      } else {
        const backoffMs = nextAttempts * 60 * 1000;
        db.prepare(
          `UPDATE crm_job_queue SET status = 'pending', next_run_at = ?, last_error = ?, updated_at = ? WHERE id = ?`
        ).run(new Date(Date.now() + backoffMs).toISOString(), errMsg, nowIso(), job.id);
      }
      failed += 1;
    }
  }

  return { picked: jobs.length, completed, failed, deferred };
}

export function generateMonthlyFeeInvoices(db, { billingMonth = getIstDateParts().monthStr, dueDay = 10, batchId = null, studentIds = null } = {}) {
  const now = nowIso();
  const safeDueDay = Math.max(1, Math.min(28, Number(dueDay || 10)));
  const dueDate = `${billingMonth}-${String(safeDueDay).padStart(2, "0")}`;

  let sql = `
    SELECT u.id AS student_id, u.full_name, u.phone, u.email,
           sp.batch_id, sp.branch_id,
           e.course_id, c.title AS course_title, c.monthly_fee
    FROM users u
    LEFT JOIN student_profiles sp ON sp.user_id = u.id
    LEFT JOIN enrollments e ON e.student_id = u.id AND e.status = 'active'
    LEFT JOIN courses c ON c.id = e.course_id
    WHERE u.role = 'student' AND u.is_active = 1 AND u.verification_status IN ('approved', 'otp_verified')
  `;
  const params = [];
  if (batchId) {
    sql += " AND (sp.batch_id = ? OR e.batch_id = ?)";
    params.push(Number(batchId), Number(batchId));
  }
  if (Array.isArray(studentIds) && studentIds.length > 0) {
    const cleanIds = studentIds.map(Number).filter(Boolean);
    if (cleanIds.length > 0) {
      sql += ` AND u.id IN (${cleanIds.map(() => "?").join(",")})`;
      params.push(...cleanIds);
    }
  }
  sql += " GROUP BY u.id";

  const students = db.prepare(sql).all(...params);
  let created = 0;
  let skipped = 0;
  const createdIds = [];

  runInImmediateTx(db, () => {
    for (const s of students) {
      const existing = db
        .prepare(`SELECT id FROM fee_records WHERE student_id = ? AND billing_month = ? LIMIT 1`)
        .get(s.student_id, billingMonth);
      if (existing) {
        skipped += 1;
        continue;
      }
      const amount = Math.max(500, Number(s.monthly_fee || 1400));
      const title = `${billingMonth} Monthly Fee — ${s.course_title || "Coaching Batch"}`;
      const res = db
        .prepare(
          `INSERT INTO fee_records (
            student_id, course_id, branch_id, title, total_amount, discount_amount,
            paid_amount, due_date, status, billing_month, created_at
          ) VALUES (?, ?, ?, ?, ?, 0, 0, ?, 'pending', ?, ?)`
        )
        .run(s.student_id, s.course_id || null, s.branch_id || null, title, amount, dueDate, billingMonth, now);
      const feeRecordId = Number(res.lastInsertRowid);
      db.prepare(
        `INSERT INTO fee_installments (
          fee_record_id, student_id, installment_no, title, amount, paid_amount, due_date, status, created_at
        ) VALUES (?, ?, 1, ?, ?, 0, ?, 'pending', ?)`
      ).run(feeRecordId, s.student_id, title, amount, dueDate, now);
      created += 1;
      createdIds.push(feeRecordId);
    }
  });

  return { billingMonth, dueDate, totalEligible: students.length, created, skipped, createdIds };
}

export function getStudentDefaulterLockState(db, studentId) {
  const cfg = getAutomationConfig(db);
  if (Number(cfg.defaulter_soft_lock_enabled) !== 1) {
    return { locked: false, overdueAmount: 0, maxOverdueDays: 0 };
  }
  const sp = db.prepare("SELECT fee_lock_exempt FROM student_profiles WHERE user_id = ?").get(studentId);
  if (Number(sp?.fee_lock_exempt || 0) === 1) {
    return { locked: false, exempt: true, overdueAmount: 0, maxOverdueDays: 0 };
  }
  const today = getIstDateParts().dateStr;
  const rows = db
    .prepare(
      `SELECT id, total_amount, discount_amount, paid_amount, due_date
       FROM fee_records
       WHERE student_id = ? AND status IN ('pending', 'partial', 'overdue') AND due_date IS NOT NULL AND due_date != '' AND due_date < ?`
    )
    .all(studentId, today);

  let overdueAmount = 0;
  let maxOverdueDays = 0;
  const todayMs = Date.parse(today);
  for (const r of rows) {
    const bal = Math.max(0, Number(r.total_amount || 0) - Number(r.discount_amount || 0) - Number(r.paid_amount || 0));
    if (bal <= 0) continue;
    overdueAmount += bal;
    const dueMs = Date.parse(r.due_date);
    if (Number.isFinite(dueMs)) {
      const days = Math.floor((todayMs - dueMs) / 86400000);
      if (days > maxOverdueDays) maxOverdueDays = days;
    }
  }
  const threshold = Number(cfg.defaulter_soft_lock_days || 15);
  return {
    locked: overdueAmount > 0 && maxOverdueDays >= threshold,
    overdueAmount,
    maxOverdueDays,
    thresholdDays: threshold,
    message:
      overdueAmount > 0 && maxOverdueDays >= threshold
        ? `Your coaching fee of ₹${overdueAmount.toLocaleString("en-IN")} is overdue by ${maxOverdueDays} days. Please clear pending dues to unlock online CBT tests and study materials.`
        : ""
  };
}

/**
 * Privacy / Anti-Poaching guard: masks student/parent mobile numbers for teachers.
 * Example: "+91 98765 43210" -> "+91 ••••••3210" | "9876543210" -> "••••••3210"
 */
export function maskPhoneForTeacher(phone) {
  const raw = String(phone || "").trim();
  if (!raw) return "";
  const digits = raw.replace(/\D/g, "");
  if (digits.length <= 4) return "••••";
  const last4 = digits.slice(-4);
  if (digits.length === 12 && digits.startsWith("91")) {
    return `+91 ••••••${last4}`;
  }
  return `••••••${last4}`;
}

export function isTeacherPhoneMaskingEnabled(db) {
  try {
    const cfg = getAutomationConfig(db);
    return Number(cfg?.mask_student_phones_for_teachers ?? 1) === 1;
  } catch {
    return true;
  }
}

/**
 * Pure deterministic clash-free substitute teacher selector.
 * Skips the absent teacher, teachers currently on overlapping leave, and any teacher with a timetable clash.
 * Prefers teachers whose subjects match affected slots and who have fewer total weekly slots.
 */
export function pickBestSubstituteTeacher(
  absentTeacherId,
  affectedSlots = [],
  activeTeachers = [],
  allTimetableSlots = [],
  onLeaveTeacherIds = []
) {
  const leaveSet = new Set((onLeaveTeacherIds || []).map((id) => Number(id)));
  const absentId = Number(absentTeacherId);
  const candidates = (activeTeachers || []).filter(
    (t) => Number(t.id) !== absentId && Number(t.is_active ?? 1) === 1 && !leaveSet.has(Number(t.id))
  );
  if (!candidates.length) return { substitute: null, reason: "no_active_teachers" };

  const affectedSubjects = new Set(
    (affectedSlots || [])
      .map((s) => String(s.subject_name || "").trim().toLowerCase())
      .filter(Boolean)
  );

  const scored = [];
  for (const t of candidates) {
    const tid = Number(t.id);
    const tSlots = (allTimetableSlots || []).filter(
      (s) => Number(s.teacher_id) === tid || Number(s.substitute_teacher_id) === tid
    );
    let hasClash = false;
    for (const slot of affectedSlots || []) {
      const check = detectTimetableClash(tSlots, {
        day_of_week: slot.day_of_week,
        start_time: slot.start_time,
        end_time: slot.end_time,
        teacher_id: tid,
        batch_id: 0,
        room_name: ""
      });
      if (check.clash) {
        hasClash = true;
        break;
      }
    }
    if (hasClash) continue;

    let subjectMatch = 0;
    const rawSubj = String(t.subjects_json || t.subjects || "").toLowerCase();
    for (const sub of affectedSubjects) {
      if (sub && rawSubj.includes(sub)) subjectMatch += 1;
    }
    scored.push({
      teacher: t,
      subjectMatch,
      weeklyLoad: tSlots.length
    });
  }

  if (!scored.length) return { substitute: null, reason: "all_teachers_have_timetable_clash" };
  scored.sort((a, b) => b.subjectMatch - a.subjectMatch || a.weeklyLoad - b.weeklyLoad || Number(a.teacher.id) - Number(b.teacher.id));
  return {
    substitute: scored[0].teacher,
    subjectMatch: scored[0].subjectMatch,
    weeklyLoad: scored[0].weeklyLoad,
    reason: "matched_clash_free"
  };
}

/**
 * Strictly strips student identity from anonymous feedback rows before returning to teachers.
 */
export function redactFeedbackForTeacher(rows = []) {
  return (rows || []).map((r) => {
    const anon = Number(r.is_anonymous ?? 1) === 1;
    return {
      id: r.id,
      teacher_id: r.teacher_id,
      batch_id: r.batch_id || null,
      batch_name: r.batch_name || "",
      course_title: r.course_title || "",
      subject_name: r.subject_name || "",
      topic_unclear: r.topic_unclear || "",
      rating: Number(r.rating || 5),
      clarity_rating: Number(r.clarity_rating || 5),
      pace_tag: r.pace_tag || "just_right",
      feedback_text: r.feedback_text || "",
      is_anonymous: anon ? 1 : 0,
      student_display: anon ? "Anonymous Student" : r.student_name || "Student",
      created_at: r.created_at
    };
  });
}

/**
 * 1-Click Student / Teacher / Staff Exit & Settlement.
 * - Frees batch seats & hides dropped students from active attendance lists.
 * - Handles pending dues (keep_due | mark_settled | waive_off) & stops automated reminders.
 * - For teachers: revokes sessions immediately and optionally hands over active slots/batches/doubts.
 * - Preserves all historical records safely for Alumni/Left archive & 1-click Rejoin.
 */
export function executeMemberExit(
  db,
  {
    userId,
    role,
    exitCategory = "dropped_out",
    exitDate = "",
    exitReason = "",
    duesAction = "keep_due",
    settlementNote = "",
    handoverTeacherId = null,
    actorId = null
  }
) {
  const uid = Number(userId);
  const expectedRole = String(role || "").toLowerCase();
  if (!["student", "teacher", "staff"].includes(expectedRole)) {
    throw new Error("Exit role must be student, teacher, or staff.");
  }
  const user = db.prepare("SELECT id, role, full_name, email, phone, is_active FROM users WHERE id = ?").get(uid);
  if (!user) throw new Error("Member account not found.");
  if (user.role !== expectedRole) {
    throw new Error(`Role mismatch: account belongs to '${user.role}', not '${expectedRole}'.`);
  }

  const now = nowIso();
  const effectiveDate = String(exitDate || getIstDateParts().dateStr).slice(0, 10);
  const safeReason = String(exitReason || "").trim().slice(0, 500);
  const safeNote = String(settlementNote || "").trim().slice(0, 400);
  const safeCat = String(exitCategory || (expectedRole === "student" ? "dropped_out" : "resigned")).trim().slice(0, 40);
  const safeDuesAction = String(duesAction || (expectedRole === "student" ? "keep_due" : "salary_settled")).trim().slice(0, 30);

  let duesSnapshot = 0;
  let enrollmentsSnapshot = [];
  let seatsFreed = 0;
  let remindersCancelled = 0;
  let handoverSlotsMoved = 0;
  let exitId = 0;

  runInImmediateTx(db, () => {
    // 1. Deactivate user & revoke live login sessions immediately
    db.prepare(
      `UPDATE users SET is_active = 0, verification_status = 'suspended', marketing_opt_in = 0, updated_at = ? WHERE id = ?`
    ).run(now, uid);
    try {
      db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(uid);
    } catch {
      // sessions table may not exist in minimal unit-test DBs
    }

    if (expectedRole === "student") {
      // 2. Snapshot & close active enrollments (frees batch seats & removes from active attendance)
      enrollmentsSnapshot = db
        .prepare(`SELECT id, course_id, batch_id, plan, status FROM enrollments WHERE student_id = ? AND status IN ('active', 'pending')`)
        .all(uid);
      const nextEnrStatus = safeCat === "course_completed_alumni" ? "completed" : "cancelled";
      if (enrollmentsSnapshot.length > 0) {
        const res = db
          .prepare(`UPDATE enrollments SET status = ? WHERE student_id = ? AND status IN ('active', 'pending')`)
          .run(nextEnrStatus, uid);
        seatsFreed = Number(res.changes || enrollmentsSnapshot.length);
      }

      // 3. Stop all automatic reminders & opt-out communication preferences in crm_message_consent
      try {
        const existingConsent = db
          .prepare(`SELECT id FROM crm_message_consent WHERE user_id = ? OR (phone != '' AND phone = ?) LIMIT 1`)
          .get(uid, user.phone || "");
        if (existingConsent) {
          db.prepare(
            `UPDATE crm_message_consent
             SET user_id = ?, whatsapp_opt_in = 0, sms_opt_in = 0, email_opt_in = 0, marketing_opt_in = 0,
                 opted_out_all = 1, opt_out_reason = ?, updated_at = ?
             WHERE id = ?`
          ).run(uid, `Student exited (${safeCat})`, now, existingConsent.id);
        } else {
          db.prepare(
            `INSERT INTO crm_message_consent (
               user_id, phone, email, whatsapp_opt_in, sms_opt_in, email_opt_in,
               marketing_opt_in, opted_out_all, opt_out_reason, updated_at
             ) VALUES (?, ?, ?, 0, 0, 0, 0, 1, ?, ?)`
          ).run(uid, user.phone || "", user.email || "", `Student exited (${safeCat})`, now);
        }
      } catch {
        // optional in minimal schemas
      }
      try {
        const jRes = db
          .prepare(
            `UPDATE crm_job_queue SET status = 'cancelled', last_error = 'Cancelled automatically on student exit', updated_at = ?
             WHERE status = 'pending' AND payload_json LIKE ?`
          )
          .run(now, `%"studentId":${uid}%`);
        remindersCancelled = Number(jRes.changes || 0);
      } catch {
        // ignore if job queue empty
      }

      // 4. Compute pending dues snapshot & apply settlement action
      const openFees = db
        .prepare(
          `SELECT id, total_amount, discount_amount, paid_amount FROM fee_records
           WHERE student_id = ? AND status IN ('pending', 'partial', 'overdue')`
        )
        .all(uid);
      for (const fr of openFees) {
        const remaining = Math.max(0, Number(fr.total_amount || 0) - Number(fr.discount_amount || 0) - Number(fr.paid_amount || 0));
        duesSnapshot += remaining;
        if (safeDuesAction === "mark_settled") {
          const fullNet = Math.max(0, Number(fr.total_amount || 0) - Number(fr.discount_amount || 0));
          db.prepare(`UPDATE fee_records SET paid_amount = ?, status = 'paid' WHERE id = ?`).run(fullNet, fr.id);
        } else if (safeDuesAction === "waive_off") {
          const newDiscount = Math.max(0, Number(fr.total_amount || 0) - Number(fr.paid_amount || 0));
          db.prepare(`UPDATE fee_records SET discount_amount = ?, status = 'paid' WHERE id = ?`).run(newDiscount, fr.id);
        }
      }
      if (safeDuesAction === "mark_settled" || safeDuesAction === "waive_off") {
        try {
          if (safeDuesAction === "mark_settled") {
            db.prepare(
              `UPDATE fee_installments SET paid_amount = amount, status = 'paid' WHERE student_id = ? AND status IN ('pending', 'partial', 'overdue')`
            ).run(uid);
          } else {
            db.prepare(
              `UPDATE fee_installments SET status = 'paid' WHERE student_id = ? AND status IN ('pending', 'partial', 'overdue')`
            ).run(uid);
          }
        } catch {
          // fee_installments optional in minimal test DB
        }
      }
    } else if (expectedRole === "teacher") {
      // Optional handover of timetable slots, batches, and open doubts to replacement teacher
      const repId = handoverTeacherId ? Number(handoverTeacherId) : null;
      if (repId && repId !== uid) {
        const rep = db.prepare(`SELECT id FROM users WHERE id = ? AND role = 'teacher' AND is_active = 1`).get(repId);
        if (rep) {
          try {
            const sRes = db.prepare(`UPDATE timetable_slots SET teacher_id = ? WHERE teacher_id = ?`).run(repId, uid);
            handoverSlotsMoved = Number(sRes.changes || 0);
          } catch {}
          try {
            db.prepare(`UPDATE batches SET teacher_id = ? WHERE teacher_id = ?`).run(repId, uid);
          } catch {}
          try {
            db.prepare(`UPDATE crm_doubts SET assigned_teacher_id = ?, updated_at = ? WHERE assigned_teacher_id = ? AND status = 'open'`).run(repId, now, uid);
          } catch {}
        }
      }
      // Snapshot any unpaid teacher payouts
      try {
        const pRow = db.prepare(`SELECT COALESCE(SUM(net_amount), 0) AS s FROM teacher_payouts WHERE teacher_id = ? AND status != 'paid'`).get(uid);
        duesSnapshot = Number(pRow?.s || 0);
      } catch {}
    }

    // Close any prior 'left' record if duplicate
    db.prepare(`UPDATE crm_member_exits SET status = 'rejoined', rejoined_at = ?, rejoin_note = 'Superseded by newer exit' WHERE user_id = ? AND status = 'left'`).run(now, uid);

    const ins = db
      .prepare(
        `INSERT INTO crm_member_exits (
           user_id, role, exit_category, exit_date, exit_reason, dues_action,
           dues_amount_snapshot, settlement_note, previous_enrollments_json,
           handover_teacher_id, reminders_stopped, status, created_by, created_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'left', ?, ?)`
      )
      .run(
        uid,
        expectedRole,
        safeCat,
        effectiveDate,
        safeReason,
        safeDuesAction,
        duesSnapshot,
        safeNote,
        JSON.stringify(enrollmentsSnapshot),
        handoverTeacherId ? Number(handoverTeacherId) : null,
        actorId ? Number(actorId) : null,
        now
      );
    exitId = Number(ins.lastInsertRowid);
  });

  return {
    ok: true,
    exitId,
    userId: uid,
    role: expectedRole,
    fullName: user.full_name,
    exitDate: effectiveDate,
    exitCategory: safeCat,
    duesAction: safeDuesAction,
    duesAmountSnapshot: duesSnapshot,
    seatsFreed,
    remindersCancelled,
    handoverSlotsMoved
  };
}

/**
 * 1-Click Rejoin for Left Student / Teacher / Staff.
 * Restores portal access, communication opt-in, and (for students) previous active enrollments/batches.
 */
export function rejoinExitedMember(db, { exitId, actorId = null, rejoinNote = "", restoreBatch = true }) {
  const row = db.prepare(`SELECT * FROM crm_member_exits WHERE id = ?`).get(Number(exitId));
  if (!row) throw new Error("Exit record not found.");
  if (row.status === "rejoined") {
    return { ok: true, alreadyRejoined: true, exitId: row.id, userId: row.user_id, role: row.role };
  }

  const now = nowIso();
  let batchesRestored = 0;

  runInImmediateTx(db, () => {
    db.prepare(
      `UPDATE users SET is_active = 1, verification_status = 'approved', marketing_opt_in = 1, updated_at = ? WHERE id = ?`
    ).run(now, row.user_id);

    if (row.role === "student") {
      try {
        const uInfo = db.prepare(`SELECT phone, email FROM users WHERE id = ?`).get(row.user_id);
        const existingConsent = db
          .prepare(`SELECT id FROM crm_message_consent WHERE user_id = ? OR (phone != '' AND phone = ?) LIMIT 1`)
          .get(row.user_id, uInfo?.phone || "");
        if (existingConsent) {
          db.prepare(
            `UPDATE crm_message_consent
             SET user_id = ?, whatsapp_opt_in = 1, sms_opt_in = 1, email_opt_in = 1, marketing_opt_in = 1,
                 opted_out_all = 0, opt_out_reason = '', updated_at = ?
             WHERE id = ?`
          ).run(row.user_id, now, existingConsent.id);
        } else {
          db.prepare(
            `INSERT INTO crm_message_consent (
               user_id, phone, email, whatsapp_opt_in, sms_opt_in, email_opt_in,
               marketing_opt_in, opted_out_all, opt_out_reason, updated_at
             ) VALUES (?, ?, ?, 1, 1, 1, 1, 0, '', ?)`
          ).run(row.user_id, uInfo?.phone || "", uInfo?.email || "", now);
        }
      } catch {}

      if (restoreBatch) {
        let prev = [];
        try {
          prev = JSON.parse(row.previous_enrollments_json || "[]");
        } catch {
          prev = [];
        }
        for (const e of prev) {
          if (!e?.id) continue;
          const r = db.prepare(`UPDATE enrollments SET status = 'active' WHERE id = ? AND student_id = ?`).run(e.id, row.user_id);
          if (Number(r.changes || 0) > 0) batchesRestored += 1;
        }
      }
    }

    db.prepare(
      `UPDATE crm_member_exits SET status = 'rejoined', rejoined_at = ?, rejoined_by = ?, rejoin_note = ? WHERE id = ?`
    ).run(now, actorId ? Number(actorId) : null, String(rejoinNote || "").trim().slice(0, 300), row.id);
  });

  return {
    ok: true,
    exitId: row.id,
    userId: row.user_id,
    role: row.role,
    batchesRestored,
    rejoinedAt: now
  };
}

/**
 * Teacher Leave Approval -> Automatic Clash-Free Substitute Assignment + Batch Student Notification.
 */
export function assignSubstituteOnTeacherLeave(db, { leaveRequestId, substituteTeacherId = null, actorId = null }) {
  const leave = db.prepare(`SELECT * FROM teacher_leave_requests WHERE id = ?`).get(Number(leaveRequestId));
  if (!leave) throw new Error("Teacher leave request not found.");

  const absentTeacher = db.prepare(`SELECT id, full_name FROM users WHERE id = ?`).get(leave.teacher_id);
  const affectedSlots = db
    .prepare(
      `SELECT ts.*, b.name AS batch_name
       FROM timetable_slots ts
       LEFT JOIN batches b ON b.id = ts.batch_id
       WHERE ts.teacher_id = ?`
    )
    .all(leave.teacher_id);

  let chosenSub = null;
  let selectionReason = "manual_selected";

  if (substituteTeacherId) {
    chosenSub = db
      .prepare(`SELECT id, full_name, is_active FROM users WHERE id = ? AND role = 'teacher' AND is_active = 1`)
      .get(Number(substituteTeacherId));
    if (!chosenSub) throw new Error("Selected substitute teacher is not active.");
  } else {
    const activeTeachers = db
      .prepare(
        `SELECT u.id, u.full_name, u.is_active, tp.subjects_json
         FROM users u
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role = 'teacher' AND u.is_active = 1`
      )
      .all();
    const allSlots = db.prepare(`SELECT * FROM timetable_slots`).all();
    const overlappingLeaves = db
      .prepare(
        `SELECT DISTINCT teacher_id FROM teacher_leave_requests
         WHERE status = 'approved' AND id != ? AND NOT (to_date < ? OR from_date > ?)`
      )
      .all(leave.id, leave.from_date, leave.to_date)
      .map((r) => r.teacher_id);

    const pick = pickBestSubstituteTeacher(leave.teacher_id, affectedSlots, activeTeachers, allSlots, overlappingLeaves);
    chosenSub = pick.substitute;
    selectionReason = pick.reason;
  }

  const now = nowIso();
  if (!chosenSub) {
    // Still flag in Exception Inbox so class never goes unnoticed
    createExceptionItem(db, {
      category: "teacher_leave_no_substitute",
      severity: "high",
      title: `Manual Substitute Needed: ${absentTeacher?.full_name || `Teacher #${leave.teacher_id}`}`,
      summary: `Leave ${leave.from_date} to ${leave.to_date} approved, but auto-substitute found no clash-free teacher (${selectionReason}).`,
      details: { leaveId: leave.id, teacherId: leave.teacher_id, fromDate: leave.from_date, toDate: leave.to_date, reason: selectionReason },
      entityType: "teacher_leave",
      entityId: String(leave.id)
    });
    return {
      ok: true,
      assigned: false,
      reason: selectionReason,
      leaveId: leave.id,
      slotsCovered: 0,
      studentsNotified: 0
    };
  }

  let studentsNotified = 0;
  const batchIds = new Set();

  runInImmediateTx(db, () => {
    db.prepare(`UPDATE teacher_leave_requests SET substitute_teacher_id = ?, substitute_assigned_at = ? WHERE id = ?`).run(
      chosenSub.id,
      now,
      leave.id
    );

    // Clear previous substitute assignment records for this leave if re-assigned
    db.prepare(`DELETE FROM crm_leave_substitutions WHERE leave_request_id = ?`).run(leave.id);

    const insSub = db.prepare(
      `INSERT INTO crm_leave_substitutions (
         leave_request_id, absent_teacher_id, substitute_teacher_id, timetable_slot_id,
         batch_id, from_date, to_date, students_notified, status, created_by, created_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'assigned', ?, ?)`
    );

    if (affectedSlots.length > 0) {
      for (const s of affectedSlots) {
        db.prepare(`UPDATE timetable_slots SET substitute_teacher_id = ? WHERE id = ?`).run(chosenSub.id, s.id);
        if (s.batch_id) batchIds.add(Number(s.batch_id));
      }
    } else {
      // Fallback: check batches owned by absent teacher
      const ownedBatches = db.prepare(`SELECT id FROM batches WHERE teacher_id = ? AND is_active = 1`).all(leave.teacher_id);
      for (const b of ownedBatches) batchIds.add(Number(b.id));
    }

    // Notify all active enrolled students in affected batches
    const notifiedStudentIds = new Set();
    const insNotif = db.prepare(
      `INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)`
    );

    for (const bid of batchIds) {
      const batchStudents = db
        .prepare(
          `SELECT DISTINCT u.id, b.name AS batch_name
           FROM enrollments e
           JOIN users u ON u.id = e.student_id
           LEFT JOIN batches b ON b.id = e.batch_id
           WHERE e.batch_id = ? AND e.status = 'active' AND u.is_active = 1`
        )
        .all(bid);
      for (const st of batchStudents) {
        if (notifiedStudentIds.has(st.id)) continue;
        notifiedStudentIds.add(st.id);
        insNotif.run(
          st.id,
          "Substitute Faculty Assigned — Class Runs On Schedule",
          `${chosenSub.full_name} will take your ${st.batch_name || "batch"} class (${leave.from_date} to ${leave.to_date}) while ${absentTeacher?.full_name || "your faculty"} is on approved leave. Please attend on time.`,
          now
        );
      }
    }
    studentsNotified = notifiedStudentIds.size;

    // Insert substitution audit rows
    if (affectedSlots.length > 0) {
      for (const s of affectedSlots) {
        insSub.run(
          leave.id,
          leave.teacher_id,
          chosenSub.id,
          s.id,
          s.batch_id || null,
          leave.from_date,
          leave.to_date,
          studentsNotified,
          actorId ? Number(actorId) : null,
          now
        );
      }
    } else {
      insSub.run(
        leave.id,
        leave.teacher_id,
        chosenSub.id,
        null,
        [...batchIds][0] || null,
        leave.from_date,
        leave.to_date,
        studentsNotified,
        actorId ? Number(actorId) : null,
        now
      );
    }

    // Notify the substitute teacher
    insNotif.run(
      chosenSub.id,
      "Substitute Class Assigned",
      `You have been assigned as substitute teacher for ${absentTeacher?.full_name || "faculty"} from ${leave.from_date} to ${leave.to_date} (${affectedSlots.length || batchIds.size} class/batch slots).`,
      now
    );
  });

  emitSystemEvent(db, "teacher.leave_approved", {
    leaveRequestId: leave.id,
    teacherId: leave.teacher_id,
    teacherName: absentTeacher?.full_name || "",
    substituteTeacherId: chosenSub.id,
    substituteTeacherName: chosenSub.full_name,
    fromDate: leave.from_date,
    toDate: leave.to_date,
    studentsNotified
  });

  return {
    ok: true,
    assigned: true,
    reason: selectionReason,
    leaveId: leave.id,
    substituteTeacherId: chosenSub.id,
    substituteTeacherName: chosenSub.full_name,
    slotsCovered: affectedSlots.length,
    batchesCovered: batchIds.size,
    studentsNotified
  };
}

function escapeEmailHtml(val) {
  return String(val ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function isLeapYear(y) {
  return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
}

/**
 * Pure IST Birthday Matcher.
 * Accepts YYYY-MM-DD (or ISO string). Celebrates Feb 29 birthdays on Feb 28 in non-leap years.
 */
export function isBirthdayTodayIst(dobStr, istParts = getIstDateParts()) {
  const raw = String(dobStr || "").trim().slice(0, 10);
  const m = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return false;
  const dobMonth = Number(m[2]);
  const dobDay = Number(m[3]);
  if (dobMonth < 1 || dobMonth > 12 || dobDay < 1 || dobDay > 31) return false;
  if (dobMonth === 2 && dobDay === 29 && !isLeapYear(Number(istParts.year))) {
    return Number(istParts.month) === 2 && Number(istParts.day) === 28;
  }
  return Number(istParts.month) === dobMonth && Number(istParts.day) === dobDay;
}

/**
 * Pure upcoming birthday finder across active members (Student, Teacher, Staff).
 */
export function getUpcomingBirthdays(members = [], istParts = getIstDateParts(), withinDays = 14) {
  const today = [];
  const upcoming = [];
  const curYear = Number(istParts.year);
  const todayUtc = Date.UTC(curYear, Number(istParts.month) - 1, Number(istParts.day));

  for (const m of members || []) {
    const dob = String(m.dob || "").trim().slice(0, 10);
    const match = dob.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) continue;
    const mo = Number(match[2]);
    const dy = Number(match[3]);
    if (mo < 1 || mo > 12 || dy < 1 || dy > 31) continue;

    if (isBirthdayTodayIst(dob, istParts)) {
      today.push({ ...m, dob, daysUntil: 0 });
      continue;
    }
    const adjDay = mo === 2 && dy === 29 && !isLeapYear(curYear) ? 28 : dy;
    let nextUtc = Date.UTC(curYear, mo - 1, adjDay);
    if (nextUtc < todayUtc) {
      const nextYr = curYear + 1;
      const nextAdjDay = mo === 2 && dy === 29 && !isLeapYear(nextYr) ? 28 : dy;
      nextUtc = Date.UTC(nextYr, mo - 1, nextAdjDay);
    }
    const diffDays = Math.round((nextUtc - todayUtc) / 86400000);
    if (diffDays > 0 && diffDays <= withinDays) {
      upcoming.push({ ...m, dob, daysUntil: diffDays });
    }
  }
  upcoming.sort((a, b) => a.daysUntil - b.daysUntil || String(a.full_name || "").localeCompare(String(b.full_name || "")));
  return { today, upcoming };
}

/**
 * Warm, branded Yuitor Smart Classes Birthday Email & WhatsApp message tailored by role.
 */
export function buildBirthdayEmailTemplate({ fullName = "Member", role = "student", siteUrl = "https://yuitor.com" } = {}) {
  const safeName = escapeEmailHtml(fullName || "Member");
  const cleanRole = String(role || "student").toLowerCase();
  const baseUrl = String(siteUrl || "https://yuitor.com").replace(/\/+$/, "");

  if (cleanRole === "teacher") {
    const subject = `Happy Birthday, ${fullName}! Warm Wishes from Yuitor Smart Classes Family`;
    const htmlBody = `
      <div style="background:linear-gradient(135deg,#5a0f24 0%,#7a1632 60%,#b47d1e 100%);border-radius:14px;padding:24px;color:#ffffff;text-align:center;margin-bottom:18px;">
        <div style="font-size:12px;letter-spacing:1.6px;text-transform:uppercase;color:#fde68a;font-weight:700;">Yuitor Smart Classes · Faculty Celebration</div>
        <h2 style="margin:8px 0 6px;font-size:24px;color:#ffffff;">Happy Birthday, ${safeName}!</h2>
        <p style="margin:0;color:#fef3c7;font-size:14px;">Janamdin ki Dher Saari Shubhkamnayein</p>
      </div>
      <p>Dear <strong>${safeName}</strong>,</p>
      <p>Wishing you a joyful, healthy, and fulfilling birthday from the entire <strong>Yuitor Smart Classes, Muradnagar</strong> family!</p>
      <p>Thank you for inspiring our students every single day with your dedication, patience, and knowledge. Great teachers shape futures — and we are truly grateful to have you on our faculty team.</p>
      <p style="background:#fdf8f0;border-left:4px solid #b47d1e;padding:12px 14px;border-radius:8px;color:#4a2511;">
        May this coming year bring you happiness, good health, and proud moments both inside and outside the classroom!
      </p>
      <p>With warm regards &amp; gratitude,<br/><strong>Director &amp; Team — Yuitor Smart Classes</strong><br/>Trimurti Vihar, Muradnagar</p>
    `;
    const whatsappText = `Happy Birthday ${fullName} ji! Wishing you a wonderful year filled with happiness, good health, and success. Thank you for guiding our students with such dedication. — Team Yuitor Smart Classes, Muradnagar`;
    return {
      subject,
      previewText: `Warm birthday wishes from the entire Yuitor Smart Classes faculty & management team!`,
      htmlBody,
      ctaLabel: "Open Faculty Portal",
      ctaUrl: `${baseUrl}/teacher/`,
      portalTitle: `Happy Birthday, ${fullName}!`,
      portalMessage: `Wishing you a joyful birthday from the entire Yuitor Smart Classes family! Thank you for inspiring our students every day.`,
      whatsappText
    };
  }

  if (cleanRole === "staff") {
    const subject = `Happy Birthday, ${fullName}! From Your Yuitor Smart Classes Family`;
    const htmlBody = `
      <div style="background:linear-gradient(135deg,#5a0f24 0%,#7a1632 60%,#b47d1e 100%);border-radius:14px;padding:24px;color:#ffffff;text-align:center;margin-bottom:18px;">
        <div style="font-size:12px;letter-spacing:1.6px;text-transform:uppercase;color:#fde68a;font-weight:700;">Yuitor Smart Classes · Team Celebration</div>
        <h2 style="margin:8px 0 6px;font-size:24px;color:#ffffff;">Happy Birthday, ${safeName}!</h2>
        <p style="margin:0;color:#fef3c7;font-size:14px;">Wishing You Happiness &amp; Success</p>
      </div>
      <p>Dear <strong>${safeName}</strong>,</p>
      <p>Janamdin ki hardik shubhkamnayein! Thank you for keeping Yuitor Smart Classes running smoothly and welcoming every student and parent with care.</p>
      <p>May your year ahead be full of peace, growth, and great moments!</p>
      <p>Warm regards,<br/><strong>Director &amp; Team — Yuitor Smart Classes</strong></p>
    `;
    const whatsappText = `Happy Birthday ${fullName}! Wishing you a very happy and prosperous year ahead. Thank you for being a valued pillar of Yuitor Smart Classes!`;
    return {
      subject,
      previewText: `Happy Birthday from your Yuitor Smart Classes team!`,
      htmlBody,
      ctaLabel: "Open Staff Portal",
      ctaUrl: `${baseUrl}/staff/`,
      portalTitle: `Happy Birthday, ${fullName}!`,
      portalMessage: `Janamdin ki hardik shubhkamnayein! Thank you for being a valued pillar of the Yuitor Smart Classes team.`,
      whatsappText
    };
  }

  // Student (default)
  const subject = `Happy Birthday, ${fullName}! Best Wishes from Yuitor Smart Classes`;
  const htmlBody = `
    <div style="background:linear-gradient(135deg,#5a0f24 0%,#7a1632 60%,#b47d1e 100%);border-radius:14px;padding:24px;color:#ffffff;text-align:center;margin-bottom:18px;">
      <div style="font-size:12px;letter-spacing:1.6px;text-transform:uppercase;color:#fde68a;font-weight:700;">Yuitor Smart Classes · Ek Kadam Safalta Ki Our</div>
      <h2 style="margin:8px 0 6px;font-size:24px;color:#ffffff;">Happy Birthday, ${safeName}!</h2>
      <p style="margin:0;color:#fef3c7;font-size:14px;">Janamdin ki Bahut-Bahut Badhaiyaan</p>
    </div>
    <p>Dear <strong>${safeName}</strong>,</p>
    <p>Aapko janamdin ki dher saari shubhkamnayein! Every teacher and mentor at <strong>Yuitor Smart Classes, Muradnagar</strong> is proud of your hard work and dreams.</p>
    <p style="background:#fdf8f0;border-left:4px solid #b47d1e;padding:12px 14px;border-radius:8px;color:#4a2511;">
      May this new year of your life bring top marks, crystal-clear concepts, good health, and big achievements. Keep shining — we are always with you!
    </p>
    <p>Lots of blessings &amp; best wishes,<br/><strong>Your Teachers &amp; Yuitor Smart Classes Family</strong><br/>Trimurti Vihar, Muradnagar · +91 78-2728-9292</p>
  `;
  const whatsappText = `Happy Birthday ${fullName}! Janamdin ki bahut-bahut shubhkamnayein! May this year bring you top scores, confidence, and bright success. — Your Teachers & Yuitor Smart Classes, Muradnagar`;
  return {
    subject,
    previewText: `Happy Birthday ${fullName}! Warm wishes & blessings from your teachers at Yuitor Smart Classes.`,
    htmlBody,
    ctaLabel: "Open Student Portal",
    ctaUrl: `${baseUrl}/student/`,
    portalTitle: `Happy Birthday, ${fullName}!`,
    portalMessage: `Janamdin ki dher saari shubhkamnayein! Your teachers at Yuitor Smart Classes wish you top marks, happiness, and bright success this year!`,
    whatsappText
  };
}

/**
 * Warm, role-specific "New Joining / Welcome Kit" Email for Student, Teacher, Parent, and Staff.
 */
export function buildRoleWelcomeEmailTemplate({
  fullName = "Member",
  role = "student",
  rollNumber = "",
  batchName = "",
  courseTitle = "",
  portalUrl = "",
  siteUrl = "https://yuitor.com"
} = {}) {
  const safeName = escapeEmailHtml(fullName || "Member");
  const cleanRole = String(role || "student").toLowerCase();
  const baseUrl = String(siteUrl || "https://yuitor.com").replace(/\/+$/, "");
  const defaultPortal =
    cleanRole === "teacher" ? `${baseUrl}/teacher/` :
    cleanRole === "parent" ? `${baseUrl}/parent/` :
    cleanRole === "staff" ? `${baseUrl}/staff/` :
    `${baseUrl}/student/`;
  const targetUrl = portalUrl || defaultPortal;

  if (cleanRole === "teacher") {
    return {
      subject: `Welcome to Yuitor Smart Classes Faculty Family, ${fullName}!`,
      previewText: `We are delighted to welcome you as faculty at Yuitor Smart Classes, Muradnagar.`,
      htmlBody: `
        <div style="background:linear-gradient(135deg,#5a0f24 0%,#7a1632 100%);border-radius:14px;padding:22px;color:#ffffff;margin-bottom:18px;">
          <div style="font-size:11px;letter-spacing:1.4px;text-transform:uppercase;color:#fde68a;font-weight:700;">Yuitor Smart Classes · Faculty Onboarding</div>
          <h2 style="margin:6px 0 4px;font-size:22px;color:#ffffff;">Welcome to Our Teaching Family, ${safeName}!</h2>
          <p style="margin:0;color:#fce7f3;font-size:13px;">Ek Kadam Safalta Ki Our · Trimurti Vihar, Muradnagar</p>
        </div>
        <p>Dear <strong>${safeName}</strong>,</p>
        <p>We are genuinely happy and proud to welcome you to the <strong>Yuitor Smart Classes Faculty Team</strong>! Your mentorship will help shape the confidence and board/competitive success of hundreds of local students.</p>
        <div style="background:#faf6f2;border:1px solid #eadfd6;border-radius:10px;padding:14px;margin:14px 0;">
          <strong>Your Teacher Portal Gives You:</strong>
          <ul style="margin:8px 0 0;padding-left:18px;line-height:1.6;">
            <li>Daily Class Timetable, Attendance &amp; Batch Schedule</li>
            <li>12-Hour Student Doubt Counter &amp; Homework/Test Grading</li>
            <li>Easy Leave Application &amp; Monthly Payout Statements</li>
            <li>Safe Institute-Logged Parent Alerts &amp; Anonymous Revision Insights</li>
          </ul>
        </div>
        <p>If you ever need classroom support, printed notes, or help with your portal, our Academic Desk is always here for you at <strong>+91 78-2728-9292</strong>.</p>
        <p>Warm welcome once again!<br/><strong>Director &amp; Academic Team — Yuitor Smart Classes</strong></p>
      `,
      ctaLabel: "Open Teacher Portal",
      ctaUrl: targetUrl,
      portalTitle: `Welcome to Yuitor Faculty Family, ${fullName}!`,
      portalMessage: `Your Faculty Portal is active! Check your assigned batches, timetable, and teaching tools anytime.`
    };
  }

  if (cleanRole === "staff") {
    return {
      subject: `Welcome to the Yuitor Smart Classes Team, ${fullName}!`,
      previewText: `Your Staff Portal is ready. Welcome aboard at Yuitor Smart Classes!`,
      htmlBody: `
        <div style="background:linear-gradient(135deg,#5a0f24 0%,#7a1632 100%);border-radius:14px;padding:22px;color:#ffffff;margin-bottom:18px;">
          <div style="font-size:11px;letter-spacing:1.4px;text-transform:uppercase;color:#fde68a;font-weight:700;">Yuitor Smart Classes · Team Onboarding</div>
          <h2 style="margin:6px 0 4px;font-size:22px;color:#ffffff;">Welcome Aboard, ${safeName}!</h2>
        </div>
        <p>Dear <strong>${safeName}</strong>,</p>
        <p>We are thrilled to have you join the <strong>Yuitor Smart Classes</strong> operations family! Together we make every student and parent feel supported, respected, and guided.</p>
        <p>Your Staff Portal account is now active — sign in anytime to manage admissions, fee receipts, attendance, and parent follow-ups.</p>
        <p>Best wishes for a wonderful journey with us!<br/><strong>Management — Yuitor Smart Classes, Muradnagar</strong></p>
      `,
      ctaLabel: "Open Staff Portal",
      ctaUrl: targetUrl,
      portalTitle: `Welcome to Yuitor Team, ${fullName}!`,
      portalMessage: `Your Staff Portal account is now live. Wishing you a great journey with Yuitor Smart Classes!`
    };
  }

  if (cleanRole === "parent") {
    return {
      subject: `Welcome to Yuitor Parent Portal, ${fullName}!`,
      previewText: `Track your child's daily attendance, Sunday test ranks & fee receipts in one place.`,
      htmlBody: `
        <div style="background:linear-gradient(135deg,#5a0f24 0%,#7a1632 100%);border-radius:14px;padding:22px;color:#ffffff;margin-bottom:18px;">
          <div style="font-size:11px;letter-spacing:1.4px;text-transform:uppercase;color:#fde68a;font-weight:700;">Yuitor Smart Classes · Parent Partnership</div>
          <h2 style="margin:6px 0 4px;font-size:22px;color:#ffffff;">Namaste &amp; Warm Welcome, ${safeName}!</h2>
        </div>
        <p>Dear <strong>${safeName}</strong>,</p>
        <p>Thank you for trusting <strong>Yuitor Smart Classes, Muradnagar</strong> with your child's education. We treat every student's progress as our personal responsibility.</p>
        <p>Through your Parent Portal, you can check daily attendance, Sunday test scorecards, fee receipts, and connect directly with our academic team anytime.</p>
        <p>Warm regards,<br/><strong>Yuitor Smart Classes Family</strong> · +91 78-2728-9292</p>
      `,
      ctaLabel: "Open Parent Portal",
      ctaUrl: targetUrl,
      portalTitle: `Welcome to Yuitor Parent Portal!`,
      portalMessage: `Track daily attendance, weekly test ranks, and verified fee receipts anytime from your Parent Portal.`
    };
  }

  // Student Welcome Kit (default)
  const detailsRows = [
    rollNumber ? `<li><strong>Roll Number:</strong> ${escapeEmailHtml(rollNumber)}</li>` : "",
    courseTitle ? `<li><strong>Course / Program:</strong> ${escapeEmailHtml(courseTitle)}</li>` : "",
    batchName ? `<li><strong>Assigned Batch:</strong> ${escapeEmailHtml(batchName)}</li>` : "",
    `<li><strong>Campus:</strong> Trimurti Vihar, Near Venus Academy, Muradnagar – 201206</li>`,
    `<li><strong>Student Helpline:</strong> +91 78-2728-9292</li>`
  ]
    .filter(Boolean)
    .join("");

  return {
    subject: `Welcome to Yuitor Smart Classes Family, ${fullName}! Your Journey Begins`,
    previewText: `Yuitor Parivaar me aapka swagat hai! Your Student Portal, ID Card & study tools are ready.`,
    htmlBody: `
      <div style="background:linear-gradient(135deg,#5a0f24 0%,#7a1632 100%);border-radius:14px;padding:22px;color:#ffffff;margin-bottom:18px;">
        <div style="font-size:11px;letter-spacing:1.4px;text-transform:uppercase;color:#fde68a;font-weight:700;">Yuitor Smart Classes · New Admission Welcome Kit</div>
        <h2 style="margin:6px 0 4px;font-size:22px;color:#ffffff;">Yuitor Parivaar me Swagat Hai, ${safeName}!</h2>
        <p style="margin:0;color:#fef3c7;font-size:13px;">Ek Kadam Safalta Ki Our — We Are Excited to Guide You to 95%+ &amp; Top Ranks</p>
      </div>
      <p>Dear <strong>${safeName}</strong> (and Respected Parents),</p>
      <p>Congratulations and a very warm welcome to <strong>Yuitor Smart Classes, Muradnagar</strong>! Taking this step shows your commitment to learning smartly with discipline and personal mentorship.</p>
      <div style="background:#faf6f2;border:1px solid #eadfd6;border-radius:10px;padding:14px;margin:14px 0;">
        <strong>Your Joining Summary:</strong>
        <ul style="margin:8px 0 0;padding-left:18px;line-height:1.65;">${detailsRows}</ul>
      </div>
      <p>Inside your <strong>Student Portal</strong>, you can access your Digital QR ID Card, Batch Timetable, Daily DPPs &amp; Notes, Sunday CBT Tests, 12-Hour Doubt Counter, and Private Feedback Desk.</p>
      <p>Wishing you confidence, clarity, and grand success ahead!<br/><strong>Your Teachers &amp; Team — Yuitor Smart Classes</strong></p>
    `,
    ctaLabel: "Open Student Portal",
    ctaUrl: targetUrl,
    portalTitle: `Welcome to Yuitor Smart Classes, ${fullName}!`,
    portalMessage: `Yuitor Parivaar me aapka swagat hai! Your Student Portal, timetable, notes, and doubt counter are ready.`
  };
}

/**
 * Send Birthday Wishes to all active members celebrating today (or a specific member via forceUserId).
 * Idempotent per year via crm_celebration_logs unique index — never wishes the same person twice in a year.
 * Automatically skips dropped/exited members (is_active = 0).
 */
export async function sendBirthdayWishesForToday(
  db,
  emailSender = null,
  { actorId = null, forceUserId = null, now = new Date() } = {}
) {
  const cfg = getAutomationConfig(db);
  if (!forceUserId && (Number(cfg.global_kill_switch) === 1 || Number(cfg.birthday_wishes_enabled ?? 1) !== 1)) {
    return { skipped: true, reason: "disabled_or_kill_switch", wished: 0, alreadyWished: 0, items: [] };
  }

  const ist = getIstDateParts(now);
  const yearKey = String(ist.year);
  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");

  const sql = forceUserId
    ? `SELECT u.id, u.role, u.full_name, u.email, u.phone,
              CASE WHEN u.dob != '' THEN u.dob ELSE COALESCE(sp.dob, '') END AS dob
       FROM users u
       LEFT JOIN student_profiles sp ON sp.user_id = u.id
       WHERE u.id = ? AND u.is_active = 1`
    : `SELECT u.id, u.role, u.full_name, u.email, u.phone,
              CASE WHEN u.dob != '' THEN u.dob ELSE COALESCE(sp.dob, '') END AS dob
       FROM users u
       LEFT JOIN student_profiles sp ON sp.user_id = u.id
       WHERE u.is_active = 1 AND u.role IN ('student', 'teacher', 'staff')
         AND (u.dob != '' OR COALESCE(sp.dob, '') != '')`;

  const rows = forceUserId ? [db.prepare(sql).get(Number(forceUserId))].filter(Boolean) : db.prepare(sql).all();
  const targets = forceUserId ? rows : rows.filter((r) => isBirthdayTodayIst(r.dob, ist));

  let wished = 0;
  let alreadyWished = 0;
  const items = [];
  const stamp = nowIso();

  for (const m of targets) {
    const existing = db
      .prepare(`SELECT id FROM crm_celebration_logs WHERE user_id = ? AND event_type = 'birthday' AND year_key = ? LIMIT 1`)
      .get(m.id, yearKey);
    if (existing) {
      alreadyWished += 1;
      items.push({ userId: m.id, fullName: m.full_name, role: m.role, alreadyWished: true });
      continue;
    }

    const tpl = buildBirthdayEmailTemplate({ fullName: m.full_name, role: m.role, siteUrl });
    let emailStatus = "portal_only";
    if (emailSender && m.email) {
      try {
        const res = await emailSender({
          to: m.email,
          recipientName: m.full_name || "Member",
          subject: tpl.subject,
          previewText: tpl.previewText,
          htmlBody: tpl.htmlBody,
          ctaLabel: tpl.ctaLabel,
          ctaUrl: tpl.ctaUrl
        });
        emailStatus = res?.sent || res?.ok ? "sent" : "logged_no_smtp";
      } catch {
        emailStatus = "email_failed_portal_sent";
      }
    }

    // In-app Portal Notification so member immediately sees birthday wishes on login
    db.prepare(
      `INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)`
    ).run(m.id, tpl.portalTitle, tpl.portalMessage, stamp);

    db.prepare(
      `INSERT OR IGNORE INTO crm_celebration_logs (
         user_id, role, event_type, year_key, channel, recipient_email, subject, status, sent_by, created_at
       ) VALUES (?, ?, 'birthday', ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      m.id,
      m.role,
      yearKey,
      m.email ? "email_and_portal" : "portal",
      m.email || "",
      tpl.subject,
      emailStatus,
      actorId ? Number(actorId) : null,
      stamp
    );

    wished += 1;
    items.push({
      userId: m.id,
      fullName: m.full_name,
      role: m.role,
      emailStatus,
      whatsappUrl: m.phone ? buildWhatsAppClickToChatUrl(m.phone, tpl.whatsappText) : ""
    });
  }

  return { ok: true, dateStr: ist.dateStr, yearKey, matched: targets.length, wished, alreadyWished, items };
}

/**
 * Send Role-Wise New Joining Welcome Kit Email + Portal Welcome Greeting.
 */
export async function sendRoleWelcomeKit(
  db,
  emailSender = null,
  { userId, actorId = null, batchName = "", courseTitle = "" } = {}
) {
  const uid = Number(userId);
  const user = db
    .prepare(
      `SELECT u.id, u.role, u.full_name, u.email, u.phone, u.is_active,
              sp.roll_number,
              COALESCE(b.name, '') AS batch_name,
              COALESCE(c.title, '') AS course_title
       FROM users u
       LEFT JOIN student_profiles sp ON sp.user_id = u.id
       LEFT JOIN batches b ON b.id = sp.batch_id
       LEFT JOIN enrollments e ON e.student_id = u.id AND e.status = 'active'
       LEFT JOIN courses c ON c.id = e.course_id
       WHERE u.id = ?
       LIMIT 1`
    )
    .get(uid);
  if (!user) throw new Error("Member account not found.");

  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  const tpl = buildRoleWelcomeEmailTemplate({
    fullName: user.full_name,
    role: user.role,
    rollNumber: user.roll_number || "",
    batchName: batchName || user.batch_name || "",
    courseTitle: courseTitle || user.course_title || "",
    siteUrl
  });

  let emailStatus = "portal_only";
  if (emailSender && user.email) {
    try {
      const res = await emailSender({
        to: user.email,
        recipientName: user.full_name || "Member",
        subject: tpl.subject,
        previewText: tpl.previewText,
        htmlBody: tpl.htmlBody,
        ctaLabel: tpl.ctaLabel,
        ctaUrl: tpl.ctaUrl
      });
      emailStatus = res?.sent || res?.ok ? "sent" : "logged_no_smtp";
    } catch {
      emailStatus = "email_failed_portal_sent";
    }
  }

  const stamp = nowIso();
  db.prepare(
    `INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)`
  ).run(user.id, tpl.portalTitle, tpl.portalMessage, stamp);

  db.prepare(
    `INSERT INTO crm_celebration_logs (
       user_id, role, event_type, year_key, channel, recipient_email, subject, status, sent_by, created_at
     ) VALUES (?, ?, 'welcome_joining', ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    user.id,
    user.role,
    getIstDateParts().dateStr,
    user.email ? "email_and_portal" : "portal",
    user.email || "",
    tpl.subject,
    emailStatus,
    actorId ? Number(actorId) : null,
    stamp
  );

  return {
    ok: true,
    userId: user.id,
    fullName: user.full_name,
    role: user.role,
    email: user.email || "",
    subject: tpl.subject,
    emailStatus
  };
}


