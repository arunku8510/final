import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  resolveTrustProxySetting,
  safeClientIp,
  verifyStrictSetupKey,
  isInstallerWindowExpired,
  resolveInstallerOwnerEmail,
  generateHighEntropyAdminSlug,
  redactSecretsForLog,
  verifyCsrfProtection,
  validateUploadMagicAndMime,
  verifyResumeDocumentContent,
  analyzeResumeText,
  isStrictLibrarian,
  stripLibrarianStudentPii,
  stripLibrarianLibraryIssues,
  buildCspHeader
} from "./security-hardening.mjs";

test("resolveTrustProxySetting defaults to false and parses numeric/boolean/string safely", () => {
  assert.equal(resolveTrustProxySetting(undefined), false);
  assert.equal(resolveTrustProxySetting(""), false);
  assert.equal(resolveTrustProxySetting("false"), false);
  assert.equal(resolveTrustProxySetting("0"), false);
  assert.equal(resolveTrustProxySetting("1"), 1);
  assert.equal(resolveTrustProxySetting("true"), true);
  assert.equal(resolveTrustProxySetting("loopback"), "loopback");
});

test("safeClientIp ignores raw X-Forwarded-For spoofing header", () => {
  const req = {
    ip: "::ffff:127.0.0.1",
    headers: { "x-forwarded-for": "1.2.3.4, 5.6.7.8" },
    socket: { remoteAddress: "::ffff:127.0.0.1" }
  };
  assert.equal(safeClientIp(req), "127.0.0.1");
});

test("verifyStrictSetupKey fails closed when empty or too short", () => {
  assert.equal(verifyStrictSetupKey("anything", ""), false);
  assert.equal(verifyStrictSetupKey("short", "short"), false);
  assert.equal(verifyStrictSetupKey("wrong-key-12345678", "super-secret-setup-key-999"), false);
  assert.equal(verifyStrictSetupKey("super-secret-setup-key-999", "super-secret-setup-key-999"), true);
});

test("isInstallerWindowExpired enforces ISO and unix timestamps", () => {
  const now = Date.parse("2026-06-01T12:00:00Z");
  assert.equal(isInstallerWindowExpired("", now), false);
  assert.equal(isInstallerWindowExpired("2026-06-01T11:00:00Z", now), true);
  assert.equal(isInstallerWindowExpired("2026-06-01T13:00:00Z", now), false);
  assert.equal(isInstallerWindowExpired("not-a-date", now), true);
});

test("resolveInstallerOwnerEmail uses env OWNER_EMAIL or ADMIN_OTP_EMAIL only", () => {
  assert.equal(resolveInstallerOwnerEmail({}), "");
  assert.equal(resolveInstallerOwnerEmail({ OWNER_EMAIL: "owner@yuitor.com" }), "owner@yuitor.com");
  assert.equal(resolveInstallerOwnerEmail({ ADMIN_OTP_EMAIL: "admin@yuitor.com" }), "admin@yuitor.com");
});

test("generateHighEntropyAdminSlug generates >= 34 char 128-bit hex slug", () => {
  const s1 = generateHighEntropyAdminSlug();
  const s2 = generateHighEntropyAdminSlug();
  assert.match(s1, /^g-[a-f0-9]{32}$/);
  assert.notEqual(s1, s2);
});

test("redactSecretsForLog strips passwords, OTPs, tokens, and explicit secrets", () => {
  const out = redactSecretsForLog(
    "Login failed password=MySecret123 otp=654321 Bearer eyJhbGciOi.secret.token gate=/g-0123456789abcdef0123456789abcdef/",
    ["g-0123456789abcdef0123456789abcdef"]
  );
  assert.doesNotMatch(out, /MySecret123/);
  assert.doesNotMatch(out, /654321/);
  assert.doesNotMatch(out, /eyJhbGciOi/);
  assert.doesNotMatch(out, /g-0123456789abcdef0123456789abcdef/);
});

test("verifyCsrfProtection blocks missing Origin/Referer without CSRF token and allows webhook", () => {
  const makeReq = (overrides) => ({
    method: "POST",
    path: "/auth/login",
    originalUrl: "/api/auth/login",
    headers: { host: "localhost:3000" },
    hostname: "localhost",
    cookies: {},
    app: { get: () => false },
    ...overrides
  });

  assert.equal(verifyCsrfProtection(makeReq({})).ok, false);
  assert.equal(verifyCsrfProtection(makeReq({ headers: { host: "localhost:3000", origin: "https://evil.example" } })).ok, false);
  assert.equal(verifyCsrfProtection(makeReq({ headers: { host: "localhost:3000", origin: "http://localhost:3000" } })).ok, true);
  assert.equal(
    verifyCsrfProtection(makeReq({ path: "/payments/webhook", originalUrl: "/api/payments/webhook" })).ok,
    true
  );

  const csrfTok = "a".repeat(48);
  assert.equal(
    verifyCsrfProtection(
      makeReq({
        cookies: { yu_csrf: csrfTok },
        headers: { host: "localhost:3000", "x-csrf-token": csrfTok }
      })
    ).ok,
    true
  );
});

test("validateUploadMagicAndMime blocks spoofed PDF, double extensions, and executables", () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "yuitor-sec-test-"));
  try {
    const allowed = new Set([".pdf", ".png", ".jpg", ".jpeg", ".webp"]);

    const fakePdf = path.join(tmpDir, "fake.pdf");
    fs.writeFileSync(fakePdf, "<?php system($_GET['c']); ?>");
    assert.equal(validateUploadMagicAndMime(fakePdf, "fake.pdf", "application/pdf", allowed).ok, false);

    const exeAsPdf = path.join(tmpDir, "mz.pdf");
    fs.writeFileSync(exeAsPdf, Buffer.from([0x4d, 0x5a, 0x90, 0x00, 0x03, 0x00]));
    assert.equal(validateUploadMagicAndMime(exeAsPdf, "mz.pdf", "application/pdf", allowed).ok, false);

    const realPdf = path.join(tmpDir, "real.pdf");
    fs.writeFileSync(realPdf, "%PDF-1.7\n1 0 obj\n<<>>\nendobj\n");
    assert.equal(validateUploadMagicAndMime(realPdf, "real.pdf", "application/pdf", allowed).ok, true);
    assert.equal(validateUploadMagicAndMime(realPdf, "evil.php.pdf", "application/pdf", allowed).ok, false);
    assert.equal(validateUploadMagicAndMime(realPdf, "real.pdf", "text/html", allowed).ok, false);
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test("Librarian PII stripping removes mobile, roll number, and academic class", () => {
  const ctx = { user: { role: "staff", staff_role: "librarian", staff_permissions: [] } };
  assert.equal(isStrictLibrarian(ctx), true);
  const stripped = stripLibrarianStudentPii([
    { id: 5, full_name: "Aarav", phone: "9876543210", roll_number: "YTR-STU-0005", class_level: "Class 10" }
  ]);
  assert.deepEqual(stripped, [{ id: 5, full_name: "Aarav" }]);
  const issues = stripLibrarianLibraryIssues([
    { id: 1, book_title: "Physics", student_name: "Aarav", roll_number: "YTR-STU-0005", phone: "9876543210" }
  ]);
  assert.equal("roll_number" in issues[0], false);
  assert.equal("phone" in issues[0], false);
});

test("buildCspHeader enforces frame-ancestors and allows Razorpay", () => {
  const csp = buildCspHeader();
  assert.match(csp, /frame-ancestors 'self'/);
  assert.match(csp, /checkout\.razorpay\.com/);
  assert.match(csp, /object-src 'none'/);
  assert.match(csp, /manifest-src 'self'/);
});

test("verifyCsrfProtection handles Origin: null from mobile WebViews using double-submit token", () => {
  const tok = "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4";
  const reqWithToken = {
    method: "POST",
    path: "/api/public/inquiries",
    headers: { host: "yuitor.com", origin: "null", "x-csrf-token": tok },
    cookies: { yu_csrf: tok },
    app: { get: () => false }
  };
  assert.equal(verifyCsrfProtection(reqWithToken).ok, true);

  const reqNoToken = {
    method: "POST",
    path: "/api/public/inquiries",
    headers: { host: "yuitor.com", origin: "null" },
    cookies: {},
    app: { get: () => false }
  };
  assert.equal(verifyCsrfProtection(reqNoToken).ok, false);
});

test("verifyResumeDocumentContent accepts genuine PDF resume and rejects blank, invoice, and random PDFs", () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "yuitor-resume-"));
  const makeSimplePdf = (textLines) => {
    const ops = textLines.map((l) => `(${l.replace(/[()\\]/g, " ")}) Tj T*`).join("\n");
    return Buffer.from(`%PDF-1.4\n1 0 obj << /Length ${ops.length + 20} >>\nstream\nBT /F1 12 Tf\n${ops}\nET\nendstream\nendobj\n%%EOF\n`, "latin1");
  };
  try {
    const goodPdf = path.join(tmpDir, "teacher_resume.pdf");
    fs.writeFileSync(goodPdf, makeSimplePdf([
      "CURRICULUM VITAE - PRIYA SHARMA",
      "Email: priya.sharma@example.com | Mobile: 9876543210 | Muradnagar",
      "Career Objective: Passionate Physics and Mathematics educator for Classes 9 to 12.",
      "Education: M.Sc Physics from CCS University (2020), B.Ed (2022), CTET Qualified.",
      "Teaching Experience: 4 years of experience as Senior Physics Faculty at Sunrise Academy.",
      "Skills: Physics, Mathematics, JEE Foundation, CBSE & UP Board preparation."
    ]));
    const goodRes = verifyResumeDocumentContent(goodPdf, "teacher_resume.pdf", "application/pdf");
    assert.equal(goodRes.ok, true);
    assert.equal(goodRes.format, "PDF");

    const blankPdf = path.join(tmpDir, "blank.pdf");
    fs.writeFileSync(blankPdf, Buffer.from("%PDF-1.4\n1 0 obj <<>> endobj\n%%EOF\n"));
    const blankRes = verifyResumeDocumentContent(blankPdf, "blank.pdf", "application/pdf");
    assert.equal(blankRes.ok, false);
    assert.equal(blankRes.code, "RESUME_UNREADABLE_OR_BLANK");

    const invoicePdf = path.join(tmpDir, "invoice_bill.pdf");
    fs.writeFileSync(invoicePdf, makeSimplePdf([
      "TAX INVOICE #INV-2026-991",
      "GSTIN: 09ABCDE1234F1Z5 | Bill To: Customer Name",
      "Item: Coaching Books | Subtotal: 1500 | CGST 9% | SGST 9% | Grand Total: 1770",
      "Amount Payable via UPI. Contact: billing@shop.com | Phone: 9811112222"
    ]));
    const invRes = verifyResumeDocumentContent(invoicePdf, "invoice_bill.pdf", "application/pdf");
    assert.equal(invRes.ok, false);
    assert.equal(invRes.code, "NOT_A_RESUME");

    const randomDoc = analyzeResumeText("Hello everyone today is a nice sunny day in the park and we went shopping for groceries and fruits with friends.");
    assert.equal(randomDoc.ok, false);
    assert.equal(randomDoc.code, "NOT_A_RESUME");
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});
