import test from "node:test";
import assert from "node:assert/strict";
import {
  BILLING_CYCLES,
  CLASS_FEE_PLANS,
  parseClassNumberFromLabel,
  normalizeBillingCycle,
  calculateClassFeePlan,
} from "./fee-plans.mjs";

test("v3.0 official Class 6th-12th fee plans match exact specification", () => {
  const expected = [
    [6, "Class 6th", 600, 7200, 720, 6480],
    [7, "Class 7th", 650, 7800, 780, 7020],
    [8, "Class 8th", 700, 8400, 840, 7560],
    [9, "Class 9th", 750, 9000, 900, 8100],
    [10, "Class 10th", 800, 9600, 960, 8640],
    [11, "Class 11th", 850, 10200, 1020, 9180],
    [12, "Class 12th", 900, 10800, 1080, 9720],
  ];

  assert.equal(CLASS_FEE_PLANS.length, 7);
  assert.equal(BILLING_CYCLES.length, 5);

  for (const [cls, label, monthly, yearlyGross, savings, yearlyNet] of expected) {
    const plan = CLASS_FEE_PLANS.find((p) => p.classNumber === cls);
    assert.ok(plan, `Missing fee plan for class ${cls}`);
    assert.equal(plan.classLabel, label);
    assert.equal(plan.monthly, monthly);
    assert.equal(plan.yearlyGross, yearlyGross);
    assert.equal(plan.yearlySavings, savings);
    assert.equal(plan.yearlyTotal, yearlyNet);

    // Check all 5 billing cycles
    assert.equal(calculateClassFeePlan(cls, "1m").totalPayable, monthly);
    assert.equal(calculateClassFeePlan(cls, "3m").totalPayable, monthly * 3);
    assert.equal(calculateClassFeePlan(cls, "6m").totalPayable, monthly * 6);
    assert.equal(calculateClassFeePlan(cls, "9m").totalPayable, monthly * 9);
    const yr = calculateClassFeePlan(cls, "yearly");
    assert.equal(yr.subtotal, yearlyGross);
    assert.equal(yr.discountPercent, 10);
    assert.equal(yr.discountAmount, savings);
    assert.equal(yr.totalPayable, yearlyNet);
  }
});

test("v3.0 class label parser & billing cycle normalizer handle variants safely", () => {
  assert.equal(parseClassNumberFromLabel("Class 6th"), 6);
  assert.equal(parseClassNumberFromLabel("Class 10 — UP Board"), 10);
  assert.equal(parseClassNumberFromLabel("12th Science PCM"), 12);
  assert.equal(parseClassNumberFromLabel("Unknown Program"), null);
  assert.equal(calculateClassFeePlan("Unknown Program", "yearly").classNumber, 10);

  assert.equal(normalizeBillingCycle("1m"), "1m");
  assert.equal(normalizeBillingCycle("3m"), "3m");
  assert.equal(normalizeBillingCycle("6m"), "6m");
  assert.equal(normalizeBillingCycle("9m"), "9m");
  assert.equal(normalizeBillingCycle("yearly"), "yearly");
  assert.equal(normalizeBillingCycle("12m"), "yearly");
  assert.equal(normalizeBillingCycle("annual"), "yearly");
  assert.equal(normalizeBillingCycle("invalid"), "1m");
});
