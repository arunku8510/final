import crypto from "node:crypto";
import { nowIso, runInImmediateTx } from "./addons-db.mjs";
import {
  BILLING_CYCLES,
  calculateComboDiscount,
  calculateCourseCyclePrice,
  normalizeBillingCycle,
} from "./fee-plans.mjs";
import {
  computeStudentCrossSellState,
  getCrossSellSettings,
  markCrossSellPurchased,
} from "./v31-engine.mjs";
import { getV32Settings } from "./v32-engine.mjs";

function cleanStr(val, maxLen = 120) {
  return String(val || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, maxLen);
}

export function mergeGuestCartToUser(db, userId, guestToken) {
  const token = cleanStr(guestToken, 80);
  if (!userId || !token) return 0;

  return runInImmediateTx(db, () => {
    const guestItems = db
      .prepare("SELECT * FROM cart_items WHERE guest_token = ? AND user_id IS NULL")
      .all(token);
    if (guestItems.length === 0) return 0;

    let merged = 0;
    const now = nowIso();
    for (const item of guestItems) {
      const existing = db
        .prepare("SELECT id FROM cart_items WHERE user_id = ? AND course_id = ? LIMIT 1")
        .get(userId, item.course_id);
      if (existing) {
        db.prepare(
          "UPDATE cart_items SET plan = ?, batch_id = COALESCE(?, batch_id), updated_at = ? WHERE id = ?"
        ).run(item.plan, item.batch_id || null, now, existing.id);
        db.prepare("DELETE FROM cart_items WHERE id = ?").run(item.id);
      } else {
        db.prepare(
          "UPDATE cart_items SET user_id = ?, guest_token = '', updated_at = ? WHERE id = ?"
        ).run(userId, now, item.id);
      }
      merged++;
    }
    return merged;
  });
}

function resolvePromoCodeServerSide(db, cleanCode, subtotal, userId = null) {
  if (!cleanCode || subtotal <= 0) {
    return { applied: null, discountAmount: 0, error: "" };
  }

  const today = nowIso().slice(0, 10);

  // 1. Standard Coupons table (includes active festival / scholarship coupon codes)
  try {
    const coupon = db.prepare("SELECT * FROM coupons WHERE UPPER(code) = ? AND is_active = 1").get(cleanCode);
    if (coupon) {
      if (Number(coupon.used_count) >= Number(coupon.max_uses) || (coupon.expires_at && coupon.expires_at < today)) {
        return { applied: null, discountAmount: 0, error: "Coupon code expired or usage limit reached." };
      }
      const discountAmount =
        coupon.discount_type === "percent"
          ? Math.round((subtotal * Number(coupon.discount_value || 0)) / 100)
          : Math.min(subtotal, Number(coupon.discount_value || 0));
      return {
        applied: {
          code: coupon.code,
          kind: cleanCode.startsWith("SCHOLAR") ? "scholarship" : "coupon",
          discountType: coupon.discount_type,
          discountValue: Number(coupon.discount_value || 0),
          discountAmount,
        },
        discountAmount,
        error: "",
      };
    }
  } catch {
    // ignore if coupons missing
  }

  // 2. Approved Scholarship Application code (e.g. YTR-SCH-XXXX or scholarship_code)
  try {
    const sch = db.prepare(`
      SELECT id, full_name, status, scholarship_percent, application_code
      FROM scholarship_applications
      WHERE UPPER(COALESCE(application_code, '')) = ? AND LOWER(COALESCE(status, '')) IN ('approved', 'awarded', 'verified')
      LIMIT 1
    `).get(cleanCode);
    if (sch) {
      const pct = Math.min(50, Math.max(5, Number(sch.scholarship_percent || 15)));
      const discountAmount = Math.round((subtotal * pct) / 100);
      return {
        applied: {
          code: cleanCode,
          kind: "scholarship",
          discountType: "percent",
          discountValue: pct,
          discountAmount,
          label: `Scholarship (${pct}% OFF)`,
        },
        discountAmount,
        error: "",
      };
    }
  } catch {
    // optional columns on older schemas
  }

  // 3. Teacher or Student Referral Code (verified from referral_profiles -> 5% welcome discount, blocks self-referral)
  try {
    const ref = db.prepare(`
      SELECT rp.referral_code, rp.role, rp.user_id, u.full_name
      FROM referral_profiles rp
      JOIN users u ON u.id = rp.user_id
      WHERE UPPER(rp.referral_code) = ? AND u.is_active = 1
      LIMIT 1
    `).get(cleanCode);
    if (ref) {
      if (userId && Number(ref.user_id) === Number(userId)) {
        return { applied: null, discountAmount: 0, error: "Self-referral code cannot be used on your own checkout." };
      }
      const pct = ref.role === "teacher" ? 5 : 5;
      const discountAmount = Math.round((subtotal * pct) / 100);
      return {
        applied: {
          code: ref.referral_code,
          kind: ref.role === "teacher" ? "teacher_referral" : "student_referral",
          discountType: "percent",
          discountValue: pct,
          discountAmount,
          referrerName: ref.full_name,
          referrerUserId: Number(ref.user_id),
          label: `${ref.role === "teacher" ? "Teacher" : "Student"} Referral (${pct}% OFF)`,
        },
        discountAmount,
        error: "",
      };
    }
  } catch {
    // ignore
  }

  return { applied: null, discountAmount: 0, error: "Invalid, expired, or unverified Coupon / Referral / Scholarship code." };
}

export function getCartDetails(db, { userId = null, guestToken = "", couponCode = "", isSibling = false }) {
  const token = cleanStr(guestToken, 80);
  if (userId && token) {
    mergeGuestCartToUser(db, userId, token);
  }

  let rows = [];
  if (userId) {
    rows = db
      .prepare(
        `SELECT ci.*, c.title, c.slug, c.category, c.class_range, c.board, c.duration_months,
                c.monthly_fee, c.yearly_fee, c.thumbnail_url,
                b.name AS batch_name, b.room_name AS batch_room, b.schedule_days AS batch_days,
                b.start_time AS batch_start, b.end_time AS batch_end
         FROM cart_items ci
         JOIN courses c ON c.id = ci.course_id AND c.is_active = 1
         LEFT JOIN batches b ON b.id = ci.batch_id
         WHERE ci.user_id = ?
         ORDER BY ci.id DESC`
      )
      .all(userId);
  } else if (token) {
    rows = db
      .prepare(
        `SELECT ci.*, c.title, c.slug, c.category, c.class_range, c.board, c.duration_months,
                c.monthly_fee, c.yearly_fee, c.thumbnail_url,
                b.name AS batch_name, b.room_name AS batch_room, b.schedule_days AS batch_days,
                b.start_time AS batch_start, b.end_time AS batch_end
         FROM cart_items ci
         JOIN courses c ON c.id = ci.course_id AND c.is_active = 1
         LEFT JOIN batches b ON b.id = ci.batch_id
         WHERE ci.guest_token = ? AND ci.user_id IS NULL
         ORDER BY ci.id DESC`
      )
      .all(token);
  }

  const items = rows.map((r) => {
    const pricing = calculateCourseCyclePrice(r, r.plan);
    return {
      id: Number(r.id),
      courseId: Number(r.course_id),
      batchId: r.batch_id ? Number(r.batch_id) : null,
      batchName: r.batch_name || "",
      batchTiming: r.batch_start ? `${r.batch_days || "Mon-Sat"} ${r.batch_start}-${r.batch_end || ""}`.trim() : "",
      plan: pricing.cycle,
      planLabel: pricing.label,
      months: pricing.months,
      title: r.title,
      subjectLabel: r.subject_label || "",
      category: r.category,
      classRange: r.class_range || r.category,
      board: r.board,
      durationMonths: pricing.months,
      monthlyFee: pricing.monthlyRate,
      yearlyFee: calculateCourseCyclePrice(r, "yearly").totalPayable,
      grossTotal: pricing.grossTotal,
      yearlySavings: pricing.yearlySavings,
      yearlyDiscountPercent: pricing.yearlyDiscountPercent,
      thumbnailUrl: r.thumbnail_url || "",
      unitPrice: pricing.totalPayable,
    };
  });

  const grossSubtotal = items.reduce((sum, it) => sum + it.grossTotal, 0);
  const yearlySavingsTotal = items.reduce((sum, it) => sum + it.yearlySavings, 0);
  const subtotal = items.reduce((sum, it) => sum + it.unitPrice, 0);

  let discountAmount = 0;
  let couponApplied = null;
  let couponError = "";
  let crossSellApplied = null;
  let comboDiscountApplied = null;
  const cleanCode = cleanStr(couponCode, 40).toUpperCase();

  // Check Admin v3.2 settings for Multi-Subject Combo / Sibling Discount
  const v32Settings = getV32Settings(db);
  let csSettings = { masterSwitch: false };
  try {
    csSettings = getCrossSellSettings(db);
  } catch {
    csSettings = { masterSwitch: false };
  }

  // Check server-side Cross-Sell eligibility strictly respecting Admin Master Switch
  let crossSellState = null;
  let crossSellEligibleSubtotal = 0;
  if (csSettings.masterSwitch && items.length > 0) {
    if (userId) {
      try {
        crossSellState = computeStudentCrossSellState(db, userId);
        if (crossSellState?.eligible && crossSellState.discountPercent > 0) {
          const eligibleIds = new Set((crossSellState.availableCourses || []).map((c) => Number(c.id)));
          crossSellEligibleSubtotal = items
            .filter((it) => eligibleIds.has(Number(it.courseId)))
            .reduce((sum, it) => sum + it.unitPrice, 0);
        }
      } catch {
        crossSellState = null;
      }
    } else if (items.length >= 2) {
      // Public frontend cross-sell synced with Master Switch: adding 2nd+ course gets 10% Week-1 cross-sell on extra course(s)
      crossSellEligibleSubtotal = items.slice(1).reduce((sum, it) => sum + it.unitPrice, 0);
      crossSellState = { eligible: true, discountPercent: 10, weekNumber: 1 };
    }
  }

  // Multi-Subject Combo / Sibling Discount (applies automatically when 2+ items or sibling toggle AND Admin setting ON)
  const comboCalc = calculateComboDiscount(subtotal, items.length, {
    enabled: v32Settings.comboDiscountEnabled,
    percent: v32Settings.comboDiscountPercent,
    isSibling: Boolean(isSibling),
  });

  if (cleanCode && subtotal > 0) {
    if (crossSellEligibleSubtotal > 0) {
      couponError = "Cross-sell discount cannot be combined with coupon codes. Your automatic cross-sell discount has been applied instead.";
      discountAmount = Math.round((crossSellEligibleSubtotal * crossSellState.discountPercent) / 100);
      crossSellApplied = {
        discountPercent: crossSellState.discountPercent,
        weekNumber: crossSellState.weekNumber,
        discountAmount,
      };
    } else {
      const promo = resolvePromoCodeServerSide(db, cleanCode, subtotal, userId);
      if (promo.error) {
        couponError = promo.error;
      } else if (promo.applied) {
        couponApplied = promo.applied;
        discountAmount = promo.discountAmount;
      }
      // Allow combo/sibling discount to stack ONLY if no coupon or choose best non-double discount; keep transparent
      if (!couponApplied && comboCalc.applied) {
        discountAmount = comboCalc.discountAmount;
        comboDiscountApplied = comboCalc;
      }
    }
  } else if (crossSellEligibleSubtotal > 0) {
    discountAmount = Math.round((crossSellEligibleSubtotal * crossSellState.discountPercent) / 100);
    crossSellApplied = {
      discountPercent: crossSellState.discountPercent,
      weekNumber: crossSellState.weekNumber,
      discountAmount,
    };
  } else if (comboCalc.applied) {
    discountAmount = comboCalc.discountAmount;
    comboDiscountApplied = comboCalc;
  }

  const totalAmount = Math.max(0, subtotal - discountAmount);
  return {
    items,
    count: items.length,
    grossSubtotal,
    yearlySavingsTotal,
    subtotal,
    discountAmount,
    totalAmount,
    couponApplied,
    couponError,
    crossSellApplied,
    crossSellMasterSwitch: csSettings.masterSwitch,
    comboDiscountApplied,
    comboDiscountSettings: {
      enabled: v32Settings.comboDiscountEnabled,
      percent: v32Settings.comboDiscountPercent,
    },
    supportedPlans: BILLING_CYCLES,
  };
}

export function addOrUpdateCartItem(
  db,
  { userId = null, guestToken = "", courseId, plan = "1m", batchId = null, subjectLabel = "" }
) {
  const cid = Number(courseId);
  const course = db.prepare("SELECT id, title, is_active FROM courses WHERE id = ? AND is_active = 1").get(cid);
  if (!course) throw new Error("Selected course not found or inactive.");

  const safePlan = normalizeBillingCycle(plan);
  let safeBatchId = batchId ? Number(batchId) : null;
  if (safeBatchId) {
    const batch = db.prepare("SELECT id, course_id, is_active FROM batches WHERE id = ?").get(safeBatchId);
    if (!batch || Number(batch.is_active) !== 1 || Number(batch.course_id) !== cid) {
      throw new Error("Selected batch does not match this course.");
    }
  } else {
    // Auto-select first active batch for this class course if available
    const defaultBatch = db.prepare("SELECT id FROM batches WHERE course_id = ? AND is_active = 1 ORDER BY id ASC LIMIT 1").get(cid);
    if (defaultBatch) safeBatchId = Number(defaultBatch.id);
  }

  const token = cleanStr(guestToken, 80);
  if (!userId && !token) throw new Error("Missing cart session identifier.");

  const cleanSubject = cleanStr(subjectLabel, 80);
  const now = nowIso();
  return runInImmediateTx(db, () => {
    const existing = userId
      ? db.prepare("SELECT id FROM cart_items WHERE user_id = ? AND course_id = ? LIMIT 1").get(userId, cid)
      : db
          .prepare("SELECT id FROM cart_items WHERE guest_token = ? AND user_id IS NULL AND course_id = ? LIMIT 1")
          .get(token, cid);

    if (existing) {
      try {
        db.prepare(
          "UPDATE cart_items SET plan = ?, batch_id = ?, subject_label = ?, reminder_sent_at = '', updated_at = ? WHERE id = ?"
        ).run(safePlan, safeBatchId, cleanSubject, now, existing.id);
      } catch {
        db.prepare("UPDATE cart_items SET plan = ?, batch_id = ?, updated_at = ? WHERE id = ?").run(
          safePlan,
          safeBatchId,
          now,
          existing.id
        );
      }
      return { itemId: Number(existing.id), updated: true, courseTitle: course.title, plan: safePlan };
    }

    let ins;
    try {
      ins = db
        .prepare(
          `INSERT INTO cart_items (user_id, guest_token, course_id, batch_id, plan, subject_label, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(userId || null, userId ? "" : token, cid, safeBatchId, safePlan, cleanSubject, now, now);
    } catch {
      ins = db
        .prepare(
          `INSERT INTO cart_items (user_id, guest_token, course_id, batch_id, plan, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        )
        .run(userId || null, userId ? "" : token, cid, safeBatchId, safePlan, now, now);
    }

    return { itemId: Number(ins.lastInsertRowid), updated: false, courseTitle: course.title, plan: safePlan };
  });
}

export function updateCartItemPlanOrBatch(db, { userId = null, guestToken = "", itemId, plan, batchId }) {
  const id = Number(itemId);
  const item = db.prepare("SELECT * FROM cart_items WHERE id = ?").get(id);
  if (!item) throw new Error("Cart item not found.");
  if (userId && Number(item.user_id) !== Number(userId)) throw new Error("Access denied.");
  if (!userId && item.guest_token !== cleanStr(guestToken, 80)) throw new Error("Access denied.");

  const nextPlan = plan !== undefined ? normalizeBillingCycle(plan) : normalizeBillingCycle(item.plan);
  const nextBatch = batchId === null || batchId === "" ? null : batchId !== undefined ? Number(batchId) : item.batch_id;
  if (nextBatch) {
    const batch = db.prepare("SELECT id, course_id, is_active FROM batches WHERE id = ?").get(nextBatch);
    if (!batch || Number(batch.is_active) !== 1 || Number(batch.course_id) !== Number(item.course_id)) {
      throw new Error("Invalid batch selection for this course.");
    }
  }
  db.prepare("UPDATE cart_items SET plan = ?, batch_id = ?, updated_at = ? WHERE id = ?").run(
    nextPlan,
    nextBatch || null,
    nowIso(),
    id
  );
  return { updated: true, plan: nextPlan };
}

export function removeCartItem(db, { userId = null, guestToken = "", itemId }) {
  const id = Number(itemId);
  const item = db.prepare("SELECT * FROM cart_items WHERE id = ?").get(id);
  if (!item) return { deleted: false };
  if (userId && Number(item.user_id) !== Number(userId)) throw new Error("Access denied.");
  if (!userId && item.guest_token !== cleanStr(guestToken, 80)) throw new Error("Access denied.");

  db.prepare("DELETE FROM cart_items WHERE id = ?").run(id);
  return { deleted: true };
}

export function clearCart(db, { userId = null, guestToken = "" }) {
  if (userId) {
    db.prepare("DELETE FROM cart_items WHERE user_id = ?").run(userId);
  } else if (guestToken) {
    db.prepare("DELETE FROM cart_items WHERE guest_token = ? AND user_id IS NULL").run(cleanStr(guestToken, 80));
  }
}

export function createCartCheckoutBatch({
  db,
  student,
  cart,
  paymentMethod = "upi",
  utrReference = "",
  gatewayOrderId = "",
  gatewayPaymentId = "",
  gatewaySignature = "",
  isGatewayVerified = false,
  validateBatchCapacityFn,
  writeAuditLogFn,
  ipAddress = ""
}) {
  if (!cart.items || cart.items.length === 0) {
    throw new Error("Your shopping cart is empty.");
  }

  for (const item of cart.items) {
    if (typeof validateBatchCapacityFn === "function" && item.batchId) {
      const check = validateBatchCapacityFn(db, item.courseId, item.batchId, student.id);
      if (!check.ok) throw new Error(check.error);
    }
  }

  return runInImmediateTx(db, () => {
    const now = nowIso();
    const orderCode = `YTR-ORD-${Date.now().toString().slice(-6)}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`;
    const invoiceNumber = `YTR-INV-C${Date.now().toString().slice(-6)}`;
    const verificationStatus = isGatewayVerified ? "verified" : "pending_verification";
    const enrollmentStatus = isGatewayVerified ? "active" : "pending";
    const receiptNumber = isGatewayVerified ? `YTR-RCP-C${Date.now().toString().slice(-6)}` : "";
    const paidAt = isGatewayVerified ? now : null;

    if (cart.couponApplied?.code && (cart.couponApplied.kind === "coupon" || !cart.couponApplied.kind)) {
      const today = now.slice(0, 10);
      const c = db.prepare("SELECT * FROM coupons WHERE UPPER(code) = ? AND is_active = 1").get(cart.couponApplied.code.toUpperCase());
      if (c) {
        if (Number(c.used_count) >= Number(c.max_uses) || (c.expires_at && c.expires_at < today)) {
          throw new Error("Coupon code expired or max uses reached.");
        }
        db.prepare("UPDATE coupons SET used_count = used_count + 1 WHERE id = ?").run(c.id);
      }
    }

    const subtotal = Math.max(1, cart.subtotal);
    let remainingDiscount = cart.discountAmount || 0;
    const createdPaymentIds = [];

    const hasEnrollmentBatchCol = db
      .prepare("PRAGMA table_info(enrollments)")
      .all()
      .some((c) => c.name === "batch_id");

    cart.items.forEach((item, idx) => {
      const isLast = idx === cart.items.length - 1;
      const itemDiscount = isLast
        ? remainingDiscount
        : Math.min(item.unitPrice, Math.round((cart.discountAmount * item.unitPrice) / subtotal));
      remainingDiscount = Math.max(0, remainingDiscount - itemDiscount);
      const itemFinal = Math.max(0, item.unitPrice - itemDiscount);

      const months = Number(item.months || (item.plan === "yearly" ? 12 : 1));
      const exp = new Date();
      exp.setMonth(exp.getMonth() + months);
      const expiresAt = exp.toISOString().slice(0, 10);
      const enrollmentPlan = item.plan === "yearly" ? "yearly" : "monthly";

      if (hasEnrollmentBatchCol) {
        db.prepare(
          `INSERT INTO enrollments (student_id, course_id, batch_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
           VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?)
           ON CONFLICT(student_id, course_id) DO UPDATE SET
             plan = excluded.plan,
             batch_id = COALESCE(excluded.batch_id, enrollments.batch_id),
             status = CASE WHEN enrollments.status IN ('active', 'completed') THEN enrollments.status ELSE excluded.status END,
             expires_at = excluded.expires_at`
        ).run(student.id, item.courseId, item.batchId || null, enrollmentPlan, enrollmentStatus, expiresAt, now);
      } else {
        db.prepare(
          `INSERT INTO enrollments (student_id, course_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
           VALUES (?, ?, ?, ?, 0, 0, ?, ?)
           ON CONFLICT(student_id, course_id) DO UPDATE SET
             plan = excluded.plan,
             status = CASE WHEN enrollments.status IN ('active', 'completed') THEN enrollments.status ELSE excluded.status END,
             expires_at = excluded.expires_at`
        ).run(student.id, item.courseId, enrollmentPlan, enrollmentStatus, expiresAt, now);
      }

      const enrollment = db
        .prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?")
        .get(student.id, item.courseId);

      const itemInv = `${invoiceNumber}-${idx + 1}`;
      const itemRcp = receiptNumber ? `${receiptNumber}-${idx + 1}` : "";
      const itemGwPayId = gatewayPaymentId ? (cart.items.length > 1 ? `${gatewayPaymentId}#${idx + 1}` : gatewayPaymentId) : "";
      const payIns = db
        .prepare(
          `INSERT INTO payments (
             student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount, coupon_code,
             payment_method, utr_reference, gateway_order_id, gateway_payment_id, gateway_signature,
             verification_status, invoice_number, receipt_number, paid_at, created_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          student.id,
          item.courseId,
          enrollment.id,
          item.plan,
          item.unitPrice,
          itemDiscount,
          itemFinal,
          cart.couponApplied?.code || "",
          paymentMethod,
          utrReference,
          gatewayOrderId,
          itemGwPayId,
          gatewaySignature,
          verificationStatus,
          itemInv,
          itemRcp,
          paidAt,
          now
        );
      createdPaymentIds.push(Number(payIns.lastInsertRowid));

      db.prepare(
        `INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        student.id,
        item.courseId,
        `${item.title} (${item.planLabel || item.plan})`,
        item.unitPrice,
        itemDiscount,
        isGatewayVerified ? itemFinal : 0,
        now.slice(0, 10),
        isGatewayVerified ? "paid" : "pending",
        now
      );
    });

    db.prepare(
      `INSERT INTO cart_orders (
         order_code, student_id, items_json, subtotal_amount, discount_amount, total_amount, coupon_code,
         payment_method, utr_reference, gateway_order_id, gateway_payment_id, verification_status,
         invoice_number, receipt_number, created_at, updated_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      orderCode,
      student.id,
      JSON.stringify(cart.items),
      cart.subtotal,
      cart.discountAmount,
      cart.totalAmount,
      cart.couponApplied?.code || "",
      paymentMethod,
      utrReference,
      gatewayOrderId,
      gatewayPaymentId,
      verificationStatus,
      invoiceNumber,
      receiptNumber,
      now,
      now
    );

    db.prepare("DELETE FROM cart_items WHERE user_id = ?").run(student.id);

    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `Cart Order (${paymentMethod.toUpperCase()})`,
      `${student.full_name} checked out ${cart.items.length} course(s) totaling ₹${cart.totalAmount} (${verificationStatus}).`,
      now
    );

    if (typeof writeAuditLogFn === "function") {
      writeAuditLogFn(db, {
        actorId: student.id,
        actorName: student.full_name,
        targetId: student.id,
        targetName: orderCode,
        action: "cart_checkout_completed",
        details: `${cart.items.length} courses · ₹${cart.totalAmount} (${verificationStatus})`,
        ipAddress
      });
    }

    if (cart.crossSellApplied || cart.items.length > 0) {
      markCrossSellPurchased(db, student.id, cart.items[0]?.courseId || null);
    }

    return {
      orderCode,
      invoiceNumber,
      receiptNumber,
      verificationStatus,
      totalAmount: cart.totalAmount,
      itemCount: cart.items.length,
      createdPaymentIds,
      courseTitles: cart.items.map((it) => `${it.title} (${it.planLabel || it.plan})`),
    };
  });
}
