import { getActiveMilestones, getReferralSettings, nowIso, runInImmediateTx } from "./addons-db.mjs";
import {
  computeMilestoneDelta,
  computeNextMilestoneOffer,
  computeVerifiedPaidMonths,
  evaluateThreeMonthProgress,
  generateReferralCode,
  normalizeReferralCode
} from "./referral-math.mjs";
import {
  creditWalletImmutable,
  debitWalletImmutable,
  getOrCreateWallet,
  syncWalletPendingRewards
} from "./wallet-service.mjs";

export function ensureReferralProfile(db, userId, roleHint = "") {
  const existing = db.prepare("SELECT * FROM referral_profiles WHERE user_id = ?").get(userId);
  if (existing) {
    getOrCreateWallet(db, userId, existing.role);
    return existing;
  }

  const user = db.prepare("SELECT id, full_name, role FROM users WHERE id = ?").get(userId);
  if (!user) throw new Error("User not found for referral profile.");
  const role = roleHint === "teacher" || user.role === "teacher" ? "teacher" : "student";

  let code = generateReferralCode(user.full_name, user.id);
  const clash = db.prepare("SELECT user_id FROM referral_profiles WHERE referral_code = ?").get(code);
  if (clash && Number(clash.user_id) !== Number(user.id)) {
    code = `${code}-${String(user.id).slice(-2)}`;
  }

  const now = nowIso();
  db.prepare(
    `INSERT OR IGNORE INTO referral_profiles (
       user_id, role, referral_code, total_referrals, qualified_referrals, pending_referrals,
       total_rewards_credited, created_at, updated_at
     ) VALUES (?, ?, ?, 0, 0, 0, 0, ?, ?)`
  ).run(userId, role, code, now, now);

  getOrCreateWallet(db, userId, role);
  return db.prepare("SELECT * FROM referral_profiles WHERE user_id = ?").get(userId);
}

export async function dispatchMultiChannelNotification(db, deps, {
  userId,
  title,
  message,
  smsMessage = "",
  whatsappMessage = "",
  ctaLabel = "Open Portal",
  ctaPath = "/student/"
}) {
  const settings = getReferralSettings(db);
  const now = nowIso();
  if (Number(settings.notify_in_app) === 1 && userId) {
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(userId, title, message, now);
  }

  const user = userId ? db.prepare("SELECT id, full_name, email, phone, role FROM users WHERE id = ?").get(userId) : null;
  if (!user) return;

  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  const rolePath = user.role === "teacher" ? "/teacher/" : ctaPath;

  if (Number(settings.notify_email) === 1 && user.email && typeof deps?.sendTransactionalEmail === "function") {
    try {
      await deps.sendTransactionalEmail({
        to: user.email,
        recipientName: user.full_name || "Member",
        subject: `${title} — Yuitor Smart Classes`,
        previewText: message.slice(0, 140),
        htmlBody: `<p>Dear {{name}},</p><p>${String(message).replace(/[<>&]/g, "")}</p>`,
        ctaLabel,
        ctaUrl: `${siteUrl}${rolePath}`,
        department: "info"
      });
    } catch {
      // Never block business transactions on SMTP delivery issues
    }
  }

  if (Number(settings.notify_sms) === 1 && user.phone && typeof deps?.dispatchSmsMessage === "function") {
    try {
      await deps.dispatchSmsMessage(user.phone, smsMessage || `${title}: ${message}`);
    } catch {
      // Non-blocking
    }
  }

  if (Number(settings.notify_whatsapp) === 1 && user.phone && typeof deps?.dispatchWhatsAppMessage === "function") {
    try {
      await deps.dispatchWhatsAppMessage(user.phone, whatsappMessage || `*${title}*\n${message}`);
    } catch {
      // Non-blocking
    }
  }
}

export function getActiveCampaignsForRole(db, role = "all") {
  const now = nowIso();
  const rows = db
    .prepare(
      `SELECT * FROM referral_campaigns
       WHERE is_active = 1
         AND (target_role = 'all' OR target_role = ?)
         AND (starts_at IS NULL OR starts_at = '' OR starts_at <= ?)
         AND (ends_at IS NULL OR ends_at = '' OR ends_at >= ?)
       ORDER BY id DESC`
    )
    .all(role === "teacher" ? "teacher" : "student", now, now);
  return rows;
}

function refreshReferrerProfileCounts(db, referrerUserId) {
  const counts = db
    .prepare(
      `SELECT
         COUNT(*) AS total,
         SUM(CASE WHEN status IN ('qualified', 'rewarded') THEN 1 ELSE 0 END) AS qualified,
         SUM(CASE WHEN status IN ('registered', 'in_progress') THEN 1 ELSE 0 END) AS pending,
         COALESCE(SUM(reward_amount_credited), 0) AS credited
       FROM referrals
       WHERE referrer_user_id = ?`
    )
    .get(referrerUserId);

  db.prepare(
    `UPDATE referral_profiles
     SET total_referrals = ?, qualified_referrals = ?, pending_referrals = ?, updated_at = ?
     WHERE user_id = ?`
  ).run(
    Number(counts?.total || 0),
    Number(counts?.qualified || 0),
    Number(counts?.pending || 0),
    nowIso(),
    referrerUserId
  );
  syncWalletPendingRewards(db, referrerUserId);
  return counts;
}

export async function attributeReferralSignup(db, {
  referredUserId,
  referredRole,
  referralCode,
  signupIp = ""
}, deps = {}) {
  const code = normalizeReferralCode(referralCode);
  if (!code) return { attributed: false, reason: "no_code" };

  // Referred person must be a student whose 3-month tuition fee counts for qualification
  if (referredRole !== "student") {
    return { attributed: false, reason: "referred_must_be_student" };
  }

  const settings = getReferralSettings(db);
  if (Number(settings.referrals_enabled) !== 1) {
    return { attributed: false, reason: "referrals_disabled" };
  }

  const profile = db
    .prepare("SELECT rp.*, u.full_name, u.phone, u.email, u.is_active FROM referral_profiles rp JOIN users u ON u.id = rp.user_id WHERE UPPER(rp.referral_code) = UPPER(?) LIMIT 1")
    .get(code);
  if (!profile) {
    return { attributed: false, reason: "invalid_code" };
  }
  if (Number(profile.is_active) !== 1) {
    return { attributed: false, reason: "referrer_inactive" };
  }
  if (profile.role === "student" && Number(settings.allow_student_referrals) !== 1) {
    return { attributed: false, reason: "student_referrals_disabled" };
  }
  if (profile.role === "teacher" && Number(settings.allow_teacher_referrals) !== 1) {
    return { attributed: false, reason: "teacher_referrals_disabled" };
  }
  if (Number(profile.user_id) === Number(referredUserId) && Number(settings.allow_self_referral) !== 1) {
    return { attributed: false, reason: "self_referral_blocked" };
  }

  const referredUser = db.prepare("SELECT id, full_name, phone, email FROM users WHERE id = ?").get(referredUserId);
  if (!referredUser) return { attributed: false, reason: "referred_not_found" };

  // Prevent fake/duplicate same-phone attribution when self-referral is off
  if (Number(settings.allow_self_referral) !== 1 && profile.phone && referredUser.phone && profile.phone === referredUser.phone) {
    return { attributed: false, reason: "duplicate_phone_blocked" };
  }

  const result = runInImmediateTx(db, () => {
    const already = db.prepare("SELECT id FROM referrals WHERE referred_user_id = ?").get(referredUserId);
    if (already) return { attributed: false, duplicate: true };

    const requiredMonths = Math.max(1, Number(settings.required_fee_months || 3));
    const activeMilestones = getActiveMilestones(db);
    const existingQualified = Number(profile.qualified_referrals || 0);
    const nextSim = computeMilestoneDelta({
      qualifiedCount: existingQualified + 1,
      alreadyCreditedTotal: Number(profile.total_rewards_credited || 0),
      milestones: activeMilestones
    });
    const estPending = Math.max(0, nextSim.deltaAmount || (activeMilestones[0]?.cumulative_reward || 200));

    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO referrals (
           referrer_user_id, referrer_role, referred_user_id, referral_code_used, status,
           paid_months_count, required_months, verified_fees_total,
           month1_paid, month2_paid, month3_paid, pending_estimated_reward,
           signup_ip, created_at, updated_at
         ) VALUES (?, ?, ?, ?, 'registered', 0, ?, 0, 0, 0, 0, ?, ?, ?, ?)`
      )
      .run(
        profile.user_id,
        profile.role,
        referredUserId,
        profile.referral_code,
        requiredMonths,
        estPending,
        String(signupIp || ""),
        now,
        now
      );

    refreshReferrerProfileCounts(db, profile.user_id);
    if (typeof deps?.writeAuditLog === "function") {
      deps.writeAuditLog(db, {
        actorId: referredUserId,
        actorName: referredUser.full_name,
        targetId: profile.user_id,
        targetName: profile.referral_code,
        action: "referral_attributed",
        details: `${referredUser.full_name} registered using code ${profile.referral_code}`,
        ipAddress: signupIp
      });
    }

    return {
      attributed: true,
      referralId: Number(ins.lastInsertRowid),
      referrerUserId: Number(profile.user_id),
      referredName: referredUser.full_name,
      referralCode: profile.referral_code
    };
  });

  if (result.attributed) {
    await dispatchMultiChannelNotification(db, deps, {
      userId: result.referrerUserId,
      title: "New Referral Registered!",
      message: `${result.referredName} registered using your referral code ${result.referralCode}. Reward unlocks automatically after 3 complete months of verified fee payments.`
    });
  }

  return result;
}

/**
 * Re-evaluates 3-month verified fee payments for a referred student, auto-qualifies at 3 months,
 * credits cumulative milestone difference to referrer wallet, awards active referral campaigns,
 * and handles refund reversals with proper clawback ledger transactions.
 */
export async function recomputeReferralForStudent(db, referredUserId, {
  eventType = "payment_verified",
  paymentId = null,
  actorId = null,
  note = ""
} = {}, deps = {}) {
  const refRow = db.prepare("SELECT * FROM referrals WHERE referred_user_id = ?").get(referredUserId);
  if (!refRow || refRow.status === "disqualified") {
    return { processed: false, reason: refRow ? "disqualified" : "no_referral" };
  }

  const settings = getReferralSettings(db);
  const requiredMonths = Math.max(1, Number(settings.required_fee_months || refRow.required_months || 3));
  const verifiedPayments = db
    .prepare(
      `SELECT id, amount, plan, verification_status, paid_at, created_at
       FROM payments
       WHERE student_id = ? AND verification_status = 'verified'
       ORDER BY COALESCE(paid_at, created_at) ASC, id ASC`
    )
    .all(referredUserId);

  const paidStats = computeVerifiedPaidMonths(verifiedPayments, settings.yearly_plan_months_credit);
  const progress = evaluateThreeMonthProgress({
    paidMonthsCount: paidStats.paidMonthsCount,
    requiredMonths
  });

  const referrerUser = db.prepare("SELECT id, full_name, role FROM users WHERE id = ?").get(refRow.referrer_user_id);
  const referredUser = db.prepare("SELECT id, full_name FROM users WHERE id = ?").get(referredUserId);
  if (!referrerUser) return { processed: false, reason: "referrer_missing" };

  ensureReferralProfile(db, referrerUser.id, referrerUser.role);

  const txResult = runInImmediateTx(db, () => {
    const latestRef = db.prepare("SELECT * FROM referrals WHERE id = ?").get(refRow.id);
    const monthsBefore = Number(latestRef.paid_months_count || 0);
    const prevQualified = latestRef.status === "qualified" || latestRef.status === "rewarded";
    const now = nowIso();

    let nextStatus = latestRef.status;
    let qualifiedAt = latestRef.qualified_at;
    if (progress.isEligible) {
      nextStatus = latestRef.reward_amount_credited > 0 ? "rewarded" : "qualified";
      if (!qualifiedAt) qualifiedAt = now;
    } else if (prevQualified) {
      // A refund dropped paid months below required 3 months -> revert qualification cleanly
      nextStatus = progress.paidMonthsCount > 0 ? "reversed" : "reversed";
      qualifiedAt = null;
    } else {
      nextStatus = progress.paidMonthsCount > 0 ? "in_progress" : "registered";
    }

    db.prepare(
      `UPDATE referrals
       SET status = ?, paid_months_count = ?, required_months = ?, verified_fees_total = ?,
           month1_paid = ?, month2_paid = ?, month3_paid = ?,
           month1_paid_at = ?, month2_paid_at = ?, month3_paid_at = ?,
           qualified_at = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      nextStatus,
      progress.paidMonthsCount,
      requiredMonths,
      paidStats.verifiedFeesTotal,
      progress.month1Paid,
      progress.month2Paid,
      progress.month3Paid,
      paidStats.month1PaidAt,
      paidStats.month2PaidAt,
      paidStats.month3PaidAt,
      qualifiedAt,
      now,
      latestRef.id
    );

    db.prepare(
      `INSERT INTO referral_fee_progress_logs (
         referral_id, payment_id, event_type, months_before, months_after, amount_delta, note, created_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      latestRef.id,
      paymentId || null,
      eventType,
      monthsBefore,
      progress.paidMonthsCount,
      0,
      note || `Verified fee months updated ${monthsBefore} -> ${progress.paidMonthsCount}`,
      now
    );

    // Recompute referrer cumulative milestone payouts cleanly
    const profile = db.prepare("SELECT * FROM referral_profiles WHERE user_id = ?").get(referrerUser.id);
    const qualifiedCount = Number(
      db
        .prepare(
          `SELECT COUNT(*) AS c FROM referrals
           WHERE referrer_user_id = ? AND status IN ('qualified', 'rewarded')`
        )
        .get(referrerUser.id)?.c || 0
    );

    const activeMilestones = getActiveMilestones(db);
    const alreadyCredited = Number(profile.total_rewards_credited || 0);
    const calc = computeMilestoneDelta({
      qualifiedCount,
      alreadyCreditedTotal: alreadyCredited,
      milestones: activeMilestones
    });

    let milestoneCredited = 0;
    let milestoneReversed = 0;
    let unlockedCampaignBonuses = [];

    if (calc.deltaAmount > 0 && progress.isEligible) {
      const creditKey = `ref_milestone:${referrerUser.id}:m${calc.unlockedMilestone.qualified_count}:t${calc.targetCumulative}`;
      const cr = creditWalletImmutable(db, {
        userId: referrerUser.id,
        walletType: profile.role,
        amount: calc.deltaAmount,
        category: "referral_reward",
        referenceType: "referral_milestone",
        referenceId: `${latestRef.id}:${calc.unlockedMilestone.qualified_count}`,
        description: `Milestone ${calc.unlockedMilestone.qualified_count} unlocked (₹${calc.targetCumulative.toLocaleString("en-IN")} cumulative) — ${referredUser?.full_name || "Student"} completed ${requiredMonths}-month verified fees`,
        idempotencyKey: creditKey,
        actorId,
        countAsReferralReward: true
      });
      if (cr.credited) {
        milestoneCredited = calc.deltaAmount;
        const newTotalCredited = alreadyCredited + calc.deltaAmount;
        db.prepare(
          "UPDATE referral_profiles SET total_rewards_credited = ?, updated_at = ? WHERE user_id = ?"
        ).run(newTotalCredited, now, referrerUser.id);
        db.prepare(
          "UPDATE referrals SET status = 'rewarded', reward_amount_credited = reward_amount_credited + ?, pending_estimated_reward = 0, milestone_reached = ?, updated_at = ? WHERE id = ?"
        ).run(calc.deltaAmount, calc.unlockedMilestone.qualified_count, now, latestRef.id);
      }

      // Check active referral campaign bonuses applicable on qualification
      const activeCampaigns = getActiveCampaignsForRole(db, profile.role);
      for (const camp of activeCampaigns) {
        if (qualifiedCount >= Number(camp.min_qualified_referrals || 1) && Number(camp.bonus_amount || 0) > 0) {
          const campKey = `ref_campaign:${referrerUser.id}:camp_${camp.id}`;
          const cRes = creditWalletImmutable(db, {
            userId: referrerUser.id,
            walletType: profile.role,
            amount: Number(camp.bonus_amount),
            category: "campaign_bonus",
            referenceType: "campaign",
            referenceId: String(camp.id),
            description: `Campaign Bonus "${camp.title}" unlocked (${qualifiedCount} qualified referrals)`,
            idempotencyKey: campKey,
            actorId,
            countAsReferralReward: true
          });
          if (cRes.credited) {
            unlockedCampaignBonuses.push({ title: camp.title, bonus: Number(camp.bonus_amount) });
          }
        }
      }
    } else if (progress.isEligible && latestRef.status !== "rewarded") {
      // Qualified cleanly (even if milestone cap reached or cumulative equals already credited)
      db.prepare("UPDATE referrals SET status = 'rewarded', pending_estimated_reward = 0, updated_at = ? WHERE id = ?").run(
        now,
        latestRef.id
      );
    } else if (!progress.isEligible && prevQualified && alreadyCredited > calc.targetCumulative) {
      // Refund reduced qualified referrals below previous milestone cumulative -> post atomic reversal debit!
      const clawback = alreadyCredited - calc.targetCumulative;
      const revKey = `ref_reversal:${latestRef.id}:${paymentId || Date.now()}:${clawback}`;
      const dr = debitWalletImmutable(db, {
        userId: referrerUser.id,
        walletType: profile.role,
        amount: clawback,
        category: "reward_reversal",
        referenceType: "referral_reversal",
        referenceId: String(latestRef.id),
        description: `Referral reward reversed (${referredUser?.full_name || "Student"} fee refunded; verified months ${progress.paidMonthsCount}/${requiredMonths})`,
        idempotencyKey: revKey,
        actorId,
        requireAvailable: false,
        adjustEarningsOnReversal: true
      });
      if (dr.debited && dr.actualDebit > 0) {
        milestoneReversed = dr.actualDebit;
        const newTotal = Math.max(0, alreadyCredited - dr.actualDebit);
        db.prepare("UPDATE referral_profiles SET total_rewards_credited = ?, updated_at = ? WHERE user_id = ?").run(
          newTotal,
          now,
          referrerUser.id
        );
        db.prepare(
          "UPDATE referrals SET reward_amount_credited = MAX(0, reward_amount_credited - ?), updated_at = ? WHERE id = ?"
        ).run(dr.actualDebit, now, latestRef.id);
      }
    }

    refreshReferrerProfileCounts(db, referrerUser.id);
    if (typeof deps?.writeAuditLog === "function") {
      deps.writeAuditLog(db, {
        actorId: actorId || referredUserId,
        actorName: "Referral Engine",
        targetId: referrerUser.id,
        targetName: referredUser?.full_name || `User #${referredUserId}`,
        action: milestoneCredited > 0 ? "referral_milestone_credited" : milestoneReversed > 0 ? "referral_reward_reversed" : "referral_progress_updated",
        details: `Months ${monthsBefore} -> ${progress.paidMonthsCount}/${requiredMonths}; Credited ₹${milestoneCredited}; Reversed ₹${milestoneReversed}`,
        ipAddress: ""
      });
    }

    return {
      processed: true,
      referralId: latestRef.id,
      referrerUserId: referrerUser.id,
      referredName: referredUser?.full_name || "Referred Student",
      monthsBefore,
      monthsAfter: progress.paidMonthsCount,
      requiredMonths,
      newlyQualified: !prevQualified && progress.isEligible,
      milestoneCredited,
      milestoneReversed,
      targetCumulative: calc.targetCumulative,
      unlockedMilestone: calc.unlockedMilestone,
      unlockedCampaignBonuses
    };
  });

  if (txResult.processed) {
    if (txResult.milestoneCredited > 0) {
      await dispatchMultiChannelNotification(db, deps, {
        userId: txResult.referrerUserId,
        title: `Referral Reward Credited: +₹${txResult.milestoneCredited.toLocaleString("en-IN")}`,
        message: `Congratulations! ${txResult.referredName} completed ${txResult.requiredMonths} months of verified fee payments. You unlocked Milestone ${txResult.unlockedMilestone?.qualified_count} (₹${txResult.targetCumulative.toLocaleString("en-IN")} cumulative) and ₹${txResult.milestoneCredited.toLocaleString("en-IN")} has been added to your Wallet.`
      });
    } else if (txResult.milestoneReversed > 0) {
      await dispatchMultiChannelNotification(db, deps, {
        userId: txResult.referrerUserId,
        title: `Referral Reward Reversed (-₹${txResult.milestoneReversed.toLocaleString("en-IN")})`,
        message: `A fee refund for ${txResult.referredName} reduced verified paid months to ${txResult.monthsAfter}/${txResult.requiredMonths}. ₹${txResult.milestoneReversed.toLocaleString("en-IN")} was reversed from your wallet.`
      });
    } else if (txResult.monthsAfter > txResult.monthsBefore) {
      await dispatchMultiChannelNotification(db, deps, {
        userId: txResult.referrerUserId,
        title: `Referral Fee Progress (${Math.min(txResult.monthsAfter, txResult.requiredMonths)}/${txResult.requiredMonths} Months)`,
        message: `${txResult.referredName} paid a verified fee installment (${Math.min(txResult.monthsAfter, txResult.requiredMonths)}/${txResult.requiredMonths} months complete).`
      });
    }

    for (const cb of txResult.unlockedCampaignBonuses || []) {
      await dispatchMultiChannelNotification(db, deps, {
        userId: txResult.referrerUserId,
        title: `Campaign Bonus Unlocked (+₹${cb.bonus.toLocaleString("en-IN")})`,
        message: `You achieved the "${cb.title}" referral campaign bonus of ₹${cb.bonus.toLocaleString("en-IN")}. Added to your Wallet!`
      });
    }
  }

  return txResult;
}

export function getUserReferralDashboard(db, userId, roleHint = "") {
  const profile = ensureReferralProfile(db, userId, roleHint);
  const settings = getReferralSettings(db);
  const milestones = getActiveMilestones(db);
  const campaigns = getActiveCampaignsForRole(db, profile.role);
  const wallet = getOrCreateWallet(db, userId, profile.role);

  const referrals = db
    .prepare(
      `SELECT r.*,
              u.full_name AS referred_name,
              u.email AS referred_email,
              u.phone AS referred_phone,
              u.verification_status AS referred_account_status
       FROM referrals r
       JOIN users u ON u.id = r.referred_user_id
       WHERE r.referrer_user_id = ?
       ORDER BY r.id DESC`
    )
    .all(userId);

  const offer = computeNextMilestoneOffer({
    qualifiedCount: profile.qualified_referrals,
    alreadyCreditedTotal: profile.total_rewards_credited,
    milestones
  });

  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  const sharePath = `/ref/${encodeURIComponent(profile.referral_code)}`;
  const whatsappText = encodeURIComponent(
    `Join Yuitor Smart Classes! Register with my referral code *${profile.referral_code}* here: ${siteUrl}${sharePath}`
  );

  return {
    profile,
    wallet,
    offer,
    milestones,
    campaigns,
    referrals: referrals.map((r) => ({
      ...r,
      progress: evaluateThreeMonthProgress({
        paidMonthsCount: r.paid_months_count,
        requiredMonths: r.required_months || settings.required_fee_months || 3
      })
    })),
    share: {
      referralCode: profile.referral_code,
      sharePath,
      shareUrl: `${siteUrl}${sharePath}`,
      whatsappShareUrl: `https://wa.me/?text=${whatsappText}`
    },
    settings: {
      referralsEnabled: Number(settings.referrals_enabled) === 1,
      requiredFeeMonths: Number(settings.required_fee_months || 3),
      minWithdrawalAmount: Number(settings.min_withdrawal_amount || 200),
      termsAndConditions: settings.terms_and_conditions || ""
    }
  };
}

export function getReferralAnalyticsReport(db, { fromDate = "", toDate = "", role = "all" } = {}) {
  const from = String(fromDate || "").trim();
  const to = String(toDate || "").trim();

  const refWhere = ["1=1"];
  const refParams = [];
  if (from) {
    refWhere.push("r.created_at >= ?");
    refParams.push(`${from}T00:00:00`);
  }
  if (to) {
    refWhere.push("r.created_at <= ?");
    refParams.push(`${to}T23:59:59`);
  }
  if (role === "student" || role === "teacher") {
    refWhere.push("r.referrer_role = ?");
    refParams.push(role);
  }

  const refSummary = db
    .prepare(
      `SELECT
         COUNT(*) AS totalReferrals,
         SUM(CASE WHEN r.status IN ('qualified', 'rewarded') THEN 1 ELSE 0 END) AS qualifiedReferrals,
         SUM(CASE WHEN r.status IN ('registered', 'in_progress') THEN 1 ELSE 0 END) AS pendingReferrals,
         SUM(CASE WHEN r.status = 'reversed' THEN 1 ELSE 0 END) AS reversedReferrals
       FROM referrals r
       WHERE ${refWhere.join(" AND ")}`
    )
    .get(...refParams);

  const txWhere = ["wt.category IN ('referral_reward', 'campaign_bonus')"];
  const txParams = [];
  if (from) {
    txWhere.push("wt.created_at >= ?");
    txParams.push(`${from}T00:00:00`);
  }
  if (to) {
    txWhere.push("wt.created_at <= ?");
    txParams.push(`${to}T23:59:59`);
  }
  if (role === "student" || role === "teacher") {
    txWhere.push("w.wallet_type = ?");
    txParams.push(role);
  }

  const rewardsDistributed = Number(
    db
      .prepare(
        `SELECT COALESCE(SUM(wt.credit_amount), 0) AS total
         FROM wallet_transactions wt
         JOIN wallets w ON w.id = wt.wallet_id
         WHERE ${txWhere.join(" AND ")}`
      )
      .get(...txParams)?.total || 0
  );

  const walletStats = db
    .prepare(
      `SELECT
         wallet_type,
         COUNT(*) AS walletCount,
         COALESCE(SUM(available_balance), 0) AS availableTotal,
         COALESCE(SUM(pending_rewards), 0) AS pendingRewardsTotal,
         COALESCE(SUM(pending_withdrawal_hold), 0) AS withdrawalHoldTotal,
         COALESCE(SUM(withdrawn_amount), 0) AS withdrawnTotal,
         COALESCE(SUM(total_earnings), 0) AS lifetimeEarnings
       FROM wallets
       GROUP BY wallet_type`
    )
    .all();

  const wdrStats = db
    .prepare(
      `SELECT
         status,
         COUNT(*) AS cnt,
         COALESCE(SUM(amount), 0) AS totalAmount
       FROM withdrawal_requests
       GROUP BY status`
    )
    .all();

  const monthlySeries = db
    .prepare(
      `SELECT
         substr(created_at, 1, 7) AS month,
         COUNT(*) AS referralsCount,
         SUM(CASE WHEN status IN ('qualified', 'rewarded') THEN 1 ELSE 0 END) AS qualifiedCount
       FROM referrals
       GROUP BY substr(created_at, 1, 7)
       ORDER BY month DESC
       LIMIT 12`
    )
    .all();

  const monthlyPayouts = db
    .prepare(
      `SELECT
         substr(COALESCE(paid_at, created_at), 1, 7) AS month,
         COUNT(*) AS payoutCount,
         COALESCE(SUM(amount), 0) AS paidAmount
       FROM withdrawal_requests
       WHERE status = 'paid'
       GROUP BY substr(COALESCE(paid_at, created_at), 1, 7)
       ORDER BY month DESC
       LIMIT 12`
    )
    .all();

  const topReferrers = db
    .prepare(
      `SELECT rp.*, u.full_name, u.email, u.phone, w.available_balance
       FROM referral_profiles rp
       JOIN users u ON u.id = rp.user_id
       LEFT JOIN wallets w ON w.user_id = rp.user_id
       ORDER BY rp.qualified_referrals DESC, rp.total_rewards_credited DESC
       LIMIT 20`
    )
    .all();

  return {
    filters: { fromDate: from, toDate: to, role },
    summary: {
      totalReferrals: Number(refSummary?.totalReferrals || 0),
      qualifiedReferrals: Number(refSummary?.qualifiedReferrals || 0),
      pendingReferrals: Number(refSummary?.pendingReferrals || 0),
      reversedReferrals: Number(refSummary?.reversedReferrals || 0),
      rewardsDistributed
    },
    walletBreakdown: walletStats,
    withdrawalBreakdown: wdrStats,
    monthlyReferrals: monthlySeries,
    monthlyPayouts,
    topReferrers
  };
}
