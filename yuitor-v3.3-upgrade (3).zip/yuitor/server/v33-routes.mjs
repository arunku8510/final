// Yuitor Smart Classes v3.3 — Express API Routers (Public, Student, Parent, Staff, Admin)
// Strictly reuses existing auth/session, Razorpay/Email/PDF helpers, and SQLite DB.

import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import { Router } from "express";
import { nowIso } from "./addons-db.mjs";
import { buildSimplePdfBuffer } from "./crm-pdf.mjs";
import {
  CLASS_SUBJECT_CATALOG,
  V33_VERSION,
  buildRevenueAndSalesAnalytics,
  buildRevenueCsv,
  buildSmartRecommendations,
  buildStudentFinancialSummary,
  calculateDynamicCheckoutQuote,
  calculateProfileCompletion,
  computeDurationPrice,
  ensureV33Schema,
  generateOtpCode,
  getBranchPricingOverlay,
  getV33PricingConfig,
  logPricingAudit,
  recalculateStudentInvoiceBalances,
  renderMessagePreview,
  runCourseRenewalV33Sweep,
  runInvoiceFollowupSweep,
  updateV33PricingConfig,
} from "./v33-engine.mjs";

function cleanStr(val, maxLen = 160) {
  return String(val || "").replace(/\s+/g, " ").trim().slice(0, maxLen);
}

function cleanPhone(val) {
  return String(val || "").replace(/\D/g, "").slice(-10);
}

function hashOtp(code) {
  return crypto.createHash("sha256").update(String(code || "")).digest("hex");
}

function parseJson(raw, fb) {
  try {
    const v = JSON.parse(raw);
    return v ?? fb;
  } catch {
    return fb;
  }
}

function isAdminUser(user) {
  const role = String(user?.role || "").toLowerCase();
  return role === "super_admin" || role === "admin";
}

function isAuthorizedStaffOrAdmin(db, user, requiredPerm = "") {
  if (!user) return false;
  if (isAdminUser(user)) return true;
  if (String(user.role || "").toLowerCase() !== "staff") return false;
  if (!requiredPerm) return true;

  const permAliases = {
    fees: ["fees", "payments", "manage_fees", "finance", "invoices"],
    communications: ["communications", "alerts", "inquiries", "admissions", "fees"],
    reports: ["reports", "analytics", "fees", "payments"],
    inquiries: ["inquiries", "admissions", "crm", "leads"],
  };
  const accepted = new Set(permAliases[requiredPerm] || [requiredPerm]);

  const roleDefaults = {
    accountant: ["fees", "payments", "expenses", "payouts", "reports", "communications"],
    receptionist: ["inquiries", "admissions", "batches", "library", "alerts", "communications"],
    librarian: ["library"],
    coordinator: ["batches", "timetable", "attendance", "tests", "inquiries", "reports", "alerts", "communications"],
  };

  const collected = new Set();
  const addPerms = (list) => {
    if (!Array.isArray(list)) return;
    for (const p of list) {
      const k = String(p || "").trim().toLowerCase();
      if (k) collected.add(k);
    }
  };

  if (Array.isArray(user.staff_permissions)) addPerms(user.staff_permissions);
  if (user.staff_permissions_json) addPerms(parseJson(user.staff_permissions_json, []));
  const userStaffRole = String(user.staff_role || "").toLowerCase();
  if (roleDefaults[userStaffRole]) addPerms(roleDefaults[userStaffRole]);

  // Also check live users table row in case caller passed a minimal user object
  try {
    const row = db.prepare("SELECT staff_role, staff_permissions_json FROM users WHERE id = ?").get(user.id);
    if (row) {
      addPerms(parseJson(row.staff_permissions_json || "[]", []));
      const dbRole = String(row.staff_role || "").toLowerCase();
      if (roleDefaults[dbRole]) addPerms(roleDefaults[dbRole]);
    }
  } catch {
    // ignore if column absent in minimal test DB
  }

  // Fallback for isolated test DBs with staff_profiles table
  try {
    const sp = db.prepare("SELECT permissions_json FROM staff_profiles WHERE user_id = ?").get(user.id);
    if (sp?.permissions_json) addPerms(parseJson(sp.permissions_json, []));
  } catch {
    // staff_profiles optional
  }

  if (collected.has("*") || collected.has("all")) return true;
  for (const p of accepted) {
    if (collected.has(p)) return true;
  }
  return false;
}

export function createV33Router(db, deps = {}) {
  const router = Router();
  const {
    getSessionContext,
    createSession,
    setSessionCookie,
    sendTransactionalEmail,
    writeAuditLog,
    clientIp,
  } = deps;

  ensureV33Schema(db);

  const getUser = (req) => {
    try {
      const ctx = typeof getSessionContext === "function" ? getSessionContext(db, req) : null;
      return ctx?.user || null;
    } catch {
      return null;
    }
  };
  const logAudit = (actor, action, targetType, targetId, summary, req) => {
    if (typeof writeAuditLog !== "function") return;
    try {
      writeAuditLog(db, {
        actorUserId: actor?.id || null,
        actorRole: actor?.role || "system",
        action,
        targetType,
        targetId: String(targetId || ""),
        summary,
        ip: typeof clientIp === "function" ? clientIp(req) : ""
      });
    } catch {
      // non-fatal
    }
  };

  const resolveFallbackCourseId = (candidateId) => {
    const cid = Number(candidateId || 0);
    if (cid > 0) return cid;
    try {
      const row = db.prepare("SELECT id FROM courses WHERE is_active = 1 ORDER BY id ASC LIMIT 1").get();
      if (row?.id) return Number(row.id);
      const anyRow = db.prepare("SELECT id FROM courses ORDER BY id ASC LIMIT 1").get();
      return Number(anyRow?.id || 1);
    } catch {
      return 1;
    }
  };

  const insertStudentUserSafe = ({ fullName, email, phone, passwordHash, branchId, mobileVerified = 1, now }) => {
    const cols = db.prepare("PRAGMA table_info(users)").all().map((c) => c.name);
    const fields = [
      "full_name",
      "email",
      "phone",
      "password_hash",
      "role",
      "branch_id",
      "mobile_verified",
      "verification_status",
      "is_active",
      "created_at",
    ];
    const values = [fullName, email, phone, passwordHash, "student", branchId || null, mobileVerified, "approved", 1, now];
    if (cols.includes("unsubscribe_token")) {
      fields.push("unsubscribe_token");
      values.push(crypto.randomBytes(16).toString("hex"));
    }
    if (cols.includes("updated_at")) {
      fields.push("updated_at");
      values.push(now);
    }
    const ph = fields.map(() => "?").join(", ");
    const ins = db.prepare(`INSERT INTO users (${fields.join(", ")}) VALUES (${ph})`).run(...values);
    return Number(ins.lastInsertRowid);
  };

  /* ============================================================================
   * 1. SIMPLIFIED 3-FIELD STUDENT REGISTRATION + OTP VERIFICATION
   *    Step 1: Full Name *, Mobile Number *, Referral Code (Optional) + Email (Optional for Email OTP)
   * ========================================================================== */
  router.post("/auth/quick-register", async (req, res) => {
    const fullName = cleanStr(req.body?.fullName, 100);
    const phone = cleanPhone(req.body?.phone);
    const referralCode = cleanStr(req.body?.referralCode, 40).toUpperCase();
    const email = cleanStr(req.body?.email, 120).toLowerCase();
    const otpChannel = req.body?.otpChannel === "email" && email ? "email" : "sms";

    if (fullName.length < 2) {
      return res.status(400).json({ error: "Please enter your full name (minimum 2 characters)." });
    }
    if (phone.length !== 10) {
      return res.status(400).json({ error: "Please enter a valid 10-digit mobile number." });
    }

    const nowSec = Math.floor(Date.now() / 1000);
    const target = otpChannel === "email" ? email : phone;

    // Resend cooldown (45 seconds) & abuse protection
    try {
      const existingMetaRow = db
        .prepare("SELECT value FROM system_settings WHERE key = ?")
        .get(`v33_reg_meta:${target}`);
      const existingMeta = existingMetaRow ? parseJson(existingMetaRow.value, null) : null;
      if (existingMeta && nowSec - Number(existingMeta.createdAt || 0) < 45) {
        return res.status(429).json({ error: "Please wait 45 seconds before requesting another OTP." });
      }
    } catch {
      // ignore if schema differs
    }

    const otp = generateOtpCode();
    const otpHash = hashOtp(otp);
    const expiresAt = nowSec + 600; // 10 minutes
    const meta = JSON.stringify({ fullName, phone, email, referralCode, otpChannel, ip: clientIp ? clientIp(req) : "" });

    // Store OTP using existing otp_tokens table (or fallback column layout)
    try {
      const cols = db.prepare("PRAGMA table_info(otp_tokens)").all().map((c) => c.name);
      if (cols.includes("code_hash") && cols.includes("target")) {
        db.prepare("DELETE FROM otp_tokens WHERE target = ? AND purpose = 'v33_quick_reg'").run(target);
        db.prepare(
          `INSERT INTO otp_tokens (target, purpose, code_hash, expires_at, attempts, meta_json, created_at)
           VALUES (?, 'v33_quick_reg', ?, ?, 0, ?, ?)`
        ).run(target, otpHash, expiresAt, meta, nowSec);
      } else if (cols.includes("phone") && cols.includes("otp_hash")) {
        db.prepare("DELETE FROM otp_tokens WHERE phone = ? AND purpose = 'v33_quick_reg'").run(target);
        db.prepare(
          `INSERT INTO otp_tokens (phone, purpose, otp_hash, expires_at, attempts, created_at)
           VALUES (?, 'v33_quick_reg', ?, ?, 0, ?)`
        ).run(target, otpHash, expiresAt, nowSec);
      }
    } catch {
      // Fallback: store inside system_settings ephemeral record if otp_tokens schema is custom
      db.prepare(
        `INSERT INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`
      ).run(
        `v33_otp:${target}`,
        JSON.stringify({ otpHash, expiresAt, attempts: 0, meta: JSON.parse(meta), createdAt: nowSec }),
        nowIso()
      );
    }

    // Also mirror payload metadata in system_settings keyed by target so verify always has fullName/referralCode
    db.prepare(
      `INSERT INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`
    ).run(
      `v33_reg_meta:${target}`,
      JSON.stringify({ otpHash, expiresAt, attempts: 0, fullName, phone, email, referralCode, otpChannel, createdAt: nowSec }),
      nowIso()
    );

    let emailSent = false;
    if (otpChannel === "email" && email && typeof sendTransactionalEmail === "function") {
      try {
        await sendTransactionalEmail({
          to: email,
          subject: `${otp} is your Yuitor Smart Classes Verification OTP`,
          html: `<p>Hi <strong>${fullName}</strong>,</p><p>Your 6-digit OTP for Yuitor Smart Classes is <strong style="font-size:20px;letter-spacing:2px;">${otp}</strong>. Valid for 10 minutes.</p>`,
        });
        emailSent = true;
      } catch {
        emailSent = false;
      }
    }

    const maskedTarget = otpChannel === "email"
      ? email.replace(/(^.).+(@.+)/, "$1***$2")
      : `******${phone.slice(-4)}`;

    const exposeDevOtp = process.env.NODE_ENV !== "production" && !emailSent;

    return res.json({
      ok: true,
      otpChannel,
      target,
      maskedTarget,
      expiresInSeconds: 600,
      emailSent,
      message: emailSent
        ? `6-digit OTP sent to ${maskedTarget}.`
        : `6-digit OTP generated for ${maskedTarget}. Enter the OTP to create your account and open your Student Dashboard.`,
      ...(exposeDevOtp ? { previewOtp: otp, devOtp: otp } : {}),
    });
  });

  router.post("/auth/quick-verify-otp", (req, res) => {
    const rawTarget = cleanStr(req.body?.target || req.body?.phone || req.body?.email, 120);
    const otp = cleanStr(req.body?.otp, 10).replace(/\D/g, "");
    const target = rawTarget.includes("@") ? rawTarget.toLowerCase() : cleanPhone(rawTarget);

    if (!target || otp.length !== 6) {
      return res.status(400).json({ error: "Valid target and 6-digit OTP are required." });
    }

    const row = db.prepare("SELECT value FROM system_settings WHERE key = ?").get(`v33_reg_meta:${target}`);
    if (!row) {
      return res.status(400).json({ error: "OTP session not found or expired. Please request a new OTP." });
    }

    const record = parseJson(row.value, null);
    const nowSec = Math.floor(Date.now() / 1000);
    if (!record || nowSec > Number(record.expiresAt || 0)) {
      db.prepare("DELETE FROM system_settings WHERE key = ?").run(`v33_reg_meta:${target}`);
      return res.status(400).json({ error: "OTP has expired. Please request a fresh OTP." });
    }
    if (Number(record.attempts || 0) >= 5) {
      db.prepare("DELETE FROM system_settings WHERE key = ?").run(`v33_reg_meta:${target}`);
      return res.status(429).json({ error: "Too many invalid OTP attempts. Please request a new OTP." });
    }

    const expectedHash = String(record.otpHash || "");
    const providedHash = hashOtp(otp);
    const valid =
      expectedHash.length === providedHash.length &&
      crypto.timingSafeEqual(Buffer.from(expectedHash), Buffer.from(providedHash));

    if (!valid) {
      record.attempts = Number(record.attempts || 0) + 1;
      db.prepare("UPDATE system_settings SET value = ?, updated_at = ? WHERE key = ?").run(
        JSON.stringify(record),
        nowIso(),
        `v33_reg_meta:${target}`
      );
      return res.status(400).json({ error: `Incorrect OTP. ${Math.max(0, 5 - record.attempts)} attempt(s) remaining.` });
    }

    // Valid OTP — consume immediately
    db.prepare("DELETE FROM system_settings WHERE key = ?").run(`v33_reg_meta:${target}`);

    const phone = cleanPhone(record.phone);
    const email = record.email || `student.${phone}@yuitor.local`;
    const fullName = cleanStr(record.fullName, 100) || "Yuitor Student";
    const now = nowIso();

    // Reuse existing student account if phone already registered (prevent duplicates!)
    let user = db.prepare("SELECT * FROM users WHERE phone = ? OR (email = ? AND email != '') LIMIT 1").get(phone, email);
    let createdNew = false;

    if (!user) {
      const randomPassHash = bcrypt.hashSync(crypto.randomBytes(24).toString("hex"), 10);
      const defaultBranch = db.prepare("SELECT id FROM branches WHERE is_active = 1 ORDER BY id ASC LIMIT 1").get();
      const userId = insertStudentUserSafe({
        fullName,
        email,
        phone,
        passwordHash: randomPassHash,
        branchId: defaultBranch?.id || null,
        mobileVerified: 1,
        now,
      });
      const rollNo = `YTR-${new Date().getFullYear()}-${String(userId).padStart(4, "0")}`;
      try {
        db.prepare(
          `INSERT OR IGNORE INTO student_profiles (
            user_id, class_level, board, subjects_json, course_duration_months,
            admission_date, enrollment_status, roll_number, branch_id, profile_completion_pct
          ) VALUES (?, '', '', '[]', 12, ?, 'active', ?, ?, 14)`
        ).run(userId, now.slice(0, 10), rollNo, defaultBranch?.id || null);
      } catch {
        // ignore if extra columns differ
      }
      // Track optional referral code safely
      if (record.referralCode) {
        try {
          const ref = db.prepare("SELECT user_id FROM referral_profiles WHERE UPPER(referral_code) = ? LIMIT 1").get(record.referralCode);
          if (ref && Number(ref.user_id) !== userId) {
            db.prepare(
              `INSERT OR IGNORE INTO referrals (referrer_user_id, referred_user_id, referral_code, status, created_at)
               VALUES (?, ?, ?, 'registered', ?)`
            ).run(ref.user_id, userId, record.referralCode, now);
          }
        } catch {
          // optional referral table
        }
      }
      user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
      createdNew = true;
    } else {
      db.prepare("UPDATE users SET mobile_verified = 1 WHERE id = ?").run(user.id);
    }

    // Create authenticated session & set cookie cleanly (matches server.js signatures!)
    if (typeof createSession === "function" && typeof setSessionCookie === "function") {
      const sessionId = createSession(db, user.id, {});
      setSessionCookie(res, req, sessionId);
    }
    logAudit(user, createdNew ? "v33_quick_register" : "v33_quick_otp_login", "user", user.id, `Student OTP verified (${phone})`, req);

    return res.json({
      ok: true,
      authenticated: true,
      createdNew,
      redirectUrl: "/student",
      user: {
        id: user.id,
        fullName: user.full_name,
        email: user.email,
        phone: user.phone,
        role: user.role,
      },
    });
  });

  /* ============================================================================
   * 2. PUBLIC & LIVE DYNAMIC PRICING CATALOG + SERVER-SIDE CHECKOUT CALCULATOR
   * ========================================================================== */
  router.get("/pricing/catalog", (req, res) => {
    const branchId = req.query?.branchId ? Number(req.query.branchId) : null;
    const cfg = getV33PricingConfig(db);
    const branchOverlay = getBranchPricingOverlay(db, branchId);
    const effectiveSchoolFees = { ...cfg.schoolSubjectFees, ...(branchOverlay.schoolSubjectFees || {}) };
    const effectiveDurationDiscounts = { ...cfg.durationDiscounts, ...(branchOverlay.durationDiscounts || {}) };
    const nowStr = nowIso();

    const branches = db.prepare("SELECT id, name, code, city, address, phone FROM branches WHERE is_active = 1 ORDER BY id ASC").all();
    const rawCourses = db
      .prepare("SELECT * FROM courses WHERE is_active = 1 AND COALESCE(show_on_frontend, 1) = 1 ORDER BY COALESCE(pricing_priority, 100) ASC, id ASC")
      .all();

    const courses = rawCourses
      .filter((c) => !branchOverlay.disabledCourseIds.includes(Number(c.id)))
      .map((c) => {
        const monthly = Number(branchOverlay.courseOverrides?.[String(c.id)] ?? c.monthly_fee ?? 0);
        const promoActive =
          Number(c.promo_enabled) === 1 &&
          Number(c.promo_price) > 0 &&
          (!c.promo_valid_until || c.promo_valid_until >= nowStr.slice(0, 10));
        const effectiveMonthly = promoActive ? Math.min(monthly, Number(c.promo_price)) : monthly;
        const packages = {};
        for (const m of [1, 3, 6, 9, 12]) {
          packages[`${m}m`] = computeDurationPrice(effectiveMonthly, m, effectiveDurationDiscounts);
        }
        return {
          id: Number(c.id),
          title: c.title,
          slug: c.slug,
          category: c.category,
          classRange: c.class_range,
          board: c.board,
          description: c.description,
          monthlyFee: monthly,
          promoActive,
          promoPrice: promoActive ? Number(c.promo_price) : 0,
          effectiveMonthly,
          packages,
          availabilityStatus: c.availability_status || "available",
        };
      });

    const schoolClasses = Object.entries(effectiveSchoolFees).map(([cls, monthly]) => {
      const packages = {};
      for (const m of [1, 3, 6, 9, 12]) {
        packages[`${m}m`] = computeDurationPrice(monthly, m, effectiveDurationDiscounts);
      }
      return {
        classNumber: Number(cls),
        classLabel: `Class ${cls}th`,
        monthlyPerSubject: Number(monthly),
        subjects: CLASS_SUBJECT_CATALOG[cls] || [],
        packages,
      };
    });

    const bundles = db
      .prepare("SELECT * FROM v33_bundles WHERE is_active = 1 AND show_on_frontend = 1 ORDER BY priority ASC, id ASC")
      .all()
      .map((b) => ({
        id: Number(b.id),
        code: b.code,
        name: b.name,
        category: b.category,
        classLevel: b.class_level,
        subjects: parseJson(b.subjects_json, []),
        baseMonthlyPrice: Number(branchOverlay.bundleOverrides?.[String(b.id)] ?? b.base_monthly_price ?? 0),
        customPrice: Number(b.custom_price || 0),
        discountPercent: Number(b.discount_percent || 0),
        promoEnabled: Boolean(b.promo_enabled),
        promoPrice: Number(b.promo_price || 0),
        badge: `Save ${Number(b.discount_percent || 0)}% with Bundle`,
        description: b.description,
      }));

    const addons = db
      .prepare("SELECT * FROM v33_addons WHERE is_active = 1 AND show_on_frontend = 1 ORDER BY id ASC")
      .all()
      .map((a) => ({
        id: Number(a.id),
        code: a.code,
        title: a.title,
        category: a.category,
        price: Number(a.price || 0),
        promoPrice: Number(a.promo_price || 0),
        effectivePrice: Number(a.promo_price) > 0 && Number(a.promo_price) < Number(a.price) ? Number(a.promo_price) : Number(a.price),
        description: a.description,
      }));

    const activeOffers = db
      .prepare("SELECT * FROM v33_promo_offers WHERE is_active = 1 AND start_at <= ? AND end_at >= ? ORDER BY end_at ASC")
      .all(nowStr, nowStr)
      .map((o) => ({
        id: Number(o.id),
        code: o.code,
        title: o.title,
        offerType: o.offer_type,
        discountType: o.discount_type,
        discountValue: Number(o.discount_value || 0),
        startAt: o.start_at,
        endAt: o.end_at,
        bannerText: o.banner_text,
      }));

    const scholarships = db
      .prepare("SELECT id, code, name, scholarship_type, discount_type, discount_value, eligibility FROM v33_scholarships WHERE is_active = 1 ORDER BY priority ASC")
      .all();

    return res.json({
      version: V33_VERSION,
      branchId,
      branches,
      schoolClasses,
      courses,
      bundles,
      addons,
      activeOffers,
      scholarships,
      durationDiscounts: effectiveDurationDiscounts,
      multiSubjectSlabs: cfg.multiSubjectSlabs,
      subjectCatalog: CLASS_SUBJECT_CATALOG,
    });
  });

  router.post("/checkout/quote", (req, res) => {
    const user = getUser(req);
    const quote = calculateDynamicCheckoutQuote(db, {
      ...req.body,
      studentId: user?.role === "student" ? user.id : req.body?.studentId,
    });
    return res.json({ ok: true, quote });
  });

  router.post("/checkout/create-order", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Please sign in to create a checkout invoice." });

    const studentId = isAdminUser(user) && req.body?.studentId ? Number(req.body.studentId) : Number(user.id);
    const quote = calculateDynamicCheckoutQuote(db, { ...req.body, studentId });
    if (quote.lineItems.length === 0 || quote.finalPayableAmount < 0) {
      return res.status(400).json({ error: "Select at least one subject, course, bundle, or add-on product." });
    }

    const paymentType = req.body?.paymentType === "partial" ? "partial" : "full";
    const requestedPayAmount =
      paymentType === "partial"
        ? Math.min(quote.finalPayableAmount, Math.max(200, Math.round(Number(req.body?.payAmount || 0))))
        : quote.finalPayableAmount;
    const paymentMethod = cleanStr(req.body?.paymentMethod || "upi", 32).toLowerCase();
    const utrReference = cleanStr(req.body?.utrReference || "", 80);

    const now = nowIso();
    const dueDate = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10);
    const expiryDate = new Date(Date.now() + quote.durationMonths * 30 * 86400000).toISOString().slice(0, 10);
    const firstCourseId = quote.lineItems.find((i) => i.courseId)?.courseId || null;
    const titleSummary = quote.lineItems.map((i) => i.title).slice(0, 3).join(" + ").slice(0, 160);
    const invNum = `YTR-INV-${Date.now().toString().slice(-6)}-${crypto.randomInt(10, 99)}`;

    const invIns = db
      .prepare(
        `INSERT INTO fee_records (
          student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date,
          status, branch_id, billing_cycle, course_duration_months, course_expiry_date, fee_plan_label, pricing_snapshot_json, created_at
        ) VALUES (?, ?, ?, ?, ?, 0, ?, 'pending', ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        studentId,
        firstCourseId,
        titleSummary || "Yuitor Course Package",
        quote.baseAmount,
        quote.breakdown.totalDiscountAmount + quote.breakdown.upgradeCredit,
        dueDate,
        quote.branchId || user.branch_id || null,
        `${quote.durationMonths}m`,
        quote.durationMonths,
        expiryDate,
        `${quote.durationMonths} Months (${paymentType === "partial" ? "Part Payment" : "Full Payment"})`,
        JSON.stringify(quote),
        now
      );
    const feeRecordId = Number(invIns.lastInsertRowid);

    // Record upgrade ledger if Smart Upgrade was applied
    if (req.body?.isUpgrade && quote.selectedBundle) {
      db.prepare(
        `INSERT INTO v33_upgrade_history (
          student_id, from_summary, to_target_type, to_target_id, to_target_name,
          gross_new_price, previous_paid_credit, remaining_payable, fee_record_id, created_by, created_at
        ) VALUES (?, ?, 'bundle', ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        studentId,
        cleanStr(req.body?.fromSummary || "Existing Course Enrollment", 160),
        quote.selectedBundle.id,
        quote.selectedBundle.name,
        quote.baseAmount - quote.breakdown.totalDiscountAmount,
        quote.breakdown.upgradeCredit,
        quote.finalPayableAmount,
        feeRecordId,
        user.id,
        now
      );
    }

    // Create PENDING payment transaction (NEVER auto-verified before backend payment verification!)
    let paymentId = null;
    if (requestedPayAmount > 0 && req.body?.submitPayment !== false) {
      const pIns = db
        .prepare(
          `INSERT INTO payments (
            student_id, course_id, plan, base_amount, discount_amount, amount, coupon_code,
            payment_method, utr_reference, verification_status, refund_status, invoice_number, notes, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending_verification', 'none', ?, ?, ?)`
        )
        .run(
          studentId,
          resolveFallbackCourseId(firstCourseId),
          `${quote.durationMonths}m`,
          quote.baseAmount,
          quote.breakdown.totalDiscountAmount,
          requestedPayAmount,
          quote.breakdown.couponCode || quote.breakdown.scholarshipCode || quote.breakdown.promoCode || "",
          paymentMethod,
          utrReference,
          invNum,
          `${req.body?.isUpgrade ? "Smart Upgrade" : quote.addonsTotal > 0 ? "Add-On & Course Checkout" : "Dynamic Checkout"} (${paymentType})`,
          now
        );
      paymentId = Number(pIns.lastInsertRowid);
    }

    // Notify Admins with deep link
    db.prepare(
      `INSERT INTO notifications (user_id, role_target, title, message, is_read, status, deep_link, entity_type, entity_id, created_at)
       VALUES (NULL, 'admin', ?, ?, 0, 'new', ?, 'payment', ?, ?)`
    ).run(
      `Payment Pending Verification (₹${requestedPayAmount})`,
      `${user.full_name} submitted ${paymentType} payment of ₹${requestedPayAmount} for ${titleSummary}. Verify to update balance.`,
      `#users?manage=${studentId}&view=invoices`,
      String(paymentId || feeRecordId),
      now
    );

    return res.status(201).json({
      ok: true,
      feeRecordId,
      paymentId,
      invoiceNumber: invNum,
      verificationStatus: "pending_verification",
      payableAmount: requestedPayAmount,
      quote,
      message: "Invoice created & payment submitted as Pending Verification. Balance updates automatically once verified.",
    });
  });

  /* ============================================================================
   * 3. STUDENT PANEL — ADVANCED INVOICES, PART/FULL PAYMENT, PDF, WIZARD, RECOMMENDATIONS
   * ========================================================================== */
  router.get("/student/finance", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const summary = buildStudentFinancialSummary(db, user.id);
    return res.json({ ok: true, ...summary });
  });

  router.post("/student/pay", (req, res) => {
    const user = getUser(req);
    if (!user || user.role !== "student") {
      return res.status(403).json({ error: "Student sign-in required." });
    }
    const fin = buildStudentFinancialSummary(db, user.id);
    const pendingBal = Number(fin?.summary?.pendingAmount || 0);
    if (pendingBal <= 0) {
      return res.status(400).json({ error: "No pending fee balance to pay." });
    }

    const rawMode = String(req.body?.paymentType || req.body?.paymentMode || "full").toLowerCase();
    const mode = rawMode === "partial" || rawMode === "part" ? "partial" : "full";
    const rawAmount = mode === "full" ? pendingBal : Math.round(Number(req.body?.amount || 0));
    const minPay = Math.min(100, pendingBal);
    if (rawAmount < minPay || rawAmount > pendingBal) {
      return res.status(400).json({ error: `Enter a valid amount between ₹${minPay} and ₹${pendingBal}.` });
    }
    const paymentMethod = cleanStr(req.body?.paymentMethod || "upi", 32).toLowerCase();
    const utrReference = cleanStr(req.body?.utrReference || req.body?.transactionId || "", 80);
    const invoiceId = req.body?.invoiceId || req.body?.feeRecordId ? Number(req.body?.invoiceId || req.body?.feeRecordId) : fin.invoices[0]?.id || null;
    const inv = invoiceId ? fin.invoices.find((i) => Number(i.id) === invoiceId) : fin.invoices[0];
    const invNum = inv?.invoice_number || `YTR-INV-${String(invoiceId || user.id).padStart(5, "0")}`;
    const now = nowIso();

    // Strictly insert as pending_verification — NEVER mark successful before verification!
    const ins = db
      .prepare(
        `INSERT INTO payments (
          student_id, course_id, plan, base_amount, discount_amount, amount,
          payment_method, utr_reference, verification_status, refund_status,
          invoice_number, notes, created_at
        ) VALUES (?, ?, ?, ?, 0, ?, ?, ?, 'pending_verification', 'none', ?, ?, ?)`
      )
      .run(
        user.id,
        resolveFallbackCourseId(inv?.course_id),
        mode === "partial" ? "part_payment" : "full_payment",
        rawAmount,
        rawAmount,
        paymentMethod,
        utrReference,
        invNum,
        `Student Portal ${mode === "partial" ? "Part" : "Full"} Payment (Awaiting Verification)`,
        now
      );
    const paymentId = Number(ins.lastInsertRowid);

    db.prepare(
      `INSERT INTO notifications (user_id, role_target, title, message, is_read, status, deep_link, entity_type, entity_id, created_at)
       VALUES (NULL, 'admin', ?, ?, 0, 'new', ?, 'payment', ?, ?)`
    ).run(
      `Student Payment Verification Needed (₹${rawAmount})`,
      `${user.full_name} submitted ${mode} payment of ₹${rawAmount} (${paymentMethod.toUpperCase()}${utrReference ? ` · Ref ${utrReference}` : ""}).`,
      `#users?manage=${user.id}&view=invoices`,
      String(paymentId),
      now
    );

    return res.status(201).json({
      ok: true,
      paymentId,
      amount: rawAmount,
      paymentType: mode,
      verificationStatus: "pending_verification",
      message: "Payment submitted as Pending Verification. Your balance and receipt will update automatically after verification.",
    });
  });

  router.get("/student/invoice/:id/pdf", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const inv = db.prepare("SELECT * FROM fee_records WHERE id = ?").get(Number(req.params.id));
    if (!inv) return res.status(404).json({ error: "Invoice not found." });
    if (!isAuthorizedStaffOrAdmin(db, user, "fees") && Number(inv.student_id) !== Number(user.id)) {
      return res.status(403).json({ error: "Access denied to this invoice." });
    }
    const student = db.prepare("SELECT full_name, email, phone FROM users WHERE id = ?").get(inv.student_id);
    const net = Math.max(0, Number(inv.total_amount || 0) - Number(inv.discount_amount || 0));
    const paid = Number(inv.paid_amount || 0);
    const pending = Math.max(0, net - paid);
    const invNo = inv.invoice_number || `YTR-INV-${String(inv.id).padStart(5, "0")}`;
    const pdf = buildSimplePdfBuffer(
      `YUITOR SMART CLASSES — OFFICIAL FEE INVOICE (${invNo})`,
      [
        `Invoice Number: ${invNo}`,
        `Date Issued: ${String(inv.created_at || "").slice(0, 10)}`,
        `Student Name: ${student?.full_name || "Student"}`,
        `Phone / Email: ${student?.phone || "-"} | ${student?.email || "-"}`,
        `Course / Package: ${inv.title || "Yuitor Course"}`,
        `Plan / Duration: ${inv.fee_plan_label || `${inv.course_duration_months || 12} Months`}`,
        `Due Date: ${inv.due_date || "-"}`,
        `Course Expiry: ${inv.course_expiry_date || "-"}`,
        `----------------------------------------------------`,
        `Gross Course Fee: INR ${Number(inv.total_amount || 0)}`,
        `Discount Applied: INR ${Number(inv.discount_amount || 0)}`,
        `Net Payable Fee:  INR ${net}`,
        `Verified Paid:    INR ${paid}`,
        `Pending Balance:  INR ${pending}`,
        `Invoice Status:   ${String(inv.status || "pending").toUpperCase()}`,
        `----------------------------------------------------`,
        `Note: Payments reflect as Paid only after backend/admin verification.`,
        `Yuitor Smart Classes · https://yuitor.com · Helpline +91 7827289292`,
      ]
    );
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${invNo}.pdf"`);
    return res.send(pdf);
  });

  router.get("/student/receipt/:id/pdf", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const pay = db.prepare("SELECT * FROM payments WHERE id = ?").get(Number(req.params.id));
    if (!pay) return res.status(404).json({ error: "Payment record not found." });
    if (!isAuthorizedStaffOrAdmin(db, user, "fees") && Number(pay.student_id) !== Number(user.id)) {
      return res.status(403).json({ error: "Access denied to this receipt." });
    }
    if (pay.verification_status !== "verified") {
      return res.status(400).json({ error: "Official receipt is available only after payment verification." });
    }
    const student = db.prepare("SELECT full_name, email, phone FROM users WHERE id = ?").get(pay.student_id);
    const recNo = pay.receipt_number || `YTR-REC-${String(pay.id).padStart(5, "0")}`;
    const pdf = buildSimplePdfBuffer(
      `YUITOR SMART CLASSES — VERIFIED PAYMENT RECEIPT (${recNo})`,
      [
        `Receipt Number: ${recNo}`,
        `Invoice Reference: ${pay.invoice_number || "-"}`,
        `Payment Date: ${String(pay.paid_at || pay.created_at || "").slice(0, 10)}`,
        `Student Name: ${student?.full_name || "Student"}`,
        `Phone / Email: ${student?.phone || "-"} | ${student?.email || "-"}`,
        `Payment Mode: ${String(pay.payment_method || "UPI").toUpperCase()}`,
        `Transaction / UTR ID: ${pay.gateway_payment_id || pay.utr_reference || `TXN-${pay.id}`}`,
        `Verification Status: VERIFIED`,
        `----------------------------------------------------`,
        `Amount Received: INR ${Number(pay.amount || 0)}`,
        `Discount Recorded: INR ${Number(pay.discount_amount || 0)}`,
        `----------------------------------------------------`,
        `Thank you for learning with Yuitor Smart Classes!`,
        `https://yuitor.com · Verified Electronic Receipt`,
      ]
    );
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${recNo}.pdf"`);
    return res.send(pdf);
  });

  // Profile Completion Wizard (0%–100%)
  router.get("/student/profile-wizard", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const fullUser = db.prepare("SELECT id, full_name, email, phone, avatar_url, branch_id FROM users WHERE id = ?").get(user.id);
    const profile = db.prepare("SELECT * FROM student_profiles WHERE user_id = ?").get(user.id) || {};
    const branches = db.prepare("SELECT id, name, city FROM branches WHERE is_active = 1 ORDER BY id ASC").all();
    const completion = calculateProfileCompletion(profile, fullUser);
    return res.json({
      ok: true,
      completion,
      profile: {
        address: profile.address || "",
        schoolName: profile.school_name || "",
        board: profile.board || "",
        classLevel: profile.class_level || "",
        subjects: completion.subjects,
        branchId: profile.branch_id || fullUser?.branch_id || "",
        avatarUrl: fullUser?.avatar_url || "",
        parentName: profile.parent_name || "",
        parentPhone: profile.parent_phone || "",
      },
      boards: ["CBSE", "ICSE", "UP Board", "State Board"],
      classes: ["6th", "7th", "8th", "9th", "10th", "11th", "12th"],
      subjectCatalog: CLASS_SUBJECT_CATALOG,
      branches,
    });
  });

  router.post("/student/profile-wizard", (req, res) => {
    const user = getUser(req);
    if (!user || user.role !== "student") {
      return res.status(403).json({ error: "Student access required." });
    }
    const address = cleanStr(req.body?.address, 260);
    const schoolName = cleanStr(req.body?.schoolName, 140);
    const board = cleanStr(req.body?.board, 40);
    const classLevel = cleanStr(req.body?.classLevel, 30);
    const branchId = req.body?.branchId ? Number(req.body.branchId) : null;
    const parentName = cleanStr(req.body?.parentName, 100);
    const parentPhone = cleanPhone(req.body?.parentPhone || "");
    const subjects = Array.isArray(req.body?.subjects)
      ? [...new Set(req.body.subjects.map((s) => cleanStr(s, 60)).filter(Boolean))]
      : [];
    const avatarUrl = cleanStr(req.body?.avatarUrl, 300);

    if (branchId) {
      db.prepare("UPDATE users SET branch_id = ? WHERE id = ?").run(branchId, user.id);
    }
    if (avatarUrl && (/^https?:\/\//i.test(avatarUrl) || avatarUrl.startsWith("/uploads/") || avatarUrl.startsWith("/assets/") || avatarUrl.startsWith("data:image/"))) {
      db.prepare("UPDATE users SET avatar_url = ? WHERE id = ?").run(avatarUrl, user.id);
    }

    const exists = db.prepare("SELECT user_id FROM student_profiles WHERE user_id = ?").get(user.id);
    if (!exists) {
      db.prepare("INSERT INTO student_profiles (user_id, admission_date, enrollment_status) VALUES (?, ?, 'active')").run(
        user.id,
        nowIso().slice(0, 10)
      );
    }
    db.prepare(
      `UPDATE student_profiles SET
        address = ?, school_name = ?, board = ?, class_level = ?,
        subjects_json = ?, enrolled_subjects_json = ?, branch_id = COALESCE(?, branch_id),
        parent_name = ?, parent_phone = ?
       WHERE user_id = ?`
    ).run(
      address,
      schoolName,
      board,
      classLevel,
      JSON.stringify(subjects),
      JSON.stringify(subjects),
      branchId,
      parentName,
      parentPhone,
      user.id
    );

    const updatedUser = db.prepare("SELECT id, full_name, email, phone, avatar_url, branch_id FROM users WHERE id = ?").get(user.id);
    const updatedProfile = db.prepare("SELECT * FROM student_profiles WHERE user_id = ?").get(user.id);
    const completion = calculateProfileCompletion(updatedProfile, updatedUser);

    db.prepare("UPDATE student_profiles SET profile_completion_pct = ?, profile_completed_at = ? WHERE user_id = ?").run(
      completion.percent,
      completion.isComplete ? nowIso() : "",
      user.id
    );

    return res.json({ ok: true, completion, message: completion.isComplete ? "100% Profile Complete!" : `Profile updated (${completion.percent}% complete).` });
  });

  // Student Smart Recommendations, Bundles, Add-Ons, Gamified Path & One-Click Upgrade
  router.get("/student/recommendations", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const sid = isAdminUser(user) && req.query?.studentId ? Number(req.query.studentId) : Number(user.id);
    const data = buildSmartRecommendations(db, sid);
    return res.json({ ok: true, ...data });
  });

  router.post("/student/upgrade-quote", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const quote = calculateDynamicCheckoutQuote(db, {
      ...req.body,
      studentId: user.id,
      isUpgrade: true,
    });
    return res.json({ ok: true, quote });
  });

  /* ============================================================================
   * 4. PARENT DASHBOARD INSIGHTS (Authorized Linked Children Only)
   * ========================================================================== */
  router.get("/parent/insights/:studentId", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const sid = Number(req.params.studentId);
    if (!isAdminUser(user)) {
      if (user.role !== "parent") return res.status(403).json({ error: "Parent authorization required." });
      const plCols = db.prepare("PRAGMA table_info(parent_links)").all().map((c) => c.name);
      const pCol = plCols.includes("parent_user_id") ? "parent_user_id" : "parent_id";
      const sCol = plCols.includes("student_user_id") ? "student_user_id" : "student_id";
      const linked = db
        .prepare(`SELECT id FROM parent_links WHERE ${pCol} = ? AND ${sCol} = ? LIMIT 1`)
        .get(user.id, sid);
      if (!linked) return res.status(403).json({ error: "You are not authorized to view this student." });
    }
    const recs = buildSmartRecommendations(db, sid);
    const fin = buildStudentFinancialSummary(db, sid);
    const skillCourses = db
      .prepare(
        `SELECT id, title, category, monthly_fee, description FROM courses
         WHERE is_active = 1 AND slug IN ('english-speaking','coding-classes','ai-classes','jee-foundation','neet-foundation','cuet-preparation')
         ORDER BY id ASC`
      )
      .all();
    return res.json({
      ok: true,
      student: fin?.student || null,
      feeStatus: fin?.summary || null,
      weakSubjects: recs.weakSubjects,
      recommendedForChild: recs.recommendations,
      upgradeSuggestions: recs.bundles.slice(0, 4),
      skillAndExamCourses: skillCourses,
      learningProgress: recs.gamifiedPath,
    });
  });

  /* ============================================================================
   * 5. SMART NOTIFICATION CENTER (New / Read / Archived / Important + Deep Links)
   * ========================================================================== */
  router.get("/notifications", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const statusFilter = cleanStr(req.query?.status || "all", 20).toLowerCase();
    const role = String(user.role || "").toLowerCase();
    const targetRoles = isAdminUser(user) ? ["admin", "super_admin", "all"] : [role, "all"];
    const ph = targetRoles.map(() => "?").join(",");

    const rows = db
      .prepare(
        `SELECT * FROM notifications
         WHERE (user_id = ? OR (user_id IS NULL AND LOWER(COALESCE(role_target, '')) IN (${ph})))
         ORDER BY id DESC LIMIT 60`
      )
      .all(user.id, ...targetRoles)
      .map((n) => {
        const computedStatus = n.status || (n.is_read ? "read" : "new");
        let deepLink = n.deep_link || "";
        if (!deepLink) {
          if (role === "student") deepLink = "#fees";
          else if (isAdminUser(user)) deepLink = "#dashboard";
        }
        return { ...n, status: computedStatus, deep_link: deepLink };
      });

    const filtered = statusFilter === "all" ? rows.filter((r) => r.status !== "archived") : rows.filter((r) => r.status === statusFilter);
    const counts = {
      new: rows.filter((r) => r.status === "new").length,
      read: rows.filter((r) => r.status === "read").length,
      important: rows.filter((r) => r.status === "important").length,
      archived: rows.filter((r) => r.status === "archived").length,
    };
    return res.json({ ok: true, notifications: filtered, counts });
  });

  router.patch("/notifications/:id", (req, res) => {
    const user = getUser(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const nid = Number(req.params.id);
    const nextStatus = cleanStr(req.body?.status || "read", 20).toLowerCase();
    if (!["new", "read", "archived", "important"].includes(nextStatus)) {
      return res.status(400).json({ error: "Invalid notification status." });
    }
    const existing = db.prepare("SELECT * FROM notifications WHERE id = ?").get(nid);
    if (!existing) return res.status(404).json({ error: "Notification not found." });
    if (!isAdminUser(user) && existing.user_id !== null && Number(existing.user_id) !== Number(user.id)) {
      return res.status(403).json({ error: "Forbidden." });
    }
    const isRead = nextStatus === "new" ? 0 : 1;
    db.prepare("UPDATE notifications SET status = ?, is_read = ? WHERE id = ?").run(nextStatus, isRead, nid);
    return res.json({ ok: true, id: nid, status: nextStatus, isRead });
  });

  /* ============================================================================
   * 6. ADMIN & STAFF — STUDENT INVOICE MANAGEMENT + AUTOMATED FOLLOW-UPS
   * ========================================================================== */
  router.get("/admin/students/:id/invoices", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "fees")) {
      return res.status(403).json({ error: "Admin or Fee-authorized Staff access required." });
    }
    const data = buildStudentFinancialSummary(db, Number(req.params.id));
    if (!data) return res.status(404).json({ error: "Student not found." });
    return res.json({ ok: true, ...data });
  });

  router.post("/admin/students/:id/record-payment", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "fees")) {
      return res.status(403).json({ error: "Admin or Fee-authorized Staff access required." });
    }
    const sid = Number(req.params.id);
    const amount = Math.round(Number(req.body?.amount || 0));
    if (amount <= 0) return res.status(400).json({ error: "Payment amount must be greater than ₹0." });

    const paymentType = req.body?.paymentType === "partial" ? "part_payment" : "full_payment";
    const paymentMethod = cleanStr(req.body?.paymentMethod || "cash", 32).toLowerCase();
    const utrReference = cleanStr(req.body?.utrReference || "", 80);
    const markVerified = Boolean(req.body?.markVerified ?? req.body?.verifyNow);
    const notes = cleanStr(req.body?.notes || `${paymentType === "part_payment" ? "Part" : "Full"} payment recorded`, 240);
    const now = nowIso();

    // Look up specific invoice if requested, otherwise fallback to student's latest invoice
    const requestedFeeId = Number(req.body?.feeRecordId || 0);
    let inv = requestedFeeId
      ? db.prepare("SELECT * FROM fee_records WHERE id = ? AND student_id = ?").get(requestedFeeId, sid)
      : null;
    if (!inv) {
      inv = db.prepare("SELECT * FROM fee_records WHERE student_id = ? ORDER BY id DESC LIMIT 1").get(sid);
    }
    if (!inv && Number(req.body?.totalFee || 0) > 0) {
      const dueDate = cleanStr(req.body?.dueDate || new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10), 20);
      const insInv = db
        .prepare(
          `INSERT INTO fee_records (student_id, title, total_amount, discount_amount, paid_amount, due_date, status, billing_cycle, created_at)
           VALUES (?, ?, ?, 0, 0, ?, 'pending', '12m', ?)`
        )
        .run(sid, cleanStr(req.body?.title || "Course Tuition Fee", 140), Math.round(Number(req.body.totalFee)), dueDate, now);
      inv = db.prepare("SELECT * FROM fee_records WHERE id = ?").get(Number(insInv.lastInsertRowid));
    }

    const verificationStatus = markVerified ? "verified" : "pending_verification";
    const receiptNo = markVerified ? `YTR-REC-${Date.now().toString().slice(-6)}-${crypto.randomInt(10, 99)}` : "";
    const invNo = inv?.invoice_number || `YTR-INV-${String(inv?.id || sid).padStart(5, "0")}`;

    const pIns = db
      .prepare(
        `INSERT INTO payments (
          student_id, course_id, plan, base_amount, discount_amount, amount, payment_method,
          utr_reference, verification_status, refund_status, invoice_number, receipt_number,
          paid_at, collected_by, notes, created_at
        ) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, 'none', ?, ?, ?, ?, ?, ?)`
      )
      .run(
        sid,
        resolveFallbackCourseId(inv?.course_id),
        paymentType,
        amount,
        amount,
        paymentMethod,
        utrReference,
        verificationStatus,
        invNo,
        receiptNo,
        markVerified ? now : null,
        user.id,
        notes,
        now
      );

    const paymentId = Number(pIns.lastInsertRowid);
    let balanceResult = null;
    if (markVerified) {
      balanceResult = recalculateStudentInvoiceBalances(db, sid);
      db.prepare(
        `INSERT INTO notifications (user_id, role_target, title, message, is_read, status, deep_link, entity_type, entity_id, created_at)
         VALUES (?, 'student', ?, ?, 0, 'new', '#fees', 'payment', ?, ?)`
      ).run(
        sid,
        `Payment Verified (₹${amount})`,
        `Your payment of ₹${amount} has been verified. Receipt #${receiptNo} is ready to download.`,
        String(paymentId),
        now
      );
    }

    logAudit(user, "v33_record_payment", "payment", paymentId, `Student #${sid} ₹${amount} (${verificationStatus})`, req);

    return res.status(201).json({
      ok: true,
      paymentId,
      verificationStatus,
      receiptNumber: receiptNo,
      balances: balanceResult,
      summary: buildStudentFinancialSummary(db, sid),
    });
  });

  router.post("/admin/payments/:paymentId/verify", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "fees")) {
      return res.status(403).json({ error: "Admin or Fee-authorized Staff access required." });
    }
    const pid = Number(req.params.paymentId);
    const pay = db.prepare("SELECT * FROM payments WHERE id = ?").get(pid);
    if (!pay) return res.status(404).json({ error: "Payment not found." });

    const action = req.body?.action === "reject" ? "rejected" : "verified";
    const now = nowIso();
    const receiptNo = action === "verified" ? pay.receipt_number || `YTR-REC-${Date.now().toString().slice(-6)}-${crypto.randomInt(10, 99)}` : "";

    db.prepare(
      `UPDATE payments SET verification_status = ?, receipt_number = COALESCE(NULLIF(?, ''), receipt_number), paid_at = COALESCE(paid_at, ?) WHERE id = ?`
    ).run(action, receiptNo, action === "verified" ? now : null, pid);

    const balances = recalculateStudentInvoiceBalances(db, pay.student_id);

    // Auto-activate student/enrollment only after verification
    if (action === "verified") {
      db.prepare("UPDATE users SET is_active = 1, verification_status = 'approved' WHERE id = ? AND role = 'student'").run(pay.student_id);
      db.prepare("UPDATE enrollments SET status = 'active' WHERE student_id = ? AND status = 'pending'").run(pay.student_id);
      db.prepare(
        `INSERT INTO notifications (user_id, role_target, title, message, is_read, status, deep_link, entity_type, entity_id, created_at)
         VALUES (?, 'student', ?, ?, 0, 'new', '#fees', 'payment', ?, ?)`
      ).run(
        pay.student_id,
        `Payment Verified — ₹${pay.amount}`,
        `Your payment of ₹${pay.amount} is verified! Invoice balance updated automatically. Receipt: ${receiptNo}.`,
        String(pid),
        now
      );
    }

    logAudit(user, `v33_payment_${action}`, "payment", pid, `Payment #${pid} for student #${pay.student_id}`, req);

    return res.json({
      ok: true,
      paymentId: pid,
      verificationStatus: action,
      receiptNumber: receiptNo,
      balances,
      summary: buildStudentFinancialSummary(db, pay.student_id),
    });
  });

  // Schedule Automated Fee Follow-Up
  router.post("/admin/students/:id/followups", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "fees")) {
      return res.status(403).json({ error: "Admin or Fee-authorized Staff access required." });
    }
    const sid = Number(req.params.id);
    const followUpDate = cleanStr(req.body?.followUpDate, 20);
    const followUpTime = cleanStr(req.body?.followUpTime || "10:00", 10);
    const reminderType = cleanStr(req.body?.reminderType || "due_payment", 40);
    const customMessage = cleanStr(req.body?.customMessage || "", 600);
    const channels = Array.isArray(req.body?.channels) && req.body.channels.length ? req.body.channels : ["email", "whatsapp", "in_app"];
    const feeRecordId = req.body?.feeRecordId ? Number(req.body.feeRecordId) : null;

    if (!/^\d{4}-\d{2}-\d{2}$/.test(followUpDate)) {
      return res.status(400).json({ error: "Valid Follow-Up Date (YYYY-MM-DD) is required." });
    }
    const scheduledAt = new Date(`${followUpDate}T${followUpTime.length === 5 ? followUpTime : "10:00"}:00+05:30`).toISOString();
    const idempotencyKey = `fup:${sid}:${followUpDate}:${followUpTime}:${reminderType}`;

    try {
      const ins = db
        .prepare(
          `INSERT INTO v33_invoice_followups (
            student_id, fee_record_id, follow_up_date, follow_up_time, scheduled_at,
            reminder_type, channels_json, custom_message, status, idempotency_key, created_by, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', ?, ?, ?)`
        )
        .run(
          sid,
          feeRecordId,
          followUpDate,
          followUpTime,
          scheduledAt,
          reminderType,
          JSON.stringify(channels),
          customMessage,
          idempotencyKey,
          user.id,
          nowIso()
        );
      if (feeRecordId) {
        db.prepare("UPDATE fee_records SET next_followup_date = ? WHERE id = ?").run(`${followUpDate} ${followUpTime}`, feeRecordId);
      }
      return res.status(201).json({
        ok: true,
        followupId: Number(ins.lastInsertRowid),
        scheduledAt,
        message: `Automated follow-up scheduled for ${followUpDate} at ${followUpTime} IST.`,
      });
    } catch (err) {
      if (String(err?.message || "").includes("UNIQUE")) {
        return res.status(409).json({ error: "An identical follow-up reminder is already scheduled for that date & time." });
      }
      throw err;
    }
  });

  router.post("/admin/followups/:id/run-now", async (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "fees")) {
      return res.status(403).json({ error: "Unauthorized." });
    }
    const fid = Number(req.params.id);
    const pastIso = new Date(Date.now() - 1000).toISOString();
    db.prepare("UPDATE v33_invoice_followups SET scheduled_at = ? WHERE id = ? AND status = 'scheduled'").run(pastIso, fid);
    const result = await runInvoiceFollowupSweep(db, { sendTransactionalEmail });
    return res.json({ ok: true, result });
  });

  /* ============================================================================
   * 7. ADMIN — DYNAMIC COURSE, SUBJECT, BRANCH, BUNDLE, SCHOLARSHIP, OFFER & ADD-ON MANAGEMENT
   * ========================================================================== */
  router.get("/admin/pricing-hub", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const config = getV33PricingConfig(db);
    const branches = db.prepare("SELECT id, name, code, city FROM branches ORDER BY id ASC").all();
    const branchOverlays = db.prepare("SELECT * FROM v33_branch_pricing").all();
    const courses = db.prepare("SELECT * FROM courses ORDER BY COALESCE(pricing_priority, 100) ASC, id ASC").all();
    const bundles = db.prepare("SELECT * FROM v33_bundles ORDER BY priority ASC, id ASC").all().map((b) => ({ ...b, subjects: parseJson(b.subjects_json, []) }));
    const scholarships = db.prepare("SELECT * FROM v33_scholarships ORDER BY priority ASC, id ASC").all();
    const promoOffers = db.prepare("SELECT * FROM v33_promo_offers ORDER BY id DESC").all();
    const addons = db.prepare("SELECT * FROM v33_addons ORDER BY id ASC").all();
    const crossSellRules = db.prepare("SELECT * FROM v33_cross_sell_rules ORDER BY priority ASC, id ASC").all().map((r) => ({ ...r, recommendedItems: parseJson(r.recommended_items_json, []) }));
    const auditLogs = db.prepare("SELECT * FROM v33_pricing_audit ORDER BY id DESC LIMIT 40").all();
    return res.json({
      ok: true,
      config,
      branches,
      branchOverlays,
      courses,
      bundles,
      scholarships,
      promoOffers,
      addons,
      crossSellRules,
      auditLogs,
    });
  });

  router.put("/admin/pricing-config", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const updated = updateV33PricingConfig(db, req.body || {}, user);
    return res.json({ ok: true, config: updated, message: "Dynamic pricing configuration saved. Historical invoices remain protected." });
  });

  router.post("/admin/courses", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const title = cleanStr(req.body?.title, 140);
    if (title.length < 2) return res.status(400).json({ error: "Course title is required." });
    const slug = cleanStr(req.body?.slug || title.toLowerCase().replace(/[^a-z0-9]+/g, "-"), 100) + "-" + crypto.randomInt(10, 99);
    const category = cleanStr(req.body?.category || "Competitive Exams", 80);
    const classRange = cleanStr(req.body?.classRange || "All Classes", 60);
    const board = cleanStr(req.body?.board || "CBSE / UP / ICSE", 60);
    const description = cleanStr(req.body?.description || "", 500);
    const monthlyFee = Math.max(0, Math.round(Number(req.body?.monthlyFee || 0)));
    const yearlyFee = Math.round(monthlyFee * 12 * 0.8);
    const showOnFrontend = req.body?.showOnFrontend !== false ? 1 : 0;
    const isActive = req.body?.isActive !== false ? 1 : 0;
    const promoPrice = Math.max(0, Math.round(Number(req.body?.promoPrice ?? req.body?.promoFee ?? 0)));
    const promoEnabled = req.body?.promoEnabled !== undefined ? (req.body.promoEnabled ? 1 : 0) : (promoPrice > 0 ? 1 : 0);
    const promoValidUntil = cleanStr(req.body?.promoValidUntil || "", 20);
    const pricingPriority = Math.round(Number(req.body?.pricingPriority || 100));
    const availabilityStatus = cleanStr(req.body?.availabilityStatus || "available", 30);

    const ins = db
      .prepare(
        `INSERT INTO courses (
          title, slug, category, class_range, board, description, duration_months,
          monthly_fee, yearly_fee, is_active, show_on_frontend, promo_enabled, promo_price,
          promo_valid_until, pricing_priority, availability_status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, 12, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        title, slug, category, classRange, board, description, monthlyFee, yearlyFee,
        isActive, showOnFrontend, promoEnabled, promoPrice, promoValidUntil, pricingPriority, availabilityStatus, nowIso()
      );
    const id = Number(ins.lastInsertRowid);
    logPricingAudit(db, { actorId: user.id, actorName: user.full_name, entityType: "course", entityId: String(id), action: "create", after: { title, monthlyFee } });
    return res.status(201).json({ ok: true, id, course: db.prepare("SELECT * FROM courses WHERE id = ?").get(id) });
  });

  router.put("/admin/courses/:id", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const id = Number(req.params.id);
    const before = db.prepare("SELECT * FROM courses WHERE id = ?").get(id);
    if (!before) return res.status(404).json({ error: "Course not found." });

    const monthlyFee = req.body?.monthlyFee !== undefined ? Math.max(0, Math.round(Number(req.body.monthlyFee))) : before.monthly_fee;
    const yearlyFee = Math.round(monthlyFee * 12 * 0.8);
    db.prepare(
      `UPDATE courses SET
        title = ?, category = ?, class_range = ?, board = ?, description = ?,
        monthly_fee = ?, yearly_fee = ?, is_active = ?, show_on_frontend = ?,
        promo_enabled = ?, promo_price = ?, promo_valid_until = ?,
        pricing_priority = ?, availability_status = ?
       WHERE id = ?`
    ).run(
      cleanStr(req.body?.title ?? before.title, 140),
      cleanStr(req.body?.category ?? before.category, 80),
      cleanStr(req.body?.classRange ?? before.class_range, 60),
      cleanStr(req.body?.board ?? before.board, 60),
      cleanStr(req.body?.description ?? before.description, 500),
      monthlyFee,
      yearlyFee,
      req.body?.isActive !== undefined ? (req.body.isActive ? 1 : 0) : before.is_active,
      req.body?.showOnFrontend !== undefined ? (req.body.showOnFrontend ? 1 : 0) : before.show_on_frontend,
      req.body?.promoEnabled !== undefined
        ? (req.body.promoEnabled ? 1 : 0)
        : (req.body?.promoPrice !== undefined || req.body?.promoFee !== undefined
            ? (Math.max(0, Math.round(Number(req.body?.promoPrice ?? req.body?.promoFee ?? 0))) > 0 ? 1 : 0)
            : before.promo_enabled),
      req.body?.promoPrice !== undefined || req.body?.promoFee !== undefined
        ? Math.max(0, Math.round(Number(req.body?.promoPrice ?? req.body?.promoFee ?? 0)))
        : before.promo_price,
      cleanStr(req.body?.promoValidUntil ?? before.promo_valid_until, 20),
      req.body?.pricingPriority !== undefined ? Math.round(Number(req.body.pricingPriority)) : before.pricing_priority,
      cleanStr(req.body?.availabilityStatus ?? before.availability_status, 30),
      id
    );
    const after = db.prepare("SELECT * FROM courses WHERE id = ?").get(id);
    logPricingAudit(db, {
      actorId: user.id, actorName: user.full_name, entityType: "course", entityId: String(id), action: "update",
      before: { monthly_fee: before.monthly_fee, promo_price: before.promo_price, is_active: before.is_active },
      after: { monthly_fee: after.monthly_fee, promo_price: after.promo_price, is_active: after.is_active },
    });
    return res.json({ ok: true, course: after });
  });

  // Branch-Wise Pricing Override
  router.put("/admin/branch-pricing/:branchId", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const branchId = Number(req.params.branchId);
    const before = getBranchPricingOverlay(db, branchId);
    const now = nowIso();
    db.prepare(
      `INSERT INTO v33_branch_pricing (
        branch_id, school_subject_fees_json, course_overrides_json, bundle_overrides_json,
        duration_discounts_json, disabled_course_ids_json, promo_note, updated_by, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(branch_id) DO UPDATE SET
        school_subject_fees_json = excluded.school_subject_fees_json,
        course_overrides_json = excluded.course_overrides_json,
        bundle_overrides_json = excluded.bundle_overrides_json,
        duration_discounts_json = excluded.duration_discounts_json,
        disabled_course_ids_json = excluded.disabled_course_ids_json,
        promo_note = excluded.promo_note,
        updated_by = excluded.updated_by,
        updated_at = excluded.updated_at`
    ).run(
      branchId,
      JSON.stringify(req.body?.schoolSubjectFees || {}),
      JSON.stringify(req.body?.courseOverrides || {}),
      JSON.stringify(req.body?.bundleOverrides || {}),
      JSON.stringify(req.body?.durationDiscounts || {}),
      JSON.stringify(Array.isArray(req.body?.disabledCourseIds) ? req.body.disabledCourseIds.map(Number) : []),
      cleanStr(req.body?.promoNote || "", 200),
      user.id,
      now
    );
    const after = getBranchPricingOverlay(db, branchId);
    logPricingAudit(db, { actorId: user.id, actorName: user.full_name, entityType: "branch_pricing", entityId: String(branchId), action: "update", before, after });
    return res.json({ ok: true, overlay: after });
  });

  // Bundles CRUD
  router.post("/admin/bundles", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const name = cleanStr(req.body?.name, 120);
    if (name.length < 2) return res.status(400).json({ error: "Bundle name is required." });
    const code = cleanStr(req.body?.code || `BND-${crypto.randomInt(1000, 9999)}`, 40).toUpperCase();
    const subjects = Array.isArray(req.body?.subjects) ? req.body.subjects : String(req.body?.subjects || "").split(",").map((s) => s.trim()).filter(Boolean);
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO v33_bundles (
          code, name, category, class_level, subjects_json, base_monthly_price, custom_price,
          discount_percent, promo_enabled, promo_price, description, is_active, show_on_frontend, priority, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        code, name, cleanStr(req.body?.category || "School", 60), cleanStr(req.body?.classLevel || "All", 60),
        JSON.stringify(subjects), Math.max(0, Math.round(Number(req.body?.baseMonthlyPrice || 0))),
        Math.max(0, Math.round(Number(req.body?.customPrice || 0))),
        Math.min(60, Math.max(0, Number(req.body?.discountPercent ?? 15))),
        req.body?.promoEnabled ? 1 : 0, Math.max(0, Math.round(Number(req.body?.promoPrice || 0))),
        cleanStr(req.body?.description || "", 400), req.body?.isActive !== false ? 1 : 0,
        req.body?.showOnFrontend !== false ? 1 : 0, Math.round(Number(req.body?.priority || 50)), now, now
      );
    const id = Number(ins.lastInsertRowid);
    logPricingAudit(db, { actorId: user.id, actorName: user.full_name, entityType: "bundle", entityId: String(id), action: "create", after: { code, name } });
    return res.status(201).json({ ok: true, id, bundle: db.prepare("SELECT * FROM v33_bundles WHERE id = ?").get(id) });
  });

  router.put("/admin/bundles/:id", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const id = Number(req.params.id);
    const before = db.prepare("SELECT * FROM v33_bundles WHERE id = ?").get(id);
    if (!before) return res.status(404).json({ error: "Bundle not found." });
    const subjects = req.body?.subjects !== undefined
      ? (Array.isArray(req.body.subjects) ? req.body.subjects : String(req.body.subjects).split(",").map((s) => s.trim()).filter(Boolean))
      : parseJson(before.subjects_json, []);
    db.prepare(
      `UPDATE v33_bundles SET
        name = ?, category = ?, class_level = ?, subjects_json = ?, base_monthly_price = ?,
        custom_price = ?, discount_percent = ?, promo_enabled = ?, promo_price = ?,
        description = ?, is_active = ?, show_on_frontend = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      cleanStr(req.body?.name ?? before.name, 120),
      cleanStr(req.body?.category ?? before.category, 60),
      cleanStr(req.body?.classLevel ?? before.class_level, 60),
      JSON.stringify(subjects),
      req.body?.baseMonthlyPrice !== undefined ? Math.max(0, Math.round(Number(req.body.baseMonthlyPrice))) : before.base_monthly_price,
      req.body?.customPrice !== undefined ? Math.max(0, Math.round(Number(req.body.customPrice))) : before.custom_price,
      req.body?.discountPercent !== undefined ? Math.min(60, Math.max(0, Number(req.body.discountPercent))) : before.discount_percent,
      req.body?.promoEnabled !== undefined ? (req.body.promoEnabled ? 1 : 0) : before.promo_enabled,
      req.body?.promoPrice !== undefined ? Math.max(0, Math.round(Number(req.body.promoPrice))) : before.promo_price,
      cleanStr(req.body?.description ?? before.description, 400),
      req.body?.isActive !== undefined ? (req.body.isActive ? 1 : 0) : before.is_active,
      req.body?.showOnFrontend !== undefined ? (req.body.showOnFrontend ? 1 : 0) : before.show_on_frontend,
      nowIso(),
      id
    );
    return res.json({ ok: true, bundle: db.prepare("SELECT * FROM v33_bundles WHERE id = ?").get(id) });
  });

  router.delete("/admin/bundles/:id", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    db.prepare("DELETE FROM v33_bundles WHERE id = ?").run(Number(req.params.id));
    return res.json({ ok: true });
  });

  // Scholarships CRUD
  router.post("/admin/scholarships", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const name = cleanStr(req.body?.name, 120);
    const code = cleanStr(req.body?.code || `SCH-${crypto.randomInt(1000, 9999)}`, 40).toUpperCase();
    if (!name) return res.status(400).json({ error: "Scholarship name is required." });
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO v33_scholarships (
          code, name, scholarship_type, discount_type, discount_value, eligibility,
          valid_from, valid_until, branch_ids_json, max_uses, priority, is_active, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        code, name, cleanStr(req.body?.scholarshipType || req.body?.category || "merit", 40),
        req.body?.discountType === "fixed" ? "fixed" : "percent",
        Math.max(1, Number(req.body?.discountValue || 10)),
        cleanStr(req.body?.eligibility || "", 260),
        cleanStr(req.body?.validFrom || "", 20),
        cleanStr(req.body?.validUntil || "", 20),
        JSON.stringify(Array.isArray(req.body?.branchIds) ? req.body.branchIds.map(Number) : []),
        Math.max(1, Math.round(Number(req.body?.maxUses || 500))),
        Math.round(Number(req.body?.priority || 50)),
        req.body?.isActive !== false ? 1 : 0,
        now, now
      );
    return res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid) });
  });

  router.put("/admin/scholarships/:id", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const id = Number(req.params.id);
    const b = db.prepare("SELECT * FROM v33_scholarships WHERE id = ?").get(id);
    if (!b) return res.status(404).json({ error: "Scholarship not found." });
    db.prepare(
      `UPDATE v33_scholarships SET name = ?, scholarship_type = ?, discount_type = ?, discount_value = ?, eligibility = ?, valid_until = ?, max_uses = ?, priority = ?, is_active = ?, updated_at = ? WHERE id = ?`
    ).run(
      cleanStr(req.body?.name ?? b.name, 120),
      cleanStr(req.body?.scholarshipType ?? req.body?.category ?? b.scholarship_type, 40),
      req.body?.discountType === "fixed" ? "fixed" : req.body?.discountType === "percent" ? "percent" : b.discount_type,
      req.body?.discountValue !== undefined ? Number(req.body.discountValue) : b.discount_value,
      cleanStr(req.body?.eligibility ?? b.eligibility, 260),
      cleanStr(req.body?.validUntil ?? b.valid_until, 20),
      req.body?.maxUses !== undefined ? Number(req.body.maxUses) : b.max_uses,
      req.body?.priority !== undefined ? Number(req.body.priority) : b.priority,
      req.body?.isActive !== undefined ? (req.body.isActive ? 1 : 0) : b.is_active,
      nowIso(),
      id
    );
    return res.json({ ok: true });
  });

  // Limited-Time Promotional Offers (with countdown support)
  router.post("/admin/promo-offers", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const title = cleanStr(req.body?.title, 120);
    const code = cleanStr(req.body?.code || `FLASH${crypto.randomInt(100, 999)}`, 40).toUpperCase();
    const startAt = cleanStr(req.body?.startAt || nowIso(), 40);
    const endAt = cleanStr(req.body?.endAt || new Date(Date.now() + 48 * 3600000).toISOString(), 40);
    if (!title) return res.status(400).json({ error: "Offer title is required." });
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO v33_promo_offers (
          code, title, offer_type, discount_type, discount_value, start_at, end_at,
          branch_ids_json, max_uses, is_active, banner_text, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        code, title, cleanStr(req.body?.offerType || "flash_sale", 40),
        req.body?.discountType === "fixed" ? "fixed" : "percent",
        Math.max(1, Number(req.body?.discountValue || 10)),
        startAt, endAt,
        JSON.stringify(Array.isArray(req.body?.branchIds) ? req.body.branchIds.map(Number) : []),
        Math.max(1, Math.round(Number(req.body?.maxUses || 500))),
        req.body?.isActive !== false ? 1 : 0,
        cleanStr(req.body?.bannerText || `${title} — Limited Time!`, 200),
        now, now
      );
    return res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid) });
  });

  router.put("/admin/promo-offers/:id", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const id = Number(req.params.id);
    const b = db.prepare("SELECT * FROM v33_promo_offers WHERE id = ?").get(id);
    if (!b) return res.status(404).json({ error: "Offer not found." });
    db.prepare(
      `UPDATE v33_promo_offers SET title = ?, discount_value = ?, end_at = ?, is_active = ?, updated_at = ? WHERE id = ?`
    ).run(
      cleanStr(req.body?.title ?? b.title, 120),
      req.body?.discountValue !== undefined ? Number(req.body.discountValue) : b.discount_value,
      cleanStr(req.body?.endAt ?? b.end_at, 40),
      req.body?.isActive !== undefined ? (req.body.isActive ? 1 : 0) : b.is_active,
      nowIso(),
      id
    );
    return res.json({ ok: true });
  });

  // Add-On Products CRUD
  router.post("/admin/addons", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const title = cleanStr(req.body?.title, 120);
    if (!title) return res.status(400).json({ error: "Add-on title is required." });
    const code = cleanStr(req.body?.code || `ADD-${crypto.randomInt(1000, 9999)}`, 40).toUpperCase();
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO v33_addons (code, title, category, price, promo_price, description, class_range, is_active, show_on_frontend, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1, ?, ?)`
      )
      .run(
        code, title, cleanStr(req.body?.category || "Test Series", 60),
        Math.max(1, Math.round(Number(req.body?.price || 299))),
        Math.max(0, Math.round(Number(req.body?.promoPrice || 0))),
        cleanStr(req.body?.description || "", 300),
        cleanStr(req.body?.classRange || "All", 40),
        now, now
      );
    return res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid) });
  });

  router.put("/admin/addons/:id", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const id = Number(req.params.id);
    const b = db.prepare("SELECT * FROM v33_addons WHERE id = ?").get(id);
    if (!b) return res.status(404).json({ error: "Add-on not found." });
    db.prepare(
      `UPDATE v33_addons SET title = ?, category = ?, price = ?, promo_price = ?, description = ?, is_active = ?, updated_at = ? WHERE id = ?`
    ).run(
      cleanStr(req.body?.title ?? b.title, 120),
      cleanStr(req.body?.category ?? b.category, 60),
      req.body?.price !== undefined ? Math.max(1, Math.round(Number(req.body.price))) : b.price,
      req.body?.promoPrice !== undefined ? Math.max(0, Math.round(Number(req.body.promoPrice))) : b.promo_price,
      cleanStr(req.body?.description ?? b.description, 300),
      req.body?.isActive !== undefined ? (req.body.isActive ? 1 : 0) : b.is_active,
      nowIso(),
      id
    );
    return res.json({ ok: true });
  });

  // Cross-Sell Rules CRUD
  router.post("/admin/cross-sell-rules", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const ruleType = cleanStr(req.body?.ruleType || "subject", 30);
    const triggerValue = cleanStr(req.body?.triggerValue, 80);
    const items = Array.isArray(req.body?.recommendedItems)
      ? req.body.recommendedItems
      : String(req.body?.recommendedItems || "").split(",").map((s) => s.trim()).filter(Boolean);
    if (!triggerValue || !items.length) return res.status(400).json({ error: "Trigger value and recommended items are required." });
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO v33_cross_sell_rules (rule_type, trigger_value, recommended_items_json, category, branch_id, priority, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`
      )
      .run(
        ruleType, triggerValue, JSON.stringify(items),
        cleanStr(req.body?.category || "School Subjects", 60),
        req.body?.branchId ? Number(req.body.branchId) : null,
        Math.round(Number(req.body?.priority || 50)),
        now, now
      );
    return res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid) });
  });

  router.put("/admin/cross-sell-rules/:id", (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const id = Number(req.params.id);
    const b = db.prepare("SELECT * FROM v33_cross_sell_rules WHERE id = ?").get(id);
    if (!b) return res.status(404).json({ error: "Rule not found." });
    const items = req.body?.recommendedItems !== undefined
      ? (Array.isArray(req.body.recommendedItems) ? req.body.recommendedItems : String(req.body.recommendedItems).split(",").map((s) => s.trim()).filter(Boolean))
      : parseJson(b.recommended_items_json, []);
    db.prepare(
      `UPDATE v33_cross_sell_rules SET trigger_value = ?, recommended_items_json = ?, category = ?, priority = ?, is_active = ?, updated_at = ? WHERE id = ?`
    ).run(
      cleanStr(req.body?.triggerValue ?? b.trigger_value, 80),
      JSON.stringify(items),
      cleanStr(req.body?.category ?? b.category, 60),
      req.body?.priority !== undefined ? Number(req.body.priority) : b.priority,
      req.body?.isActive !== undefined ? (req.body.isActive ? 1 : 0) : b.is_active,
      nowIso(),
      id
    );
    return res.json({ ok: true });
  });

  /* ============================================================================
   * 8. MESSAGE PREVIEW & TEMPLATE MANAGEMENT (Panel Mail, One-Click Mail, WhatsApp, Invoice)
   * ========================================================================== */
  router.get("/admin/message-templates", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "communications")) {
      return res.status(403).json({ error: "Unauthorized." });
    }
    const templates = db.prepare("SELECT * FROM v31_mail_templates ORDER BY id ASC").all();
    return res.json({ ok: true, templates });
  });

  router.post("/admin/messages/preview", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "communications")) {
      return res.status(403).json({ error: "Unauthorized." });
    }
    const studentId = Number(req.body?.studentId || 0);
    const fin = studentId ? buildStudentFinancialSummary(db, studentId) : null;
    const tplKey = cleanStr(req.body?.templateKey || "", 80);
    let subject = String(req.body?.subject || "");
    let bodyHtml = String(req.body?.bodyHtml ?? req.body?.body ?? "");

    if (tplKey && (!subject || !bodyHtml)) {
      const tpl = db.prepare("SELECT subject, body_html FROM v31_mail_templates WHERE template_key = ? LIMIT 1").get(tplKey);
      if (tpl) {
        if (!subject) subject = tpl.subject;
        if (!bodyHtml) bodyHtml = tpl.body_html;
      }
    }

    const preview = renderMessagePreview({
      subject,
      bodyHtml,
      context: {
        studentName: fin?.student?.fullName || req.body?.studentName || "Student",
        course: fin?.invoices?.[0]?.course_title || fin?.student?.classLevel || "Course",
        branch: fin?.student?.branchName || "Muradnagar Branch",
        feeAmount: fin?.summary?.totalCourseFees ?? 0,
        pendingAmount: fin?.summary?.pendingAmount ?? 0,
        dueDate: fin?.summary?.dueDate || "-",
        rollNumber: fin?.student?.rollNumber || "-",
        phone: fin?.student?.phone || "",
      },
    });
    return res.json({ ok: true, preview });
  });

  router.post("/admin/messages/send", async (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "communications")) {
      return res.status(403).json({ error: "Unauthorized." });
    }
    const studentId = Number(req.body?.studentId || 0);
    const channel = cleanStr(req.body?.channel || "email", 24).toLowerCase();
    const scheduledAt = cleanStr(req.body?.scheduledAt || "", 40);
    const fin = buildStudentFinancialSummary(db, studentId);
    if (!fin) return res.status(404).json({ error: "Student not found." });

    const preview = renderMessagePreview({
      subject: req.body?.subject || "Update from Yuitor Smart Classes",
      bodyHtml: req.body?.bodyHtml ?? req.body?.body ?? "",
      context: {
        studentName: fin.student.fullName,
        course: fin.invoices?.[0]?.course_title || fin.student.classLevel || "Course",
        branch: fin.student.branchName,
        feeAmount: fin.summary.totalCourseFees,
        pendingAmount: fin.summary.pendingAmount,
        dueDate: fin.summary.dueDate,
        rollNumber: fin.student.rollNumber,
        phone: fin.student.phone,
      },
    });

    const now = nowIso();
    if (scheduledAt && scheduledAt > now) {
      const ins = db
        .prepare(
          `INSERT INTO v33_scheduled_messages (student_id, channel, template_key, subject, body_html, scheduled_at, status, created_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'scheduled', ?, ?)`
        )
        .run(studentId, channel, cleanStr(req.body?.templateKey || "v33_custom_message", 60), preview.subject, preview.html, scheduledAt, user.id, now);
      return res.status(201).json({ ok: true, scheduled: true, id: Number(ins.lastInsertRowid), preview });
    }

    // Instant dispatch
    let delivered = false;
    if (channel === "email" && fin.student.email && typeof sendTransactionalEmail === "function") {
      try {
        await sendTransactionalEmail({ to: fin.student.email, subject: preview.subject, html: preview.html });
        delivered = true;
      } catch {
        delivered = false;
      }
    }
    if (channel === "in_app" || channel === "email" || channel === "invoice") {
      db.prepare(
        `INSERT INTO notifications (user_id, role_target, title, message, is_read, status, deep_link, entity_type, entity_id, created_at)
         VALUES (?, 'student', ?, ?, 0, 'new', '#fees', 'message', ?, ?)`
      ).run(studentId, preview.subject.slice(0, 120), preview.plainText.slice(0, 500), String(studentId), now);
    }
    try {
      db.prepare(
        `INSERT INTO alert_dispatch_logs (channel, recipient_user_id, recipient_name, recipient_contact, category, message, status, provider_response, created_by, created_at)
         VALUES (?, ?, ?, ?, 'v33_template_send', ?, ?, ?, ?, ?)`
      ).run(channel, studentId, fin.student.fullName, channel === "whatsapp" ? fin.student.phone : fin.student.email, preview.plainText, delivered ? "sent" : "logged", preview.whatsappUrl || "", user.id, now);
    } catch {
      // ignore
    }

    return res.json({ ok: true, sent: true, delivered, preview });
  });

  /* ============================================================================
   * 9. ADMIN REVENUE & SALES ANALYTICS + CSV EXPORT + RENEWAL SWEEP + CRM LEAD UPGRADE
   * ========================================================================== */
  router.get("/admin/revenue-analytics", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "reports")) {
      return res.status(403).json({ error: "Admin or Report-authorized Staff access required." });
    }
    const analytics = buildRevenueAndSalesAnalytics(db, {
      fromDate: req.query?.fromDate || "",
      toDate: req.query?.toDate || "",
      branchId: req.query?.branchId || "",
      courseId: req.query?.courseId || "",
      subject: req.query?.subject || "",
    });
    const branches = db.prepare("SELECT id, name FROM branches ORDER BY id ASC").all();
    const courses = db.prepare("SELECT id, title FROM courses ORDER BY title ASC").all();
    return res.json({ ok: true, analytics, branches, courses });
  });

  router.get("/admin/revenue-analytics/csv", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "reports")) {
      return res.status(403).json({ error: "Unauthorized." });
    }
    const analytics = buildRevenueAndSalesAnalytics(db, {
      fromDate: req.query?.fromDate || "",
      toDate: req.query?.toDate || "",
      branchId: req.query?.branchId || "",
      courseId: req.query?.courseId || "",
      subject: req.query?.subject || "",
    });
    const csv = buildRevenueCsv(analytics);
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="yuitor-v33-revenue-report.csv"`);
    return res.send(csv);
  });

  router.post("/admin/renewals/run-sweep", async (req, res) => {
    const user = getUser(req);
    if (!isAdminUser(user)) return res.status(403).json({ error: "Admin access required." });
    const result = await runCourseRenewalV33Sweep(db, { sendTransactionalEmail });
    return res.json({ ok: true, result });
  });

  // CRM Lead Upgrade: Interested Subjects, Counselor Notes & Duplicate-Free Admission Conversion
  router.put("/admin/leads/:id/details", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "inquiries")) {
      return res.status(403).json({ error: "Unauthorized." });
    }
    const lid = Number(req.params.id);
    const lead = db.prepare("SELECT * FROM inquiries WHERE id = ?").get(lid);
    if (!lead) return res.status(404).json({ error: "Lead not found." });

    const subjects = Array.isArray(req.body?.interestedSubjects)
      ? req.body.interestedSubjects
      : String(req.body?.interestedSubjects || "").split(",").map((s) => s.trim()).filter(Boolean);
    db.prepare(
      `UPDATE inquiries SET
        source = ?, status = ?, class_or_course = ?, interested_subjects_json = ?,
        counselor_notes = ?, follow_up_date = ?, assigned_staff = ?, last_contacted_at = ?
       WHERE id = ?`
    ).run(
      cleanStr(req.body?.source ?? lead.source, 60),
      cleanStr(req.body?.status ?? lead.status, 30),
      cleanStr(req.body?.classOrCourse ?? lead.class_or_course, 100),
      JSON.stringify(subjects),
      cleanStr(req.body?.counselorNotes ?? lead.counselor_notes, 800),
      cleanStr(req.body?.followUpDate ?? lead.follow_up_date, 20),
      cleanStr(req.body?.assignedStaff ?? lead.assigned_staff, 80),
      nowIso(),
      lid
    );
    return res.json({ ok: true, lead: db.prepare("SELECT * FROM inquiries WHERE id = ?").get(lid) });
  });

  router.post("/admin/leads/:id/convert", (req, res) => {
    const user = getUser(req);
    if (!isAuthorizedStaffOrAdmin(db, user, "inquiries")) {
      return res.status(403).json({ error: "Unauthorized." });
    }
    const lid = Number(req.params.id);
    const lead = db.prepare("SELECT * FROM inquiries WHERE id = ?").get(lid);
    if (!lead) return res.status(404).json({ error: "Lead not found." });

    const phone = cleanPhone(lead.phone);
    const email = cleanStr(lead.email || `lead.${phone || lid}@yuitor.local`, 120).toLowerCase();
    const now = nowIso();

    // Prevent duplicate student accounts!
    let student = phone ? db.prepare("SELECT * FROM users WHERE phone = ? LIMIT 1").get(phone) : null;
    if (!student && lead.email) {
      student = db.prepare("SELECT * FROM users WHERE LOWER(email) = ? LIMIT 1").get(email);
    }

    let createdNew = false;
    if (!student) {
      const hash = bcrypt.hashSync(crypto.randomBytes(18).toString("hex"), 10);
      const uid = insertStudentUserSafe({
        fullName: lead.name || "New Student",
        email,
        phone,
        passwordHash: hash,
        branchId: lead.branch_id || null,
        mobileVerified: 0,
        now,
      });
      const roll = `YTR-${new Date().getFullYear()}-${String(uid).padStart(4, "0")}`;
      try {
        db.prepare(
          `INSERT OR IGNORE INTO student_profiles (user_id, class_level, subjects_json, admission_date, enrollment_status, roll_number, branch_id)
           VALUES (?, ?, ?, ?, 'active', ?, ?)`
        ).run(uid, lead.class_or_course || "", lead.interested_subjects_json || "[]", now.slice(0, 10), roll, lead.branch_id || null);
      } catch {
        // ignore
      }
      student = db.prepare("SELECT * FROM users WHERE id = ?").get(uid);
      createdNew = true;
    }

    db.prepare("UPDATE inquiries SET status = 'admitted', converted_student_id = ?, last_contacted_at = ? WHERE id = ?").run(student.id, now, lid);
    return res.status(createdNew ? 201 : 200).json({
      ok: true,
      leadId: lid,
      studentId: student.id,
      createdNew,
      alreadyExisted: !createdNew,
      message: createdNew
        ? `Lead converted and new student account #${student.id} created.`
        : `Lead linked to existing student account #${student.id} (no duplicate created).`,
    });
  });

  return router;
}
