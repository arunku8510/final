# Deployment & Hardening Guide — Yuitor Smart Classes

Short production checklist for **Shared Hosting (cPanel Node.js Selector)** and **VPS (Ubuntu + Nginx + PM2)**.

---

## 1. Environment Variables (`.env`)

Copy `.env.example` to `.env` in the application root (NEVER inside `public/`) and generate strong random secrets:

```bash
cp .env.example .env
chmod 600 .env
```

Generate secrets with Node.js:

```bash
node -e "console.log('SESSION_SECRET=' + require('crypto').randomBytes(32).toString('hex'))"
node -e "console.log('ADMIN_PATH=g-' + require('crypto').randomBytes(16).toString('hex'))"
node -e "console.log('YU_ADMIN_SETUP_KEY=' + require('crypto').randomBytes(24).toString('hex'))"
```

Required production values in `.env`:
- `NODE_ENV=production`
- `APP_URL=https://yuitor.com`
- `TRUST_PROXY=1` (behind Nginx/Apache/cPanel proxy) — or `false` if Node listens directly without a proxy
- `SESSION_SECRET` (>= 64 hex chars)
- `ADMIN_PATH` (random 34+ char slug; never commit or log)
- `YU_ADMIN_SETUP_KEY` (>= 16 chars; required ONLY for first-time Super Admin creation, remove after setup)
- `OWNER_EMAIL` (owner email that receives first-time Installer OTP; never passed via browser form)
- `YU_ADMIN_SETUP_EXPIRES_AT` (optional ISO UTC deadline for initial setup window, e.g. `2026-12-31T23:59:59Z`)
- `ADMIN_OTP_EMAIL` (2FA email for Admin logins)
- `ADMIN_IP_ALLOWLIST` (optional comma-separated static admin IPs)
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM_EMAIL`
- `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`
- `GEMINI_API_KEY` (optional, server-side only)

---

## 2. File & Directory Permissions (Critical)

Run inside the application root on Linux (both VPS and cPanel SSH):

```bash
# Private runtime directories: owner read/write/execute only (0700)
mkdir -p data backups logs uploads/resumes uploads/knowledge tmp
chmod 700 data backups logs uploads/resumes uploads/knowledge tmp

# Sensitive files: owner read/write only (0600)
chmod 600 .env
[ -f data/yuitor.db ] && chmod 600 data/yuitor.db
[ -f data/.vault.key ] && chmod 600 data/.vault.key
find backups -type f -exec chmod 600 {} + 2>/dev/null || true

# Do NOT leave release ZIPs or backup_original/ in production public/
rm -f public/*.zip
rm -rf backup_original
```

`server.js` also applies `chmod 0700` / `0600` automatically on boot (best-effort).

---

## 3. Shared Hosting (cPanel — Setup Node.js App)

1. Upload and extract the release ZIP into your app folder (e.g. `/home/<user>/yuitor`, **NOT** inside `public_html/`).
2. In **cPanel → Setup Node.js App**:
   - **Node.js Version**: `22.x` (required for built-in `node:sqlite`)
   - **Application Mode**: `Production`
   - **Application Root**: `yuitor`
   - **Application Startup File**: `app.cjs` (or `server.js`)
3. Set `TRUST_PROXY=1` in `.env` (Apache/LiteSpeed sits in front of Passenger).
4. Ensure `.env`, `data/`, `backups/`, `logs/`, and `uploads/resumes/` remain outside `public_html` (and keep `htaccess.example` rules denying direct access to `.env`, `.db`, `.sqlite`, `.log`).
5. Click **Restart App** and run first-time Super Admin setup once using `YU_ADMIN_SETUP_KEY` + OTP sent to `OWNER_EMAIL`. Installer locks permanently (`HTTP 410`) immediately after first admin creation.

---

## 4. VPS Deployment (Ubuntu + Nginx + PM2)

```bash
# 1. Install Node.js 22 LTS + PM2 + optional ClamAV
sudo apt-get update && sudo apt-get install -y nginx clamav clamav-daemon
sudo npm install -g pm2

# 2. Extract app to /var/www/yuitor (owned by dedicated non-root user)
sudo useradd -r -s /bin/false yuitor || true
sudo chown -R yuitor:yuitor /var/www/yuitor
cd /var/www/yuitor
npm ci --omit=dev

# 3. Apply strict permissions (Section 2 above), configure .env with TRUST_PROXY=1
# 4. Bind Node to localhost via PM2
pm2 start server.js --name yuitor-smart-classes --env production
pm2 save && pm2 startup
```

Minimal **Nginx** reverse proxy (`/etc/nginx/sites-available/yuitor.conf`):

```nginx
server {
    listen 443 ssl http2;
    server_name yuitor.com www.yuitor.com;

    # TLS managed by Certbot (Let's Encrypt)
    client_max_body_size 10M;

    # Block sensitive dotfiles/paths at edge as defense-in-depth
    location ~ /\.(?!well-known) { return 404; }
    location ~ ^/(data|backups|logs|server|scripts|backup_original|database)/ { return 404; }

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Reload Nginx & verify HTTPS:
```bash
sudo nginx -t && sudo systemctl reload nginx
```

---

## 5. Post-Deploy Verification

1. Run `node scripts/security-smoke-test.mjs` against `http://127.0.0.1:3000` (or staging URL).
2. Confirm `https://yuitor.com/.env`, `https://yuitor.com/data/yuitor.db`, and `https://yuitor.com/backups/` all return `404`.
3. Configure Razorpay Webhook URL `https://yuitor.com/api/payments/webhook` with `RAZORPAY_WEBHOOK_SECRET` matching `.env`.
4. Set up automated daily off-server encrypted backups of `data/yuitor.db` (outside web root).

---

## 6. Fixing "Miscellaneous / Unknown Source / Blocked" on School, Office & Mobile Networks

The application code now includes explicit `text/html; charset=utf-8` & Apache MIME `AddType` declarations, ES2020 browser compatibility, `/.well-known/security.txt`, Education classification metadata, mobile WebView CSRF fallback (`Origin: null` + `X-CSRF-Token`), and HTTPS-only HSTS/COOP headers.

If a specific college/office Wi-Fi or ISP firewall still blocks your live domain (`yuitor.com`) as **"Miscellaneous / Uncategorized / Unknown Source"**, complete this 1-time hosting/DNS checklist:
1. **Valid Full-Chain SSL Certificate:** Ensure Let's Encrypt / AutoSSL serves the complete intermediate certificate chain (verify at `https://www.ssllabs.com/ssltest/`).
2. **Domain Web-Filter Categorization (Free, 1-time):** Submit `https://yuitor.com` under category **Education** on:
   - FortiGuard Web Filter (`fortiguard.com/faq/wfratingsubmit`)
   - Palo Alto URL Filtering (`urlfiltering.paloaltonetworks.com`)
   - Cisco Talos (`talosintelligence.com`)
   - Google Search Console (`search.google.com/search-console`) to confirm zero Safe Browsing flags.
3. **DNS Auth Records:** Configure `SPF`, `DKIM`, and `DMARC` TXT records for `yuitor.com` so OTP emails land in Inbox (not Spam) and domain reputation stays clean.
4. **Behind Cloudflare / LiteSpeed / Nginx:** Set `TRUST_PROXY=1` in `.env` (and optionally `DISABLE_APP_GZIP=1` if your reverse proxy already compresses responses).

