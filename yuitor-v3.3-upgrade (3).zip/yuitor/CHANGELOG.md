# Changelog — Yuitor Smart Institute CRM

## v2.5.0 — Complete Coaching Automation, Smart Admin Panel & Hybrid Operations
**Upgrade Strategy:** Additive, backward-compatible upgrade built directly inside the existing Yuitor Smart Classes codebase. Zero existing records, tables, or working routes were deleted or replaced.

### Database & Migrations
- Added safe additive migration `database/migrations/003_crm_v25_automation.sql` and runtime schema manager `server/crm-db.mjs`:
  - Automation engine tables: `crm_automation_config`, `crm_automation_rules`, `crm_automation_events`, `crm_job_queue`, `crm_scheduler_runs`, `crm_exception_inbox`, `crm_message_consent`.
  - Operations & academic tables: `crm_lead_activities`, `crm_counsellor_tasks`, `crm_financial_approvals`, `crm_payment_reconciliations`, `crm_study_materials`, `crm_doubts`, `crm_live_class_joins`, `crm_student_risk_scores`, `crm_daily_reports`, `crm_marketing_campaigns`, `crm_batch_waitlist`, `crm_document_checklists`, `crm_counsellor_incentives`.
  - Additive columns on existing tables (`batches.delivery_mode`, `inquiries` scoring/UTM/SLA fields, `timetable_slots` live links & substitute teacher, `quizzes`/`quiz_attempts` competitive CBT marking & percentile fields, `lessons`/`lesson_progress` video watch progress, `teacher_profiles` payroll fields, `student_profiles` soft-lock exemption & parent consent).

### Smart Automation Engine & IST Scheduler
- Implemented `server/crm-engine.mjs`: Event Bus (11 standard coaching events), versioned IF/THEN Rule Engine with ON/OFF switches & dry-run testing, idempotent Job Queue with 3x retry + Exception Inbox dead-letter escalation, IST quiet hours (`21:00–08:00`), daily 3-message student cap, global kill switch, opt-in/opt-out (`STOP`), and `WhatsApp -> SMS -> Email -> Staff Call Task` fallback chain.
- Implemented `server/crm-scheduler.mjs` + integrated into single `* * * * *` cron entry `scripts/run-scheduled.mjs` (`Asia/Kolkata` timezone, non-overlapping locks, execution heartbeat logs, failure alerts): 1m queue/SLA, 5m payment reconciliation, 15m class/doubt SLA, 06:30 timetable validation, 08:00 fee reminders, 20:00 & 21:30 Founder/Owner reports, 23:30 cleanup, 02:00 auto DB backup, 03:00 dropout-risk calculation, Mon 08:00 weekly report, Day-1 monthly fee generation, Day-25 payroll drafts, Day-28 course renewal campaign.

### Offline & Online Coaching ERP Modules
- **Smart Admin Dashboard (`public/assets/crm-v25.js`, `crm-v25.css`)**: Today's Desk (6 1-click daily actions), Live KPI Alerts (4 clickable counters), Founder's Daily Digest card, and global `Ctrl + K` Quick Command Bar with instant student actions (*Collect Fee*, *WhatsApp Reminder*, *Mark Present/Absent*, *ID Card QR*, *Print Receipt*, *Change Batch*).
- **Quick Fee Collection Desk**: Fast roll/phone lookup, Cash/UPI/Cheque/Online recording with idempotency protection, instant PDF Receipt + `wa.me` share, 1-click idempotent Monthly Fee Generation, Financial Approvals workflow, and optional Fee Defaulter Soft Lock.
- **Inquiry & Admission CRM**: Duplicate phone check, 0–100 lead scoring, Today's Follow-ups filter, Demo booking, 1-click `wa.me` follow-up, and 1-click Convert Inquiry to Student (reusing existing fields + batch capacity waitlist + document checklist).
- **Printable Branded PDFs (`server/crm-pdf.mjs`)**: Official Yuitor logo + scannable QR SVG for Student ID Cards, Fee Receipts, Admit Cards, and Monthly Progress Report Cards (both Print Sheet and downloadable binary `%PDF-1.4`).
- **Online Coaching Hub**: Hybrid/Online/Offline batch modes, Live Class Launcher (Google Meet / Zoom / YouTube Unlisted) with Timetable Clash Detection, Substitute Teacher assignment, verified active-session online attendance (heartbeat), Competitive CBT Exam Engine (`+4/-1`, live timer, Question Palette, instant rank/percentile, weak-topic `<40%` auto-remediation), Batch-Locked DPP & Notes Locker, and Student Doubt Counter with 12-hour teacher SLA.
- **Bulk Operations, Staff & BI**: CSV preview/validation/duplicate check + commit, accounting-ready CSV exports, checkbox bulk student actions, 1-click Staff Role Permission Templates (Receptionist, Fee Clerk, Academic Coordinator), Teacher Payroll Draft Calculator, Dropout-Risk Monitor, and Marketing CPA tracker.

### External API Configuration Notes (Optional Paid Integrations)
- **Automated Meta WhatsApp Business API**: Set `WHATSAPP_ACCESS_TOKEN` & `WHATSAPP_PHONE_NUMBER_ID` in Admin -> Settings -> API (1-click manual `wa.me` click-to-chat works immediately at ₹0 cost).
- **DLT SMS**: Set `FAST2SMS_API_KEY`, `FAST2SMS_ROUTE=dlt`, `FAST2SMS_SENDER_ID`, `FAST2SMS_DLT_TEMPLATE_ID`.
- **Razorpay Online Checkout & Webhooks**: Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`.
- **Server Cron**: Add one cron entry `* * * * * cd /path/to/yuitor && npm run cron >> logs/cron.log 2>&1` (in-process scheduler also runs automatically when Node stays up).
