(() => {
  "use strict";

  if (window.YuitorV32) return;

  const esc = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const inr = (n) => `₹${Number(n || 0).toLocaleString("en-IN")}`;

  const ADMIN_GATE =
    window.__YU_ADMIN_GATE__ && typeof window.__YU_ADMIN_GATE__ === "object" ? window.__YU_ADMIN_GATE__ : null;
  const ADMIN_API_BASE = ADMIN_GATE?.apiBase ? String(ADMIN_GATE.apiBase).replace(/\/+$/, "") : "";
  const adminApiUrl = (suffix) => `${ADMIN_API_BASE}${String(suffix || "").startsWith("/") ? suffix : "/" + suffix}`;

  function readCsrfCookie() {
    const m = document.cookie.match(/(?:^|;\s*)(?:yu_csrf|yuitor_csrf)=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : "";
  }

  async function reqJson(url, opts = {}) {
    const method = String(opts.method || "GET").toUpperCase();
    const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
    if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
      const csrf = readCsrfCookie();
      if (csrf && !headers["X-CSRF-Token"]) headers["X-CSRF-Token"] = csrf;
    }
    const res = await fetch(url, {
      credentials: "same-origin",
      ...opts,
      headers,
      body: opts.body && typeof opts.body !== "string" ? JSON.stringify(opts.body) : opts.body,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  }

  /* ==========================================================================
   * 1. SCOPED STYLES (For Portals, Modals, PWA & Shreya AI Interactive Tabs)
   *    Zero overrides to the original public website look!
   * ======================================================================== */
  function injectStyles() {
    if (document.getElementById("yu-v32-styles")) return;
    const style = document.createElement("style");
    style.id = "yu-v32-styles";
    style.textContent = `
      .yu32-ai-panel{padding:10px;background:#FAF7F5;font-family:'Plus Jakarta Sans','Inter',system-ui,sans-serif;color:#111827;font-size:12.5px;box-sizing:border-box}
      .yu32-ai-panel *,.yu32-modal *{box-sizing:border-box}
      .yu32-cycles{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:10px;align-items:center}
      .yu32-cycle-btn{border:1px solid #D6C7C2;background:#fff;color:#1F2937;padding:5px 9px;border-radius:7px;font-size:11.5px;font-weight:700;cursor:pointer;transition:all .15s ease}
      .yu32-cycle-btn:hover{border-color:#7A0F28;color:#7A0F28}
      .yu32-cycle-btn.is-active{background:#7A0F28;border-color:#7A0F28;color:#fff}
      .yu32-save-tag{background:#FDE68A;color:#78350F;font-size:10px;font-weight:800;padding:1px 5px;border-radius:4px;margin-left:4px}
      .yu32-banner{background:#FFF8EB;border:1px solid #E6B450;border-left:3px solid #7A0F28;border-radius:8px;padding:8px 10px;margin-bottom:10px;font-size:11.5px;color:#3F2212;line-height:1.4}
      .yu32-ai-list{display:flex;flex-direction:column;gap:10px}
      .yu32-card{background:#fff;border:1px solid #E5DCD7;border-radius:10px;padding:11px;display:flex;flex-direction:column;gap:6px;box-shadow:0 2px 8px rgba(15,23,42,.04)}
      .yu32-card-top{display:flex;justify-content:space-between;align-items:center;gap:8px}
      .yu32-cls-title{font-family:'Playfair Display',Georgia,serif;font-size:16px;font-weight:700;color:#111827;margin:0}
      .yu32-seat-note{font-size:10.5px;font-weight:700;color:#9A3412;background:#FFEDD5;padding:2px 7px;border-radius:5px;white-space:nowrap}
      .yu32-seat-note.is-full{background:#FEE2E2;color:#991B1B}
      .yu32-price-row{display:flex;align-items:baseline;gap:6px}
      .yu32-price{font-size:20px;font-weight:800;color:#7A0F28;font-variant-numeric:tabular-nums}
      .yu32-strike{font-size:12px;color:#9CA3AF;text-decoration:line-through;font-variant-numeric:tabular-nums}
      .yu32-price-meta{font-size:11.5px;color:#4B5563}
      .yu32-saved{color:#15803D;font-weight:700}
      .yu32-batch-select{width:100%;padding:6px 8px;border:1px solid #D1D5DB;border-radius:7px;font-size:11.5px;background:#F9FAFB;color:#111827}
      .yu32-btn{display:inline-flex;align-items:center;justify-content:center;gap:5px;background:#7A0F28;color:#fff;border:1px solid #7A0F28;border-radius:8px;padding:8px 12px;font-size:12.5px;font-weight:700;cursor:pointer;text-decoration:none;transition:background .15s ease}
      .yu32-btn:hover{background:#5E0B1E}
      .yu32-btn:disabled{opacity:.55;cursor:not-allowed}
      .yu32-btn--ghost{background:#fff;color:#7A0F28;border:1px solid #7A0F28}
      .yu32-btn--ghost:hover{background:#FDF2F4}
      .yu32-btn--sm{padding:6px 10px;font-size:11.5px}
      .yu32-quiz-bar{display:flex;justify-content:space-between;align-items:center;gap:8px;border-bottom:1px solid #ECE2DD;padding-bottom:8px;margin-bottom:10px}
      .yu32-timer{font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:700;padding:4px 9px;border-radius:7px;background:#FEF2F2;color:#7A0F28;border:1px solid #FECACA}
      .yu32-q-item{border:1px solid #ECE2DD;border-radius:9px;padding:9px 10px;margin-bottom:8px;background:#fff}
      .yu32-q-title{font-weight:700;font-size:12.5px;margin:0 0 7px;color:#111827;line-height:1.35}
      .yu32-q-opts{display:grid;grid-template-columns:1fr 1fr;gap:5px}
      .yu32-q-opt{display:flex;align-items:center;gap:6px;padding:6px 7px;border:1px solid #D6D3D1;border-radius:7px;background:#FAF7F5;cursor:pointer;font-size:11.5px}
      .yu32-q-opt:hover{border-color:#7A0F28}
      .yu32-q-opt input{accent-color:#7A0F28;margin:0}
      .yu32-result-box{background:#F0FDF4;border:1px solid #86EFAC;border-radius:10px;padding:12px;margin-top:8px}
      .yu32-tag-free{font-size:10px;font-weight:800;color:#166534;background:#DCFCE7;padding:2px 6px;border-radius:4px;display:inline-block}
      .yu32-tag-lock{font-size:10px;font-weight:800;color:#92400E;background:#FEF3C7;padding:2px 6px;border-radius:4px;display:inline-block}
      /* Portal Live Notice Banner */
      .yu32-notice-bar{background:#7A0F28;color:#fff;padding:10px 18px;font-size:13.5px;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;border-bottom:2px solid #E6B450;font-family:'Plus Jakarta Sans','Inter',system-ui,sans-serif}
      .yu32-notice-bar a{color:#FDE68A;font-weight:700;text-decoration:underline}
      .yu32-notice-cls{background:#E6B450;color:#3B0712;font-size:11px;font-weight:800;padding:2px 7px;border-radius:4px;margin-right:8px;text-transform:uppercase}
      /* Docked Floating Controls (Bottom-Left: PWA Install + Portal Tools) */
      .yu32-dock{position:fixed;left:16px;bottom:16px;z-index:9990;display:flex;flex-direction:column;gap:8px;align-items:flex-start}
      .yu32-dock-btn{background:#111827;color:#fff;border:1px solid rgba(255,255,255,.16);border-radius:10px;padding:9px 14px;font-size:12.5px;font-weight:700;cursor:pointer;box-shadow:0 8px 24px rgba(15,23,42,.22);display:inline-flex;align-items:center;gap:7px;font-family:'Plus Jakarta Sans','Inter',system-ui,sans-serif}
      .yu32-dock-btn--brand{background:#7A0F28;border-color:#E6B450}
      .yu32-dock-btn:hover{filter:brightness(1.08)}
      /* Modal */
      .yu32-modal-backdrop{position:fixed;inset:0;background:rgba(15,23,42,.62);z-index:10050;display:flex;align-items:center;justify-content:center;padding:16px}
      .yu32-modal-backdrop[hidden]{display:none}
      .yu32-modal{background:#fff;color:#111827;width:min(960px,100%);max-height:90vh;overflow:auto;border-radius:14px;box-shadow:0 24px 60px rgba(0,0,0,.35);font-family:'Plus Jakarta Sans','Inter',system-ui,sans-serif}
      .yu32-modal-hdr{display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid #E5E7EB;position:sticky;top:0;background:#fff;z-index:2}
      .yu32-modal-body{padding:18px 20px}
      .yu32-tabs{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px;border-bottom:1px solid #E5E7EB;padding-bottom:10px}
      .yu32-tab{border:1px solid #D1D5DB;background:#F9FAFB;color:#374151;padding:7px 12px;border-radius:8px;font-size:12.5px;font-weight:700;cursor:pointer}
      .yu32-tab.is-active{background:#7A0F28;border-color:#7A0F28;color:#fff}
      .yu32-table-wrap{overflow-x:auto;border:1px solid #E5E7EB;border-radius:10px}
      .yu32-table{width:100%;border-collapse:collapse;font-size:13px}
      .yu32-table th,.yu32-table td{padding:9px 11px;border-bottom:1px solid #E5E7EB;text-align:left;white-space:nowrap}
      .yu32-table th{background:#F8FAFC;font-weight:700;color:#334155}
      .yu32-form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:14px}
      .yu32-field label{display:block;font-size:12px;font-weight:700;color:#374151;margin-bottom:4px}
      .yu32-field input,.yu32-field select,.yu32-field textarea{width:100%;padding:8px 10px;border:1px solid #D1D5DB;border-radius:8px;font-size:13px;font-family:inherit}
      .yu32-msg{padding:10px 12px;border-radius:8px;font-size:13px;margin-bottom:12px}
      .yu32-msg--ok{background:#DCFCE7;color:#166534;border:1px solid #86EFAC}
      .yu32-msg--err{background:#FEE2E2;color:#991B1B;border:1px solid #FCA5A5}
      .yu32-offline-toast{position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:10060;background:#2D050E;color:#E6B450;padding:8px 16px;border-radius:8px;font-size:13px;font-weight:700;box-shadow:0 8px 24px rgba(0,0,0,.25)}
      .yu32-sidebar-tool{width:100%;display:flex;align-items:center;justify-content:center;gap:6px;padding:8px 10px;border-radius:9px;border:1px solid #EADFE2;background:#FAF7F5;color:#7A0F28;font-size:12px;font-weight:700;cursor:pointer;text-align:center;transition:all .15s ease;font-family:'Plus Jakarta Sans','Inter',system-ui,sans-serif}
      .yu32-sidebar-tool:hover{background:#7A0F28;border-color:#7A0F28;color:#FFFFFF}
      .yu32-sidebar-tool--brand{background:#7A0F28;border-color:#7A0F28;color:#FFFFFF}
      .yu32-sidebar-tool--brand:hover{background:#58091B;border-color:#58091B}
      .yu32-modal-backdrop.is-dark .yu32-modal{background:#1B0B11;color:#FAF4F6;border:1px solid #3D1D29}
      .yu32-modal-backdrop.is-dark .yu32-modal-hdr{background:#1B0B11;border-bottom-color:#3D1D29}
      .yu32-modal-backdrop.is-dark .yu32-modal-hdr strong{color:#E6B450 !important}
      .yu32-modal-backdrop.is-dark .yu32-tabs{border-bottom-color:#3D1D29}
      .yu32-modal-backdrop.is-dark .yu32-tab{background:#271119;border-color:#3D1D29;color:#FAF4F6}
      .yu32-modal-backdrop.is-dark .yu32-tab.is-active{background:#A31838;border-color:#A31838;color:#FFFFFF}
      .yu32-modal-backdrop.is-dark .yu32-field label{color:#E8D8DE}
      .yu32-modal-backdrop.is-dark .yu32-field input,.yu32-modal-backdrop.is-dark .yu32-field select,.yu32-modal-backdrop.is-dark .yu32-field textarea{background:#271119;border-color:#3D1D29;color:#FAF4F6}
      .yu32-modal-backdrop.is-dark .yu32-table-wrap{border-color:#3D1D29}
      .yu32-modal-backdrop.is-dark .yu32-table th{background:#271119;color:#E6B450;border-bottom-color:#3D1D29}
      .yu32-modal-backdrop.is-dark .yu32-table td{border-bottom-color:#3D1D29;color:#FAF4F6}
      @media (max-width:640px){
        .yu32-dock{left:10px;bottom:10px}
      }
    `;
    document.head.appendChild(style);
  }

  function getDock() {
    let dock = document.getElementById("yu-v32-dock");
    if (!dock) {
      dock = document.createElement("div");
      dock.id = "yu-v32-dock";
      dock.className = "yu32-dock";
      document.body.appendChild(dock);
    }
    return dock;
  }

  function getPortalToolsContainer() {
    const slot = document.querySelector("[data-erp-v32-slot]");
    if (slot) return { container: slot, inSidebar: true };
    return { container: getDock(), inSidebar: false };
  }

  /* ==========================================================================
   * 2. PWA SERVICE WORKER + OFFLINE FALLBACK (NO INSTALL PROMOTION UI)
   * ======================================================================== */
  function initPwa() {
    if ("serviceWorker" in navigator) {
      window.addEventListener("load", () => {
        navigator.serviceWorker.register("/sw.js").catch(() => {});
      });
    }

    const updateOnlineBanner = () => {
      let toast = document.getElementById("yu-v32-offline-toast");
      if (!navigator.onLine) {
        if (!toast) {
          toast = document.createElement("div");
          toast.id = "yu-v32-offline-toast";
          toast.className = "yu32-offline-toast";
          toast.textContent = "You are offline — showing cached Yuitor pages.";
          document.body.appendChild(toast);
        }
      } else if (toast) {
        toast.remove();
      }
    };
    window.addEventListener("online", updateOnlineBanner);
    window.addEventListener("offline", updateOnlineBanner);
    updateOnlineBanner();
  }

  function openSimpleModal(title, bodyHtml) {
    let bd = document.getElementById("yu-v32-modal-backdrop");
    if (!bd) {
      bd = document.createElement("div");
      bd.id = "yu-v32-modal-backdrop";
      bd.className = "yu32-modal-backdrop";
      bd.addEventListener("click", (e) => {
        if (e.target === bd) bd.hidden = true;
      });
      document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && !bd.hidden) bd.hidden = true;
      });
      document.body.appendChild(bd);
    }
    const darkOn = Boolean(document.querySelector("#root main.portal-main.portal-dark"));
    bd.classList.toggle("is-dark", darkOn);
    const titleColor = darkOn ? "#E6B450" : "#7A0F28";
    bd.innerHTML = `
      <div class="yu32-modal" role="dialog" aria-label="${esc(title)}">
        <div class="yu32-modal-hdr">
          <strong style="font-size:17px;color:${titleColor};">${esc(title)}</strong>
          <button type="button" class="yu32-btn yu32-btn--ghost yu32-btn--sm" data-yu32-close>Close</button>
        </div>
        <div class="yu32-modal-body">${bodyHtml}</div>
      </div>`;
    bd.querySelector("[data-yu32-close]")?.addEventListener("click", () => {
      bd.hidden = true;
    });
    bd.hidden = false;
    return bd;
  }

  function alertSafe(msg) {
    openSimpleModal("Notice", `<div class="yu32-msg yu32-msg--err">${esc(msg)}</div>`);
  }

  async function addToCartSafe(courseId, plan = "1m", batchId = null) {
    if (window.YuitorAddons?.addToCartAndOpen) {
      await window.YuitorAddons.addToCartAndOpen(courseId, plan, batchId);
      return;
    }
    await reqJson("/api/cart/items", {
      method: "POST",
      body: { courseId: Number(courseId), plan, batchId: batchId || null },
    });
    window.location.href = "/?openCart=1";
  }

  /* ==========================================================================
   * 3. SHREYA AI INTERACTIVE TABS (Hosted INSIDE Ask Shreya AI Widget —
   *    NOT injected on index.html or any other public page!)
   * ======================================================================== */
  const aiState = {
    catalog: null,
    selectedCycle: "1m",
    quizClass: 10,
    quizData: null,
    quizAnswers: {},
    quizResult: null,
    quizSecondsLeft: 60,
    quizTimerId: null,
    notesClass: "all",
    notesData: null,
  };

  function stopQuizTimer() {
    if (aiState.quizTimerId) {
      clearInterval(aiState.quizTimerId);
      aiState.quizTimerId = null;
    }
  }

  async function renderAiClassesTab(container) {
    if (!container) return;
    if (!aiState.catalog) {
      container.innerHTML = `<div class="yu32-ai-panel"><p style="color:#6B7280;margin:6px 0;">Loading Class 6th–12th fee plans &amp; live seats...</p></div>`;
      try {
        aiState.catalog = await reqJson("/api/public/classes-catalog");
      } catch (err) {
        container.innerHTML = `<div class="yu32-ai-panel"><div class="yu32-msg yu32-msg--err">${esc(err.message)}</div></div>`;
        return;
      }
    }

    const data = aiState.catalog;
    const cycles = data.billingCycles || [
      { id: "1m", label: "1m", months: 1, discountPercent: 0 },
      { id: "3m", label: "3m", months: 3, discountPercent: 0 },
      { id: "6m", label: "6m", months: 6, discountPercent: 0 },
      { id: "9m", label: "9m", months: 9, discountPercent: 0 },
      { id: "yearly", label: "12m Yearly", months: 12, discountPercent: 10 },
    ];
    const sel = aiState.selectedCycle;

    container.innerHTML = `
      <div class="yu32-ai-panel">
        <div style="font-weight:800;font-size:13px;color:#7A0F28;margin-bottom:4px;">Class 6th–12th Individual Fee Plans</div>
        <div style="font-size:11.5px;color:#4B5563;margin-bottom:8px;">Pick duration (10% OFF on Yearly) &amp; add directly to Cart.</div>

        ${
          data.crossSell?.enabled
            ? `<div class="yu32-banner"><strong>Cross-Sell Active:</strong> ${esc(data.crossSell.headline)}</div>`
            : ""
        }
        ${
          data.comboDiscount?.enabled
            ? `<div class="yu32-banner" style="background:#F0FDF4;border-color:#86EFAC;border-left-color:#15803D;color:#14532D;">
                 <strong>Combo / Sibling (${Number(data.comboDiscount.percent || 5)}% OFF):</strong> Add 2+ subjects or toggle Sibling inside Cart.
               </div>`
            : ""
        }

        <div class="yu32-cycles" role="tablist" aria-label="Fee duration">
          ${cycles
            .map((c) => {
              const cKey = c.id || c.key;
              const shortLbl = cKey === "yearly" ? "12m Yearly" : `${c.months}m`;
              return `
                <button type="button" class="yu32-cycle-btn ${sel === cKey ? "is-active" : ""}" data-yu32-cycle="${esc(cKey)}">
                  ${esc(shortLbl)}${c.discountPercent ? `<span class="yu32-save-tag">${c.discountPercent}% OFF</span>` : ""}
                </button>`;
            })
            .join("")}
        </div>

        <div class="yu32-ai-list">
          ${(data.classes || [])
            .map((cls) => {
              const p = cls.pricingByCycle?.[sel] || {
                monthlyRate: cls.monthlyFee,
                months: 1,
                subtotal: cls.monthlyFee,
                discountAmount: 0,
                totalPayable: cls.monthlyFee,
              };
              const finalAmt = Number(p.totalPayable ?? p.finalAmount ?? cls.monthlyFee);
              const grossAmt = Number(p.subtotal ?? p.grossAmount ?? finalAmt);
              const discAmt = Number(p.discountAmount ?? p.savings ?? 0);
              const batches = cls.batches || [];
              const vacant = Number(cls.vacantSeats ?? 0);
              return `
                <article class="yu32-card" data-yu32-class-card="${cls.classNumber}">
                  <div class="yu32-card-top">
                    <h4 class="yu32-cls-title">${esc(cls.classLabel)}</h4>
                    <span class="yu32-seat-note ${vacant === 0 ? "is-full" : ""}">
                      ${vacant > 0 ? `Only ${vacant} seats left` : "Batch Full"}
                    </span>
                  </div>
                  <div class="yu32-price-row">
                    <span class="yu32-price">${inr(finalAmt)}</span>
                    ${discAmt > 0 ? `<span class="yu32-strike">${inr(grossAmt)}</span>` : ""}
                  </div>
                  <div class="yu32-price-meta">
                    ${inr(cls.monthlyFee)}/mo × ${p.months} ${p.months === 1 ? "mo" : "mos"}
                    ${discAmt > 0 ? ` · <span class="yu32-saved">Save ${inr(discAmt)} (10% OFF)</span>` : ""}
                  </div>
                  ${
                    batches.length
                      ? `<select class="yu32-batch-select" data-yu32-batch="${cls.classNumber}" aria-label="Select batch for ${esc(cls.classLabel)}">
                          ${batches
                            .map((b) => `<option value="${b.id}">${esc(b.name)} · ${esc(b.timing)} (${b.seatsRemaining} left)</option>`)
                            .join("")}
                        </select>`
                      : ""
                  }
                  <button type="button" class="yu32-btn yu32-btn--sm" data-yu32-add-cart="${cls.courseId}" data-yu32-cls="${cls.classNumber}" ${!cls.courseId ? "disabled" : ""}>
                    Add ${esc(cls.classLabel)} to Cart
                  </button>
                </article>`;
            })
            .join("")}
        </div>
      </div>`;

    container.querySelectorAll("[data-yu32-cycle]").forEach((btn) => {
      btn.addEventListener("click", () => {
        aiState.selectedCycle = btn.getAttribute("data-yu32-cycle") || "1m";
        renderAiClassesTab(container);
      });
    });

    container.querySelectorAll("[data-yu32-add-cart]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const courseId = Number(btn.getAttribute("data-yu32-add-cart"));
        const clsNum = btn.getAttribute("data-yu32-cls");
        const batchSel = container.querySelector(`[data-yu32-batch="${clsNum}"]`);
        const batchId = batchSel ? Number(batchSel.value) || null : null;
        btn.disabled = true;
        const orig = btn.textContent;
        btn.textContent = "Adding...";
        try {
          await addToCartSafe(courseId, aiState.selectedCycle, batchId);
        } catch (err) {
          alertSafe(err.message);
        } finally {
          btn.disabled = false;
          btn.textContent = orig;
        }
      });
    });
  }

  async function loadAiQuiz(cls, container) {
    stopQuizTimer();
    aiState.quizClass = cls;
    aiState.quizAnswers = {};
    aiState.quizResult = null;
    aiState.quizSecondsLeft = 60;
    container.innerHTML = `<div class="yu32-ai-panel"><p style="color:#6B7280;margin:6px 0;">Loading Class ${cls}th Quick Quiz...</p></div>`;
    try {
      aiState.quizData = await reqJson(`/api/public/quick-quiz/${cls}`);
    } catch {
      aiState.quizData = null;
    }
    renderAiQuizTab(container, true);
  }

  function startAiQuizTimer(container) {
    if (aiState.quizTimerId || aiState.quizResult) return;
    aiState.quizTimerId = setInterval(() => {
      aiState.quizSecondsLeft -= 1;
      const el = container.querySelector("[data-yu32-quiz-timer]");
      if (el) {
        const s = Math.max(0, aiState.quizSecondsLeft);
        el.textContent = `00:${String(s).padStart(2, "0")}`;
      }
      if (aiState.quizSecondsLeft <= 0) {
        stopQuizTimer();
        submitAiQuiz(container);
      }
    }, 1000);
  }

  async function submitAiQuiz(container) {
    stopQuizTimer();
    const qs = aiState.quizData?.questions || [];
    const answers = qs.map((q) => (aiState.quizAnswers[q.index] !== undefined ? Number(aiState.quizAnswers[q.index]) : -1));
    try {
      aiState.quizResult = await reqJson(`/api/public/quick-quiz/${aiState.quizClass}/submit`, {
        method: "POST",
        body: { answers },
      });
      renderAiQuizTab(container, true);
    } catch (err) {
      alertSafe(err.message);
    }
  }

  async function renderAiQuizTab(container, skipFetch = false) {
    if (!container) return;
    if (!aiState.quizData && !skipFetch) {
      await loadAiQuiz(aiState.quizClass, container);
      return;
    }
    const qData = aiState.quizData;
    const res = aiState.quizResult;
    const mm = String(Math.floor(aiState.quizSecondsLeft / 60)).padStart(2, "0");
    const ss = String(aiState.quizSecondsLeft % 60).padStart(2, "0");

    container.innerHTML = `
      <div class="yu32-ai-panel">
        <div class="yu32-quiz-bar">
          <div>
            <strong style="font-size:13px;color:#7A0F28;">5-Question Quick Quiz (60s)</strong>
            <div style="font-size:11px;color:#6B7280;">Class ${aiState.quizClass}th · Instant Score Card</div>
          </div>
          <div class="yu32-timer" data-yu32-quiz-timer>${mm}:${ss}</div>
        </div>

        <div class="yu32-cycles">
          ${[6, 7, 8, 9, 10, 11, 12]
            .map(
              (c) => `<button type="button" class="yu32-cycle-btn ${aiState.quizClass === c ? "is-active" : ""}" data-yu32-qcls="${c}">${c}th</button>`
            )
            .join("")}
        </div>

        ${
          !qData
            ? `<p style="color:#6B7280;">Could not load quiz right now.</p>`
            : `
              <div>
                ${(qData.questions || [])
                  .map(
                    (q) => `
                  <div class="yu32-q-item">
                    <p class="yu32-q-title">Q${q.index + 1}. ${esc(q.question)}</p>
                    <div class="yu32-q-opts">
                      ${(q.options || [])
                        .map(
                          (opt, oIdx) => `
                        <label class="yu32-q-opt">
                          <input type="radio" name="yu32_ai_q_${q.index}" value="${oIdx}" data-yu32-qopt="${q.index}" ${
                            aiState.quizAnswers[q.index] === oIdx ? "checked" : ""
                          } ${res ? "disabled" : ""} />
                          <span>${esc(opt)}</span>
                        </label>`
                        )
                        .join("")}
                    </div>
                  </div>`
                  )
                  .join("")}
              </div>

              ${
                res
                  ? `<div class="yu32-result-box" data-yu32-quiz-result>
                      <div style="font-size:10.5px;font-weight:800;color:#15803D;text-transform:uppercase;">${esc(res.badge || "Completed")}</div>
                      <div style="font-size:17px;font-weight:800;color:#111827;margin:2px 0;">Score: ${Number(res.score ?? res.correct ?? 0)} / ${Number(res.total || 5)} (${Number(res.percent || 0)}%)</div>
                      <div style="font-size:11.5px;color:#374151;margin-bottom:8px;">${esc(res.recommendation || "")}</div>
                      <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        ${
                          res.courseId
                            ? `<button type="button" class="yu32-btn yu32-btn--sm" data-yu32-quiz-cta="${res.courseId}">${esc(res.ctaLabel || `Join Class ${aiState.quizClass}th — Add to Cart`)}</button>`
                            : ""
                        }
                        <button type="button" class="yu32-btn yu32-btn--ghost yu32-btn--sm" data-yu32-quiz-retry>Try Again</button>
                      </div>
                    </div>`
                  : `<button type="button" class="yu32-btn" style="width:100%;" data-yu32-quiz-submit>Submit Quiz &amp; Get Instant Score</button>`
              }
            `
        }
      </div>`;

    container.querySelectorAll("[data-yu32-qcls]").forEach((b) => {
      b.addEventListener("click", () => loadAiQuiz(Number(b.getAttribute("data-yu32-qcls")), container));
    });

    container.querySelectorAll("[data-yu32-qopt]").forEach((inp) => {
      inp.addEventListener("change", () => {
        const idx = Number(inp.getAttribute("data-yu32-qopt"));
        aiState.quizAnswers[idx] = Number(inp.value);
        startAiQuizTimer(container);
      });
    });

    container.querySelector("[data-yu32-quiz-submit]")?.addEventListener("click", () => submitAiQuiz(container));
    container.querySelector("[data-yu32-quiz-retry]")?.addEventListener("click", () => loadAiQuiz(aiState.quizClass, container));
    container.querySelector("[data-yu32-quiz-cta]")?.addEventListener("click", async (e) => {
      const cid = Number(e.currentTarget.getAttribute("data-yu32-quiz-cta"));
      await addToCartSafe(cid, "1m", null);
    });
  }

  async function renderAiNotesTab(container) {
    if (!container) return;
    if (!aiState.notesData) {
      container.innerHTML = `<div class="yu32-ai-panel"><p style="color:#6B7280;margin:6px 0;">Loading Class 6th–12th Notes &amp; PYQ Library...</p></div>`;
      try {
        aiState.notesData = await reqJson("/api/public/study-library");
      } catch (err) {
        container.innerHTML = `<div class="yu32-ai-panel"><div class="yu32-msg yu32-msg--err">${esc(err.message)}</div></div>`;
        return;
      }
    }

    const clsFilter = aiState.notesClass;
    const allItems = aiState.notesData?.items || [];
    const shown =
      clsFilter === "all" ? allItems.slice(0, 14) : allItems.filter((it) => Number(it.classNumber) === Number(clsFilter));

    container.innerHTML = `
      <div class="yu32-ai-panel">
        <div style="font-weight:800;font-size:13px;color:#7A0F28;margin-bottom:4px;">Freemium Notes &amp; PYQ Bank</div>
        <div style="font-size:11.5px;color:#4B5563;margin-bottom:8px;">Free sample formula sheets for everyone · Full chapter notes unlock on active admission.</div>

        <div class="yu32-cycles">
          <button type="button" class="yu32-cycle-btn ${clsFilter === "all" ? "is-active" : ""}" data-yu32-ncls="all">All</button>
          ${[6, 7, 8, 9, 10, 11, 12]
            .map(
              (c) => `<button type="button" class="yu32-cycle-btn ${String(clsFilter) === String(c) ? "is-active" : ""}" data-yu32-ncls="${c}">${c}th</button>`
            )
            .join("")}
        </div>

        <div class="yu32-ai-list">
          ${
            shown.length
              ? shown
                  .map(
                    (it) => `
                <article class="yu32-card">
                  <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;">
                    <span style="font-size:11px;font-weight:700;color:#7A0F28;">${esc(it.classLabel)} · ${esc(it.subjectName)}</span>
                    ${
                      it.isFreeSample
                        ? `<span class="yu32-tag-free">Free Sample</span>`
                        : it.unlocked
                          ? `<span class="yu32-tag-free">Unlocked</span>`
                          : `<span class="yu32-tag-lock">Enrolled Only</span>`
                    }
                  </div>
                  <div style="font-weight:700;font-size:12.5px;color:#111827;">${esc(it.title)}</div>
                  <div style="font-size:11.5px;color:#4B5563;">${esc(it.description || it.chapterName || "Board-aligned notes & solved PYQs.")}</div>
                  <div>
                    ${
                      it.unlocked && it.downloadUrl
                        ? `<a class="yu32-btn yu32-btn--sm" href="${esc(it.downloadUrl)}" target="_blank" rel="noopener">Download PDF</a>`
                        : `<button type="button" class="yu32-btn yu32-btn--ghost yu32-btn--sm" data-yu32-unlock-course="${it.courseId || ""}" data-yu32-unlock-cls="${it.classNumber}">Enroll Class ${it.classNumber}th to Unlock</button>`
                    }
                  </div>
                </article>`
                  )
                  .join("")
              : `<p style="color:#6B7280;">No notes found for this filter.</p>`
          }
        </div>
      </div>`;

    container.querySelectorAll("[data-yu32-ncls]").forEach((b) => {
      b.addEventListener("click", () => {
        aiState.notesClass = b.getAttribute("data-yu32-ncls") || "all";
        renderAiNotesTab(container);
      });
    });

    container.querySelectorAll("[data-yu32-unlock-course]").forEach((b) => {
      b.addEventListener("click", async () => {
        const cid = Number(b.getAttribute("data-yu32-unlock-course"));
        if (cid) {
          await addToCartSafe(cid, "1m", null);
        } else {
          window.YuitorShreya?.open?.("fees");
        }
      });
    });
  }

  /* ==========================================================================
   * 4. PORTAL LIVE CLASS-WISE NOTICE BOARD (Student / Parent / Teacher Only)
   * ======================================================================== */
  async function mountPortalLiveNotices() {
    const p = (window.location.pathname || "/").toLowerCase();
    const isPortal = /^\/(?:student|parent|teacher)(?:\/|$)/i.test(p);
    if (!isPortal || ADMIN_GATE) return;
    if (document.getElementById("yu-v32-notice-bar")) return;

    try {
      const data = await reqJson("/api/public/live-notices");
      const notices = data.notices || [];
      if (!notices.length) return;
      let idx = 0;
      const bar = document.createElement("div");
      bar.id = "yu-v32-notice-bar";
      bar.className = "yu32-notice-bar";

      const render = () => {
        const n = notices[idx];
        const clsTag = !n.target_class || n.target_class === "all" ? "All Classes" : n.target_class;
        bar.innerHTML = `
          <div>
            <span class="yu32-notice-cls">${esc(clsTag)}</span>
            <strong>${esc(n.title)}</strong>${n.body ? ` — ${esc(n.body)}` : ""}
            ${n.link_url ? ` <a href="${esc(n.link_url)}">View</a>` : ""}
          </div>
          <div style="display:flex;gap:8px;align-items:center;">
            ${notices.length > 1 ? `<button type="button" class="yu32-btn yu32-btn--sm" style="background:rgba(255,255,255,.15);border-color:rgba(255,255,255,.3);" data-yu32-nnext>Next (${idx + 1}/${notices.length})</button>` : ""}
            <button type="button" class="yu32-btn yu32-btn--sm" style="background:transparent;border-color:rgba(255,255,255,.35);" data-yu32-nclose>×</button>
          </div>`;
        bar.querySelector("[data-yu32-nnext]")?.addEventListener("click", () => {
          idx = (idx + 1) % notices.length;
          render();
        });
        bar.querySelector("[data-yu32-nclose]")?.addEventListener("click", () => bar.remove());
      };
      render();
      const slot = document.querySelector("[data-erp-notice-slot]");
      if (slot) {
        slot.innerHTML = "";
        slot.appendChild(bar);
      } else {
        document.body.prepend(bar);
      }
    } catch {
      // ignore
    }
  }

  /* ==========================================================================
   * 5. STUDENT PORTAL: HYBRID DOUBT BOX & 1-CLICK QR CERTIFICATES
   * ======================================================================== */
  function mountStudentTools() {
    const p = (window.location.pathname || "/").toLowerCase();
    if (!/^\/student(?:\/|$)/i.test(p) || ADMIN_GATE) return;
    if (!document.querySelector("[data-erp-v32-slot]")) return;
    const { container, inSidebar } = getPortalToolsContainer();
    document.querySelectorAll("#yu-v32-dock [data-yu32-doubt-btn], #yu-v32-dock [data-yu32-stu-cert-btn]").forEach((el) => el.remove());

    if (!container.querySelector("[data-yu32-doubt-btn]")) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = inSidebar ? "yu32-sidebar-tool yu32-sidebar-tool--brand" : "yu32-dock-btn yu32-dock-btn--brand";
      btn.setAttribute("data-yu32-doubt-btn", "1");
      btn.textContent = "Hybrid Doubt Box";
      btn.title = "Hybrid Doubt Box (Photo + AI)";
      btn.addEventListener("click", () => openHybridDoubtModal());
      container.appendChild(btn);
    }

    if (!container.querySelector("[data-yu32-stu-cert-btn]")) {
      const cbtn = document.createElement("button");
      cbtn.type = "button";
      cbtn.className = inSidebar ? "yu32-sidebar-tool" : "yu32-dock-btn";
      cbtn.setAttribute("data-yu32-stu-cert-btn", "1");
      cbtn.textContent = "My QR Certificates";
      cbtn.title = "My QR-Verified Certificates";
      cbtn.addEventListener("click", () => openStudentCertificatesModal());
      container.appendChild(cbtn);
    }
  }

  async function openStudentCertificatesModal() {
    const bd = openSimpleModal("My QR-Verified Certificates", `<p style="color:#6B7280;">Loading your certificates...</p>`);
    const body = bd.querySelector(".yu32-modal-body");
    try {
      const data = await reqJson("/api/student/v32/certificates");
      const certs = data.certificates || [];
      if (!certs.length) {
        body.innerHTML = `<p style="color:#4B5563;margin:0;">No topper or course completion certificates issued yet. Once your course completes or you place on the topper board, your QR-verified printable certificate will appear here automatically.</p>`;
        return;
      }
      body.innerHTML = `
        <div class="yu32-table-wrap">
          <table class="yu32-table">
            <thead><tr><th>Code</th><th>Class / Program</th><th>Achievement</th><th>Actions</th></tr></thead>
            <tbody>
              ${certs
                .map(
                  (c) => `
                <tr>
                  <td><code>${esc(c.certificate_code)}</code></td>
                  <td><strong>${esc(c.class_label || c.course_title)}</strong></td>
                  <td>${esc(c.rank_or_score || "Verified")}</td>
                  <td>
                    <a class="yu32-btn yu32-btn--sm" href="/api/certificates/${encodeURIComponent(c.certificate_code)}/print" target="_blank" rel="noopener">Print QR</a>
                    <a class="yu32-btn yu32-btn--ghost yu32-btn--sm" href="/api/certificates/${encodeURIComponent(c.certificate_code)}/pdf" target="_blank" rel="noopener">PDF</a>
                  </td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>`;
    } catch (err) {
      body.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
    }
  }

  function openHybridDoubtModal() {
    const bd = openSimpleModal(
      "Hybrid Doubt Box — Shreya AI Hint + Teacher Verification",
      `
      <p style="margin:0 0 12px;font-size:13.5px;color:#4B5563;">
        Type your doubt or upload a clear question photo/PDF (max 5 MB). Shreya AI gives an instant short hint first, and your subject teacher verifies the final solution.
      </p>
      <div data-yu32-doubt-msg></div>
      <form data-yu32-doubt-form>
        <div class="yu32-form-grid">
          <div class="yu32-field">
            <label>Subject *</label>
            <input name="subjectName" required placeholder="e.g. Mathematics / Science" />
          </div>
          <div class="yu32-field">
            <label>Title / Topic *</label>
            <input name="title" required placeholder="e.g. Quadratic Formula Step 2" />
          </div>
        </div>
        <div class="yu32-field" style="margin-bottom:12px;">
          <label>Describe Your Question *</label>
          <textarea name="questionText" rows="3" required placeholder="Write your question in Hindi, Hinglish, or English..."></textarea>
        </div>
        <div class="yu32-field" style="margin-bottom:14px;">
          <label>Question Photo / PDF (Optional · JPG, PNG, WebP, PDF · Max 5 MB)</label>
          <input type="file" name="attachment" accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf" />
        </div>
        <button type="submit" class="yu32-btn">Submit Doubt &amp; Get Instant AI Hint</button>
      </form>
      <div data-yu32-doubt-hint style="margin-top:14px;"></div>
    `
    );

    const form = bd.querySelector("[data-yu32-doubt-form]");
    const msgBox = bd.querySelector("[data-yu32-doubt-msg]");
    const hintBox = bd.querySelector("[data-yu32-doubt-hint]");

    form?.addEventListener("submit", async (e) => {
      e.preventDefault();
      msgBox.innerHTML = "";
      hintBox.innerHTML = "";
      const fd = new FormData(form);
      const file = fd.get("attachment");
      let attachmentBase64 = "";
      let attachmentName = "";
      let attachmentMime = "";

      if (file && file.size > 0) {
        if (file.size > 5 * 1024 * 1024) {
          msgBox.innerHTML = `<div class="yu32-msg yu32-msg--err">File exceeds 5 MB limit. Please upload a smaller image or PDF.</div>`;
          return;
        }
        attachmentName = file.name;
        attachmentMime = file.type;
        attachmentBase64 = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || "").split(",")[1] || "");
          reader.onerror = () => reject(new Error("Could not read file."));
          reader.readAsDataURL(file);
        });
      }

      const submitBtn = form.querySelector("button[type=submit]");
      submitBtn.disabled = true;
      submitBtn.textContent = "Getting Shreya AI Hint...";
      try {
        const res = await reqJson("/api/student/crm/doubts", {
          method: "POST",
          body: {
            subjectName: String(fd.get("subjectName") || ""),
            title: String(fd.get("title") || ""),
            questionText: String(fd.get("questionText") || ""),
            attachmentBase64,
            attachmentName,
            attachmentMime,
          },
        });
        msgBox.innerHTML = `<div class="yu32-msg yu32-msg--ok">Doubt submitted! Queued for Teacher verification.</div>`;
        if (res.aiHint) {
          hintBox.innerHTML = `
            <div style="background:#FFF8EB;border:1px solid #E6B450;border-radius:10px;padding:14px;">
              <div style="font-size:12px;font-weight:800;color:#7A0F28;margin-bottom:6px;">SHREYA AI INSTANT HINT</div>
              <div style="font-size:13.5px;line-height:1.6;white-space:pre-wrap;">${esc(res.aiHint)}</div>
            </div>`;
        }
        form.reset();
      } catch (err) {
        msgBox.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = "Submit Doubt & Get Instant AI Hint";
      }
    });
  }

  /* ==========================================================================
   * 6. TEACHER PORTAL: 1-CLICK WHATSAPP TEMPLATES & MONTHLY PAYOUT LOG
   * ======================================================================== */
  function renderWhatsAppPanelHtml() {
    return `
      <div class="yu32-form-grid">
        <div class="yu32-field"><label>Parent / Student Phone (10 digits)</label><input data-wa-phone placeholder="9876543210" /></div>
        <div class="yu32-field"><label>Student Name</label><input data-wa-name value="Aarav Sharma" /></div>
        <div class="yu32-field"><label>Class</label>
          <select data-wa-class>
            ${[6, 7, 8, 9, 10, 11, 12].map((c) => `<option value="Class ${c}th" ${c === 10 ? "selected" : ""}>Class ${c}th</option>`).join("")}
          </select>
        </div>
        <div class="yu32-field"><label>Fee Due (₹)</label><input data-wa-due type="number" value="800" /></div>
        <div class="yu32-field"><label>Exam / Test Name</label><input data-wa-exam value="Weekly Science Test" /></div>
        <div class="yu32-field"><label>Score / Marks</label><input data-wa-score value="46/50 (Rank 2)" /></div>
      </div>
      <button type="button" class="yu32-btn yu32-btn--sm" data-wa-gen style="margin-bottom:14px;">Generate Ready Templates</button>
      <div data-wa-list></div>
    `;
  }

  function bindWhatsAppPanel(rootEl) {
    const gen = async () => {
      const phone = String(rootEl.querySelector("[data-wa-phone]")?.value || "").replace(/\D/g, "").slice(-10);
      const qs = new URLSearchParams({
        studentName: rootEl.querySelector("[data-wa-name]")?.value || "Student",
        className: rootEl.querySelector("[data-wa-class]")?.value || "Class 10th",
        amountDue: rootEl.querySelector("[data-wa-due]")?.value || "0",
        examName: rootEl.querySelector("[data-wa-exam]")?.value || "Weekly Test",
        score: rootEl.querySelector("[data-wa-score]")?.value || "",
      });
      const list = rootEl.querySelector("[data-wa-list]");
      list.innerHTML = `<p style="color:#6B7280;font-size:13px;">Loading templates...</p>`;
      try {
        const data = await reqJson(`/api/v32/whatsapp-templates?${qs.toString()}`);
        list.innerHTML = (data.templates || [])
          .map((t) => {
            const href = phone
              ? `https://wa.me/91${phone}?text=${encodeURIComponent(t.text)}`
              : `https://wa.me/?text=${encodeURIComponent(t.text)}`;
            return `
              <div style="border:1px solid #E5E7EB;border-radius:10px;padding:12px;margin-bottom:10px;background:#F9FAFB;">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px;">
                  <strong>${esc(t.label)}</strong>
                  <a class="yu32-btn yu32-btn--sm" style="background:#16A34A;border-color:#16A34A;" href="${esc(href)}" target="_blank" rel="noopener">Open in WhatsApp</a>
                </div>
                <div style="font-size:13px;color:#374151;white-space:pre-wrap;">${esc(t.text)}</div>
              </div>`;
          })
          .join("");
      } catch (err) {
        list.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
      }
    };
    rootEl.querySelector("[data-wa-gen]")?.addEventListener("click", gen);
    gen();
  }

  function mountTeacherTools() {
    const p = (window.location.pathname || "/").toLowerCase();
    if (!/^\/teacher(?:\/|$)/i.test(p) || ADMIN_GATE) return;
    if (!document.querySelector("[data-erp-v32-slot]")) return;
    const { container, inSidebar } = getPortalToolsContainer();
    document.querySelectorAll("#yu-v32-dock [data-yu32-teacher-btn]").forEach((el) => el.remove());
    if (container.querySelector("[data-yu32-teacher-btn]")) return;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = inSidebar ? "yu32-sidebar-tool yu32-sidebar-tool--brand" : "yu32-dock-btn yu32-dock-btn--brand";
    btn.setAttribute("data-yu32-teacher-btn", "1");
    btn.textContent = "WhatsApp & Payouts";
    btn.title = "WhatsApp Templates & Monthly Payout Log";
    btn.addEventListener("click", () => {
      const bd = openSimpleModal(
        "Teacher v3.2 Tools — WhatsApp Templates & Payout Log",
        `
        <div class="yu32-tabs">
          <button type="button" class="yu32-tab is-active" data-ttab="wa">1-Click WhatsApp Templates</button>
          <button type="button" class="yu32-tab" data-ttab="payout">My Monthly Payout &amp; Class Log</button>
        </div>
        <div data-ttab-body></div>
      `
      );
      const body = bd.querySelector("[data-ttab-body]");
      const showTab = async (tab) => {
        bd.querySelectorAll("[data-ttab]").forEach((b) => b.classList.toggle("is-active", b.getAttribute("data-ttab") === tab));
        if (tab === "wa") {
          body.innerHTML = renderWhatsAppPanelHtml();
          bindWhatsAppPanel(body);
        } else {
          body.innerHTML = `<p style="color:#6B7280;">Loading payout log...</p>`;
          try {
            const data = await reqJson("/api/v32/teacher/payout-log");
            body.innerHTML = renderPayoutTableHtml(data.salaryMonth, data.rows || []);
          } catch (err) {
            body.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
          }
        }
      };
      bd.querySelectorAll("[data-ttab]").forEach((b) =>
        b.addEventListener("click", () => showTab(b.getAttribute("data-ttab")))
      );
      showTab("wa");
    });
    container.appendChild(btn);
  }

  function renderPayoutTableHtml(month, rows) {
    return `
      <div style="margin-bottom:10px;font-size:13px;color:var(--pt-muted,#4B5563);">Month: <strong>${esc(month)}</strong></div>
      <div class="yu32-table-wrap">
        <table class="yu32-table">
          <thead><tr><th>Teacher</th><th>Classes Taken</th><th>Verified Referrals</th><th>Referral Bonus</th><th>Net Monthly Payout</th></tr></thead>
          <tbody>
            ${
              rows.length
                ? rows
                    .map(
                      (r) => `
                  <tr>
                    <td><strong>${esc(r.fullName)}</strong></td>
                    <td>${Number(r.classesTaken || 0)}</td>
                    <td>${Number(r.verifiedReferrals || 0)}</td>
                    <td>${inr(r.referralBonus || 0)}</td>
                    <td><strong>${inr(r.estimatedMonthlyPayout || 0)}</strong></td>
                  </tr>`
                    )
                    .join("")
                : `<tr><td colspan="5" style="color:#6B7280;">No teacher payout records for this month.</td></tr>`
            }
          </tbody>
        </table>
      </div>`;
  }

  /* ==========================================================================
   * 7. ADMIN PANEL v3.2 OPERATIONS HUB (Reports, QR Cert Generator, Settings)
   * ======================================================================== */
  function mountAdminV32Hub() {
    if (!ADMIN_GATE || !ADMIN_API_BASE) return;
    if (!document.querySelector("[data-erp-v32-slot]")) return;
    const { container, inSidebar } = getPortalToolsContainer();
    document.querySelectorAll("#yu-v32-dock [data-yu32-admin-btn]").forEach((el) => el.remove());
    if (container.querySelector("[data-yu32-admin-btn]")) return;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = inSidebar ? "yu32-sidebar-tool yu32-sidebar-tool--brand" : "yu32-dock-btn yu32-dock-btn--brand";
    btn.setAttribute("data-yu32-admin-btn", "1");
    btn.textContent = "v3.2 Hub & Reports";
    btn.title = "v3.2 Reports, Certs & Settings";
    btn.addEventListener("click", () => openAdminV32Modal());
    container.appendChild(btn);
  }

  function openAdminV32Modal(initialTab = "finance") {
    const bd = openSimpleModal(
      "Yuitor v3.2 Admin Operations Hub",
      `
      <div class="yu32-tabs">
        <button type="button" class="yu32-tab is-active" data-atab="finance">Class 6th–12th Revenue &amp; Dues</button>
        <button type="button" class="yu32-tab" data-atab="settings">v3.2 Combo &amp; AI Limits</button>
        <button type="button" class="yu32-tab" data-atab="payouts">Teacher Payout Log</button>
        <button type="button" class="yu32-tab" data-atab="certs">QR Certificate Generator</button>
        <button type="button" class="yu32-tab" data-atab="wa">WhatsApp Templates</button>
      </div>
      <div data-atab-body></div>
    `
    );

    const body = bd.querySelector("[data-atab-body]");

    const loadTab = async (tab) => {
      bd.querySelectorAll("[data-atab]").forEach((b) => b.classList.toggle("is-active", b.getAttribute("data-atab") === tab));
      body.innerHTML = `<p style="color:#6B7280;">Loading...</p>`;

      if (tab === "finance") {
        try {
          const rep = await reqJson(adminApiUrl("/v32/finance/class-report"));
          body.innerHTML = `
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px;">
              <div style="font-size:13.5px;">
                Total Admissions: <strong>${rep.totals?.admissions || 0}</strong> ·
                Collected: <strong style="color:#15803D;">${inr(rep.totals?.feeCollected || 0)}</strong> ·
                Pending Dues: <strong style="color:#B91C1C;">${inr(rep.totals?.pendingDues || 0)}</strong> ·
                Vacant Seats: <strong>${rep.totals?.vacantSeats || 0}</strong>
              </div>
              <div style="display:flex;gap:8px;">
                <a class="yu32-btn yu32-btn--sm" href="${esc(adminApiUrl("/v32/finance/class-report/export?format=csv"))}">Export CSV</a>
                <a class="yu32-btn yu32-btn--ghost yu32-btn--sm" href="${esc(adminApiUrl("/v32/finance/class-report/export?format=excel"))}">Export Excel</a>
              </div>
            </div>
            <div class="yu32-table-wrap">
              <table class="yu32-table">
                <thead><tr><th>Class</th><th>Monthly Fee</th><th>Admissions</th><th>Fee Collected</th><th>Pending Dues</th><th>Vacant Seats</th></tr></thead>
                <tbody>
                  ${(rep.rows || [])
                    .map(
                      (r) => `
                    <tr>
                      <td><strong>${esc(r.classLabel)}</strong></td>
                      <td>${inr(r.monthlyFee)}/mo</td>
                      <td>${r.admissions}</td>
                      <td style="color:#15803D;font-weight:700;">${inr(r.feeCollected)}</td>
                      <td style="color:#B91C1C;font-weight:700;">${inr(r.pendingDues)}</td>
                      <td>${r.vacantSeats}</td>
                    </tr>`
                    )
                    .join("")}
                </tbody>
              </table>
            </div>`;
        } catch (err) {
          body.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
        }
      } else if (tab === "settings") {
        try {
          const data = await reqJson(adminApiUrl("/v32/settings"));
          const s = data.settings || {};
          body.innerHTML = `
            <div data-v32-set-msg></div>
            <form data-v32-set-form>
              <div class="yu32-form-grid">
                <div class="yu32-field">
                  <label>Multi-Subject Combo / Sibling Discount</label>
                  <select name="comboDiscountEnabled">
                    <option value="true" ${s.comboDiscountEnabled ? "selected" : ""}>ON (Active)</option>
                    <option value="false" ${!s.comboDiscountEnabled ? "selected" : ""}>OFF</option>
                  </select>
                </div>
                <div class="yu32-field"><label>Combo / Sibling Discount %</label><input type="number" name="comboDiscountPercent" min="1" max="40" value="${Number(s.comboDiscountPercent || 5)}" /></div>
                <div class="yu32-field"><label>Guest Daily Shreya Questions</label><input type="number" name="guestDailyAiQuestions" min="1" max="50" value="${Number(s.guestDailyAiQuestions || 5)}" /></div>
                <div class="yu32-field"><label>Guest Daily File Uploads</label><input type="number" name="guestDailyAiUploads" min="0" max="20" value="${Number(s.guestDailyAiUploads || 2)}" /></div>
                <div class="yu32-field"><label>Active Student Daily Questions</label><input type="number" name="studentDailyAiQuestions" min="5" max="200" value="${Number(s.studentDailyAiQuestions || 30)}" /></div>
                <div class="yu32-field"><label>Active Student Daily Uploads</label><input type="number" name="studentDailyAiUploads" min="1" max="50" value="${Number(s.studentDailyAiUploads || 10)}" /></div>
                <div class="yu32-field"><label>Abandoned Cart Reminder Delay (Hours)</label><input type="number" name="abandonedCartHours" min="1" max="24" value="${Number(s.abandonedCartHours || 1)}" /></div>
              </div>
              <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <button type="submit" class="yu32-btn">Save v3.2 Settings</button>
                <button type="button" class="yu32-btn yu32-btn--ghost" data-v32-run-sweeps>Run Abandoned Cart &amp; Renewal Reminders Now</button>
              </div>
            </form>`;
          body.querySelector("[data-v32-set-form]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            const msg = body.querySelector("[data-v32-set-msg]");
            try {
              await reqJson(adminApiUrl("/v32/settings"), {
                method: "PATCH",
                body: {
                  comboDiscountEnabled: fd.get("comboDiscountEnabled") === "true",
                  comboDiscountPercent: Number(fd.get("comboDiscountPercent")),
                  guestDailyAiQuestions: Number(fd.get("guestDailyAiQuestions")),
                  guestDailyAiUploads: Number(fd.get("guestDailyAiUploads")),
                  studentDailyAiQuestions: Number(fd.get("studentDailyAiQuestions")),
                  studentDailyAiUploads: Number(fd.get("studentDailyAiUploads")),
                  abandonedCartHours: Number(fd.get("abandonedCartHours")),
                },
              });
              msg.innerHTML = `<div class="yu32-msg yu32-msg--ok">v3.2 settings saved successfully.</div>`;
            } catch (err) {
              msg.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
            }
          });
          body.querySelector("[data-v32-run-sweeps]")?.addEventListener("click", async () => {
            const msg = body.querySelector("[data-v32-set-msg]");
            try {
              const out = await reqJson(adminApiUrl("/v32/reminders/run"), { method: "POST" });
              msg.innerHTML = `<div class="yu32-msg yu32-msg--ok">Sweeps complete — Abandoned reminders sent: ${out.abandoned?.sent || 0}, Renewal reminders sent: ${out.renewals?.sent || 0}.</div>`;
            } catch (err) {
              msg.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
            }
          });
        } catch (err) {
          body.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
        }
      } else if (tab === "payouts") {
        try {
          const data = await reqJson(adminApiUrl("/v32/teachers/payout-log"));
          body.innerHTML = renderPayoutTableHtml(data.salaryMonth, data.rows || []);
        } catch (err) {
          body.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
        }
      } else if (tab === "certs") {
        try {
          const data = await reqJson(adminApiUrl("/v32/certificates"));
          const certs = data.certificates || [];
          body.innerHTML = `
            <div data-v32-cert-msg></div>
            <form data-v32-cert-form style="margin-bottom:16px;">
              <div class="yu32-form-grid">
                <div class="yu32-field"><label>Student Full Name *</label><input name="studentName" required placeholder="e.g. Ananya Verma" /></div>
                <div class="yu32-field"><label>Class</label>
                  <select name="classLabel">
                    ${[6, 7, 8, 9, 10, 11, 12].map((c) => `<option value="Class ${c}th" ${c === 10 ? "selected" : ""}>Class ${c}th</option>`).join("")}
                  </select>
                </div>
                <div class="yu32-field"><label>Certificate Type</label>
                  <select name="certType">
                    <option value="topper">Topper Excellence Certificate</option>
                    <option value="completion">Course Completion Certificate</option>
                  </select>
                </div>
                <div class="yu32-field"><label>Rank / Score / Remark</label><input name="rankOrScore" placeholder="Rank 1 · 98.4% Board Topper" /></div>
              </div>
              <button type="submit" class="yu32-btn">Generate QR-Verified Certificate</button>
            </form>
            <div class="yu32-table-wrap">
              <table class="yu32-table">
                <thead><tr><th>Code</th><th>Student</th><th>Class &amp; Type</th><th>Achievement</th><th>Actions</th></tr></thead>
                <tbody>
                  ${
                    certs.length
                      ? certs
                          .map(
                            (c) => `
                        <tr>
                          <td><code>${esc(c.certificate_code)}</code></td>
                          <td><strong>${esc(c.student_name)}</strong></td>
                          <td>${esc(c.class_label)} · ${esc(c.cert_type)}</td>
                          <td>${esc(c.rank_or_score || "—")}</td>
                          <td>
                            <a class="yu32-btn yu32-btn--sm" href="/api/certificates/${encodeURIComponent(c.certificate_code)}/print" target="_blank" rel="noopener">Print QR</a>
                            <a class="yu32-btn yu32-btn--ghost yu32-btn--sm" href="/api/certificates/${encodeURIComponent(c.certificate_code)}/pdf" target="_blank" rel="noopener">PDF</a>
                          </td>
                        </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="5" style="color:#6B7280;">No v3.2 certificates issued yet.</td></tr>`
                  }
                </tbody>
              </table>
            </div>`;
          body.querySelector("[data-v32-cert-form]")?.addEventListener("submit", async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            const msg = body.querySelector("[data-v32-cert-msg]");
            try {
              const out = await reqJson(adminApiUrl("/v32/certificates"), {
                method: "POST",
                body: Object.fromEntries(fd.entries()),
              });
              msg.innerHTML = `<div class="yu32-msg yu32-msg--ok">Issued <strong>${esc(out.certificate?.certificate_code)}</strong>! <a href="${esc(out.printUrl)}" target="_blank" rel="noopener" style="color:#166534;font-weight:800;">Open Printable QR Certificate</a></div>`;
              loadTab("certs");
            } catch (err) {
              msg.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
            }
          });
        } catch (err) {
          body.innerHTML = `<div class="yu32-msg yu32-msg--err">${esc(err.message)}</div>`;
        }
      } else if (tab === "wa") {
        body.innerHTML = renderWhatsAppPanelHtml();
        bindWhatsAppPanel(body);
      }
    };

    bd.querySelectorAll("[data-atab]").forEach((b) =>
      b.addEventListener("click", () => loadTab(b.getAttribute("data-atab")))
    );
    loadTab(initialTab);
  }

  /* ==========================================================================
   * 8. URL ACTION HANDLER (?renewCourse=...&plan=...) & BOOTSTRAP
   * ======================================================================== */
  async function handleUrlActions() {
    try {
      const sp = new URLSearchParams(window.location.search);
      const renewCourse = Number(sp.get("renewCourse") || 0);
      const plan = sp.get("plan") || "1m";
      if (renewCourse > 0) {
        await addToCartSafe(renewCourse, plan, null);
      }
    } catch {
      // ignore
    }
  }

  function syncWorkspaceSlots() {
    const existingBar = document.getElementById("yu-v32-notice-bar");
    const noticeSlot = document.querySelector("[data-erp-notice-slot]");
    if (existingBar && noticeSlot && !noticeSlot.contains(existingBar)) {
      noticeSlot.innerHTML = "";
      noticeSlot.appendChild(existingBar);
    } else if (!existingBar) {
      mountPortalLiveNotices();
    }
    mountStudentTools();
    mountTeacherTools();
    mountAdminV32Hub();
    window.YuitorV33?.syncAdminSidebarSlot?.();
  }

  function bootstrap() {
    injectStyles();
    initPwa();
    syncWorkspaceSlots();
    handleUrlActions();
  }

  window.YuitorV32 = {
    renderAiClassesTab,
    renderAiQuizTab,
    renderAiNotesTab,
    openAdminV32Modal,
    openHybridDoubtModal,
    openStudentCertificatesModal,
    addToCartSafe,
    syncWorkspaceSlots,
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootstrap, { once: true });
  } else {
    bootstrap();
  }
})();
