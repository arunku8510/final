(() => {
  "use strict";
  if (document.getElementById("yu-ai-guide-root")) return;

  const SHREYA_INTRO =
    "Hi! I'm Shreya, Yuitor Smart Classes AI Assistant. Ask about Class 6th–12th fees, batches, admissions, upload a question photo/PDF (max 5 MB), or use the tabs above for Fee Plans, Quick Quiz & Free Notes.";
  const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;
  const ALLOWED_MIMES = new Set(["image/jpeg", "image/jpg", "image/png", "image/webp", "application/pdf"]);
  const ALLOWED_EXTS = /\.(jpe?g|png|webp|pdf)$/i;

  let conversationId = sessionStorage.getItem("yuitor_shreya_conv_id") || "";
  let visitorId = sessionStorage.getItem("yuitor_visitor_id") || "";
  if (!visitorId) {
    visitorId = "v-" + Math.random().toString(36).slice(2, 10);
    sessionStorage.setItem("yuitor_visitor_id", visitorId);
  }

  let busy = false;
  let currentRating = 5;
  let pendingFile = null;
  let latestCta = null;
  let latestQuota = null;
  let activeTab = "chat";

  if (!document.getElementById("yu-shreya-resp-css")) {
    const st = document.createElement("style");
    st.id = "yu-shreya-resp-css";
    st.textContent = `
      #yu-ai-guide-root{position:fixed;bottom:18px;right:18px;z-index:9999;display:flex;flex-direction:column;align-items:flex-end;font-family:'Plus Jakarta Sans',system-ui,-apple-system,sans-serif;}
      #yu-smart-ai-toggle{background:#7A0F28;color:#fff;border:2px solid #E6B450;padding:10px 16px;border-radius:999px;font-weight:700;font-size:13.5px;cursor:pointer;box-shadow:0 10px 26px rgba(45,5,14,.28);min-height:40px;}
      #yu-shreya-box{width:min(404px,calc(100vw - 24px));max-height:calc(100dvh - 96px);}
      @media (max-width:767px){
        #yu-ai-guide-root{bottom:12px;right:12px;}
        #yu-smart-ai-toggle{padding:8px 13px;font-size:12.5px;min-height:38px;}
        #yu-shreya-box{width:calc(100vw - 20px);max-height:calc(100dvh - 82px);}
      }
    `;
    document.head.appendChild(st);
  }

  const root = document.createElement("div");
  root.id = "yu-ai-guide-root";
  root.className = "yu-ai-guide-root";

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.id = "yu-smart-ai-toggle";
  toggle.textContent = "Ask Shreya";
  toggle.setAttribute("aria-label", "Open Ask Shreya AI Assistant");

  const box = document.createElement("div");
  box.id = "yu-shreya-box";
  box.hidden = true;
  box.style.cssText =
    "display:flex;flex-direction:column;background:#fff;border:1px solid #EADFE2;border-radius:16px;box-shadow:0 18px 40px rgba(45,5,14,.28);overflow:hidden;margin-bottom:10px;";
  box.style.display = "none";

  box.innerHTML = `
    <div style="background:linear-gradient(135deg,#3A0714,#7A0F28);color:#fff;padding:11px 13px;display:flex;justify-content:space-between;align-items:center;gap:8px;flex-shrink:0;">
      <div style="min-width:0;">
        <div style="font-weight:700;font-size:14.5px;font-family:'Playfair Display',Georgia,serif;">Shreya · Yuitor AI Assistant</div>
        <div id="yu-shreya-quota" style="font-size:11px;color:#F3CF7A;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">Class 6th–12th Fees, Quiz, Notes &amp; Photo Doubts (≤5 MB)</div>
      </div>
      <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;">
        <button type="button" id="yu-chat-new-btn" title="Start new chat" style="background:rgba(255,255,255,.14);color:#fff;border:0;border-radius:6px;padding:4px 7px;font-size:11px;cursor:pointer;">New</button>
        <button type="button" id="yu-chat-info-btn" style="background:rgba(255,255,255,.14);color:#fff;border:0;border-radius:6px;padding:4px 7px;font-size:11px;cursor:pointer;">Info</button>
        <button type="button" id="yu-chat-rate-btn" style="background:rgba(255,255,255,.14);color:#fff;border:0;border-radius:6px;padding:4px 7px;font-size:11px;cursor:pointer;">Rate</button>
        <button type="button" id="yu-chat-close" aria-label="Close Shreya AI Chat" style="background:none;border:0;color:#fff;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
      </div>
    </div>
    <div id="yu-shreya-tabs" role="tablist" aria-label="Shreya AI tools" style="display:grid;grid-template-columns:repeat(4,1fr);background:#FFF8F9;border-bottom:1px solid #EADFE2;flex-shrink:0;">
      <button type="button" data-ai-tab="chat" role="tab" aria-selected="true" style="padding:8px 4px;font-size:11.5px;font-weight:700;border:0;border-bottom:2px solid #7A0F28;background:#fff;color:#7A0F28;cursor:pointer;">AI Chat</button>
      <button type="button" data-ai-tab="fees" role="tab" aria-selected="false" style="padding:8px 4px;font-size:11.5px;font-weight:700;border:0;border-bottom:2px solid transparent;background:transparent;color:#4B5563;cursor:pointer;">Fees 6–12</button>
      <button type="button" data-ai-tab="quiz" role="tab" aria-selected="false" style="padding:8px 4px;font-size:11.5px;font-weight:700;border:0;border-bottom:2px solid transparent;background:transparent;color:#4B5563;cursor:pointer;">Quick Quiz</button>
      <button type="button" data-ai-tab="notes" role="tab" aria-selected="false" style="padding:8px 4px;font-size:11.5px;font-weight:700;border:0;border-bottom:2px solid transparent;background:transparent;color:#4B5563;cursor:pointer;">Notes &amp; PYQ</button>
    </div>
    <div id="yu-chat-contact" hidden style="padding:10px;background:#FAF7F5;border-bottom:1px solid #EADFE2;display:none;gap:6px;font-size:12px;flex-shrink:0;">
      <input id="yu-v-name" type="text" placeholder="Your name (optional)" style="padding:6px 8px;border:1px solid #EADFE2;border-radius:8px;font-size:12px;background:#ffffff;color:#1D1014;">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
        <input id="yu-v-phone" type="tel" placeholder="Mobile (optional)" style="padding:6px 8px;border:1px solid #EADFE2;border-radius:8px;font-size:12px;background:#ffffff;color:#1D1014;">
        <input id="yu-v-email" type="email" placeholder="Email (optional)" style="padding:6px 8px;border:1px solid #EADFE2;border-radius:8px;font-size:12px;background:#ffffff;color:#1D1014;">
      </div>
    </div>
    <form id="yu-chat-rate" hidden style="padding:10px;background:#FFF9EB;border-bottom:1px solid #F0DBA8;display:none;gap:6px;font-size:12px;flex-shrink:0;">
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <strong style="color:#1D1014;">Rate Shreya</strong>
        <div id="yu-stars" style="display:flex;gap:4px;"></div>
      </div>
      <input id="yu-fb-text" type="text" placeholder="Optional feedback..." style="padding:6px 8px;border:1px solid #EADFE2;border-radius:8px;font-size:12px;background:#ffffff;color:#1D1014;">
      <button type="submit" style="background:#7A0F28;color:#fff;border:0;padding:6px 10px;border-radius:8px;font-weight:600;cursor:pointer;">Save Feedback</button>
    </form>
    <div id="yu-chat-msgs" style="height:310px;max-height:56dvh;overflow-y:auto;padding:12px;background:#FAF7F5;display:flex;flex-direction:column;gap:8px;font-size:13px;line-height:1.48;"></div>
    <div id="yu-ai-tool-view" hidden style="height:375px;max-height:62dvh;overflow-y:auto;background:#FAF7F5;display:none;"></div>
    <div id="yu-chat-file-bar" hidden style="padding:6px 10px;background:#FFF7ED;border-top:1px solid #FED7AA;display:none;align-items:center;justify-content:space-between;gap:8px;font-size:12px;color:#9A3412;">
      <span id="yu-chat-file-name" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"></span>
      <button type="button" id="yu-chat-file-clear" style="background:#9A3412;color:#fff;border:0;border-radius:6px;padding:2px 7px;font-size:11px;cursor:pointer;">Remove</button>
    </div>
    <form id="yu-chat-form" style="display:flex;gap:6px;padding:10px;border-top:1px solid #EADFE2;background:#fff;flex-shrink:0;align-items:center;">
      <input id="yu-chat-file" type="file" accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf" hidden>
      <button type="button" id="yu-chat-attach" title="Upload question photo or PDF (max 5 MB)" aria-label="Upload question photo or PDF" style="background:#FFF1F2;color:#7A0F28;border:1px solid #E5C8D0;border-radius:10px;padding:7px 9px;font-weight:700;font-size:13px;cursor:pointer;flex-shrink:0;">+File</button>
      <input id="yu-chat-in" type="text" maxlength="600" placeholder="Ask in English, Hindi or Hinglish..." style="flex:1;padding:8px 10px;border:1px solid #EADFE2;border-radius:10px;font-size:13px;min-width:0;background:#ffffff;color:#1D1014;">
      <button type="submit" id="yu-chat-submit" style="background:#7A0F28;color:#fff;border:0;padding:8px 13px;border-radius:10px;font-weight:700;cursor:pointer;white-space:nowrap;">Send</button>
    </form>
  `;

  root.append(box, toggle);
  document.body.appendChild(root);

  const msgsEl = box.querySelector("#yu-chat-msgs");
  const toolViewEl = box.querySelector("#yu-ai-tool-view");
  const tabBtns = box.querySelectorAll("[data-ai-tab]");
  const form = box.querySelector("#yu-chat-form");
  const input = box.querySelector("#yu-chat-in");
  const fileInput = box.querySelector("#yu-chat-file");
  const attachBtn = box.querySelector("#yu-chat-attach");
  const fileBar = box.querySelector("#yu-chat-file-bar");
  const fileNameEl = box.querySelector("#yu-chat-file-name");
  const fileClearBtn = box.querySelector("#yu-chat-file-clear");
  const quotaEl = box.querySelector("#yu-shreya-quota");
  const submitBtn = box.querySelector("#yu-chat-submit");
  const closeBtn = box.querySelector("#yu-chat-close");
  const newBtn = box.querySelector("#yu-chat-new-btn");
  const infoBtn = box.querySelector("#yu-chat-info-btn");
  const rateBtn = box.querySelector("#yu-chat-rate-btn");
  const contactPanel = box.querySelector("#yu-chat-contact");
  const rateForm = box.querySelector("#yu-chat-rate");
  const starsWrap = box.querySelector("#yu-stars");

  const localMessages = [{ sender: "assistant", message: SHREYA_INTRO }];
  let isEscalated = false;

  const STARTER_CHIPS = [
    "Class 10th fees kitni hai?",
    "Class 12th yearly 10% OFF?",
    "Class 8th batch timing?",
    "Upload question photo help",
  ];

  const LINK_TOKEN_RE =
    /(\+91[\s-]?\d{2,5}[\s-]?\d{4,6}(?:[\s-]?\d{4})?|[a-zA-Z0-9._%+-]+@yuitor\.com|\/(?:register\/teacher|register\/student|register\/parent|course\/[a-z0-9-]+|class-(?:6|7|8|9|10|11|12)|fee-calculator|admission|scholarship|teachers|courses|contact|register|refund|login|student\/|teacher\/|parent\/))/g;

  function switchTab(tab) {
    const valid = ["chat", "fees", "quiz", "notes"].includes(tab) ? tab : "chat";
    activeTab = valid;
    tabBtns.forEach((b) => {
      const isAct = b.getAttribute("data-ai-tab") === valid;
      b.setAttribute("aria-selected", isAct ? "true" : "false");
      b.style.borderBottomColor = isAct ? "#7A0F28" : "transparent";
      b.style.background = isAct ? "#fff" : "transparent";
      b.style.color = isAct ? "#7A0F28" : "#4B5563";
    });
    if (valid === "chat") {
      msgsEl.style.display = "flex";
      form.style.display = "flex";
      if (pendingFile && fileBar) {
        fileBar.hidden = false;
        fileBar.style.display = "flex";
      }
      toolViewEl.hidden = true;
      toolViewEl.style.display = "none";
      window.setTimeout(() => input.focus(), 40);
    } else {
      msgsEl.style.display = "none";
      form.style.display = "none";
      if (fileBar) {
        fileBar.hidden = true;
        fileBar.style.display = "none";
      }
      toolViewEl.hidden = false;
      toolViewEl.style.display = "block";
      if (valid === "fees" && window.YuitorV32?.renderAiClassesTab) {
        window.YuitorV32.renderAiClassesTab(toolViewEl);
      } else if (valid === "quiz" && window.YuitorV32?.renderAiQuizTab) {
        window.YuitorV32.renderAiQuizTab(toolViewEl);
      } else if (valid === "notes" && window.YuitorV32?.renderAiNotesTab) {
        window.YuitorV32.renderAiNotesTab(toolViewEl);
      } else {
        toolViewEl.innerHTML = `<div style="padding:14px;color:#6B7280;font-size:12.5px;">Loading tool...</div>`;
      }
    }
  }

  tabBtns.forEach((b) => {
    b.addEventListener("click", () => switchTab(b.getAttribute("data-ai-tab")));
  });

  function clearPendingFile() {
    pendingFile = null;
    if (fileInput) fileInput.value = "";
    if (fileBar) {
      fileBar.hidden = true;
      fileBar.style.display = "none";
    }
  }

  function updateQuotaText(q) {
    if (!q || !quotaEl) return;
    latestQuota = q;
    const remQ = q.remainingQuestions !== undefined ? q.remainingQuestions : Math.max(0, (q.maxQuestions || 5) - (q.usedQuestions || 0));
    const remU = q.remainingUploads !== undefined ? q.remainingUploads : Math.max(0, (q.maxUploads || 2) - (q.usedUploads || 0));
    quotaEl.textContent = `Today left: ${remQ}/${q.maxQuestions || 5} Qs · ${remU}/${q.maxUploads || 2} Uploads (≤5 MB)`;
  }

  function appendRichMessageText(container, text) {
    container.textContent = "";
    const str = String(text || "");
    let lastIndex = 0;
    LINK_TOKEN_RE.lastIndex = 0;
    let match;
    while ((match = LINK_TOKEN_RE.exec(str)) !== null) {
      if (match.index > lastIndex) {
        container.appendChild(document.createTextNode(str.slice(lastIndex, match.index)));
      }
      const token = match[0];
      const a = document.createElement("a");
      a.textContent = token;
      if (token.startsWith("+91")) a.href = `tel:${token.replace(/[^+\d]/g, "")}`;
      else if (token.includes("@")) a.href = `mailto:${token}`;
      else a.href = token;
      a.style.cssText = "color:#7A0F28;font-weight:700;text-decoration:underline;text-underline-offset:2px;";
      container.appendChild(a);
      lastIndex = LINK_TOKEN_RE.lastIndex;
    }
    if (lastIndex < str.length) {
      container.appendChild(document.createTextNode(str.slice(lastIndex)));
    }
  }

  function renderCtaCard(cta) {
    if (!cta || !cta.classNumber) return null;
    const wrap = document.createElement("div");
    wrap.style.cssText =
      "align-self:stretch;background:#FFF7F8;border:1.5px solid #7A0F28;border-radius:12px;padding:10px;display:flex;flex-direction:column;gap:6px;";
    const title = document.createElement("div");
    title.style.cssText = "font-size:12.5px;font-weight:700;color:#7A0F28;";
    title.textContent = `${cta.classLabel}: ₹${cta.monthlyFee}/mo · Yearly ₹${Number(cta.yearlyFee || 0).toLocaleString("en-IN")} (10% OFF)`;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = cta.label || `Add ${cta.classLabel} to Cart`;
    btn.style.cssText =
      "background:#7A0F28;color:#fff;border:0;border-radius:8px;padding:8px 12px;font-weight:700;font-size:12.5px;cursor:pointer;";
    btn.addEventListener("click", async () => {
      if (cta.courseId && window.YuitorAddons && typeof window.YuitorAddons.addToCartAndOpen === "function") {
        await window.YuitorAddons.addToCartAndOpen(cta.courseId, "1m");
      } else {
        switchTab("fees");
      }
    });
    wrap.append(title, btn);
    return wrap;
  }

  function renderMessages(list) {
    msgsEl.innerHTML = "";
    const items = Array.isArray(list) && list.length ? list : [{ sender: "assistant", message: SHREYA_INTRO }];
    for (const m of items) {
      const div = document.createElement("div");
      const isUser = m.sender === "user";
      div.style.cssText = isUser
        ? "align-self:flex-end;background:#7A0F28;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;word-break:break-word;"
        : "align-self:flex-start;background:#fff;border:1px solid #EADFE2;color:#1D1014;padding:9px 11px;border-radius:12px;max-width:90%;white-space:pre-line;word-break:break-word;";
      if (isUser) div.textContent = m.message;
      else appendRichMessageText(div, m.message);
      msgsEl.appendChild(div);
    }
    if (latestCta) {
      const ctaEl = renderCtaCard(latestCta);
      if (ctaEl) msgsEl.appendChild(ctaEl);
    }
    if (isEscalated) {
      const escBanner = document.createElement("div");
      escBanner.style.cssText =
        "align-self:stretch;background:#fef3c7;border:1px solid #fcd34d;color:#92400e;padding:7px 10px;border-radius:10px;font-size:11.5px;font-weight:600;";
      appendRichMessageText(escBanner, "Flagged for Yuitor Team. Call +91 78-2728-9292 for urgent support.");
      msgsEl.appendChild(escBanner);
    }
    if (items.length <= 1) {
      const chipWrap = document.createElement("div");
      chipWrap.style.cssText = "display:flex;flex-wrap:wrap;gap:6px;margin-top:4px;";
      for (const label of STARTER_CHIPS) {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.textContent = label;
        chip.style.cssText =
          "background:#FFF7F8;color:#7A0F28;border:1px solid #E5C8D0;border-radius:999px;padding:5px 10px;font-size:11.5px;font-weight:600;cursor:pointer;text-align:left;";
        chip.addEventListener("click", () => sendMessage(label));
        chipWrap.appendChild(chip);
      }
      msgsEl.appendChild(chipWrap);
    }
    msgsEl.scrollTop = msgsEl.scrollHeight;
  }

  function renderStars() {
    starsWrap.innerHTML = "";
    for (let i = 1; i <= 5; i++) {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = i <= currentRating ? "★" : "☆";
      b.style.cssText = `background:none;border:0;font-size:16px;cursor:pointer;color:${i <= currentRating ? "#d97706" : "#94a3b8"};padding:0 2px;`;
      b.addEventListener("click", () => {
        currentRating = i;
        renderStars();
      });
      starsWrap.appendChild(b);
    }
  }
  renderStars();
  renderMessages(localMessages);

  function localFallbackReply(text) {
    const q = String(text || "").trim().toLowerCase();
    const m = q.match(/(?:class\s*)?(6|7|8|9|10|11|12)(?:th)?\b/);
    const fees = { 6: 600, 7: 650, 8: 700, 9: 750, 10: 800, 11: 850, 12: 900 };
    if (m && fees[Number(m[1])]) {
      const cls = Number(m[1]);
      const mo = fees[cls];
      const yr = Math.round(mo * 12 * 0.9);
      return `Class ${cls}th fee: ₹${mo}/month (1/3/6/9/12m). Yearly 12m plan is ₹${yr.toLocaleString("en-IN")} (10% OFF).`;
    }
    return "Class 6th–12th fees: 6th ₹600, 7th ₹650, 8th ₹700, 9th ₹750, 10th ₹800, 11th ₹850, 12th ₹900/mo (10% OFF on Yearly). Call +91 78-2728-9292.";
  }

  function getCsrfToken() {
    try {
      const m = document.cookie.match(/(?:^|;\s*)yu_csrf=([^;]+)/);
      return m ? decodeURIComponent(m[1]) : "";
    } catch {
      return "";
    }
  }

  async function safeFetchJson(url, payload) {
    const headers = { "Content-Type": "application/json", Accept: "application/json" };
    const csrf = getCsrfToken();
    if (csrf) headers["X-CSRF-Token"] = csrf;
    const res = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers,
      body: JSON.stringify(payload || {}),
    });
    const text = await res.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    return { ok: res.ok, status: res.status, data };
  }

  async function safeUploadFormData(url, formData) {
    const headers = { Accept: "application/json" };
    const csrf = getCsrfToken();
    if (csrf) headers["X-CSRF-Token"] = csrf;
    const res = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers,
      body: formData,
    });
    const text = await res.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    return { ok: res.ok, status: res.status, data };
  }

  async function ensureSession() {
    try {
      const { ok, data } = await safeFetchJson("/api/public/chatbot/session", { conversationId, visitorId });
      if (!ok) return;
      if (data?.conversation?.id) {
        conversationId = data.conversation.id;
        sessionStorage.setItem("yuitor_shreya_conv_id", conversationId);
      }
      if (Array.isArray(data?.messages) && data.messages.length) {
        renderMessages(data.messages);
      }
    } catch {
      // ignore
    }
  }

  attachBtn?.addEventListener("click", () => fileInput?.click());
  fileClearBtn?.addEventListener("click", clearPendingFile);
  fileInput?.addEventListener("change", () => {
    const f = fileInput.files && fileInput.files[0];
    if (!f) {
      clearPendingFile();
      return;
    }
    if (f.size > MAX_UPLOAD_BYTES) {
      clearPendingFile();
      const errDiv = document.createElement("div");
      errDiv.style.cssText =
        "align-self:stretch;background:#FEF2F2;border:1px solid #FCA5A5;color:#991B1B;padding:7px 10px;border-radius:10px;font-size:12px;";
      errDiv.textContent = "File rejected: maximum allowed size is strictly 5 MB (JPG, PNG, WebP, or PDF).";
      msgsEl.appendChild(errDiv);
      msgsEl.scrollTop = msgsEl.scrollHeight;
      return;
    }
    if ((f.type && !ALLOWED_MIMES.has(f.type.toLowerCase())) || !ALLOWED_EXTS.test(f.name)) {
      clearPendingFile();
      const errDiv = document.createElement("div");
      errDiv.style.cssText =
        "align-self:stretch;background:#FEF2F2;border:1px solid #FCA5A5;color:#991B1B;padding:7px 10px;border-radius:10px;font-size:12px;";
      errDiv.textContent = "Only JPG, PNG, WebP images or PDF files are allowed.";
      msgsEl.appendChild(errDiv);
      msgsEl.scrollTop = msgsEl.scrollHeight;
      return;
    }
    pendingFile = f;
    if (fileNameEl) fileNameEl.textContent = `${f.name} (${(f.size / 1024).toFixed(0)} KB)`;
    if (fileBar) {
      fileBar.hidden = false;
      fileBar.style.display = "flex";
    }
  });

  async function sendMessage(text) {
    if (activeTab !== "chat") switchTab("chat");
    const clean = String(text || "").trim();
    const attached = pendingFile;
    if ((!clean && !attached) || busy) return;
    busy = true;
    input.disabled = true;
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.style.opacity = "0.65";
    }
    const displayText = attached ? `${clean ? clean + "\n" : ""}[Attached: ${attached.name}]` : clean;
    localMessages.push({ sender: "user", message: displayText });

    const uBubble = document.createElement("div");
    uBubble.style.cssText =
      "align-self:flex-end;background:#7A0F28;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;word-break:break-word;";
    uBubble.textContent = displayText;
    msgsEl.appendChild(uBubble);

    const typing = document.createElement("div");
    typing.style.cssText =
      "align-self:flex-start;background:#fff;border:1px solid #EADFE2;color:#6E5A60;padding:7px 11px;border-radius:12px;font-size:12px;";
    typing.textContent = attached ? "Shreya is reading your uploaded question..." : "Shreya is typing...";
    msgsEl.appendChild(typing);
    msgsEl.scrollTop = msgsEl.scrollHeight;
    input.value = "";
    clearPendingFile();

    try {
      if (!conversationId) await ensureSession();
      const vName = box.querySelector("#yu-v-name").value.trim();
      const vPhone = box.querySelector("#yu-v-phone").value.trim();
      const vEmail = box.querySelector("#yu-v-email").value.trim();

      let resp;
      if (attached) {
        const fd = new FormData();
        fd.append("file", attached, attached.name);
        if (conversationId) fd.append("conversationId", conversationId);
        if (clean) fd.append("message", clean);
        if (vName) fd.append("visitorName", vName);
        if (vPhone) fd.append("visitorPhone", vPhone);
        if (vEmail) fd.append("visitorEmail", vEmail);
        resp = await safeUploadFormData("/api/public/chatbot/upload", fd);
      } else {
        const payload = {
          conversationId,
          message: clean,
          visitorName: vName || undefined,
          visitorPhone: vPhone || undefined,
          visitorEmail: vEmail || undefined,
        };
        resp = await safeFetchJson("/api/public/chatbot/message", payload);
      }

      const { ok, data } = resp;
      if (data?.conversationId) {
        conversationId = data.conversationId;
        sessionStorage.setItem("yuitor_shreya_conv_id", conversationId);
      }
      if (data?.quota) updateQuotaText(data.quota);
      latestCta = data?.cta || null;
      isEscalated = Boolean(data?.escalated);

      if (ok && Array.isArray(data?.messages) && data.messages.length) {
        renderMessages(data.messages);
      } else if (ok && data?.reply) {
        appendRichMessageText(typing, data.reply);
        typing.style.color = "#0f172a";
        if (latestCta) {
          const ctaEl = renderCtaCard(latestCta);
          if (ctaEl) msgsEl.appendChild(ctaEl);
        }
      } else if (data?.error) {
        typing.textContent = data.error;
        typing.style.color = "#991b1b";
      } else {
        const reply = localFallbackReply(clean);
        localMessages.push({ sender: "assistant", message: reply });
        appendRichMessageText(typing, reply);
        typing.style.color = "#0f172a";
      }
    } catch {
      const reply = localFallbackReply(clean);
      localMessages.push({ sender: "assistant", message: reply });
      appendRichMessageText(typing, reply);
      typing.style.color = "#0f172a";
    } finally {
      busy = false;
      input.disabled = false;
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.style.opacity = "1";
      }
      input.focus();
    }
  }

  function openShreyaBox(tab = null) {
    box.hidden = false;
    box.style.display = "flex";
    ensureSession();
    if (tab) {
      switchTab(tab);
    } else if (activeTab === "chat") {
      window.setTimeout(() => input.focus(), 60);
    }
  }
  function closeShreyaBox() {
    box.hidden = true;
    box.style.display = "none";
  }

  window.YuitorShreya = {
    open: openShreyaBox,
    close: closeShreyaBox,
    switchTab,
    toggle() {
      if (box.hidden) openShreyaBox();
      else closeShreyaBox();
    },
    isOpen() {
      return !box.hidden;
    },
  };

  toggle.addEventListener("click", () => window.YuitorShreya.toggle());
  closeBtn.addEventListener("click", () => closeShreyaBox());
  newBtn?.addEventListener("click", async () => {
    switchTab("chat");
    conversationId = "";
    isEscalated = false;
    latestCta = null;
    clearPendingFile();
    sessionStorage.removeItem("yuitor_shreya_conv_id");
    localMessages.length = 0;
    localMessages.push({ sender: "assistant", message: SHREYA_INTRO });
    renderMessages(localMessages);
    await ensureSession();
    input.focus();
  });
  infoBtn.addEventListener("click", () => {
    contactPanel.hidden = !contactPanel.hidden;
    contactPanel.style.display = contactPanel.hidden ? "none" : "grid";
  });
  rateBtn.addEventListener("click", () => {
    rateForm.hidden = !rateForm.hidden;
    rateForm.style.display = rateForm.hidden ? "none" : "grid";
  });
  rateForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      if (!conversationId) await ensureSession();
      await safeFetchJson("/api/public/chatbot/feedback", {
        conversationId,
        rating: currentRating,
        feedback: box.querySelector("#yu-fb-text").value.trim(),
        resolved: currentRating >= 4,
      });
    } catch {
      // ignore
    }
    rateForm.hidden = true;
    rateForm.style.display = "none";
    const note = document.createElement("div");
    note.style.cssText =
      "align-self:center;background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;padding:5px 10px;border-radius:999px;font-size:11.5px;font-weight:700;";
    note.textContent = `Thank you! Feedback saved (${currentRating}/5).`;
    msgsEl.appendChild(note);
    msgsEl.scrollTop = msgsEl.scrollHeight;
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendMessage(input.value);
  });
  void latestQuota;
})();
