(function () {
  "use strict";

  function esc(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function inr(v) {
    return "₹" + Math.round(Number(v || 0)).toLocaleString("en-IN");
  }

  function readCsrf() {
    const m = document.cookie.match(/(?:^|;\s*)yu_csrf=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : "";
  }

  async function apiJson(url, opts = {}) {
    const method = String(opts.method || "GET").toUpperCase();
    const headers = { ...(opts.headers || {}) };
    if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
      const csrf = readCsrf();
      if (csrf && !headers["X-CSRF-Token"]) headers["X-CSRF-Token"] = csrf;
    }
    let body = opts.body;
    if (body && typeof body === "object" && !(body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(body);
    }
    const resp = await fetch(url, { method, credentials: "same-origin", headers, body });
    const txt = await resp.text();
    let data = {};
    try {
      data = txt ? JSON.parse(txt) : {};
    } catch {
      data = { raw: txt };
    }
    if (!resp.ok) {
      throw new Error(data?.error || `Request failed (${resp.status})`);
    }
    return data;
  }

  function noticeHtml(okMsg, errMsg) {
    if (errMsg) return `<div class="portal-message portal-message--error" style="margin-bottom:12px;">${esc(errMsg)}</div>`;
    if (okMsg) return `<div class="portal-message portal-message--success" style="margin-bottom:12px;">${esc(okMsg)}</div>`;
    return "";
  }

  // ==================== 1. SMART DASHBOARD: TODAY'S DESK + LIVE KPI ALERTS + FOUNDER REPORT ====================
  async function mountSmartDashboardHeader(container, { adminApiUrl, onNavigate }) {
    if (!container) return;
    container.innerHTML = `<div class="crm-panel"><p class="crm-panel-sub">Loading Smart Operations Desk…</p></div>`;
    try {
      const data = await apiJson(adminApiUrl("/crm/dashboard"));
      const k = data.kpi || {};
      const cfg = data.config || {};
      const killBanner = Number(cfg.global_kill_switch) === 1
        ? `<div class="portal-message portal-message--error" style="margin-bottom:12px;"><strong>Automation Kill Switch Active:</strong> Automated outbound reminders and jobs are currently paused.</div>`
        : "";

      container.innerHTML = `
        <div class="crm-desk-wrap" data-testid="crm-smart-dashboard">
          ${killBanner}
          <section class="crm-panel" aria-label="Today's Desk Quick Actions">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Today's Desk — Daily Ops</h3>
              </div>
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-open-cmdbar>All Search (Ctrl+K)</button>
            </div>
            <div class="crm-desk-grid">
              <button type="button" class="crm-desk-btn" data-desk-nav="crm_fee_desk"><span>Quick Fee Collect</span><small>Cash / UPI / Receipt</small></button>
              <button type="button" class="crm-desk-btn" data-desk-nav="crm_leads"><span>Fast Admission</span><small>Convert Inquiry 1-Click</small></button>
              <button type="button" class="crm-desk-btn" data-desk-nav="crm_hub" data-desk-sub="attendance"><span>Take Batch Attendance</span><small>QR + Absent WhatsApp</small></button>
              <button type="button" class="crm-desk-btn" data-desk-nav="crm_fee_desk" data-desk-sub="monthly"><span>Send Due Reminders</span><small>Monthly Fee &amp; Alerts</small></button>
              <button type="button" class="crm-desk-btn" data-desk-nav="crm_bulk" data-desk-sub="actions"><span>Post Batch Notice</span><small>Bulk Student Broadcast</small></button>
              <a class="crm-desk-btn" href="${esc(adminApiUrl("/crm/bulk/export/collections?today=1"))}" style="text-decoration:none;"><span>Today's Collection CSV</span><small>Instant Accounting Export</small></a>
            </div>
          </section>

          <section class="crm-kpi-strip" aria-label="Live Daily KPI Alerts">
            <button type="button" class="crm-kpi-card" data-desk-nav="crm_leads" data-desk-sub="today_followups">
              <div>
                <div class="crm-kpi-val ${k.todaysFollowups > 0 ? "crm-state-warn" : "crm-state-ok"}">${Number(k.todaysFollowups || 0)}</div>
                <div class="crm-kpi-lbl">Today's Follow-ups</div>
              </div>
              <span class="crm-panel-sub">Open list</span>
            </button>
            <button type="button" class="crm-kpi-card" data-desk-nav="crm_hub" data-desk-sub="attendance">
              <div>
                <div class="crm-kpi-val ${k.absentStudents > 0 ? "crm-state-alert" : "crm-state-ok"}">${Number(k.absentStudents || 0)}</div>
                <div class="crm-kpi-lbl">Today's Absentees</div>
              </div>
              <span class="crm-panel-sub">Alert parents</span>
            </button>
            <button type="button" class="crm-kpi-card" data-desk-nav="crm_fee_desk">
              <div>
                <div class="crm-kpi-val ${k.feesDueToday > 0 ? "crm-state-alert" : "crm-state-ok"}">${Number(k.feesDueToday || 0)}</div>
                <div class="crm-kpi-lbl">Fees Due Today</div>
              </div>
              <span class="crm-panel-sub">Collect now</span>
            </button>
            <button type="button" class="crm-kpi-card" data-desk-nav="crm_teacher_ops">
              <div>
                <div class="crm-kpi-val ${k.pendingTeacherLeaves > 0 ? "crm-state-warn" : "crm-state-ok"}">${Number(k.pendingTeacherLeaves || 0)}</div>
                <div class="crm-kpi-lbl">Pending Teacher Leaves</div>
              </div>
              <span class="crm-panel-sub">Review</span>
            </button>
          </section>

          <section class="crm-panel" aria-label="Daily Digest Live Snapshot">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Daily Digest — Live Snapshot</h3>
              </div>
              <div class="crm-row-actions">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-desk-nav="crm_automation">Exceptions (${Number(k.openExceptions || 0)})</button>
                <button type="button" class="portal-button portal-button--small" data-gen-founder-report>Snapshot Daily Report</button>
              </div>
            </div>
            <div class="crm-founder-grid">
              <div class="crm-founder-cell"><span>Today Cash Collection</span><strong>${inr(k.cashCollection)}</strong></div>
              <div class="crm-founder-cell"><span>Today Online Collection</span><strong>${inr(k.onlineCollection)}</strong></div>
              <div class="crm-founder-cell"><span>Total Collected Today</span><strong>${inr(k.totalCollection)}</strong></div>
              <div class="crm-founder-cell"><span>New Inquiries / Admissions</span><strong>${Number(k.newInquiries || 0)} / ${Number(k.admissions || 0)}</strong></div>
              <div class="crm-founder-cell"><span>Total Pending Fees</span><strong>${inr(k.totalPendingFees)}</strong></div>
            </div>
            <div class="crm-panel-sub" style="margin-top:10px;">
              Teachers on Leave: <strong>${Number(k.teachersOnLeave || 0)}</strong> · Open Doubts: <strong>${Number(k.openDoubts || 0)}</strong> · Failed Automation Jobs: <strong>${Number(k.failedAutomations || 0)}</strong>
            </div>
          </section>
        </div>
      `;

      container.querySelector("[data-open-cmdbar]")?.addEventListener("click", () => openCommandBar());
      container.querySelectorAll("[data-desk-nav]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const targetTab = btn.getAttribute("data-desk-nav");
          const sub = btn.getAttribute("data-desk-sub") || "";
          if (sub) window.__YU_CRM_SUBTAB__ = sub;
          onNavigate?.({ tab: targetTab });
        });
      });
      container.querySelector("[data-gen-founder-report]")?.addEventListener("click", async (e) => {
        const b = e.currentTarget;
        b.disabled = true;
        b.textContent = "Saving…";
        try {
          await apiJson(adminApiUrl("/crm/founder-report/generate"), { method: "POST", body: { reportType: "founder_8pm" } });
          b.textContent = "Report Saved";
          setTimeout(() => { b.disabled = false; b.textContent = "Snapshot Daily Report"; }, 1800);
        } catch {
          b.disabled = false;
          b.textContent = "Snapshot Daily Report";
        }
      });
    } catch (err) {
      container.innerHTML = noticeHtml("", err.message);
    }
  }

  // ==================== 2. CTRL + K QUICK COMMAND BAR ====================
  let cmdBackdrop = null;
  let cmdConfig = null;
  let cmdKeyBound = false;

  function openCommandBar() {
    if (!cmdBackdrop || !cmdConfig) return;
    const gs = document.querySelector(".yu-gsearch-backdrop");
    if (gs) gs.hidden = true;
    cmdBackdrop.hidden = false;
    const inp = cmdBackdrop.querySelector(".crm-cmd-input");
    if (inp) {
      inp.value = "";
      inp.focus();
      runCommandSearch("");
    }
  }

  function closeCommandBar() {
    if (cmdBackdrop) cmdBackdrop.hidden = true;
  }

  async function runCommandSearch(query) {
    if (!cmdBackdrop || !cmdConfig) return;
    const body = cmdBackdrop.querySelector(".crm-cmd-body");
    body.innerHTML = `<p class="crm-panel-sub">Searching students &amp; batches…</p>`;
    try {
      const res = await apiJson(cmdConfig.adminApiUrl(`/crm/command-search?q=${encodeURIComponent(query)}`));
      const students = res.students || [];
      const batches = res.batches || [];
      if (!students.length) {
        body.innerHTML = `<p class="crm-panel-sub">No matching students found for "${esc(query)}". Try searching by name, roll number, phone, or batch.</p>`;
        return;
      }
      body.innerHTML = students
        .map(
          (s) => `
          <div class="crm-cmd-student" data-cmd-stu="${s.id}">
            <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;">
              <div>
                <strong>${esc(s.full_name)}</strong>
                <span class="crm-panel-sub"> · ${esc(s.roll_number || `YSC-${s.id}`)} · ${esc(s.phone || "-")} · ${esc(s.batch_name || "No Batch")}</span>
              </div>
              <strong class="crm-num ${Number(s.pending_fee) > 0 ? "crm-state-alert" : "crm-state-ok"}">Due: ${inr(s.pending_fee)}</strong>
            </div>
            <div class="crm-row-actions">
              <button type="button" class="portal-button portal-button--small" data-cmd-act="collect" data-sid="${s.id}" data-q="${esc(s.roll_number || s.phone)}">Collect Fee</button>
              ${s.whatsappFeeUrl ? `<a class="crm-wa-btn" href="${esc(s.whatsappFeeUrl)}" target="_blank" rel="noopener">WhatsApp Reminder</a>` : ""}
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cmd-act="present" data-sid="${s.id}">Mark Present</button>
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cmd-act="absent" data-sid="${s.id}">Mark Absent</button>
              <a class="portal-button portal-button--small portal-button--quiet" href="${esc(cmdConfig.adminApiUrl(`/crm/pdf/id-card/${s.id}`))}" target="_blank" rel="noopener">ID Card QR</a>
              ${s.last_payment_id ? `<a class="portal-button portal-button--small portal-button--quiet" href="${esc(cmdConfig.adminApiUrl(`/crm/pdf/receipt/${s.last_payment_id}`))}" target="_blank" rel="noopener">Print Receipt</a>` : ""}
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cmd-act="profile" data-sid="${s.id}">View Profile</button>
              ${
                batches.length
                  ? `<select class="portal-input" style="width:auto;padding:4px 8px;font-size:12px;" data-cmd-batch="${s.id}" aria-label="Change batch for ${esc(s.full_name)}">
                       <option value="">Change Batch…</option>
                       ${batches.map((b) => `<option value="${b.id}" ${Number(b.id) === Number(s.batch_id) ? "selected" : ""}>${esc(b.name)}</option>`).join("")}
                     </select>`
                  : ""
              }
            </div>
          </div>`
        )
        .join("");

      body.querySelectorAll("[data-cmd-act]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const act = btn.getAttribute("data-cmd-act");
          const sid = Number(btn.getAttribute("data-sid"));
          if (act === "collect") {
            window.__YU_CRM_FEE_LOOKUP__ = btn.getAttribute("data-q") || "";
            closeCommandBar();
            cmdConfig.onNavigate?.({ tab: "crm_fee_desk" });
          } else if (act === "profile") {
            closeCommandBar();
            cmdConfig.onNavigate?.({ tab: "users", role: "student" });
          } else if (act === "present" || act === "absent") {
            btn.disabled = true;
            const out = await apiJson(cmdConfig.adminApiUrl("/crm/quick-attendance"), {
              method: "POST",
              body: { studentId: sid, status: act }
            });
            btn.textContent = act === "present" ? "Marked Present" : "Marked Absent";
            if (out.waAbsentUrl) {
              const row = btn.closest(".crm-row-actions");
              if (row && !row.querySelector("[data-wa-absent-now]")) {
                const a = document.createElement("a");
                a.href = out.waAbsentUrl;
                a.target = "_blank";
                a.rel = "noopener";
                a.className = "crm-wa-btn";
                a.setAttribute("data-wa-absent-now", "1");
                a.textContent = "Send Absent WhatsApp";
                row.appendChild(a);
              }
            }
          }
        });
      });

      body.querySelectorAll("[data-cmd-batch]").forEach((sel) => {
        sel.addEventListener("change", async () => {
          const bid = Number(sel.value);
          const sid = Number(sel.getAttribute("data-cmd-batch"));
          if (!bid) return;
          await apiJson(cmdConfig.adminApiUrl("/crm/quick-batch-change"), { method: "POST", body: { studentId: sid, batchId: bid } });
          runCommandSearch(query);
        });
      });
    } catch (err) {
      body.innerHTML = noticeHtml("", err.message);
    }
  }

  function mountCtrlKCommandBar({ adminApiUrl, onNavigate }) {
    cmdConfig = { adminApiUrl, onNavigate };
    if (window.__YU_ADMIN_GATE__) {
      const shreyaFab = document.getElementById("yu-ai-guide-root");
      if (shreyaFab) shreyaFab.style.display = "none";
    }
    if (!cmdBackdrop) {
      cmdBackdrop = document.createElement("div");
      cmdBackdrop.className = "crm-cmd-backdrop";
      cmdBackdrop.hidden = true;
      cmdBackdrop.setAttribute("role", "dialog");
      cmdBackdrop.setAttribute("aria-modal", "true");
      cmdBackdrop.setAttribute("aria-label", "Quick Command Bar");
      cmdBackdrop.innerHTML = `
        <div class="crm-cmd-dialog">
          <div class="crm-cmd-input-row">
            <input type="search" class="crm-cmd-input" placeholder="Search student name, roll number, phone, or batch… (Esc to close)" aria-label="Search students or batches" />
            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cmd-global>All Pages Search</button>
            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cmd-close>Esc</button>
          </div>
          <div class="crm-cmd-jumps" role="navigation" aria-label="Quick Module Jumps">
            <button type="button" class="crm-cmd-jump" data-cmd-nav="crm_fee_desk">Quick Fee Desk</button>
            <button type="button" class="crm-cmd-jump" data-cmd-nav="crm_leads">Leads &amp; Admissions</button>
            <button type="button" class="crm-cmd-jump" data-cmd-nav="crm_hub">Academic Hub</button>
            <button type="button" class="crm-cmd-jump" data-cmd-nav="crm_bulk">Bulk CSV Tools</button>
            <button type="button" class="crm-cmd-jump" data-cmd-nav="crm_automation">Automation &amp; Exceptions</button>
          </div>
          <div class="crm-cmd-body"></div>
        </div>
      `;
      cmdBackdrop.addEventListener("click", (e) => {
        if (e.target === cmdBackdrop) closeCommandBar();
      });
      cmdBackdrop.querySelector("[data-cmd-close]").addEventListener("click", closeCommandBar);
      cmdBackdrop.querySelector("[data-cmd-global]").addEventListener("click", () => {
        closeCommandBar();
        if (window.YuitorAddons?.openGlobalSearch) {
          window.YuitorAddons.openGlobalSearch({ adminApiUrl: cmdConfig.adminApiUrl, onNavigate: cmdConfig.onNavigate });
        }
      });
      cmdBackdrop.querySelectorAll("[data-cmd-nav]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const tab = btn.getAttribute("data-cmd-nav");
          closeCommandBar();
          cmdConfig?.onNavigate?.({ tab });
        });
      });
      let debounce = null;
      cmdBackdrop.querySelector(".crm-cmd-input").addEventListener("input", (e) => {
        clearTimeout(debounce);
        const val = e.target.value;
        debounce = setTimeout(() => runCommandSearch(val), 180);
      });
      document.body.appendChild(cmdBackdrop);
    }
    if (!cmdKeyBound) {
      cmdKeyBound = true;
      window.addEventListener("keydown", (e) => {
        if ((e.ctrlKey || e.metaKey) && String(e.key).toLowerCase() === "k") {
          e.preventDefault();
          if (cmdBackdrop && !cmdBackdrop.hidden) closeCommandBar();
          else openCommandBar();
        } else if (e.key === "Escape" && cmdBackdrop && !cmdBackdrop.hidden) {
          closeCommandBar();
        }
      });
    }
  }

  // ==================== 3. QUICK FEE COLLECTION DESK + MONTHLY GENERATOR + APPROVALS ====================
  async function renderQuickFeeDesk(container, { adminApiUrl }) {
    let query = window.__YU_CRM_FEE_LOOKUP__ || "";
    window.__YU_CRM_FEE_LOOKUP__ = "";
    let matches = [];
    let lastReceipt = null;
    let approvals = [];
    let okMsg = "";
    let errMsg = "";

    async function load() {
      try {
        const apprRes = await apiJson(adminApiUrl("/crm/financial-approvals"));
        approvals = apprRes.approvals || [];
        if (query) {
          const lk = await apiJson(adminApiUrl(`/crm/fee-desk/lookup?q=${encodeURIComponent(query)}`));
          matches = lk.matches || [];
        }
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          <section class="crm-panel">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Quick Fee Collection Counter</h3>
                <p class="crm-panel-sub">Enter roll number, mobile number, or name → record Cash / UPI / Cheque / Online payment → instant PDF receipt &amp; WhatsApp share</p>
              </div>
              <form data-monthly-gen-form class="crm-row-actions">
                <input type="month" name="billingMonth" class="portal-input" style="width:auto;" value="${new Date().toISOString().slice(0, 7)}" aria-label="Billing month" />
                <button type="submit" class="portal-button portal-button--small">Generate Monthly Invoices</button>
              </form>
            </div>
            <form data-fee-lookup-form class="crm-row-actions" style="margin-bottom:14px;">
              <input type="search" name="q" class="portal-input" style="flex:1;min-width:240px;" value="${esc(query)}" placeholder="Enter Roll No (e.g. YSC26...), 10-digit Phone, or Student Name…" required />
              <button type="submit" class="portal-button">Find Student</button>
            </form>

            ${
              lastReceipt
                ? `<div class="portal-message portal-message--success" style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px;">
                     <div><strong>Payment Confirmed:</strong> Receipt ${esc(lastReceipt.receiptNumber)} · Paid ${inr(lastReceipt.amount)} · Remaining Balance ${inr(lastReceipt.outstandingBalance)}</div>
                     <div class="crm-row-actions">
                       <a class="portal-button portal-button--small" href="${esc(adminApiUrl(`/crm/pdf/receipt/${lastReceipt.paymentId}`))}" target="_blank" rel="noopener">Print / PDF Receipt</a>
                       ${lastReceipt.whatsappReceiptUrl ? `<a class="crm-wa-btn" href="${esc(lastReceipt.whatsappReceiptUrl)}" target="_blank" rel="noopener">Share on WhatsApp</a>` : ""}
                     </div>
                   </div>`
                : ""
            }

            ${
              matches.length
                ? matches
                    .map(
                      (s) => `
                    <div class="crm-panel" style="margin-bottom:12px;">
                      <div class="crm-panel-head">
                        <div>
                          <strong>${esc(s.full_name)}</strong>
                          <span class="crm-panel-sub"> · Roll: ${esc(s.roll_number || `YSC-${s.id}`)} · Phone: ${esc(s.phone)} · Batch: ${esc(s.batch_name || "Unassigned")}</span>
                        </div>
                        <div class="crm-row-actions">
                          <strong class="crm-num ${s.outstanding > 0 ? "crm-state-alert" : "crm-state-ok"}">Outstanding: ${inr(s.outstanding)}</strong>
                          ${s.whatsappReminderUrl ? `<a class="crm-wa-btn" href="${esc(s.whatsappReminderUrl)}" target="_blank" rel="noopener">WhatsApp Due Reminder</a>` : ""}
                        </div>
                      </div>
                      <form data-collect-fee-form="${s.id}" class="crm-grid-3">
                        <input type="hidden" name="studentId" value="${s.id}" />
                        <input type="hidden" name="idempotencyKey" value="desk-${s.id}-${Date.now()}" />
                        <label class="portal-field"><span>Amount (INR)</span><input type="number" name="amount" min="1" class="portal-input" value="${s.outstanding > 0 ? s.outstanding : 1400}" required /></label>
                        <label class="portal-field"><span>Payment Mode</span>
                          <select name="paymentMethod" class="portal-input">
                            <option value="cash">Cash Counter</option>
                            <option value="upi">UPI QR / Transfer</option>
                            <option value="cheque">Cheque</option>
                            <option value="online">Verified Online Gateway</option>
                          </select>
                        </label>
                        <label class="portal-field"><span>UTR / Cheque / Ref (Optional for Cash)</span><input type="text" name="utrReference" class="portal-input" placeholder="UTR / Ref No" /></label>
                        <div style="grid-column:1/-1;" class="crm-row-actions">
                          <button type="submit" class="portal-button">Confirm &amp; Generate Receipt</button>
                          <a class="portal-button portal-button--small portal-button--quiet" href="${esc(adminApiUrl(`/crm/pdf/id-card/${s.id}`))}" target="_blank" rel="noopener">Student ID Card</a>
                          <a class="portal-button portal-button--small portal-button--quiet" href="${esc(adminApiUrl(`/crm/pdf/report-card/${s.id}`))}" target="_blank" rel="noopener">Report Card PDF</a>
                        </div>
                      </form>
                    </div>`
                    )
                    .join("")
                : `<p class="crm-panel-sub">${query ? "No student found matching your search." : "Search any student by roll number or phone above to collect fees in seconds."}</p>`
            }
          </section>

          <section class="crm-panel">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Financial Approval Controls (Discounts, Waivers &amp; Refunds)</h3>
                <p class="crm-panel-sub">All fee adjustments require explicit administrator approval with immutable audit logs</p>
              </div>
            </div>
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>ID</th><th>Type</th><th>Student</th><th>Amount</th><th>Reason</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                  ${
                    approvals.length
                      ? approvals
                          .map(
                            (a) => `<tr>
                              <td class="crm-num">#${a.id}</td>
                              <td>${esc(a.request_type)}</td>
                              <td>${esc(a.student_name || `Student #${a.student_id}`)}</td>
                              <td class="crm-num">${inr(a.amount)}</td>
                              <td>${esc(a.reason)}</td>
                              <td>${esc(a.status)}</td>
                              <td>${
                                a.status === "pending"
                                  ? `<div class="crm-row-actions">
                                       <button type="button" class="portal-button portal-button--small" data-fin-decide="${a.id}" data-decision="approved">Approve</button>
                                       <button type="button" class="portal-button portal-button--small portal-button--quiet" data-fin-decide="${a.id}" data-decision="rejected">Reject</button>
                                     </div>`
                                  : esc(a.review_note || "Reviewed")
                              }</td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="7" class="portal-empty">No pending financial approval requests.</td></tr>`
                  }
                </tbody>
              </table>
            </div>
          </section>
        </div>
      `;

      container.querySelector("[data-fee-lookup-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        query = String(new FormData(e.currentTarget).get("q") || "").trim();
        await load();
      });

      container.querySelector("[data-monthly-gen-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        const fd = new FormData(e.currentTarget);
        try {
          const out = await apiJson(adminApiUrl("/crm/fee-desk/generate-monthly"), {
            method: "POST",
            body: { billingMonth: fd.get("billingMonth") }
          });
          okMsg = `Monthly fees for ${out.billingMonth}: Created ${out.created} invoice(s), skipped ${out.skipped} existing (duplicate-safe).`;
        } catch (err) {
          errMsg = err.message;
        }
        draw();
      });

      container.querySelectorAll("[data-collect-fee-form]").forEach((form) => {
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          okMsg = "";
          errMsg = "";
          const fd = new FormData(form);
          try {
            lastReceipt = await apiJson(adminApiUrl("/crm/fee-desk/collect"), {
              method: "POST",
              body: {
                studentId: Number(fd.get("studentId")),
                amount: Number(fd.get("amount")),
                paymentMethod: fd.get("paymentMethod"),
                utrReference: fd.get("utrReference"),
                idempotencyKey: fd.get("idempotencyKey")
              }
            });
            okMsg = `Fee recorded successfully (${lastReceipt.receiptNumber}).`;
            await load();
          } catch (err) {
            errMsg = err.message;
            draw();
          }
        });
      });

      container.querySelectorAll("[data-fin-decide]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await apiJson(adminApiUrl(`/crm/financial-approvals/${btn.getAttribute("data-fin-decide")}/decide`), {
            method: "POST",
            body: { decision: btn.getAttribute("data-decision") }
          });
          okMsg = "Financial decision recorded in audit log.";
          await load();
        });
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  // ==================== 4. INQUIRY & ADMISSION CRM PIPELINE ====================
  async function renderLeadsCrm(container, { adminApiUrl }) {
    let filter = window.__YU_CRM_SUBTAB__ === "today_followups" ? "today_followups" : "all";
    window.__YU_CRM_SUBTAB__ = "";
    let data = { leads: [], tasks: [] };
    let okMsg = "";
    let errMsg = "";

    async function load() {
      try {
        data = await apiJson(adminApiUrl(`/crm/leads?filter=${encodeURIComponent(filter)}`));
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          <section class="crm-panel">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Add New Coaching Lead (Duplicate-Checked &amp; Auto-Scored)</h3>
                <p class="crm-panel-sub">Supports Walk-in QR, Website, Facebook Ads, Google Ads, WhatsApp, and Missed Calls</p>
              </div>
            </div>
            <form data-new-lead-form class="crm-grid-3">
              <label class="portal-field"><span>Student Name</span><input name="name" class="portal-input" required placeholder="Full name" /></label>
              <label class="portal-field"><span>Mobile Number</span><input name="phone" class="portal-input" required placeholder="10-digit mobile" /></label>
              <label class="portal-field"><span>Target Class / Exam</span><input name="classOrCourse" class="portal-input" value="Class 10 Board" /></label>
              <label class="portal-field"><span>Lead Source</span>
                <select name="source" class="portal-input">
                  <option value="walk_in">Walk-in / QR Counter</option>
                  <option value="website">Website Form</option>
                  <option value="whatsapp">WhatsApp</option>
                  <option value="facebook_ads">Facebook Ads</option>
                  <option value="google_ads">Google Ads</option>
                  <option value="missed_call">Missed Call</option>
                </select>
              </label>
              <label class="portal-field"><span>Next Follow-up Date</span><input type="date" name="followUpDate" class="portal-input" value="${esc(data.today || "")}" /></label>
              <label class="portal-field"><span>Demo Class Date (Optional)</span><input type="date" name="demoDate" class="portal-input" /></label>
              <div style="grid-column:1/-1;"><button type="submit" class="portal-button">Save Lead &amp; Start 15-Min SLA</button></div>
            </form>
          </section>

          <section class="crm-panel">
            <div class="crm-panel-head">
              <h3 class="crm-panel-title">Inquiry Pipeline &amp; 1-Click Admission Conversion</h3>
              <div class="crm-tabs" style="margin:0;">
                ${[
                  ["all", "All Leads"],
                  ["today_followups", "Today's Follow-ups"],
                  ["demo", "Demo Scheduled"],
                  ["hot", "Hot Leads (70+)"]
                ]
                  .map(([k, lbl]) => `<button type="button" class="crm-tab-btn ${filter === k ? "is-active" : ""}" data-lead-filter="${k}">${lbl}</button>`)
                  .join("")}
              </div>
            </div>
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Score</th><th>Lead</th><th>Course / Source</th><th>Follow-up / Demo</th><th>Status</th><th>Quick Actions</th></tr></thead>
                <tbody>
                  ${
                    (data.leads || []).length
                      ? data.leads
                          .map(
                            (l) => `<tr>
                              <td class="crm-num"><strong>${Number(l.lead_score || 40)}</strong>/100</td>
                              <td><strong>${esc(l.name)}</strong><div class="crm-panel-sub">${esc(l.phone)}</div></td>
                              <td>${esc(l.class_or_course || "-")}<div class="crm-panel-sub">${esc(l.source || "website")}</div></td>
                              <td class="crm-num">${esc(l.follow_up_date || "-")}${l.demo_date ? `<div class="crm-panel-sub">Demo: ${esc(l.demo_date)}</div>` : ""}</td>
                              <td>${esc(l.status)}</td>
                              <td>
                                <div class="crm-row-actions">
                                  ${l.whatsappUrl ? `<a class="crm-wa-btn" href="${esc(l.whatsappUrl)}" target="_blank" rel="noopener">WhatsApp</a>` : ""}
                                  ${
                                    l.status !== "admitted"
                                      ? `<button type="button" class="portal-button portal-button--small" data-convert-lead="${l.id}">Convert to Student</button>`
                                      : `<span class="crm-state-ok">Admitted</span>`
                                  }
                                </div>
                              </td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="6" class="portal-empty">No leads in this view.</td></tr>`
                  }
                </tbody>
              </table>
            </div>
          </section>
        </div>
      `;

      container.querySelectorAll("[data-lead-filter]").forEach((btn) => {
        btn.addEventListener("click", () => {
          filter = btn.getAttribute("data-lead-filter");
          load();
        });
      });

      container.querySelector("[data-new-lead-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        const fd = new FormData(e.currentTarget);
        try {
          const out = await apiJson(adminApiUrl("/crm/leads"), {
            method: "POST",
            body: Object.fromEntries(fd.entries())
          });
          okMsg = `Lead #${out.id} saved with Lead Score ${out.leadScore}/100 (${out.priority}).`;
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelectorAll("[data-convert-lead]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          btn.disabled = true;
          okMsg = "";
          errMsg = "";
          try {
            const out = await apiJson(adminApiUrl(`/crm/leads/${btn.getAttribute("data-convert-lead")}/convert`), { method: "POST", body: {} });
            okMsg = `Converted to Student #${out.studentId} (Roll: ${out.rollNumber}${out.waitlisted ? ", Batch Full -> Added to Waitlist" : ""}). Portal login & checklist created!`;
            await load();
          } catch (err) {
            errMsg = err.message;
            draw();
          }
        });
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  // ==================== 5. ONLINE, CBT, DPP, DOUBTS & ATTENDANCE HUB ====================
  async function renderOnlineAcademicHub(container, { adminApiUrl }) {
    let sub = window.__YU_CRM_SUBTAB__ || "live";
    window.__YU_CRM_SUBTAB__ = "";
    let liveRes = { slots: [], teachers: [] };
    let cbtRes = { exams: [] };
    let matRes = { materials: [] };
    let doubtRes = { doubts: [] };
    let studentsList = [];
    let okMsg = "";
    let errMsg = "";
    let qrScanResult = null;

    async function load() {
      try {
        [liveRes, cbtRes, matRes, doubtRes] = await Promise.all([
          apiJson(adminApiUrl("/crm/live-classes")),
          apiJson(adminApiUrl("/crm/cbt/exams")),
          apiJson(adminApiUrl("/crm/materials")),
          apiJson(adminApiUrl("/crm/doubts"))
        ]);
        const cmdRes = await apiJson(adminApiUrl("/crm/command-search?q="));
        studentsList = cmdRes.students || [];
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          <div class="crm-tabs" role="tablist">
            ${[
              ["live", "Live Classes & Timetable"],
              ["cbt", "Competitive CBT Exams"],
              ["dpp", "DPP & Study Material Locker"],
              ["doubts", `Doubt Counter (${(doubtRes.doubts || []).filter((d) => d.status !== "answered" && d.status !== "resolved").length})`],
              ["attendance", "QR Attendance & Printable PDFs"]
            ]
              .map(([k, lbl]) => `<button type="button" class="crm-tab-btn ${sub === k ? "is-active" : ""}" data-hub-tab="${k}">${lbl}</button>`)
              .join("")}
          </div>

          ${
            sub === "live"
              ? `<section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">Schedule Hybrid / Online Live Class (With Clash Detection)</h3></div>
                   <form data-live-form class="crm-grid-3" style="margin-bottom:14px;">
                     <label class="portal-field"><span>Subject</span><input name="subjectName" class="portal-input" required placeholder="Physics / Maths" /></label>
                     <label class="portal-field"><span>Day</span>
                       <select name="dayOfWeek" class="portal-input">${["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"].map((d) => `<option>${d}</option>`).join("")}</select>
                     </label>
                     <label class="portal-field"><span>Mode</span>
                       <select name="mode" class="portal-input"><option value="hybrid">Hybrid</option><option value="online">Online</option><option value="offline">Offline</option></select>
                     </label>
                     <label class="portal-field"><span>Start Time</span><input type="time" name="startTime" class="portal-input" value="16:00" required /></label>
                     <label class="portal-field"><span>End Time</span><input type="time" name="endTime" class="portal-input" value="17:00" required /></label>
                     <label class="portal-field"><span>Platform</span>
                       <select name="meetingPlatform" class="portal-input"><option value="google_meet">Google Meet</option><option value="zoom">Zoom</option><option value="youtube_unlisted">YouTube Unlisted</option></select>
                     </label>
                     <label class="portal-field" style="grid-column:1/-1;"><span>Live Class URL</span><input type="url" name="meetingUrl" class="portal-input" placeholder="https://meet.google.com/..." /></label>
                     <div><button type="submit" class="portal-button">Add Class &amp; Check Clashes</button></div>
                   </form>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Day &amp; Time</th><th>Subject</th><th>Mode / Room</th><th>Live Link</th><th>Teacher / Substitute</th></tr></thead>
                       <tbody>
                         ${(liveRes.slots || []).map((s) => `<tr>
                           <td class="crm-num">${esc(s.day_of_week)} · ${esc(s.start_time)}–${esc(s.end_time)}</td>
                           <td><strong>${esc(s.subject_name)}</strong></td>
                           <td>${esc(s.mode)} · ${esc(s.room_name)}</td>
                           <td>${s.meeting_url ? `<a href="${esc(s.meeting_url)}" target="_blank" rel="noopener">Open ${esc(s.meeting_platform)}</a>` : "Offline only"}</td>
                           <td>${esc(s.substitute_name ? `${s.substitute_name} (Sub)` : s.teacher_name || "Assigned")}</td>
                         </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No live or hybrid classes scheduled yet.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>`
              : ""
          }

          ${
            sub === "cbt"
              ? `<section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">Create Competitive CBT Exam (JEE / NEET / CUET / SSC)</h3></div>
                   <form data-cbt-form class="crm-grid-3" style="margin-bottom:14px;">
                     <label class="portal-field"><span>Exam Title</span><input name="title" class="portal-input" required placeholder="JEE Physics Full Mock 01" /></label>
                     <label class="portal-field"><span>Subject</span><input name="subjectName" class="portal-input" value="Physics" /></label>
                     <label class="portal-field"><span>Duration (Minutes)</span><input type="number" name="durationMinutes" class="portal-input" value="30" min="5" /></label>
                     <label class="portal-field"><span>Positive Marks</span><input type="number" step="0.5" name="positiveMarks" class="portal-input" value="4" /></label>
                     <label class="portal-field"><span>Negative Marks</span><input type="number" step="0.25" name="negativeMarks" class="portal-input" value="1" /></label>
                     <label class="portal-field"><span>Pattern</span><input name="examPattern" class="portal-input" value="JEE/NEET (+4/-1)" /></label>
                     <label class="portal-field" style="grid-column:1/-1;"><span>Bulk Questions CSV (question,option_a,option_b,option_c,option_d,correct_answer,topic)</span>
                       <textarea name="questionsCsv" class="portal-input" rows="4">question,option_a,option_b,option_c,option_d,correct_answer,topic
SI unit of Force is?,Joule,Newton,Watt,Pascal,Newton,Mechanics
Value of g on Earth surface (m/s^2)?,8.9,9.8,10.8,6.67,9.8,Gravitation</textarea>
                     </label>
                     <div><button type="submit" class="portal-button">Publish CBT Exam</button></div>
                   </form>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Title</th><th>Pattern</th><th>Duration</th><th>Max Marks</th><th>Attempts</th></tr></thead>
                       <tbody>
                         ${(cbtRes.exams || []).map((q) => `<tr><td><strong>${esc(q.title)}</strong></td><td>${esc(q.exam_pattern || "+4/-1")}</td><td class="crm-num">${Number(q.duration_minutes || 30)} min</td><td class="crm-num">${Number(q.max_marks || 0)}</td><td class="crm-num">${Number(q.attempt_count || 0)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No CBT exams created yet.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>`
              : ""
          }

          ${
            sub === "dpp"
              ? `<section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">DPP, Notes &amp; Study Material Locker (Batch-Locked)</h3></div>
                   <form data-dpp-form class="crm-grid-3" style="margin-bottom:14px;">
                     <label class="portal-field"><span>Material Title</span><input name="title" class="portal-input" required placeholder="Electrostatics DPP #04" /></label>
                     <label class="portal-field"><span>Type</span>
                       <select name="materialType" class="portal-input"><option value="dpp">Daily Practice Problem (DPP)</option><option value="notes">Chapter Notes PDF</option><option value="pyq">Previous Year Papers</option><option value="homework">Homework</option><option value="assignment">Assignment</option></select>
                     </label>
                     <label class="portal-field"><span>Subject</span><input name="subjectName" class="portal-input" value="Mathematics" /></label>
                     <label class="portal-field"><span>Chapter</span><input name="chapterName" class="portal-input" value="Chapter 1" /></label>
                     <label class="portal-field" style="grid-column:span 2;"><span>PDF / Resource Link</span><input name="fileUrl" class="portal-input" placeholder="/uploads/... or Google Drive PDF link" /></label>
                     <div><button type="submit" class="portal-button">Add to Locker</button></div>
                   </form>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Title</th><th>Type</th><th>Subject / Chapter</th><th>Resource</th></tr></thead>
                       <tbody>
                         ${(matRes.materials || []).map((m) => `<tr><td><strong>${esc(m.title)}</strong></td><td>${esc(m.material_type)}</td><td>${esc(m.subject_name)} · ${esc(m.chapter_name)}</td><td>${m.file_url ? `<a href="${esc(m.file_url)}" target="_blank" rel="noopener">Open File</a>` : "Attached text"}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No DPP or notes uploaded yet.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>`
              : ""
          }

          ${
            sub === "doubts"
              ? `<section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">Student Doubt Counter (12-Hour SLA Monitor)</h3></div>
                   ${(doubtRes.doubts || []).length
                     ? doubtRes.doubts
                         .map(
                           (d) => `<div class="crm-panel" style="margin-bottom:10px;">
                             <div class="crm-panel-head">
                               <div><strong>#${d.id} · ${esc(d.student_name)}</strong> <span class="crm-panel-sub">· ${esc(d.subject_name)} ${d.chapter_name ? `(${esc(d.chapter_name)})` : ""} · Assigned: ${esc(d.teacher_name || "Faculty")}</span></div>
                               <span class="${d.status === "escalated" ? "crm-state-alert" : d.status === "answered" ? "crm-state-ok" : "crm-state-warn"}">${esc(d.status)}</span>
                             </div>
                             <p style="margin:0 0 8px;font-size:13px;">${esc(d.question_text)}</p>
                             ${
                               d.reply_text
                                 ? `<div class="portal-message portal-message--success"><strong>Solution:</strong> ${esc(d.reply_text)}</div>`
                                 : `<form data-doubt-reply="${d.id}" class="crm-row-actions">
                                      <input name="replyText" class="portal-input" style="flex:1;" placeholder="Write solution explanation or paste link…" required />
                                      <button type="submit" class="portal-button portal-button--small">Send Reply</button>
                                    </form>`
                             }
                           </div>`
                         )
                         .join("")
                     : `<p class="crm-panel-sub">No student doubts pending.</p>`}
                 </section>`
              : ""
          }

          ${
            sub === "attendance"
              ? `<section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">QR ID Card Scanner &amp; Branded Printable PDFs</h3></div>
                   <form data-qr-scan-form class="crm-row-actions" style="margin-bottom:14px;">
                     <input name="qrCode" class="portal-input" style="flex:1;" placeholder="Scan Student ID QR (YUITOR:STU:...) or enter Roll Number to mark Present…" required />
                     <button type="submit" class="portal-button">Mark Present via QR</button>
                   </form>
                   ${qrScanResult ? `<div class="portal-message portal-message--success" style="margin-bottom:12px;">Marked <strong>${esc(qrScanResult.student.full_name)}</strong> Present for ${esc(qrScanResult.attDate)}.</div>` : ""}
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Student</th><th>Roll No</th><th>Batch</th><th>Printable PDFs (Official Yuitor Logo)</th></tr></thead>
                       <tbody>
                         ${studentsList
                           .map(
                             (s) => `<tr>
                               <td><strong>${esc(s.full_name)}</strong></td>
                               <td class="crm-num">${esc(s.roll_number || `YSC-${s.id}`)}</td>
                               <td>${esc(s.batch_name || "Unassigned")}</td>
                               <td>
                                 <div class="crm-row-actions">
                                   <a class="portal-button portal-button--small portal-button--quiet" href="${esc(adminApiUrl(`/crm/pdf/id-card/${s.id}`))}" target="_blank" rel="noopener">ID Card QR</a>
                                   <a class="portal-button portal-button--small portal-button--quiet" href="${esc(adminApiUrl(`/crm/pdf/admit-card/${s.id}`))}" target="_blank" rel="noopener">Admit Card</a>
                                   <a class="portal-button portal-button--small portal-button--quiet" href="${esc(adminApiUrl(`/crm/pdf/report-card/${s.id}`))}" target="_blank" rel="noopener">Progress Report</a>
                                 </div>
                               </td>
                             </tr>`
                           )
                           .join("") || `<tr><td colspan="4" class="portal-empty">No students available yet.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>`
              : ""
          }
        </div>
      `;

      container.querySelectorAll("[data-hub-tab]").forEach((btn) => {
        btn.addEventListener("click", () => {
          sub = btn.getAttribute("data-hub-tab");
          draw();
        });
      });

      container.querySelector("[data-live-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        try {
          await apiJson(adminApiUrl("/crm/live-classes"), { method: "POST", body: Object.fromEntries(new FormData(e.currentTarget).entries()) });
          okMsg = "Live class scheduled cleanly (zero timetable clashes).";
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelector("[data-cbt-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        try {
          const out = await apiJson(adminApiUrl("/crm/cbt/exams"), { method: "POST", body: Object.fromEntries(new FormData(e.currentTarget).entries()) });
          okMsg = `Published CBT Exam #${out.id} (${out.questionCount} questions, ${out.maxMarks} max marks).`;
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelector("[data-dpp-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        try {
          await apiJson(adminApiUrl("/crm/materials"), { method: "POST", body: Object.fromEntries(new FormData(e.currentTarget).entries()) });
          okMsg = "Study material added to batch-locked locker.";
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelectorAll("[data-doubt-reply]").forEach((form) => {
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          const id = form.getAttribute("data-doubt-reply");
          await apiJson(adminApiUrl(`/crm/doubts/${id}/reply`), { method: "POST", body: { replyText: new FormData(form).get("replyText") } });
          okMsg = `Doubt #${id} answered.`;
          await load();
        });
      });

      container.querySelector("[data-qr-scan-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        try {
          qrScanResult = await apiJson(adminApiUrl("/crm/attendance/qr-scan"), { method: "POST", body: { qrCode: new FormData(e.currentTarget).get("qrCode") } });
          draw();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  // ==================== 6. BULK IMPORT / EXPORT & BULK BATCH ACTIONS ====================
  async function renderBulkImportExport(container, { adminApiUrl }) {
    let preview = null;
    let csvText = "full_name,phone,class_level,board,parent_name,parent_phone\nAarav Sharma,9876543210,Class 10,CBSE,Rajesh Sharma,9876543211";
    let entity = "students";
    let students = [];
    let batches = [];
    let okMsg = "";
    let errMsg = "";

    async function load() {
      try {
        const res = await apiJson(adminApiUrl("/crm/command-search?q="));
        students = res.students || [];
        batches = res.batches || [];
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          <section class="crm-panel">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Accounting-Ready One-Click CSV / Excel Exports</h3>
                <p class="crm-panel-sub">Download audit-logged spreadsheets for CA accounting, fee registers, defaulters, and attendance</p>
              </div>
            </div>
            <div class="crm-row-actions">
              <a class="portal-button portal-button--small" href="${esc(adminApiUrl("/crm/bulk/export/fee_register"))}">Export Fee Register</a>
              <a class="portal-button portal-button--small" href="${esc(adminApiUrl("/crm/bulk/export/defaulters"))}">Export Defaulter List</a>
              <a class="portal-button portal-button--small" href="${esc(adminApiUrl("/crm/bulk/export/collections"))}">Export Collections</a>
              <a class="portal-button portal-button--small" href="${esc(adminApiUrl("/crm/bulk/export/income_expense"))}">Export Income &amp; Expense</a>
              <a class="portal-button portal-button--small portal-button--quiet" href="${esc(adminApiUrl("/crm/bulk/export/attendance"))}">Export Attendance</a>
              <a class="portal-button portal-button--small portal-button--quiet" href="${esc(adminApiUrl("/crm/bulk/export/students"))}">Export Students</a>
            </div>
          </section>

          <section class="crm-panel">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Bulk CSV Import (Validation, Duplicate Check &amp; Preview Before Save)</h3>
              </div>
            </div>
            <form data-bulk-preview-form>
              <div class="crm-row-actions" style="margin-bottom:10px;">
                <select name="entity" class="portal-input" style="width:auto;">
                  <option value="students" ${entity === "students" ? "selected" : ""}>Bulk Students Import</option>
                  <option value="offline_marks" ${entity === "offline_marks" ? "selected" : ""}>Bulk Offline Test Marks</option>
                </select>
                <button type="submit" class="portal-button portal-button--small">Validate &amp; Preview CSV</button>
                ${preview && preview.validCount > 0 ? `<button type="button" class="portal-button portal-button--small" data-bulk-commit>Commit ${preview.validCount} Valid Row(s)</button>` : ""}
              </div>
              <textarea name="csvText" class="portal-input" rows="5" style="font-family:monospace;font-size:12px;">${esc(csvText)}</textarea>
            </form>
            ${
              preview
                ? `<div style="margin-top:12px;font-size:13px;">
                     <strong>Preview Summary:</strong> Total ${preview.totalRows} · <span class="crm-state-ok">Valid ${preview.validCount}</span> · <span class="crm-state-warn">Duplicates ${preview.duplicateCount}</span> · <span class="crm-state-alert">Errors ${preview.errorCount}</span>
                   </div>`
                : ""
            }
          </section>

          <section class="crm-panel">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Bulk Batch Actions (Select Students)</h3>
                <p class="crm-panel-sub">Promote to next batch, generate monthly fees, or send batch notice in one action</p>
              </div>
            </div>
            <form data-bulk-stu-form>
              <div class="crm-row-actions" style="margin-bottom:10px;">
                <select name="action" class="portal-input" style="width:auto;">
                  <option value="generate_monthly_fees">Generate Monthly Fees</option>
                  <option value="promote_batch">Promote to Batch</option>
                  <option value="send_notice">Send Batch Notice</option>
                </select>
                <select name="targetBatchId" class="portal-input" style="width:auto;">
                  <option value="">Select Target Batch (for Promote)…</option>
                  ${batches.map((b) => `<option value="${b.id}">${esc(b.name)}</option>`).join("")}
                </select>
                <input name="message" class="portal-input" style="flex:1;min-width:180px;" placeholder="Notice message (for Send Notice)…" />
                <button type="submit" class="portal-button portal-button--small">Run Bulk Action</button>
              </div>
              <div class="portal-table-scroll">
                <table class="portal-table">
                  <thead><tr><th>Select</th><th>Student</th><th>Roll No</th><th>Batch</th><th>Pending Due</th></tr></thead>
                  <tbody>
                    ${students.map((s) => `<tr><td><input type="checkbox" name="studentIds" value="${s.id}" aria-label="Select ${esc(s.full_name)}" /></td><td>${esc(s.full_name)}</td><td class="crm-num">${esc(s.roll_number || `YSC-${s.id}`)}</td><td>${esc(s.batch_name || "-")}</td><td class="crm-num">${inr(s.pending_fee)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No students found.</td></tr>`}
                  </tbody>
                </table>
              </div>
            </form>
          </section>
        </div>
      `;

      container.querySelector("[data-bulk-preview-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        const fd = new FormData(e.currentTarget);
        entity = String(fd.get("entity") || "students");
        csvText = String(fd.get("csvText") || "");
        try {
          preview = await apiJson(adminApiUrl("/crm/bulk/import-preview"), { method: "POST", body: { entity, csvText } });
        } catch (err) {
          errMsg = err.message;
        }
        draw();
      });

      container.querySelector("[data-bulk-commit]")?.addEventListener("click", async () => {
        okMsg = "";
        errMsg = "";
        try {
          const out = await apiJson(adminApiUrl("/crm/bulk/import-commit"), { method: "POST", body: { entity, csvText } });
          okMsg = `Bulk import complete: ${out.inserted} inserted, ${out.skipped} skipped.`;
          preview = null;
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelector("[data-bulk-stu-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        const fd = new FormData(e.currentTarget);
        const ids = fd.getAll("studentIds").map(Number).filter(Boolean);
        if (!ids.length) {
          errMsg = "Please check at least one student row first.";
          draw();
          return;
        }
        try {
          const out = await apiJson(adminApiUrl("/crm/students/bulk-action"), {
            method: "POST",
            body: {
              action: fd.get("action"),
              studentIds: ids,
              targetBatchId: fd.get("targetBatchId") ? Number(fd.get("targetBatchId")) : null,
              message: fd.get("message")
            }
          });
          okMsg = `Bulk action "${out.action}" completed cleanly.`;
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  // ==================== 7. AUTOMATION CONTROL PANEL, EXCEPTION INBOX, PAYROLL, STAFF TEMPLATES, RISK & CPA ====================
  async function renderAutomationControl(container, { adminApiUrl }) {
    let sub = "controls";
    let autoRes = { config: {}, rules: [], jobs: [], schedulerRuns: [], exceptions: [], deliveryLogs: [] };
    let staffRes = { templates: [], staff: [] };
    let riskRes = { risks: [] };
    let mktRes = { campaigns: [] };
    let okMsg = "";
    let errMsg = "";

    async function load() {
      try {
        [autoRes, staffRes, riskRes, mktRes] = await Promise.all([
          apiJson(adminApiUrl("/crm/automation/overview")),
          apiJson(adminApiUrl("/crm/staff-templates")),
          apiJson(adminApiUrl("/crm/retention/risks")),
          apiJson(adminApiUrl("/crm/marketing/campaigns"))
        ]);
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      const cfg = autoRes.config || {};
      const openEx = (autoRes.exceptions || []).filter((x) => x.status === "open").length;
      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          <div class="crm-tabs" role="tablist">
            ${[
              ["controls", "Safety Controls & Rules"],
              ["exceptions", `Exception Inbox (${openEx})`],
              ["scheduler", "IST Scheduler & Job Queue"],
              ["staff_payroll", "Staff Templates & Payroll"],
              ["retention_mkt", "Dropout Risk & Marketing CPA"]
            ]
              .map(([k, lbl]) => `<button type="button" class="crm-tab-btn ${sub === k ? "is-active" : ""}" data-auto-tab="${k}">${lbl}</button>`)
              .join("")}
          </div>

          ${
            sub === "controls"
              ? `<section class="crm-panel" style="margin-bottom:14px;">
                   <div class="crm-panel-head">
                     <div>
                       <h3 class="crm-panel-title">Global Automation Safety Controls (IST Asia/Kolkata)</h3>
                       <p class="crm-panel-sub">Quiet hours, daily message cap, global kill switch, and optional fee defaulter soft lock</p>
                     </div>
                   </div>
                   <form data-auto-cfg-form>
                     <div class="crm-switch-row">
                       <div><strong>Global Automation Kill Switch</strong><div class="crm-panel-sub">Immediately halts all automatic rules and outbound notifications</div></div>
                       <input type="checkbox" name="global_kill_switch" ${Number(cfg.global_kill_switch) === 1 ? "checked" : ""} aria-label="Global Automation Kill Switch" />
                     </div>
                     <div class="crm-switch-row">
                       <div><strong>Quiet Hours (9:00 PM – 8:00 AM IST)</strong><div class="crm-panel-sub">Defers non-urgent student/parent messages until morning</div></div>
                       <input type="checkbox" name="quiet_hours_enabled" ${Number(cfg.quiet_hours_enabled) === 1 ? "checked" : ""} aria-label="Quiet Hours Enabled" />
                     </div>
                     <div class="crm-switch-row">
                       <div><strong>Optional Fee Defaulter Soft Lock (15–30 Days Overdue)</strong><div class="crm-panel-sub">Shows polite pending-fee notice &amp; restricts online CBT/DPP without deleting accounts</div></div>
                       <input type="checkbox" name="defaulter_soft_lock_enabled" ${Number(cfg.defaulter_soft_lock_enabled) === 1 ? "checked" : ""} aria-label="Fee Defaulter Soft Lock" />
                     </div>
                     <div class="crm-switch-row">
                       <div><strong>Mask Student &amp; Parent Mobile Numbers for Teachers (Anti-Poaching Guard)</strong><div class="crm-panel-sub">Hides raw mobile numbers (shows ••••••3210) in Teacher Portal; teachers contact parents via official logged alerts</div></div>
                       <input type="checkbox" name="mask_student_phones_for_teachers" ${Number(cfg.mask_student_phones_for_teachers ?? 1) === 1 ? "checked" : ""} aria-label="Mask Student Phones for Teachers" />
                     </div>
                     <div class="crm-switch-row">
                       <div><strong>Auto-Assign Clash-Free Substitute Teacher on Leave Approval</strong><div class="crm-panel-sub">Automatically assigns an available teacher and notifies affected batch students when a teacher leave is approved</div></div>
                       <input type="checkbox" name="auto_substitute_on_leave" ${Number(cfg.auto_substitute_on_leave ?? 1) === 1 ? "checked" : ""} aria-label="Auto Assign Substitute on Leave" />
                     </div>
                     <div class="crm-switch-row">
                       <div><strong>Auto Daily Birthday Wishes (09:00 AM IST)</strong><div class="crm-panel-sub">Sends branded Happy Birthday email + in-portal birthday card to active Students, Teachers &amp; Staff (once per year; skips exited members)</div></div>
                       <input type="checkbox" name="birthday_wishes_enabled" ${Number(cfg.birthday_wishes_enabled ?? 1) === 1 ? "checked" : ""} aria-label="Auto Daily Birthday Wishes" />
                     </div>
                     <div class="crm-switch-row">
                       <div><strong>Auto Role-Wise New Joining Welcome Kit Emails</strong><div class="crm-panel-sub">Automatically sends warm, personalized welcome emails when Students, Teachers, Staff or Parents join Yuitor</div></div>
                       <input type="checkbox" name="welcome_emails_enabled" ${Number(cfg.welcome_emails_enabled ?? 1) === 1 ? "checked" : ""} aria-label="Auto Role-Wise Welcome Emails" />
                     </div>
                     <div class="crm-grid-3" style="margin-top:12px;">
                       <label class="portal-field"><span>Max Auto Messages / Student / Day</span><input type="number" name="max_auto_messages_per_day" class="portal-input" value="${Number(cfg.max_auto_messages_per_day || 3)}" min="1" max="10" /></label>
                       <label class="portal-field"><span>Low Attendance Alert Threshold (%)</span><input type="number" name="low_attendance_threshold" class="portal-input" value="${Number(cfg.low_attendance_threshold || 75)}" min="30" max="95" /></label>
                       <label class="portal-field"><span>Defaulter Soft Lock Days</span><input type="number" name="defaulter_soft_lock_days" class="portal-input" value="${Number(cfg.defaulter_soft_lock_days || 15)}" min="7" max="90" /></label>
                     </div>
                     <div style="margin-top:12px;"><button type="submit" class="portal-button">Save Automation Safety Settings</button></div>
                   </form>
                 </section>

                 <section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">IF / THEN Automation Rules (Individual ON/OFF &amp; Dry-Run)</h3></div>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Rule</th><th>Event Trigger</th><th>Runs</th><th>State</th><th>Controls</th></tr></thead>
                       <tbody>
                         ${(autoRes.rules || [])
                           .map(
                             (r) => `<tr>
                               <td><strong>${esc(r.name)}</strong><div class="crm-panel-sub">${esc(r.description)} (v${r.version})</div></td>
                               <td class="crm-num">${esc(r.event_name)}</td>
                               <td class="crm-num">${Number(r.execution_count || 0)}</td>
                               <td><span class="${Number(r.is_enabled) === 1 ? "crm-state-ok" : "crm-state-warn"}">${Number(r.is_enabled) === 1 ? "Active" : "Paused"}</span></td>
                               <td>
                                 <div class="crm-row-actions">
                                   <button type="button" class="portal-button portal-button--small portal-button--quiet" data-rule-toggle="${r.id}" data-next="${Number(r.is_enabled) === 1 ? 0 : 1}">${Number(r.is_enabled) === 1 ? "Turn OFF" : "Turn ON"}</button>
                                   <button type="button" class="portal-button portal-button--small portal-button--quiet" data-rule-dryrun="${r.id}">Dry Run</button>
                                 </div>
                               </td>
                             </tr>`
                           )
                           .join("")}
                       </tbody>
                     </table>
                   </div>
                 </section>`
              : ""
          }

          ${
            sub === "exceptions"
              ? `<section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">Central Exception Inbox (Failed Jobs, SLA Breaches &amp; Approvals)</h3></div>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Severity</th><th>Title &amp; Details</th><th>Level</th><th>Status</th><th>Action</th></tr></thead>
                       <tbody>
                         ${(autoRes.exceptions || []).length
                           ? autoRes.exceptions
                               .map(
                                 (ex) => `<tr>
                                   <td class="${ex.severity === "critical" || ex.severity === "high" ? "crm-state-alert" : "crm-state-warn"}">${esc(ex.severity)}</td>
                                   <td><strong>${esc(ex.title)}</strong><div class="crm-panel-sub">${esc(ex.summary)}</div></td>
                                   <td>${esc(ex.escalation_level)}</td>
                                   <td>${esc(ex.status)}</td>
                                   <td>${
                                     ex.status === "open"
                                       ? `<div class="crm-row-actions">
                                            <button type="button" class="portal-button portal-button--small" data-ex-act="${ex.id}" data-act="approve">Approve</button>
                                            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-ex-act="${ex.id}" data-act="retry">Retry</button>
                                            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-ex-act="${ex.id}" data-act="ignore">Ignore</button>
                                          </div>`
                                       : esc(ex.resolution_note || ex.status)
                                   }</td>
                                 </tr>`
                               )
                               .join("")
                           : `<tr><td colspan="5" class="portal-empty">Inbox zero — no open exceptions or failed tasks.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>`
              : ""
          }

          ${
            sub === "scheduler"
              ? `<section class="crm-panel" style="margin-bottom:14px;">
                   <div class="crm-panel-head">
                     <div>
                       <h3 class="crm-panel-title">Central IST Scheduler (* * * * * Asia/Kolkata)</h3>
                       <p class="crm-panel-sub">Single cron entry runs queue, reconciliation, reminders, backups, risk scoring &amp; payroll drafts</p>
                     </div>
                     <div class="crm-row-actions">
                       <button type="button" class="portal-button portal-button--small" data-sched-run="queue_and_sla">Run Queue &amp; SLA</button>
                       <button type="button" class="portal-button portal-button--small portal-button--quiet" data-sched-run="payment_reconciliation">Reconcile Payments</button>
                       <button type="button" class="portal-button portal-button--small portal-button--quiet" data-sched-run="fee_reminders">Run Fee Reminders</button>
                     </div>
                   </div>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Job Name</th><th>Status</th><th>Duration</th><th>Started At</th></tr></thead>
                       <tbody>
                         ${(autoRes.schedulerRuns || []).map((sr) => `<tr><td>${esc(sr.job_name)}</td><td>${esc(sr.status)}</td><td class="crm-num">${Number(sr.duration_ms || 0)} ms</td><td class="crm-num">${esc(sr.started_at)}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No scheduler runs logged yet. Click a trigger above to run now.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>
                 <section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">Job Queue (Auto-Retry up to 3x)</h3></div>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>ID</th><th>Job Type</th><th>Attempts</th><th>Status</th><th>Action</th></tr></thead>
                       <tbody>
                         ${(autoRes.jobs || []).map((j) => `<tr><td class="crm-num">#${j.id}</td><td>${esc(j.job_type)}</td><td class="crm-num">${j.attempts}/${j.max_attempts}</td><td>${esc(j.status)}</td><td>${["failed","dead_letter"].includes(j.status) ? `<button type="button" class="portal-button portal-button--small" data-job-retry="${j.id}">Retry</button>` : "-"}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">Job queue is empty.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>`
              : ""
          }

          ${
            sub === "staff_payroll"
              ? `<section class="crm-panel" style="margin-bottom:14px;">
                   <div class="crm-panel-head">
                     <div>
                       <h3 class="crm-panel-title">Teacher Salary Payroll Draft Generator (Auto 25th of Month)</h3>
                       <p class="crm-panel-sub">Calculates fixed + per-class pay + approved leave adjustments automatically</p>
                     </div>
                     <button type="button" class="portal-button portal-button--small" data-gen-payroll>Generate Payroll Draft Now</button>
                   </div>
                 </section>
                 <section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">Ready-Made Staff Permission Templates</h3></div>
                   <div class="crm-grid-3" style="margin-bottom:14px;">
                     ${(staffRes.templates || []).map((t) => `<div class="crm-founder-cell"><strong>${esc(t.label)}</strong><p class="crm-panel-sub">${esc(t.description)}</p><div class="crm-panel-sub" style="margin-top:6px;">Permissions: ${esc(t.permissions.join(", "))}</div></div>`).join("")}
                   </div>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Staff Member</th><th>Current Role</th><th>Apply 1-Click Template</th></tr></thead>
                       <tbody>
                         ${(staffRes.staff || []).map((st) => `<tr><td><strong>${esc(st.full_name)}</strong><div class="crm-panel-sub">${esc(st.email)}</div></td><td>${esc(st.staff_role || "Custom")}</td><td><div class="crm-row-actions">${(staffRes.templates || []).map((t) => `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-apply-tpl="${st.id}" data-tpl="${t.key}">${esc(t.label)}</button>`).join("")}</div></td></tr>`).join("") || `<tr><td colspan="3" class="portal-empty">Add staff accounts in Users -> Staff to apply 1-click role templates.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>`
              : ""
          }

          ${
            sub === "retention_mkt"
              ? `<section class="crm-panel" style="margin-bottom:14px;">
                   <div class="crm-panel-head">
                     <div>
                       <h3 class="crm-panel-title">Student Dropout-Risk Monitor (Nightly 3:00 AM IST)</h3>
                       <p class="crm-panel-sub">Tracks attendance %, overdue fee days &amp; test scores to auto-assign mentor tasks</p>
                     </div>
                     <button type="button" class="portal-button portal-button--small" data-recalc-risk>Recalculate Risk Scores</button>
                   </div>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Student</th><th>Risk Score</th><th>Attendance</th><th>Overdue</th><th>Recommended Action</th></tr></thead>
                       <tbody>
                         ${(riskRes.risks || []).map((r) => `<tr><td><strong>${esc(r.full_name)}</strong></td><td class="crm-num ${r.risk_score >= 50 ? "crm-state-alert" : "crm-state-ok"}">${r.risk_score}/100 (${esc(r.risk_level)})</td><td class="crm-num">${r.attendance_percent}%</td><td class="crm-num">${r.overdue_days}d</td><td>${esc(r.recommended_action)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">Click "Recalculate Risk Scores" to evaluate active students.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>
                 <section class="crm-panel">
                   <div class="crm-panel-head"><h3 class="crm-panel-title">Marketing Campaigns &amp; Cost Per Admission (CPA)</h3></div>
                   <form data-mkt-camp-form class="crm-grid-3" style="margin-bottom:12px;">
                     <label class="portal-field"><span>Campaign Name</span><input name="name" class="portal-input" required placeholder="Board Batch Admissions Ads" /></label>
                     <label class="portal-field"><span>UTM Source</span><input name="utmSource" class="portal-input" value="facebook_ads" /></label>
                     <label class="portal-field"><span>Ad Spend (INR)</span><input type="number" name="spendAmount" class="portal-input" value="3000" /></label>
                     <div><button type="submit" class="portal-button portal-button--small">Track Campaign</button></div>
                   </form>
                   <div class="portal-table-scroll">
                     <table class="portal-table">
                       <thead><tr><th>Campaign</th><th>Source</th><th>Spend</th><th>Leads / Admissions</th><th>Cost Per Admission</th></tr></thead>
                       <tbody>
                         ${(mktRes.campaigns || []).map((c) => `<tr><td><strong>${esc(c.name)}</strong></td><td>${esc(c.utm_source)}</td><td class="crm-num">${inr(c.spend_amount)}</td><td class="crm-num">${c.leadsCount} / ${c.admissionsCount}</td><td class="crm-num ${c.pauseAlert ? "crm-state-alert" : "crm-state-ok"}">${inr(c.cpa)}${c.pauseAlert ? " · Pause Alert" : ""}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No marketing campaigns tracked yet.</td></tr>`}
                       </tbody>
                     </table>
                   </div>
                 </section>`
              : ""
          }
        </div>
      `;

      container.querySelectorAll("[data-auto-tab]").forEach((btn) => {
        btn.addEventListener("click", () => {
          sub = btn.getAttribute("data-auto-tab");
          draw();
        });
      });

      container.querySelector("[data-auto-cfg-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        const form = e.currentTarget;
        const fd = new FormData(form);
        try {
          await apiJson(adminApiUrl("/crm/automation/config"), {
            method: "PATCH",
            body: {
              global_kill_switch: form.querySelector('[name="global_kill_switch"]').checked ? 1 : 0,
              quiet_hours_enabled: form.querySelector('[name="quiet_hours_enabled"]').checked ? 1 : 0,
              defaulter_soft_lock_enabled: form.querySelector('[name="defaulter_soft_lock_enabled"]').checked ? 1 : 0,
              mask_student_phones_for_teachers: form.querySelector('[name="mask_student_phones_for_teachers"]')?.checked ? 1 : 0,
              auto_substitute_on_leave: form.querySelector('[name="auto_substitute_on_leave"]')?.checked ? 1 : 0,
              birthday_wishes_enabled: form.querySelector('[name="birthday_wishes_enabled"]')?.checked ? 1 : 0,
              welcome_emails_enabled: form.querySelector('[name="welcome_emails_enabled"]')?.checked ? 1 : 0,
              max_auto_messages_per_day: Number(fd.get("max_auto_messages_per_day") || 3),
              low_attendance_threshold: Number(fd.get("low_attendance_threshold") || 75),
              defaulter_soft_lock_days: Number(fd.get("defaulter_soft_lock_days") || 15)
            }
          });
          okMsg = "Automation safety settings saved.";
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelectorAll("[data-rule-toggle]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await apiJson(adminApiUrl(`/crm/automation/rules/${btn.getAttribute("data-rule-toggle")}`), {
            method: "PATCH",
            body: { isEnabled: Number(btn.getAttribute("data-next")) }
          });
          okMsg = "Automation rule state updated.";
          await load();
        });
      });

      container.querySelectorAll("[data-rule-dryrun]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const out = await apiJson(adminApiUrl(`/crm/automation/rules/${btn.getAttribute("data-rule-dryrun")}/dry-run`), { method: "POST", body: {} });
          okMsg = `Dry-run OK for ${out.ruleKey}: matched ${out.simulation?.matchedRules?.length || 0} rule(s), 0 side effects.`;
          draw();
        });
      });

      container.querySelectorAll("[data-ex-act]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await apiJson(adminApiUrl(`/crm/exceptions/${btn.getAttribute("data-ex-act")}/action`), {
            method: "POST",
            body: { action: btn.getAttribute("data-act") }
          });
          okMsg = "Exception item updated.";
          await load();
        });
      });

      container.querySelectorAll("[data-sched-run]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const jobName = btn.getAttribute("data-sched-run");
          await apiJson(adminApiUrl("/crm/automation/scheduler/run"), { method: "POST", body: { jobName } });
          okMsg = `Scheduler task "${jobName}" executed cleanly in Asia/Kolkata timezone.`;
          await load();
        });
      });

      container.querySelectorAll("[data-job-retry]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await apiJson(adminApiUrl(`/crm/automation/jobs/${btn.getAttribute("data-job-retry")}/retry`), { method: "POST", body: {} });
          okMsg = "Job re-queued and processed.";
          await load();
        });
      });

      container.querySelector("[data-gen-payroll]")?.addEventListener("click", async () => {
        const out = await apiJson(adminApiUrl("/crm/payroll/generate-draft"), { method: "POST", body: {} });
        okMsg = `Payroll draft for ${out.salaryMonth}: created ${out.created}, skipped ${out.skipped}.`;
        draw();
      });

      container.querySelectorAll("[data-apply-tpl]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await apiJson(adminApiUrl(`/crm/staff/${btn.getAttribute("data-apply-tpl")}/apply-template`), {
            method: "POST",
            body: { templateKey: btn.getAttribute("data-tpl") }
          });
          okMsg = "Staff permission template applied & audit logged.";
          await load();
        });
      });

      container.querySelector("[data-recalc-risk]")?.addEventListener("click", async () => {
        const out = await apiJson(adminApiUrl("/crm/retention/recalculate"), { method: "POST", body: {} });
        okMsg = `Evaluated ${out.evaluated} student(s); ${out.highRiskCount} high-risk mentor task(s) active.`;
        await load();
      });

      container.querySelector("[data-mkt-camp-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await apiJson(adminApiUrl("/crm/marketing/campaigns"), { method: "POST", body: Object.fromEntries(new FormData(e.currentTarget).entries()) });
        okMsg = "Campaign added to CPA tracker.";
        await load();
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  function renderPortalCelebrationHtml(celeb) {
    if (!celeb) return "";
    if (celeb.isBirthdayToday) {
      return `
        <section class="crm-panel" data-testid="birthday-celebration-banner" style="margin-bottom:14px;background:linear-gradient(135deg,#fff8eb 0%,#fdf2f2 100%);border:1px solid #d4a359;border-left:5px solid #8c1d18;">
          <div class="crm-panel-head" style="margin-bottom:4px;">
            <div>
              <div style="font-size:11px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#8c1d18;">Yuitor Family Celebration</div>
              <h3 class="crm-panel-title" style="color:#5c110e;margin-top:2px;">${esc(celeb.bannerTitle || "Happy Birthday from Yuitor Smart Classes!")}</h3>
            </div>
            <span class="crm-state-ok" style="background:#8c1d18;color:#fff;padding:4px 10px;border-radius:6px;font-size:12px;">Birthday Special</span>
          </div>
          <p style="margin:6px 0 0;color:#4a3731;line-height:1.55;">${esc(celeb.bannerMessage || "Wishing you a joyful birthday and a bright year ahead!")}</p>
        </section>`;
    }
    if (!celeb.dob) {
      return `
        <section class="crm-panel" data-testid="portal-save-dob-bar" style="margin-bottom:14px;background:#faf7f2;border:1px solid #e6d8c3;">
          <form data-portal-dob-form style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;">
            <div>
              <strong style="color:#5c110e;">Add Your Birthday (Date of Birth)</strong>
              <div class="crm-panel-sub">Share your birthday so the Yuitor family can send you warm wishes on your special day.</div>
            </div>
            <div style="display:flex;align-items:center;gap:8px;">
              <input type="date" name="dob" class="portal-input" style="width:auto;" aria-label="Date of Birth" required />
              <button type="submit" class="portal-button portal-button--small">Save Birthday</button>
            </div>
          </form>
        </section>`;
    }
    return "";
  }

  // ==================== 8. STUDENT PORTAL CRM HUB (LIVE CLASSES, CBT EXAM RUNNER, DPP LOCKER, DOUBTS, PDFS) ====================
  async function renderStudentCrmTab(container) {
    let hub = null;
    let feedbackData = { teachers: [], myFeedback: [] };
    let celebStatus = null;
    let activeExam = null;
    let cbtState = null;
    let cbtTimerId = null;
    let lastCbtResult = null;
    let okMsg = "";
    let errMsg = "";

    function clearTimer() {
      if (cbtTimerId) {
        clearInterval(cbtTimerId);
        cbtTimerId = null;
      }
    }

    async function load() {
      try {
        [hub, feedbackData, celebStatus] = await Promise.all([
          apiJson("/api/student/crm/hub"),
          apiJson("/api/student/crm/feedback").catch(() => ({ teachers: [], myFeedback: [] })),
          apiJson("/api/portal/crm/celebration-status").catch(() => null)
        ]);
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    async function submitActiveCbt() {
      if (!activeExam || !cbtState) return;
      clearTimer();
      try {
        lastCbtResult = await apiJson(`/api/student/crm/cbt/${activeExam.id}/submit`, {
          method: "POST",
          body: { answers: cbtState.answers, statusMap: cbtState.statusMap }
        });
        activeExam = null;
        cbtState = null;
        okMsg = `CBT submitted! Score: ${lastCbtResult.score}/${lastCbtResult.maxMarks} · Batch Rank #${lastCbtResult.rank} · Percentile ${lastCbtResult.percentile}%`;
        await load();
      } catch (err) {
        errMsg = err.message;
        draw();
      }
    }

    function draw() {
      if (activeExam && cbtState) {
        const qs = cbtState.questions;
        const cur = qs[cbtState.index] || {};
        const qKey = String(cur.id ?? cbtState.index);
        const mins = Math.floor(cbtState.secondsLeft / 60);
        const secs = cbtState.secondsLeft % 60;
        container.innerHTML = `
          <div class="crm-panel" data-testid="cbt-runner">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">${esc(activeExam.title)} (${esc(activeExam.exam_pattern || "+4/-1")})</h3>
                <p class="crm-panel-sub">Question ${cbtState.index + 1} of ${qs.length} · Topic: ${esc(cur.topic || activeExam.subject_name)}</p>
              </div>
              <div class="crm-row-actions">
                <strong class="crm-num crm-state-alert" data-cbt-timer>Time Left: ${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}</strong>
                <button type="button" class="portal-button portal-button--small" data-cbt-submit>Submit Exam</button>
              </div>
            </div>
            <div class="crm-cbt-layout">
              <div>
                <p style="font-size:15px;font-weight:600;margin:0 0 14px;">${esc(cur.question || "")}</p>
                <div style="display:flex;flex-direction:column;gap:8px;">
                  ${(cur.options || [])
                    .map(
                      (opt) => `<label style="display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid var(--pt-border);border-radius:8px;cursor:pointer;">
                        <input type="radio" name="cbtOpt" value="${esc(opt)}" ${String(cbtState.answers[qKey] || "") === String(opt) ? "checked" : ""} />
                        <span>${esc(opt)}</span>
                      </label>`
                    )
                    .join("")}
                </div>
                <div class="crm-row-actions" style="margin-top:16px;">
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cbt-prev ${cbtState.index === 0 ? "disabled" : ""}>Previous</button>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cbt-review>Mark for Review</button>
                  <button type="button" class="portal-button portal-button--small" data-cbt-next>${cbtState.index + 1 >= qs.length ? "Finish & Submit" : "Save & Next"}</button>
                </div>
              </div>
              <aside>
                <div class="crm-panel-sub" style="margin-bottom:8px;"><strong>Question Palette</strong></div>
                <div class="crm-cbt-palette">
                  ${qs
                    .map((q, idx) => {
                      const k = String(q.id ?? idx);
                      const cls = [
                        "crm-cbt-qnum",
                        cbtState.statusMap[k] === "review" ? "is-review" : cbtState.answers[k] ? "is-answered" : "",
                        idx === cbtState.index ? "is-current" : ""
                      ].join(" ");
                      return `<button type="button" class="${cls}" data-cbt-jump="${idx}">${idx + 1}</button>`;
                    })
                    .join("")}
                </div>
              </aside>
            </div>
          </div>
        `;

        container.querySelectorAll('input[name="cbtOpt"]').forEach((r) => {
          r.addEventListener("change", () => {
            cbtState.answers[qKey] = r.value;
            cbtState.statusMap[qKey] = "answered";
          });
        });
        container.querySelector("[data-cbt-prev]")?.addEventListener("click", () => { cbtState.index = Math.max(0, cbtState.index - 1); draw(); });
        container.querySelector("[data-cbt-review]")?.addEventListener("click", () => { cbtState.statusMap[qKey] = "review"; draw(); });
        container.querySelector("[data-cbt-next]")?.addEventListener("click", () => {
          if (cbtState.index + 1 >= qs.length) submitActiveCbt();
          else { cbtState.index += 1; draw(); }
        });
        container.querySelectorAll("[data-cbt-jump]").forEach((b) => {
          b.addEventListener("click", () => { cbtState.index = Number(b.getAttribute("data-cbt-jump")); draw(); });
        });
        container.querySelector("[data-cbt-submit]")?.addEventListener("click", submitActiveCbt);
        return;
      }

      const lock = hub?.lockState || {};
      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          ${renderPortalCelebrationHtml(celebStatus)}
          ${lock.locked ? `<div class="portal-message portal-message--error"><strong>Pending Fee Notice:</strong> ${esc(lock.message)}</div>` : ""}

          <section class="crm-panel">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">My Official Documents &amp; Live Classes</h3>
                <p class="crm-panel-sub">Download your QR Student ID Card, Monthly Progress Report, or join scheduled online classes</p>
              </div>
              <div class="crm-row-actions">
                <a class="portal-button portal-button--small" href="/api/student/crm/pdf/id-card" target="_blank" rel="noopener">My QR ID Card</a>
                <a class="portal-button portal-button--small portal-button--quiet" href="/api/student/crm/pdf/report-card" target="_blank" rel="noopener">My Progress Report</a>
              </div>
            </div>
            ${(hub?.liveClasses || []).length
              ? hub.liveClasses
                  .map(
                    (lc) => `<div class="crm-switch-row">
                      <div><strong>${esc(lc.subject_name)}</strong> · ${esc(lc.day_of_week)} ${esc(lc.start_time)}–${esc(lc.end_time)} (${esc(lc.teacher_name || "Faculty")})</div>
                      <button type="button" class="portal-button portal-button--small" data-join-live="${lc.id}">Join Live Class</button>
                    </div>`
                  )
                  .join("")
              : `<p class="crm-panel-sub">No live classes scheduled right now.</p>`}
          </section>

          <section class="crm-panel">
            <div class="crm-panel-head"><h3 class="crm-panel-title">Competitive CBT Exams (JEE / NEET / CUET / SSC)</h3></div>
            ${lastCbtResult ? `<div class="portal-message portal-message--success" style="margin-bottom:10px;">Latest Result: <strong>${lastCbtResult.score}/${lastCbtResult.maxMarks}</strong> (${lastCbtResult.percentage}%) · Rank #${lastCbtResult.rank} · Percentile ${lastCbtResult.percentile}% ${lastCbtResult.weakTopics?.length ? `· Focus Topics: ${esc(lastCbtResult.weakTopics.join(", "))}` : ""}</div>` : ""}
            ${(hub?.cbtExams || []).length
              ? hub.cbtExams
                  .map(
                    (q) => `<div class="crm-switch-row">
                      <div><strong>${esc(q.title)}</strong><div class="crm-panel-sub">${esc(q.exam_pattern || "+4/-1")} · ${Number(q.duration_minutes || 30)} mins · Max ${q.max_marks} marks${q.last_rank ? ` · Last Rank #${q.last_rank} (${q.last_percentile}%ile)` : ""}</div></div>
                      <button type="button" class="portal-button portal-button--small" data-start-cbt="${q.id}">Start CBT Test</button>
                    </div>`
                  )
                  .join("")
              : `<p class="crm-panel-sub">${lock.locked ? "Clear overdue fees to unlock CBT tests." : "No CBT tests published for your batch yet."}</p>`}
          </section>

          <div class="crm-grid-2">
            <section class="crm-panel">
              <div class="crm-panel-head"><h3 class="crm-panel-title">DPP &amp; Batch Notes Locker</h3></div>
              ${(hub?.materials || []).length
                ? hub.materials.map((m) => `<div class="crm-switch-row"><div><strong>${esc(m.title)}</strong><div class="crm-panel-sub">${esc(m.material_type)} · ${esc(m.subject_name)}</div></div>${m.file_url ? `<a class="portal-button portal-button--small portal-button--quiet" href="${esc(m.file_url)}" target="_blank" rel="noopener">Open</a>` : ""}</div>`).join("")
                : `<p class="crm-panel-sub">No batch study materials available yet.</p>`}
            </section>

            <section class="crm-panel">
              <div class="crm-panel-head"><h3 class="crm-panel-title">Student Doubt Counter (12h Teacher SLA)</h3></div>
              <form data-student-doubt-form style="display:flex;flex-direction:column;gap:8px;margin-bottom:12px;">
                <input name="subjectName" class="portal-input" value="Mathematics" placeholder="Subject" required />
                <input name="chapterName" class="portal-input" placeholder="Chapter name" />
                <textarea name="questionText" class="portal-input" rows="2" placeholder="Describe your doubt or question…" required></textarea>
                <button type="submit" class="portal-button portal-button--small">Ask Subject Teacher</button>
              </form>
              ${(hub?.doubts || []).map((d) => `<div class="crm-switch-row"><div><strong>${esc(d.subject_name)}</strong>: ${esc(d.question_text)}${d.reply_text ? `<div class="crm-state-ok" style="font-size:12px;margin-top:4px;">Solution: ${esc(d.reply_text)}</div>` : `<div class="crm-panel-sub">Pending teacher reply</div>`}</div></div>`).join("")}
            </section>
          </div>

          <section class="crm-panel" style="margin-top:14px;">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Private / Anonymous Feedback &amp; Teacher Rating</h3>
                <p class="crm-panel-sub">Bina dare batayein kaunsa topic samajh nahi aaya — Anonymous ON rakhne par teacher ko aapka naam kabhi nahi dikhega</p>
              </div>
            </div>
            <form data-student-feedback-form style="display:flex;flex-direction:column;gap:10px;margin-bottom:14px;">
              <div class="crm-grid-3">
                <label class="portal-field">
                  <span>Select Teacher *</span>
                  <select name="teacherId" class="portal-input" required>
                    <option value="">Choose faculty…</option>
                    ${(feedbackData.teachers || []).map((t) => `<option value="${t.id}">${esc(t.full_name)}</option>`).join("")}
                  </select>
                </label>
                <label class="portal-field">
                  <span>Subject</span>
                  <input name="subjectName" class="portal-input" placeholder="e.g. Physics / Maths / English" />
                </label>
                <label class="portal-field">
                  <span>Teaching Rating (1–5 ★)</span>
                  <select name="rating" class="portal-input">
                    <option value="5">5 ★ — Excellent</option>
                    <option value="4">4 ★ — Good</option>
                    <option value="3">3 ★ — Average (Need Revision)</option>
                    <option value="2">2 ★ — Confusing</option>
                    <option value="1">1 ★ — Needs Extra Support</option>
                  </select>
                </label>
              </div>
              <div class="crm-grid-2">
                <label class="portal-field">
                  <span>Kaunsa Topic Samajh Nahi Aaya? (Topic to Revise)</span>
                  <input name="topicUnclear" class="portal-input" placeholder="e.g. Trigonometry Identities / Organic Chemistry Ch-3" />
                </label>
                <label class="portal-field">
                  <span>Class Speed / Pace</span>
                  <select name="paceTag" class="portal-input">
                    <option value="just_right">Just Right (Perfect Pace)</option>
                    <option value="too_fast">Too Fast (Thoda slow padhayein)</option>
                    <option value="too_slow">Too Slow</option>
                  </select>
                </label>
              </div>
              <label class="portal-field">
                <span>Private Feedback / Suggestion</span>
                <textarea name="feedbackText" class="portal-input" rows="2" placeholder="Write freely — helps us arrange revision or doubt classes…"></textarea>
              </label>
              <label style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;cursor:pointer;">
                <input type="checkbox" name="isAnonymous" checked />
                <span>Submit Anonymously (Keep my name &amp; roll number 100% hidden from teacher)</span>
              </label>
              <div><button type="submit" class="portal-button portal-button--small">Submit Private Feedback</button></div>
            </form>
            ${(feedbackData.myFeedback || []).length
              ? `<div class="crm-panel-sub" style="margin-bottom:6px;font-weight:700;">Your Submitted Feedback (${feedbackData.myFeedback.length})</div>` +
                feedbackData.myFeedback
                  .slice(0, 6)
                  .map(
                    (f) => `<div class="crm-switch-row">
                      <div>
                        <strong>${esc(f.teacher_name)}</strong> · ${"★".repeat(Number(f.rating || 5))} (${esc(f.pace_tag.replace("_", " "))}) · <span class="crm-badge">${Number(f.is_anonymous) === 1 ? "Anonymous" : "Named"}</span>
                        ${f.topic_unclear ? `<div class="crm-panel-sub">Topic to revise: <strong>${esc(f.topic_unclear)}</strong></div>` : ""}
                        ${f.feedback_text ? `<div class="crm-panel-sub">${esc(f.feedback_text)}</div>` : ""}
                      </div>
                    </div>`
                  )
                  .join("")
              : ""}
          </section>
        </div>
      `;

      container.querySelectorAll("[data-join-live]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const out = await apiJson(`/api/student/crm/live-classes/${btn.getAttribute("data-join-live")}/join`, { method: "POST", body: {} });
          okMsg = out.attendanceNote;
          draw();
        });
      });

      container.querySelectorAll("[data-start-cbt]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = Number(btn.getAttribute("data-start-cbt"));
          const exam = (hub?.cbtExams || []).find((x) => Number(x.id) === id);
          if (!exam) return;
          let qs = [];
          try { qs = JSON.parse(exam.questions_json || "[]"); } catch { qs = []; }
          if (!qs.length) { errMsg = "This CBT exam has no questions yet."; draw(); return; }
          activeExam = exam;
          cbtState = { questions: qs, index: 0, answers: {}, statusMap: {}, secondsLeft: Math.max(60, Number(exam.duration_minutes || 30) * 60) };
          clearTimer();
          cbtTimerId = setInterval(() => {
            if (!cbtState) { clearTimer(); return; }
            cbtState.secondsLeft -= 1;
            const tEl = container.querySelector("[data-cbt-timer]");
            if (tEl) {
              const m = Math.floor(Math.max(0, cbtState.secondsLeft) / 60);
              const s = Math.max(0, cbtState.secondsLeft) % 60;
              tEl.textContent = `Time Left: ${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
            }
            if (cbtState.secondsLeft <= 0) submitActiveCbt();
          }, 1000);
          draw();
        });
      });

      container.querySelector("[data-student-doubt-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        try {
          await apiJson("/api/student/crm/doubts", { method: "POST", body: Object.fromEntries(new FormData(e.currentTarget).entries()) });
          okMsg = "Doubt assigned to subject teacher (12-hour SLA started).";
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelector("[data-student-feedback-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        const form = e.currentTarget;
        const fd = new FormData(form);
        try {
          const out = await apiJson("/api/student/crm/feedback", {
            method: "POST",
            body: {
              teacherId: Number(fd.get("teacherId")),
              subjectName: fd.get("subjectName"),
              rating: Number(fd.get("rating") || 5),
              paceTag: fd.get("paceTag") || "just_right",
              topicUnclear: fd.get("topicUnclear"),
              feedbackText: fd.get("feedbackText"),
              isAnonymous: form.querySelector('[name="isAnonymous"]')?.checked ? 1 : 0
            }
          });
          okMsg = out.isAnonymous
            ? "Anonymous feedback submitted! Your identity is completely hidden from the teacher."
            : "Feedback submitted successfully.";
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });
      container.querySelector("[data-portal-dob-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        try {
          const out = await apiJson("/api/portal/crm/save-dob", {
            method: "POST",
            body: { dob: new FormData(e.currentTarget).get("dob") }
          });
          okMsg = out.isBirthdayToday ? "Happy Birthday! Your birthday has been saved." : "Birthday saved! We look forward to celebrating with you.";
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  // ==================== 9. TEACHER PORTAL CRM HUB (DOUBTS + MASKED ROSTER + SUBSTITUTES + ANONYMOUS FEEDBACK) ====================
  async function renderTeacherCrmTab(container) {
    let hub = { doubts: [], liveClasses: [], phoneMaskingEnabled: true, maskedRoster: [], substitutions: [], feedbackSummary: { count: 0, avgRating: 0, topicsToRevise: [], items: [] } };
    let celebStatus = null;
    let okMsg = "";
    let errMsg = "";
    let alertTarget = null;

    async function load() {
      try {
        [hub, celebStatus] = await Promise.all([
          apiJson("/api/teacher/crm/hub"),
          apiJson("/api/portal/crm/celebration-status").catch(() => null)
        ]);
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      const fb = hub.feedbackSummary || { count: 0, avgRating: 0, topicsToRevise: [], items: [] };
      const subs = hub.substitutions || [];
      const roster = hub.maskedRoster || [];
      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          ${renderPortalCelebrationHtml(celebStatus)}

          ${subs.length ? `
          <section class="crm-panel" style="margin-bottom:14px;border-left:4px solid #b45309;">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Assigned Substitute Classes (${subs.length})</h3>
                <p class="crm-panel-sub">Classes temporarily assigned to you while a colleague is on approved leave</p>
              </div>
            </div>
            ${subs
              .map(
                (s) => `<div class="crm-switch-row">
                  <div>
                    <strong>${esc(s.batch_name || "Batch")}</strong> · ${esc(s.subject_name || "Class")} (${esc(s.from_date)} to ${esc(s.to_date)})
                    <div class="crm-panel-sub">Covering for ${esc(s.absent_teacher_name)} ${s.day_of_week ? `· ${esc(s.day_of_week)} ${esc(s.start_time)}–${esc(s.end_time)}` : ""}</div>
                  </div>
                  <span class="crm-state-ok">Assigned</span>
                </div>`
              )
              .join("")}
          </section>` : ""}

          <section class="crm-panel" style="margin-bottom:14px;">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Active Batch Students (${roster.length})</h3>
                <p class="crm-panel-sub">${hub.phoneMaskingEnabled ? "Privacy Guard ON: Raw student/parent mobile numbers are masked (anti-poaching). Use Official Parent Alert to message parents safely." : "Active enrolled students (dropped/left students automatically hidden)."}</p>
              </div>
              <span class="${hub.phoneMaskingEnabled ? "crm-state-ok" : "crm-state-warn"}">${hub.phoneMaskingEnabled ? "Phones Masked" : "Masking Off"}</span>
            </div>
            ${alertTarget ? `
              <form data-t-parent-alert-form class="crm-panel" style="margin-bottom:12px;background:#faf8f6;">
                <div class="crm-panel-head"><strong>Send Official Parent Alert for ${esc(alertTarget.full_name)}</strong><button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-parent-alert>Cancel</button></div>
                <input type="hidden" name="studentId" value="${alertTarget.id}" />
                <textarea name="message" class="portal-input" rows="2" placeholder="Write homework, attendance or progress note for parent…" required></textarea>
                <div style="margin-top:8px;"><button type="submit" class="portal-button portal-button--small">Send Logged Alert via Institute Portal</button></div>
              </form>
            ` : ""}
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Student</th><th>Batch</th><th>Parent / Student Phone</th><th>Safe Contact</th></tr></thead>
                <tbody>
                  ${roster.length
                    ? roster
                        .map(
                          (st) => `<tr>
                            <td><strong>${esc(st.full_name)}</strong><div class="crm-panel-sub">${esc(st.roll_number || "")}</div></td>
                            <td>${esc(st.batch_name || st.course_title || "-")}</td>
                            <td class="crm-num">${esc(st.parent_phone || st.student_phone || "••••")}</td>
                            <td><button type="button" class="portal-button portal-button--small portal-button--quiet" data-open-parent-alert="${st.id}">Send Official Alert</button></td>
                          </tr>`
                        )
                        .join("")
                    : `<tr><td colspan="4" class="portal-empty">No active students assigned to your batches yet.</td></tr>`}
                </tbody>
              </table>
            </div>
          </section>

          <div class="crm-grid-2">
            <section class="crm-panel">
              <div class="crm-panel-head">
                <div>
                  <h3 class="crm-panel-title">Anonymous Student Feedback &amp; Revision Topics</h3>
                  <p class="crm-panel-sub">Average Rating: <strong>${fb.avgRating ? `${fb.avgRating} / 5 ★` : "No ratings yet"}</strong> (${fb.count} responses · student names hidden when anonymous)</p>
                </div>
              </div>
              ${(fb.topicsToRevise || []).length ? `
                <div style="margin-bottom:10px;padding:10px;border-radius:10px;background:#fff8eb;border:1px solid #f5d7a1;">
                  <strong style="font-size:12px;">Topics Students Want Revised:</strong>
                  <div style="margin-top:4px;font-size:13px;">${fb.topicsToRevise.map((t) => `<span class="crm-badge" style="margin:2px 4px 2px 0;display:inline-block;">${esc(t)}</span>`).join("")}</div>
                </div>
              ` : ""}
              ${(fb.items || []).length
                ? fb.items
                    .slice(0, 8)
                    .map(
                      (f) => `<div class="crm-switch-row">
                        <div>
                          <strong>${esc(f.student_display)}</strong> · ${"★".repeat(Number(f.rating || 5))} <span class="crm-panel-sub">(${esc(f.pace_tag.replace("_", " "))})</span>
                          ${f.topic_unclear ? `<div style="font-size:12px;color:#8a1c36;"><strong>Unclear Topic:</strong> ${esc(f.topic_unclear)}</div>` : ""}
                          ${f.feedback_text ? `<div class="crm-panel-sub">${esc(f.feedback_text)}</div>` : ""}
                        </div>
                      </div>`
                    )
                    .join("")
                : `<p class="crm-panel-sub">No student feedback received yet.</p>`}
            </section>

            <section class="crm-panel">
              <div class="crm-panel-head"><h3 class="crm-panel-title">Assigned Student Doubts (12-Hour Response SLA)</h3></div>
            ${(hub.doubts || []).length
              ? hub.doubts
                  .map(
                    (d) => `<div class="crm-panel" style="margin-bottom:10px;">
                      <div class="crm-panel-head"><strong>${esc(d.student_name)} · ${esc(d.subject_name)}</strong><span>${esc(d.status)}</span></div>
                      <p style="margin:0 0 8px;">${esc(d.question_text)}</p>
                      ${
                        d.reply_text
                          ? `<div class="portal-message portal-message--success">${esc(d.reply_text)}</div>`
                          : `<form data-t-doubt-reply="${d.id}" class="crm-row-actions">
                               <input name="replyText" class="portal-input" style="flex:1;" placeholder="Type solution explanation…" required />
                               <button type="submit" class="portal-button portal-button--small">Post Solution</button>
                             </form>`
                      }
                    </div>`
                  )
                  .join("")
              : `<p class="crm-panel-sub">No pending student doubts assigned to you.</p>`}
            </section>
          </div>
        </div>
      `;

      container.querySelectorAll("[data-open-parent-alert]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const sid = Number(btn.getAttribute("data-open-parent-alert"));
          alertTarget = roster.find((x) => Number(x.id) === sid) || null;
          draw();
        });
      });

      container.querySelector("[data-cancel-parent-alert]")?.addEventListener("click", () => {
        alertTarget = null;
        draw();
      });

      container.querySelector("[data-t-parent-alert-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        const fd = new FormData(e.currentTarget);
        try {
          const out = await apiJson("/api/teacher/crm/notify-parent", {
            method: "POST",
            body: { studentId: Number(fd.get("studentId")), message: fd.get("message") }
          });
          alertTarget = null;
          okMsg = `Official alert logged & sent via Yuitor Portal (${out.parentsNotified} linked parent account(s) + student notified).`;
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelectorAll("[data-t-doubt-reply]").forEach((form) => {
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          await apiJson(`/api/teacher/crm/doubts/${form.getAttribute("data-t-doubt-reply")}/reply`, {
            method: "POST",
            body: { replyText: new FormData(form).get("replyText") }
          });
          okMsg = "Solution sent to student.";
          await load();
        });
      });
      container.querySelector("[data-portal-dob-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        okMsg = "";
        errMsg = "";
        try {
          const out = await apiJson("/api/portal/crm/save-dob", {
            method: "POST",
            body: { dob: new FormData(e.currentTarget).get("dob") }
          });
          okMsg = out.isBirthdayToday ? "Happy Birthday! Thank you for being part of the Yuitor faculty family." : "Birthday saved successfully.";
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  // ==================== 10. ADMIN DEDICATED STUDENT EXITS, DROPOUT SETTLEMENT & ALUMNI REJOIN ====================
  async function renderStudentExitsPanel(container, { adminApiUrl }) {
    let data = { activeMembers: [], exitedMembers: [] };
    let search = "";
    let selectedStudent = null;
    let okMsg = "";
    let errMsg = "";

    async function load() {
      try {
        data = await apiJson(adminApiUrl("/crm/exits?role=student"));
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      const q = search.trim().toLowerCase();
      const activeList = (data.activeMembers || []).filter(
        (m) => !q || `${m.full_name} ${m.roll_number || ""} ${m.phone || ""} ${m.active_batches || ""}`.toLowerCase().includes(q)
      );
      const exitedList = data.exitedMembers || [];
      const todayStr = new Date().toISOString().slice(0, 10);

      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          <section class="crm-panel" style="margin-bottom:14px;">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Student Exit / Dropout &amp; Alumni Settlement</h3>
                <p class="crm-panel-sub">1-click exit frees batch seats, hides student from attendance, settles/waives pending dues, stops auto fee reminders, and archives safely for 1-click Rejoin</p>
              </div>
              <input type="search" class="portal-input" style="max-width:260px;" placeholder="Search student name / roll / phone…" value="${esc(search)}" data-stu-exit-search />
            </div>

            ${selectedStudent ? `
              <form data-stu-exit-form class="crm-panel" style="margin-bottom:14px;background:#fff8f8;border:1px solid #e7b8c1;">
                <div class="crm-panel-head">
                  <div>
                    <strong>Mark Student Left / Dropout: ${esc(selectedStudent.full_name)} (${esc(selectedStudent.roll_number || `ID #${selectedStudent.id}`)})</strong>
                    <div class="crm-panel-sub">Batch: ${esc(selectedStudent.active_batches || "Unassigned")} · Pending Dues: <strong>${inr(selectedStudent.pending_dues)}</strong></div>
                  </div>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-stu-exit>Cancel</button>
                </div>
                <div class="crm-grid-3" style="margin-top:8px;">
                  <label class="portal-field">
                    <span>Exit Date *</span>
                    <input type="date" name="exitDate" class="portal-input" value="${todayStr}" required />
                  </label>
                  <label class="portal-field">
                    <span>Exit Category *</span>
                    <select name="exitCategory" class="portal-input">
                      <option value="dropped_out">Dropped Out / Left Coaching</option>
                      <option value="course_completed_alumni">Course Completed (Alumni)</option>
                      <option value="relocated">Family Relocated / Shifted</option>
                      <option value="fees_issue">Fees / Financial Reason</option>
                      <option value="school_timing">School Timing Clash</option>
                      <option value="other">Other Reason</option>
                    </select>
                  </label>
                  <label class="portal-field">
                    <span>Pending Dues Settlement (${inr(selectedStudent.pending_dues)})</span>
                    <select name="duesAction" class="portal-input">
                      <option value="waive_off">Waive Off Pending Dues (Stop Reminders &amp; Clear Balance)</option>
                      <option value="mark_settled">Mark Full Dues Paid / Settled</option>
                      <option value="keep_due">Keep Due in Ledger (Still Stop Auto Reminders)</option>
                    </select>
                  </label>
                </div>
                <div class="crm-grid-2" style="margin-top:10px;">
                  <label class="portal-field"><span>Exit Reason *</span><input name="exitReason" class="portal-input" placeholder="e.g. Shifted to another city / Board exams finished" required /></label>
                  <label class="portal-field"><span>Settlement / No-Dues Note</span><input name="settlementNote" class="portal-input" placeholder="Optional receipt / refund / remarks" /></label>
                </div>
                <div style="margin-top:10px;">
                  <button type="submit" class="portal-button portal-button--small">Confirm 1-Click Student Exit (Free Seat &amp; Stop Reminders)</button>
                </div>
              </form>
            ` : ""}

            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Active Student</th><th>Batch / Class</th><th>Pending Dues</th><th>Action</th></tr></thead>
                <tbody>
                  ${activeList.length
                    ? activeList
                        .slice(0, 40)
                        .map(
                          (st) => `<tr>
                            <td><strong>${esc(st.full_name)}</strong><div class="crm-panel-sub">${esc(st.roll_number || "")} · ${esc(st.phone || "")}</div></td>
                            <td>${esc(st.active_batches || st.academic_class || "-")}</td>
                            <td class="crm-num">${inr(st.pending_dues)}</td>
                            <td><button type="button" class="portal-button portal-button--small portal-button--quiet" data-pick-stu-exit="${st.id}">Mark Left / Dropout</button></td>
                          </tr>`
                        )
                        .join("")
                    : `<tr><td colspan="4" class="portal-empty">No matching active students.</td></tr>`}
                </tbody>
              </table>
            </div>
          </section>

          <section class="crm-panel">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Left / Alumni Students Archive (${exitedList.length})</h3>
                <p class="crm-panel-sub">All historical fee receipts, attendance, and test records stay safe — click Rejoin anytime to restore portal &amp; batch seat</p>
              </div>
            </div>
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Student</th><th>Exit Date &amp; Category</th><th>Reason &amp; Dues Settlement</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                  ${exitedList.length
                    ? exitedList
                        .map(
                          (ex) => `<tr>
                            <td><strong>${esc(ex.full_name)}</strong><div class="crm-panel-sub">${esc(ex.roll_number || "")} · ${esc(ex.phone || "")}</div></td>
                            <td><strong>${esc(ex.exit_date)}</strong><div class="crm-panel-sub">${esc(ex.exit_category.replace(/_/g, " "))}</div></td>
                            <td>${esc(ex.exit_reason || "-")}<div class="crm-panel-sub">Dues (${inr(ex.dues_amount_snapshot)}): <strong>${esc(ex.dues_action.replace(/_/g, " "))}</strong> · Auto Reminders Stopped</div></td>
                            <td><span class="${ex.status === "left" ? "crm-state-warn" : "crm-state-ok"}">${ex.status === "left" ? "Left / Alumni" : "Rejoined"}</span></td>
                            <td>${ex.status === "left" ? `<button type="button" class="portal-button portal-button--small" data-rejoin-member="${ex.id}">1-Click Rejoin</button>` : `<span class="crm-panel-sub">${esc(ex.rejoined_at.slice(0, 10))}</span>`}</td>
                          </tr>`
                        )
                        .join("")
                    : `<tr><td colspan="5" class="portal-empty">No left or alumni student records yet.</td></tr>`}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      `;

      container.querySelector("[data-stu-exit-search]")?.addEventListener("input", (e) => {
        search = e.currentTarget.value;
        draw();
      });
      container.querySelectorAll("[data-pick-stu-exit]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = Number(btn.getAttribute("data-pick-stu-exit"));
          selectedStudent = (data.activeMembers || []).find((x) => Number(x.id) === id) || null;
          draw();
        });
      });
      container.querySelector("[data-cancel-stu-exit]")?.addEventListener("click", () => {
        selectedStudent = null;
        draw();
      });
      container.querySelector("[data-stu-exit-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        if (!selectedStudent) return;
        okMsg = "";
        errMsg = "";
        const fd = new FormData(e.currentTarget);
        try {
          const out = await apiJson(adminApiUrl(`/crm/exits/student/${selectedStudent.id}`), {
            method: "POST",
            body: Object.fromEntries(fd.entries())
          });
          selectedStudent = null;
          okMsg = `Student exit recorded for ${out.fullName}: ${out.seatsFreed} batch seat(s) freed, auto-reminders stopped, dues action=${out.duesAction}.`;
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });
      container.querySelectorAll("[data-rejoin-member]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          okMsg = "";
          errMsg = "";
          try {
            const out = await apiJson(adminApiUrl(`/crm/exits/${btn.getAttribute("data-rejoin-member")}/rejoin`), {
              method: "POST",
              body: { restoreBatch: true }
            });
            okMsg = `Student rejoined & reactivated! Restored ${out.batchesRestored || 0} batch enrollment(s) and re-enabled alerts.`;
            await load();
          } catch (err) {
            errMsg = err.message;
            draw();
          }
        });
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  // ==================== 11. ADMIN DEDICATED TEACHER OPS (EXITS + LEAVE AUTO-SUBSTITUTE + RATINGS/FEEDBACK) ====================
  async function renderTeacherOpsPanel(container, { adminApiUrl }) {
    let sub = ["leaves", "exits", "ratings"].includes(window.__YU_CRM_SUBTAB__) ? window.__YU_CRM_SUBTAB__ : "leaves";
    window.__YU_CRM_SUBTAB__ = "";
    let exitsData = { activeMembers: [], exitedMembers: [] };
    let leavesData = { leaves: [], activeTeachers: [], substitutions: [] };
    let feedbackData = { teacherRatings: [], entries: [] };
    let selectedTeacher = null;
    let okMsg = "";
    let errMsg = "";

    async function load() {
      try {
        [exitsData, leavesData, feedbackData] = await Promise.all([
          apiJson(adminApiUrl("/crm/exits?role=teacher")),
          apiJson(adminApiUrl("/crm/leaves/overview")),
          apiJson(adminApiUrl("/crm/feedback/overview"))
        ]);
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      const todayStr = new Date().toISOString().slice(0, 10);
      const pendingLeaves = (leavesData.leaves || []).filter((l) => l.status === "pending").length;
      const activeTeachers = exitsData.activeMembers || [];
      const formerTeachers = exitsData.exitedMembers || [];

      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          <div class="crm-tabs" role="tablist">
            ${[
              ["leaves", `Leave → Auto Substitute (${pendingLeaves} Pending)`],
              ["exits", `Teacher Exits & Former Faculty (${formerTeachers.length})`],
              ["ratings", `Teacher Ratings & Anonymous Feedback (${(feedbackData.entries || []).length})`]
            ]
              .map(([k, lbl]) => `<button type="button" class="crm-tab-btn ${sub === k ? "is-active" : ""}" data-tops-tab="${k}">${lbl}</button>`)
              .join("")}
          </div>

          ${sub === "leaves" ? `
            <section class="crm-panel" style="margin-bottom:14px;">
              <div class="crm-panel-head">
                <div>
                  <h3 class="crm-panel-title">Teacher Leave Approval → Auto Substitute &amp; Batch Notification</h3>
                  <p class="crm-panel-sub">Approving a leave automatically assigns a clash-free substitute teacher and notifies every student in the affected batches</p>
                </div>
              </div>
              <div class="portal-table-scroll">
                <table class="portal-table">
                  <thead><tr><th>Teacher &amp; Dates</th><th>Reason</th><th>Status</th><th>Substitute &amp; Action</th></tr></thead>
                  <tbody>
                    ${(leavesData.leaves || []).length
                      ? leavesData.leaves
                          .map(
                            (l) => `<tr>
                              <td><strong>${esc(l.teacher_name)}</strong><div class="crm-panel-sub">${esc(l.from_date)} to ${esc(l.to_date)} · ${Number(l.affected_slots_count || 0)} slot(s)</div></td>
                              <td>${esc(l.reason || "-")}</td>
                              <td><span class="${l.status === "approved" ? "crm-state-ok" : "crm-state-warn"}">${esc(l.status)}</span></td>
                              <td>
                                ${l.status === "pending" ? `
                                  <div class="crm-row-actions">
                                    <select class="portal-input" style="max-width:200px;" data-leave-sub-sel="${l.id}">
                                      <option value="">Auto-Pick (${esc(l.suggested_substitute_name || "Best Free")})</option>
                                      ${(leavesData.activeTeachers || [])
                                        .filter((t) => Number(t.id) !== Number(l.teacher_id))
                                        .map((t) => `<option value="${t.id}">${esc(t.full_name)}</option>`)
                                        .join("")}
                                    </select>
                                    <button type="button" class="portal-button portal-button--small" data-approve-sub-leave="${l.id}">Approve + Assign Sub &amp; Notify Batch</button>
                                  </div>
                                ` : `<span>${l.substitute_teacher_name ? `Substitute: <strong>${esc(l.substitute_teacher_name)}</strong>` : esc(l.admin_note || "-")}</span>`}
                              </td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="4" class="portal-empty">No teacher leave requests yet.</td></tr>`}
                  </tbody>
                </table>
              </div>
            </section>

            <section class="crm-panel">
              <div class="crm-panel-head"><h3 class="crm-panel-title">Active Substitute Assignments Log (${(leavesData.substitutions || []).length})</h3></div>
              <div class="portal-table-scroll">
                <table class="portal-table">
                  <thead><tr><th>Absent Teacher</th><th>Substitute Teacher</th><th>Batch / Slot</th><th>Dates</th><th>Students Notified</th></tr></thead>
                  <tbody>
                    ${(leavesData.substitutions || []).length
                      ? leavesData.substitutions
                          .map(
                            (s) => `<tr>
                              <td>${esc(s.absent_teacher_name)}</td>
                              <td><strong>${esc(s.substitute_teacher_name)}</strong></td>
                              <td>${esc(s.batch_name || "Batch")} ${s.subject_name ? `· ${esc(s.subject_name)}` : ""}</td>
                              <td>${esc(s.from_date)} to ${esc(s.to_date)}</td>
                              <td class="crm-num">${Number(s.students_notified || 0)} notified</td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="5" class="portal-empty">No substitute classes assigned yet.</td></tr>`}
                  </tbody>
                </table>
              </div>
            </section>
          ` : ""}

          ${sub === "exits" ? `
            <section class="crm-panel" style="margin-bottom:14px;">
              <div class="crm-panel-head">
                <div>
                  <h3 class="crm-panel-title">Teacher Exit / Relieving &amp; Batch Handover</h3>
                  <p class="crm-panel-sub">Immediately revokes teacher login &amp; sessions, records final salary settlement, and optionally transfers all active batches/slots/doubts to a replacement teacher</p>
                </div>
              </div>

              ${selectedTeacher ? `
                <form data-tch-exit-form class="crm-panel" style="margin-bottom:14px;background:#fff8f8;border:1px solid #e7b8c1;">
                  <div class="crm-panel-head">
                    <div>
                      <strong>Mark Teacher Left / Relieved: ${esc(selectedTeacher.full_name)}</strong>
                      <div class="crm-panel-sub">${Number(selectedTeacher.active_batches || 0)} batch(es), ${Number(selectedTeacher.active_slots || 0)} timetable slot(s) · Pending Payout: <strong>${inr(selectedTeacher.pending_payout)}</strong></div>
                    </div>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-tch-exit>Cancel</button>
                  </div>
                  <div class="crm-grid-3" style="margin-top:8px;">
                    <label class="portal-field"><span>Relieving Date *</span><input type="date" name="exitDate" class="portal-input" value="${todayStr}" required /></label>
                    <label class="portal-field">
                      <span>Exit Category</span>
                      <select name="exitCategory" class="portal-input">
                        <option value="resigned">Resigned</option>
                        <option value="relocated">Relocated</option>
                        <option value="contract_ended">Contract / Session Completed</option>
                        <option value="terminated">Terminated</option>
                        <option value="other">Other</option>
                      </select>
                    </label>
                    <label class="portal-field">
                      <span>Salary Settlement Status</span>
                      <select name="duesAction" class="portal-input">
                        <option value="salary_settled">Final Salary Settled</option>
                        <option value="salary_pending">Final Salary Pending</option>
                      </select>
                    </label>
                  </div>
                  <div class="crm-grid-2" style="margin-top:10px;">
                    <label class="portal-field">
                      <span>Handover Batches, Timetable &amp; Open Doubts To (Optional)</span>
                      <select name="handoverTeacherId" class="portal-input">
                        <option value="">No automatic handover</option>
                        ${activeTeachers
                          .filter((t) => Number(t.id) !== Number(selectedTeacher.id))
                          .map((t) => `<option value="${t.id}">${esc(t.full_name)}</option>`)
                          .join("")}
                      </select>
                    </label>
                    <label class="portal-field"><span>Exit Reason &amp; Handover Note *</span><input name="exitReason" class="portal-input" placeholder="e.g. Relocated / Full & final cleared" required /></label>
                  </div>
                  <div style="margin-top:10px;"><button type="submit" class="portal-button portal-button--small">Confirm Teacher Exit &amp; Revoke Access</button></div>
                </form>
              ` : ""}

              <div class="portal-table-scroll">
                <table class="portal-table">
                  <thead><tr><th>Active Teacher</th><th>Load</th><th>Pending Payout</th><th>Action</th></tr></thead>
                  <tbody>
                    ${activeTeachers.length
                      ? activeTeachers
                          .map(
                            (t) => `<tr>
                              <td><strong>${esc(t.full_name)}</strong><div class="crm-panel-sub">${esc(t.phone || "")} · ${esc(t.qualification || "")}</div></td>
                              <td>${Number(t.active_batches || 0)} batches · ${Number(t.active_slots || 0)} slots</td>
                              <td class="crm-num">${inr(t.pending_payout)}</td>
                              <td><button type="button" class="portal-button portal-button--small portal-button--quiet" data-pick-tch-exit="${t.id}">Mark Teacher Left</button></td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="4" class="portal-empty">No active teachers found.</td></tr>`}
                  </tbody>
                </table>
              </div>
            </section>

            <section class="crm-panel">
              <div class="crm-panel-head"><h3 class="crm-panel-title">Former Teachers Archive (${formerTeachers.length})</h3></div>
              <div class="portal-table-scroll">
                <table class="portal-table">
                  <thead><tr><th>Teacher</th><th>Exit Date &amp; Reason</th><th>Handover &amp; Settlement</th><th>Status</th><th>Action</th></tr></thead>
                  <tbody>
                    ${formerTeachers.length
                      ? formerTeachers
                          .map(
                            (ex) => `<tr>
                              <td><strong>${esc(ex.full_name)}</strong><div class="crm-panel-sub">${esc(ex.phone || "")}</div></td>
                              <td>${esc(ex.exit_date)} · ${esc(ex.exit_reason || ex.exit_category)}</td>
                              <td>${ex.handover_teacher_name ? `Handover: <strong>${esc(ex.handover_teacher_name)}</strong> · ` : ""}${esc(ex.dues_action.replace(/_/g, " "))}</td>
                              <td><span class="${ex.status === "left" ? "crm-state-warn" : "crm-state-ok"}">${ex.status === "left" ? "Relieved" : "Rejoined"}</span></td>
                              <td>${ex.status === "left" ? `<button type="button" class="portal-button portal-button--small" data-rejoin-tch="${ex.id}">1-Click Rejoin</button>` : `<span class="crm-panel-sub">${esc(ex.rejoined_at.slice(0, 10))}</span>`}</td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="5" class="portal-empty">No former teachers recorded yet.</td></tr>`}
                  </tbody>
                </table>
              </div>
            </section>
          ` : ""}

          ${sub === "ratings" ? `
            <section class="crm-panel" style="margin-bottom:14px;">
              <div class="crm-panel-head">
                <div>
                  <h3 class="crm-panel-title">Teacher Rating Summary (Student Feedback Quality Score)</h3>
                  <p class="crm-panel-sub">Spot fast-paced batches and unclear topics early before students drop out</p>
                </div>
              </div>
              <div class="portal-table-scroll">
                <table class="portal-table">
                  <thead><tr><th>Teacher</th><th>Responses</th><th>Avg Rating</th><th>Too-Fast Flags</th><th>Topics Flagged</th></tr></thead>
                  <tbody>
                    ${(feedbackData.teacherRatings || []).length
                      ? feedbackData.teacherRatings
                          .map(
                            (r) => `<tr>
                              <td><strong>${esc(r.teacher_name)}</strong></td>
                              <td class="crm-num">${Number(r.feedback_count || 0)}</td>
                              <td class="crm-num"><strong>${r.avg_rating ? `${r.avg_rating} / 5 ★` : "-"}</strong></td>
                              <td class="crm-num">${Number(r.too_fast_count || 0)}</td>
                              <td class="crm-num">${Number(r.unclear_topics_count || 0)}</td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="5" class="portal-empty">No active teachers found.</td></tr>`}
                  </tbody>
                </table>
              </div>
            </section>

            <section class="crm-panel">
              <div class="crm-panel-head"><h3 class="crm-panel-title">Student Feedback &amp; Unclear Topics Stream</h3></div>
              <div class="portal-table-scroll">
                <table class="portal-table">
                  <thead><tr><th>Teacher</th><th>Student</th><th>Rating &amp; Pace</th><th>Unclear Topic &amp; Comment</th><th>Review</th></tr></thead>
                  <tbody>
                    ${(feedbackData.entries || []).length
                      ? feedbackData.entries
                          .map(
                            (f) => `<tr>
                              <td><strong>${esc(f.teacher_name)}</strong><div class="crm-panel-sub">${esc(f.subject_name || f.batch_name || "")}</div></td>
                              <td><span class="crm-badge">${esc(f.student_display)}</span></td>
                              <td>${"★".repeat(Number(f.rating || 5))}<div class="crm-panel-sub">${esc(f.pace_tag.replace("_", " "))}</div></td>
                              <td>${f.topic_unclear ? `<strong>${esc(f.topic_unclear)}</strong><br/>` : ""}${esc(f.feedback_text || "-")}</td>
                              <td>${Number(f.admin_reviewed) === 1 ? `<span class="crm-state-ok">Reviewed</span>` : `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-review-fb="${f.id}">Mark Reviewed</button>`}</td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="5" class="portal-empty">No student feedback submitted yet.</td></tr>`}
                  </tbody>
                </table>
              </div>
            </section>
          ` : ""}
        </div>
      `;

      container.querySelectorAll("[data-tops-tab]").forEach((btn) => {
        btn.addEventListener("click", () => {
          sub = btn.getAttribute("data-tops-tab");
          draw();
        });
      });

      container.querySelectorAll("[data-approve-sub-leave]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const lid = Number(btn.getAttribute("data-approve-sub-leave"));
          const sel = container.querySelector(`[data-leave-sub-sel="${lid}"]`);
          okMsg = "";
          errMsg = "";
          try {
            const out = await apiJson(adminApiUrl(`/crm/leaves/${lid}/approve-substitute`), {
              method: "POST",
              body: { substituteTeacherId: sel?.value ? Number(sel.value) : null }
            });
            okMsg = out.substitution?.assigned
              ? `Leave approved! ${out.substitution.substituteTeacherName} assigned as substitute & ${out.substitution.studentsNotified} batch student(s) notified.`
              : "Leave approved! No clash-free substitute found — flagged in Exception Inbox.";
            await load();
          } catch (err) {
            errMsg = err.message;
            draw();
          }
        });
      });

      container.querySelectorAll("[data-pick-tch-exit]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = Number(btn.getAttribute("data-pick-tch-exit"));
          selectedTeacher = activeTeachers.find((x) => Number(x.id) === id) || null;
          draw();
        });
      });
      container.querySelector("[data-cancel-tch-exit]")?.addEventListener("click", () => {
        selectedTeacher = null;
        draw();
      });
      container.querySelector("[data-tch-exit-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        if (!selectedTeacher) return;
        okMsg = "";
        errMsg = "";
        const fd = new FormData(e.currentTarget);
        try {
          const out = await apiJson(adminApiUrl(`/crm/exits/teacher/${selectedTeacher.id}`), {
            method: "POST",
            body: Object.fromEntries(fd.entries())
          });
          selectedTeacher = null;
          okMsg = `Teacher ${out.fullName} relieved & sessions revoked (${out.handoverSlotsMoved || 0} slot(s) handed over).`;
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelectorAll("[data-rejoin-tch]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          okMsg = "";
          errMsg = "";
          try {
            await apiJson(adminApiUrl(`/crm/exits/${btn.getAttribute("data-rejoin-tch")}/rejoin`), { method: "POST", body: {} });
            okMsg = "Teacher rejoined and portal access restored.";
            await load();
          } catch (err) {
            errMsg = err.message;
            draw();
          }
        });
      });

      container.querySelectorAll("[data-review-fb]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await apiJson(adminApiUrl(`/crm/feedback/${btn.getAttribute("data-review-fb")}/review`), { method: "PATCH", body: {} });
          okMsg = "Feedback marked reviewed.";
          await load();
        });
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  // ==================== 12. ADMIN DEDICATED STAFF EXITS & 1-CLICK REJOIN ====================
  async function renderStaffExitsPanel(container, { adminApiUrl }) {
    let data = { activeMembers: [], exitedMembers: [] };
    let selectedStaff = null;
    let okMsg = "";
    let errMsg = "";

    async function load() {
      try {
        data = await apiJson(adminApiUrl("/crm/exits?role=staff"));
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      const todayStr = new Date().toISOString().slice(0, 10);
      const activeList = data.activeMembers || [];
      const exitedList = data.exitedMembers || [];
      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}
          <section class="crm-panel" style="margin-bottom:14px;">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Staff Exit / Relieving &amp; Instant Access Revocation</h3>
                <p class="crm-panel-sub">Dedicated exit workflow for receptionists, counsellors, fee clerks, and coordinators — immediately revokes sessions while preserving audit logs</p>
              </div>
            </div>
            ${selectedStaff ? `
              <form data-stf-exit-form class="crm-panel" style="margin-bottom:14px;background:#fff8f8;border:1px solid #e7b8c1;">
                <div class="crm-panel-head">
                  <strong>Mark Staff Left / Relieved: ${esc(selectedStaff.full_name)} (${esc(selectedStaff.staff_role || "Staff")})</strong>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-stf-exit>Cancel</button>
                </div>
                <div class="crm-grid-3" style="margin-top:8px;">
                  <label class="portal-field"><span>Relieving Date *</span><input type="date" name="exitDate" class="portal-input" value="${todayStr}" required /></label>
                  <label class="portal-field">
                    <span>Exit Category</span>
                    <select name="exitCategory" class="portal-input">
                      <option value="resigned">Resigned</option>
                      <option value="contract_ended">Contract Ended</option>
                      <option value="terminated">Terminated</option>
                      <option value="other">Other</option>
                    </select>
                  </label>
                  <label class="portal-field">
                    <span>Final Settlement</span>
                    <select name="duesAction" class="portal-input">
                      <option value="salary_settled">Salary Settled</option>
                      <option value="salary_pending">Salary Pending</option>
                    </select>
                  </label>
                </div>
                <label class="portal-field" style="margin-top:10px;"><span>Exit Reason &amp; Note *</span><input name="exitReason" class="portal-input" placeholder="e.g. Relieved after handover" required /></label>
                <div style="margin-top:10px;"><button type="submit" class="portal-button portal-button--small">Confirm Staff Exit &amp; Revoke Login</button></div>
              </form>
            ` : ""}
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Active Staff</th><th>Role</th><th>Contact</th><th>Action</th></tr></thead>
                <tbody>
                  ${activeList.length
                    ? activeList
                        .map(
                          (s) => `<tr>
                            <td><strong>${esc(s.full_name)}</strong></td>
                            <td>${esc(s.staff_role || "Staff")}</td>
                            <td>${esc(s.phone || s.email || "-")}</td>
                            <td><button type="button" class="portal-button portal-button--small portal-button--quiet" data-pick-stf-exit="${s.id}">Mark Staff Left</button></td>
                          </tr>`
                        )
                        .join("")
                    : `<tr><td colspan="4" class="portal-empty">No active staff accounts.</td></tr>`}
                </tbody>
              </table>
            </div>
          </section>

          <section class="crm-panel">
            <div class="crm-panel-head"><h3 class="crm-panel-title">Former Staff Archive (${exitedList.length})</h3></div>
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Staff Member</th><th>Exit Date &amp; Reason</th><th>Settlement</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                  ${exitedList.length
                    ? exitedList
                        .map(
                          (ex) => `<tr>
                            <td><strong>${esc(ex.full_name)}</strong><div class="crm-panel-sub">${esc(ex.staff_role || "Staff")}</div></td>
                            <td>${esc(ex.exit_date)} · ${esc(ex.exit_reason || ex.exit_category)}</td>
                            <td>${esc(ex.dues_action.replace(/_/g, " "))}</td>
                            <td><span class="${ex.status === "left" ? "crm-state-warn" : "crm-state-ok"}">${ex.status === "left" ? "Relieved" : "Rejoined"}</span></td>
                            <td>${ex.status === "left" ? `<button type="button" class="portal-button portal-button--small" data-rejoin-stf="${ex.id}">1-Click Rejoin</button>` : `<span class="crm-panel-sub">${esc(ex.rejoined_at.slice(0, 10))}</span>`}</td>
                          </tr>`
                        )
                        .join("")
                    : `<tr><td colspan="5" class="portal-empty">No former staff records yet.</td></tr>`}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      `;

      container.querySelectorAll("[data-pick-stf-exit]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = Number(btn.getAttribute("data-pick-stf-exit"));
          selectedStaff = activeList.find((x) => Number(x.id) === id) || null;
          draw();
        });
      });
      container.querySelector("[data-cancel-stf-exit]")?.addEventListener("click", () => {
        selectedStaff = null;
        draw();
      });
      container.querySelector("[data-stf-exit-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        if (!selectedStaff) return;
        okMsg = "";
        errMsg = "";
        try {
          const out = await apiJson(adminApiUrl(`/crm/exits/staff/${selectedStaff.id}`), {
            method: "POST",
            body: Object.fromEntries(new FormData(e.currentTarget).entries())
          });
          selectedStaff = null;
          okMsg = `Staff ${out.fullName} relieved and login access revoked.`;
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });
      container.querySelectorAll("[data-rejoin-stf]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await apiJson(adminApiUrl(`/crm/exits/${btn.getAttribute("data-rejoin-stf")}/rejoin`), { method: "POST", body: {} });
          okMsg = "Staff member rejoined and access restored.";
          await load();
        });
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  // ==================== 13. ADMIN BIRTHDAYS & ROLE-WISE WELCOME MAILS PANEL ====================
  async function renderCelebrationsPanel(container, { adminApiUrl }) {
    let roleFilter = "all";
    let search = "";
    let data = { ist: {}, todayBirthdays: [], upcomingBirthdays: [], members: [], logs: [] };
    let okMsg = "";
    let errMsg = "";

    async function load() {
      try {
        data = await apiJson(adminApiUrl(`/crm/celebrations/overview?role=${encodeURIComponent(roleFilter)}`));
      } catch (e) {
        errMsg = e.message;
      }
      draw();
    }

    function draw() {
      const todayList = data.todayBirthdays || [];
      const upcomingList = data.upcomingBirthdays || [];
      const q = search.trim().toLowerCase();
      const memberList = (data.members || []).filter((m) =>
        !q || `${m.full_name} ${m.email} ${m.phone} ${m.role} ${m.roll_number || ""}`.toLowerCase().includes(q)
      );
      const logs = data.logs || [];

      container.innerHTML = `
        <div class="crm-desk-wrap">
          ${noticeHtml(okMsg, errMsg)}

          <section class="crm-panel" style="margin-bottom:14px;border-left:4px solid #8c1d18;background:linear-gradient(135deg,#fffbf5 0%,#ffffff 100%);">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Today's Birthdays (${todayList.length}) · ${esc(data.ist?.dateStr || "IST Today")}</h3>
                <p class="crm-panel-sub">Auto-wished daily at 09:00 AM IST via branded Email + Portal Celebration Banner (skips left/inactive members automatically)</p>
              </div>
              <div class="crm-row-actions">
                <button type="button" class="portal-button portal-button--small" data-run-bday-today>Run All Today's Birthday Wishes</button>
              </div>
            </div>
            ${
              todayList.length
                ? `<div class="crm-grid-2">
                    ${todayList
                      .map(
                        (m) => `<div class="crm-panel" style="background:#fffdf9;border:1px solid #e6d8c3;">
                          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
                            <div>
                              <strong>${esc(m.full_name)}</strong>
                              <div class="crm-panel-sub">${esc(String(m.role || "").toUpperCase())} ${m.roll_number ? `· ${esc(m.roll_number)}` : ""} · DOB: ${esc(m.dob)}</div>
                              <div class="crm-panel-sub">${esc(m.email || "-")} ${m.phone ? `· ${esc(m.phone)}` : ""}</div>
                            </div>
                            <span class="${Number(m.wished_this_year) > 0 ? "crm-state-ok" : "crm-state-warn"}">${Number(m.wished_this_year) > 0 ? "Wished This Year" : "Pending Wish"}</span>
                          </div>
                          <div class="crm-row-actions" style="margin-top:10px;">
                            <button type="button" class="portal-button portal-button--small" data-send-bday="${m.id}" ${Number(m.wished_this_year) > 0 ? "disabled" : ""}>${Number(m.wished_this_year) > 0 ? "Email & Portal Wished" : "Send Birthday Email & Wish"}</button>
                            ${m.whatsapp_wish_url ? `<a class="portal-button portal-button--small portal-button--quiet" href="${esc(m.whatsapp_wish_url)}" target="_blank" rel="noopener">WhatsApp Wish</a>` : ""}
                          </div>
                        </div>`
                      )
                      .join("")}
                  </div>`
                : `<p class="crm-panel-sub">No active student, teacher, staff or parent birthday falls on today's IST date. Add member DOBs below to enable automatic wishes.</p>`
            }
          </section>

          <section class="crm-panel" style="margin-bottom:14px;">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Upcoming Birthdays (Next 14 Days · ${upcomingList.length})</h3>
                <p class="crm-panel-sub">Plan warm wishes ahead for students, faculty, staff, and parents</p>
              </div>
            </div>
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Member</th><th>Role</th><th>DOB</th><th>In Days</th><th>Quick Wish</th></tr></thead>
                <tbody>
                  ${
                    upcomingList.length
                      ? upcomingList
                          .map(
                            (m) => `<tr>
                              <td><strong>${esc(m.full_name)}</strong><div class="crm-panel-sub">${esc(m.email || "-")}</div></td>
                              <td>${esc(String(m.role || "").toUpperCase())}</td>
                              <td class="crm-num">${esc(m.dob)}</td>
                              <td class="crm-num">In ${Number(m.daysUntil || 0)} day(s)</td>
                              <td>${m.whatsapp_wish_url ? `<a class="portal-button portal-button--small portal-button--quiet" href="${esc(m.whatsapp_wish_url)}" target="_blank" rel="noopener">WhatsApp</a>` : "-"}</td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="5" class="portal-empty">No upcoming birthdays in the next 14 days.</td></tr>`
                  }
                </tbody>
              </table>
            </div>
          </section>

          <section class="crm-panel" style="margin-bottom:14px;">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Member Birthdays &amp; 1-Click Role-Wise Welcome Kit Mails</h3>
                <p class="crm-panel-sub">Set or update Date of Birth for any Student, Teacher, Staff or Parent, and send warm New Joining Welcome Emails anytime</p>
              </div>
              <div class="crm-row-actions">
                <input type="search" class="portal-input" style="max-width:220px;" placeholder="Search member…" value="${esc(search)}" data-celeb-search />
              </div>
            </div>
            <div class="crm-tabs" style="margin-bottom:12px;">
              ${[
                ["all", "All Active"],
                ["student", "Students"],
                ["teacher", "Teachers"],
                ["staff", "Staff"],
                ["parent", "Parents"]
              ]
                .map(([k, lbl]) => `<button type="button" class="crm-tab-btn ${roleFilter === k ? "is-active" : ""}" data-celeb-role="${k}">${lbl}</button>`)
                .join("")}
            </div>
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Member</th><th>Role</th><th>Date of Birth (DOB)</th><th>Welcome Kit Mail</th></tr></thead>
                <tbody>
                  ${
                    memberList.length
                      ? memberList
                          .map(
                            (m) => `<tr>
                              <td><strong>${esc(m.full_name)}</strong><div class="crm-panel-sub">${esc(m.email || "-")} ${m.roll_number ? `· ${esc(m.roll_number)}` : ""}</div></td>
                              <td>${esc(String(m.role || "").toUpperCase())}</td>
                              <td>
                                <form data-save-dob-form="${m.id}" style="display:flex;align-items:center;gap:6px;">
                                  <input type="date" name="dob" class="portal-input" style="width:148px;padding:4px 8px;" value="${esc(m.dob || "")}" aria-label="DOB for ${esc(m.full_name)}" />
                                  <button type="submit" class="portal-button portal-button--small portal-button--quiet">Save DOB</button>
                                </form>
                              </td>
                              <td>
                                <div class="crm-row-actions">
                                  <button type="button" class="portal-button portal-button--small" data-send-welcome="${m.id}">${m.last_welcome_at ? "Resend Welcome Mail" : "Send Welcome Mail"}</button>
                                  ${m.last_welcome_at ? `<span class="crm-panel-sub">Sent ${esc(String(m.last_welcome_at).slice(0, 10))}</span>` : ""}
                                </div>
                              </td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="4" class="portal-empty">No matching active members found.</td></tr>`
                  }
                </tbody>
              </table>
            </div>
          </section>

          <section class="crm-panel">
            <div class="crm-panel-head">
              <div>
                <h3 class="crm-panel-title">Recent Birthday &amp; Welcome Mail Logs (${logs.length})</h3>
                <p class="crm-panel-sub">Audit trail of automatic &amp; manual birthday wishes and new joining welcome kits</p>
              </div>
            </div>
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Date</th><th>Member</th><th>Role</th><th>Type</th><th>Subject</th><th>Status</th></tr></thead>
                <tbody>
                  ${
                    logs.length
                      ? logs
                          .map(
                            (l) => `<tr>
                              <td class="crm-num">${esc(String(l.created_at || "").slice(0, 16).replace("T", " "))}</td>
                              <td><strong>${esc(l.full_name)}</strong><div class="crm-panel-sub">${esc(l.recipient_email || "-")}</div></td>
                              <td>${esc(String(l.role || "").toUpperCase())}</td>
                              <td>${l.event_type === "birthday" ? "Birthday Wish" : "Welcome Kit"}</td>
                              <td>${esc(l.subject || "-")}</td>
                              <td><span class="${l.status === "sent" ? "crm-state-ok" : "crm-state-warn"}">${esc(l.status)}</span></td>
                            </tr>`
                          )
                          .join("")
                      : `<tr><td colspan="6" class="portal-empty">No birthday or welcome mail logs recorded yet.</td></tr>`
                  }
                </tbody>
              </table>
            </div>
          </section>
        </div>
      `;

      container.querySelectorAll("[data-celeb-role]").forEach((btn) => {
        btn.addEventListener("click", () => {
          roleFilter = btn.getAttribute("data-celeb-role") || "all";
          load();
        });
      });

      container.querySelector("[data-celeb-search]")?.addEventListener("input", (e) => {
        search = e.currentTarget.value;
        draw();
      });

      container.querySelector("[data-run-bday-today]")?.addEventListener("click", async () => {
        okMsg = "";
        errMsg = "";
        try {
          const out = await apiJson(adminApiUrl("/crm/celebrations/birthday-run-today"), { method: "POST", body: {} });
          okMsg = `Today's Birthday Run complete: matched ${out.matched}, sent ${out.wished} new wish(es), ${out.alreadyWished} already wished this year.`;
          await load();
        } catch (err) {
          errMsg = err.message;
          draw();
        }
      });

      container.querySelectorAll("[data-send-bday]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          okMsg = "";
          errMsg = "";
          try {
            const uid = btn.getAttribute("data-send-bday");
            const out = await apiJson(adminApiUrl(`/crm/celebrations/birthday-wish/${uid}`), { method: "POST", body: {} });
            okMsg = out.wished > 0 ? "Birthday Email & Portal Wish sent!" : "Member has already been wished this year.";
            await load();
          } catch (err) {
            errMsg = err.message;
            draw();
          }
        });
      });

      container.querySelectorAll("[data-save-dob-form]").forEach((form) => {
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          okMsg = "";
          errMsg = "";
          const uid = form.getAttribute("data-save-dob-form");
          const dob = new FormData(form).get("dob") || "";
          try {
            await apiJson(adminApiUrl(`/crm/celebrations/dob/${uid}`), { method: "POST", body: { dob } });
            okMsg = dob ? `Date of Birth saved (${dob}).` : "Date of Birth cleared.";
            await load();
          } catch (err) {
            errMsg = err.message;
            draw();
          }
        });
      });

      container.querySelectorAll("[data-send-welcome]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          okMsg = "";
          errMsg = "";
          try {
            const uid = btn.getAttribute("data-send-welcome");
            const out = await apiJson(adminApiUrl(`/crm/celebrations/welcome-mail/${uid}`), { method: "POST", body: {} });
            okMsg = `Warm ${out.role} Welcome Kit sent to ${out.fullName} (Portal notification + Email status: ${out.emailStatus}).`;
            await load();
          } catch (err) {
            errMsg = err.message;
            draw();
          }
        });
      });
      window.YuitorUI?.enhanceTables?.(container);
    }

    await load();
  }

  window.YuitorCrmV25 = {
    mountSmartDashboardHeader,
    mountCtrlKCommandBar,
    openCommandBar,
    renderQuickFeeDesk,
    renderLeadsCrm,
    renderOnlineAcademicHub,
    renderStudentExitsPanel,
    renderTeacherOpsPanel,
    renderStaffExitsPanel,
    renderCelebrationsPanel,
    renderBulkImportExport,
    renderAutomationControl,
    renderStudentCrmTab,
    renderTeacherCrmTab
  };
})();
