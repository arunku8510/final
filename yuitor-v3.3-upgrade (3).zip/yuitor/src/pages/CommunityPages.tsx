import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Award,
  Calendar,
  ChevronDown,
  ChevronUp,
  Clock,
  X,
  Building2,
  Calculator,
  Sparkles,
  Phone,
  Mail,
} from 'lucide-react';
import type { BootstrapData } from '../types';
import {
  BATCH_OPENINGS,
  BOARD_PARTNERS,
  BRAND_IMAGES,
  BRAND_INFO,
  COMMUNITY_STATS,
  COMPARISON_ROWS,
  EDITORIAL_BLOGS,
  GALLERY_ITEMS,
  STUDENT_SUCCESS_STORIES,
  TOP_ACHIEVERS,
  UPCOMING_WORKSHOPS,
} from '../data/siteContent';
import { SafeImage } from '../components/SafeImage';
import { EnquiryForm } from '../components/EnquiryForm';
import {
  BILLING_CYCLES,
  CLASS_FEE_PLANS,
  calculateClassFeePlan,
  formatINR,
  type BillingCycleId,
} from '../utils/catalog';

/* ================= RESULTS, TOPPERS & TESTIMONIALS ================= */
export function AlumniResultsPage({
  boot,
  tab = 'results',
  onOpenEnquiry,
}: {
  boot: BootstrapData;
  tab?: 'alumni' | 'results' | 'testimonials';
  onOpenEnquiry: (course?: string) => void;
}) {
  const liveTestimonials = boot.testimonials || [];

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      <section className="bg-[#24040C] text-white py-16 border-b border-[#4A0817]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-wider text-[#E6B450]">
            {tab === 'testimonials'
              ? 'Verified Student & Parent Voices'
              : tab === 'alumni'
                ? 'Yuitor Smart Classes Alumni & Merit Network'
                : 'Verified Board & Entrance Exam Results'}
          </p>
          <h1 className="mt-2 font-editorial text-4xl sm:text-5xl font-bold text-white">
            {tab === 'testimonials'
              ? 'Trusted by Students & Parents Across Muradnagar'
              : tab === 'alumni'
                ? '2,500+ Mentored Learners Building Strong Futures'
                : '95%+ Board Toppers & Entrance Exam Achievers'}
          </h1>
          <p className="mt-3 text-base text-white/80 max-w-2xl">
            From Class 6–12 CBSE, UP Board, ICSE &amp; State Board distinctions to NEET, JEE, CUET, NDA, SSC, Banking, and practical Computer, Spoken English &amp; Coding success — explore real outcomes from {BRAND_INFO.name}.
          </p>
          <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {COMMUNITY_STATS.map((s) => (
              <div key={s.label} className="rounded-xl bg-white/10 border border-white/15 p-3.5 text-center">
                <div className="font-mono tabular-nums text-xl font-bold text-[#F3CF7A]">{s.value}</div>
                <div className="text-[11px] text-white/80 mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Top Achievers */}
      <section className="py-14 bg-white border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="font-editorial text-3xl font-bold text-[#1D1014]">
            Merit Achievers &amp; Board Toppers
          </h2>
          <div className="mt-7 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {TOP_ACHIEVERS.map((t) => (
              <div key={t.name} className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-6">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[#7A0F28]">{t.credential}</span>
                  <span className="font-mono tabular-nums text-sm font-bold text-[#B07F20]">{t.score}</span>
                </div>
                <h3 className="mt-2 font-editorial text-xl font-bold text-[#1D1014]">{t.name}</h3>
                <p className="mt-1 text-xs text-[#5E4B51]">{t.company}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Student Success Stories */}
      <section className="py-14 border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="font-editorial text-3xl font-bold text-[#1D1014]">
            Featured Student Stories
          </h2>
          <div className="mt-7 grid grid-cols-1 md:grid-cols-2 gap-6">
            {STUDENT_SUCCESS_STORIES.map((al) => (
              <div key={al.id} className="rounded-2xl bg-white border border-[#EADFE2] p-6">
                <div className="text-xs font-semibold text-[#7A0F28]">
                  {al.credential} · {al.city}
                </div>
                <h3 className="mt-1 font-editorial text-xl font-bold text-[#1D1014]">{al.name}</h3>
                <div className="text-xs text-[#76646A]">
                  {al.role} · {al.company}
                </div>
                <p className="mt-3 text-sm text-[#4B3B40] leading-relaxed">{al.story}</p>
                <div className="mt-4 pt-3 border-t border-[#F0E6E9] text-xs font-bold text-[#7A0F28]">
                  Verified Result: {al.outcome}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Live Backend Testimonials from SQLite */}
      {liveTestimonials.length > 0 && (
        <section className="py-14 bg-white border-b border-[#EADFE2]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <h2 className="font-editorial text-3xl font-bold text-[#1D1014]">
              Verified Student &amp; Parent Reviews
            </h2>
            <div className="mt-7 grid grid-cols-1 md:grid-cols-3 gap-5">
              {liveTestimonials.map((item) => (
                <div key={item.id} className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-6">
                  <p className="text-sm text-[#3A2429] leading-relaxed">&ldquo;{item.quote}&rdquo;</p>
                  <div className="mt-4 pt-3 border-t border-[#EADFE2]">
                    <div className="text-sm font-bold text-[#1D1014]">{item.student_name}</div>
                    <div className="text-xs text-[#7A0F28]">
                      {[item.course_or_class, item.achievement].filter(Boolean).join(' · ')}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Open Admission Batches */}
      <section className="py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <h2 className="font-editorial text-3xl font-bold text-[#1D1014]">
              Open Small-Batch Admissions (Muradnagar)
            </h2>
            <button
              type="button"
              onClick={() => onOpenEnquiry('Admission & Free Demo Class')}
              className="rounded-full bg-[#7A0F28] px-6 py-2.5 text-xs font-semibold text-white cursor-pointer"
            >
              Book Free 2-Day Demo
            </button>
          </div>
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-5">
            {BATCH_OPENINGS.map((batch) => (
              <div key={batch.id} className="rounded-2xl bg-white border border-[#EADFE2] p-5">
                <div className="text-xs font-bold text-[#7A0F28]">
                  {batch.company} · {batch.vacancies} Seats Left
                </div>
                <div className="mt-1.5 font-bold text-[#1D1014]">{batch.role}</div>
                <div className="mt-2 text-xs text-[#5E4B51]">
                  {batch.experience} · {batch.location} · {batch.credential}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

/* ================= GALLERY PAGE ================= */
export function GalleryPage() {
  const [filter, setFilter] = useState<string>('All');
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);

  const categories = [
    'All',
    'Campus & Facilities',
    'Classrooms & Teaching',
    'Science & Labs',
    'Computer & Coding Lab',
    'Student Activities',
    'Toppers & Events',
  ];
  const visible = filter === 'All' ? GALLERY_ITEMS : GALLERY_ITEMS.filter((g) => g.category === filter);

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      <section className="bg-[#24040C] text-white py-14 border-b border-[#4A0817]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-wider text-[#E6B450]">
            Trimurti Vihar, Muradnagar · Campus Chronicles
          </p>
          <h1 className="mt-2 font-editorial text-4xl sm:text-5xl font-bold text-white">
            Yuitor Smart Classes Gallery — Classrooms, Labs &amp; Toppers
          </h1>
          <div className="mt-6 flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setFilter(c)}
                className={`rounded-full px-4 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                  filter === c
                    ? 'bg-[#E6B450] text-[#1D1014]'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {visible.map((item, idx) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setLightboxIdx(idx)}
              className="group text-left rounded-2xl bg-white border border-[#EADFE2] overflow-hidden hover:border-[#7A0F28]/50 transition-colors cursor-pointer"
            >
              <div className="aspect-[4/3] overflow-hidden bg-[#24040C]">
                <SafeImage
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4">
                <div className="text-[11px] font-semibold text-[#7A0F28]">
                  {item.category} · {item.location}
                </div>
                <h2 className="mt-1 font-editorial text-base font-bold text-[#1D1014]">
                  {item.title}
                </h2>
                <p className="mt-1 text-xs text-[#5E4B51] line-clamp-2">{item.caption}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {lightboxIdx !== null && visible[lightboxIdx] && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Photo lightbox"
          onClick={() => setLightboxIdx(null)}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-3xl w-full rounded-2xl bg-white overflow-hidden"
          >
            <button
              type="button"
              onClick={() => setLightboxIdx(null)}
              aria-label="Close photo"
              className="absolute top-3 right-3 z-10 w-9 h-9 rounded-full bg-black/70 text-white flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="aspect-[16/10] bg-black">
              <SafeImage
                src={visible[lightboxIdx].image}
                alt={visible[lightboxIdx].title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-5">
              <div className="text-xs font-semibold text-[#7A0F28]">
                {visible[lightboxIdx].category} · {visible[lightboxIdx].location}
              </div>
              <h3 className="mt-1 font-editorial text-xl font-bold text-[#1D1014]">
                {visible[lightboxIdx].title}
              </h3>
              <p className="mt-1.5 text-sm text-[#5E4B51]">{visible[lightboxIdx].caption}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= FREE WORKSHOPS & DEMO WEBINARS PAGE ================= */
export function WebinarsPage({ boot }: { boot: BootstrapData }) {
  const [selectedWorkshop, setSelectedWorkshop] = useState(UPCOMING_WORKSHOPS[0].title);

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      <section className="bg-[#24040C] text-white py-14 border-b border-[#4A0817]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-wider text-[#E6B450]">
            Free Strategy Workshops &amp; Live Demo Sessions
          </p>
          <h1 className="mt-2 font-editorial text-4xl sm:text-5xl font-bold text-white">
            Attend Free Board, JEE/NEET &amp; Skill Lab Workshops
          </h1>
          <p className="mt-3 text-base text-white/80 max-w-2xl">
            Join interactive offline &amp; live online orientation sessions with {BRAND_INFO.name} senior faculty — includes free printed formula sheets, demo classes, and scholarship eligibility.
          </p>
        </div>
      </section>

      <section className="py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-7 space-y-5">
            {UPCOMING_WORKSHOPS.map((w) => (
              <div
                key={w.id}
                className={`rounded-2xl bg-white border p-6 transition-colors ${
                  selectedWorkshop === w.title ? 'border-[#7A0F28] ring-2 ring-[#7A0F28]/15' : 'border-[#EADFE2]'
                }`}
              >
                <div className="text-xs font-semibold text-[#7A0F28]">{w.topicTag}</div>
                <h2 className="mt-1.5 font-editorial text-2xl font-bold text-[#1D1014]">{w.title}</h2>
                <p className="mt-2 text-sm text-[#5E4B51] leading-relaxed">{w.summary}</p>
                <div className="mt-4 flex flex-wrap gap-4 text-xs text-[#4B3B40]">
                  <span className="inline-flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#7A0F28]" aria-hidden="true" />
                    {w.date}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#7A0F28]" aria-hidden="true" />
                    {w.time}
                  </span>
                </div>
                <div className="mt-4 pt-4 border-t border-[#F0E6E9] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="text-xs">
                    <strong className="text-[#1D1014]">{w.speaker}</strong> ·{' '}
                    <span className="text-[#76646A]">{w.speakerRole}</span>
                    <div className="text-[#B07F20] font-semibold mt-0.5">{w.benefit}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedWorkshop(w.title)}
                    className="rounded-full bg-[#7A0F28] hover:bg-[#58091B] px-5 py-2 text-xs font-semibold text-white cursor-pointer whitespace-nowrap"
                  >
                    Select Workshop
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="lg:col-span-5">
            <EnquiryForm
              heading="Reserve Your Free Workshop Seat"
              subheading={`Selected session: ${selectedWorkshop}`}
              ctaLabel="Confirm Free Seat"
              defaultCourse={`Workshop: ${selectedWorkshop}`}
              source="webinar_registration"
              courses={boot.courses}
              branches={boot.branches}
              compact
            />
          </div>
        </div>
      </section>
    </div>
  );
}

/* ================= ACADEMIC & SCHOOL PARTNERSHIPS PAGE ================= */
export function CorporatePage({
  boot,
  section = 'journey',
}: {
  boot: BootstrapData;
  section?: 'journey' | 'events' | 'tie-ups';
}) {
  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      <section className="bg-[#24040C] text-white py-16 border-b border-[#4A0817]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-wider text-[#E6B450]">
            School Programs, Parent Seminars &amp; Academic Tracks
          </p>
          <h1 className="mt-2 font-editorial text-4xl sm:text-5xl font-bold text-white">
            {section === 'events'
              ? 'Academic Seminars, Toppers Meet & Parent Orientations'
              : section === 'tie-ups'
                ? 'Boards, Competitive Exams & Skill Lab Tracks'
                : 'Yuitor Smart Classes Academic Ecosystem'}
          </h1>
          <p className="mt-3 text-base text-white/80 max-w-2xl">
            Delivering integrated Classes 6–12 board alignment, entrance coaching, and 1-to-1 Computer Classes, Spoken English &amp; Coding Classes at {BRAND_INFO.address}.
          </p>
        </div>
      </section>

      <section className="py-14 bg-white border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="font-editorial text-2xl sm:text-3xl font-bold text-[#1D1014]">
            Boards, Entrance Exams &amp; Skill Disciplines
          </h2>
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
            {BOARD_PARTNERS.map((partner) => (
              <div
                key={partner}
                className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] py-4 px-3 text-center text-sm font-bold text-[#1D1014]"
              >
                {partner}
              </div>
            ))}
          </div>

          <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#7A0F28]">
                <Building2 className="w-4 h-4" aria-hidden="true" />
                <span>Active Academic Batches</span>
              </div>
              <h3 className="font-editorial text-2xl font-bold text-[#1D1014]">
                Small-Batch Discipline With Live Parent ERP
              </h3>
              <p className="text-sm text-[#4B3B40] leading-relaxed">
                Every student batch at {BRAND_INFO.name} combines daily concept instruction, Sunday testing, AI-assisted weak-topic revision, and transparent Student &amp; Parent portal tracking.
              </p>
              <div className="space-y-3 pt-2">
                {BATCH_OPENINGS.slice(0, 4).map((b) => (
                  <div key={b.id} className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] p-4">
                    <div className="font-bold text-sm text-[#1D1014]">{b.company} — {b.role}</div>
                    <div className="text-xs text-[#5E4B51] mt-0.5">{b.experience} · {b.location}</div>
                  </div>
                ))}
              </div>
            </div>

            <EnquiryForm
              heading="Request Batch Details or School Workshop"
              subheading="Connect with our Muradnagar campus leadership desk."
              ctaLabel="Submit Request"
              defaultCourse="Academic Batch & Demo Enquiry"
              source={`academic_${section}`}
              courses={boot.courses}
              branches={boot.branches}
            />
          </div>
        </div>
      </section>
    </div>
  );
}

/* ================= BLOGS & ARTICLE READER ================= */
export function BlogsPage({
  boot,
  slug,
  presetCategory,
  onNavigate,
}: {
  boot: BootstrapData;
  slug?: string;
  presetCategory?: string;
  onNavigate: (path: string) => void;
}) {
  const [cat, setCat] = useState(presetCategory || 'All');
  const allPosts = [...(boot.blogs || []), ...EDITORIAL_BLOGS];

  function go(e: React.MouseEvent, path: string) {
    e.preventDefault();
    onNavigate(path);
  }

  if (slug) {
    const post = allPosts.find((p) => p.slug === slug) || allPosts[0];
    return (
      <article className="bg-[#FAF7F5] text-[#1D1014] py-12 lg:py-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6">
          <a
            href="/blog"
            onClick={(e) => go(e, '/blog')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#7A0F28] hover:underline"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Study Guides</span>
          </a>

          <div className="mt-5 text-xs text-[#76646A]">
            {post.category} · {post.author || 'Yuitor Academic Desk'} · {post.readTime || '5 min read'}
          </div>
          <h1 className="mt-2 font-editorial text-3xl sm:text-5xl font-bold text-[#1D1014] leading-tight">
            {post.title}
          </h1>

          {post.image && (
            <div className="mt-7 rounded-2xl overflow-hidden border border-[#EADFE2] aspect-[16/9]">
              <SafeImage src={post.image} alt={post.title} className="w-full h-full object-cover" />
            </div>
          )}

          <div className="mt-8 space-y-5 text-base text-[#3A2429] leading-relaxed">
            {post.content.split('\n\n').map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </div>

          <div className="mt-12 rounded-2xl bg-[#24040C] text-white p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="font-editorial text-xl font-bold">Need Personalized Study Guidance?</div>
              <p className="text-xs text-white/75 mt-1">
                Book a free 2-day demo class or call {BRAND_INFO.phoneDisplay} to speak with {BRAND_INFO.name} faculty.
              </p>
            </div>
            <a
              href="/contact"
              onClick={(e) => go(e, '/contact')}
              className="rounded-full bg-[#E6B450] text-[#1D1014] font-bold px-5 py-2.5 text-xs whitespace-nowrap"
            >
              Book Free Demo
            </a>
          </div>
        </div>
      </article>
    );
  }

  const categories = ['All', 'Board Exams', 'Competitive Exams', 'Skill Courses', 'Student Corner'];
  const visible = cat === 'All' ? allPosts : allPosts.filter((p) => p.category === cat);

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      <section className="bg-[#24040C] text-white py-14 border-b border-[#4A0817]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-wider text-[#E6B450]">
            Yuitor Smart Classes · Study Guides &amp; Student Corner
          </p>
          <h1 className="mt-2 font-editorial text-4xl sm:text-5xl font-bold text-white">
            Blogs, Board Tips &amp; Competitive Exam Strategies
          </h1>
          <div className="mt-6 flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCat(c)}
                className={`rounded-full px-4 py-2 text-xs font-semibold cursor-pointer transition-colors ${
                  cat === c ? 'bg-[#E6B450] text-[#1D1014]' : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {visible.map((post) => (
            <a
              key={post.slug}
              href={`/blog/${post.slug}`}
              onClick={(e) => go(e, `/blog/${post.slug}`)}
              className="group rounded-2xl bg-white border border-[#EADFE2] overflow-hidden flex flex-col hover:border-[#7A0F28]/50 transition-colors"
            >
              <div className="aspect-[16/10] bg-[#24040C] overflow-hidden">
                <SafeImage
                  src={post.image || BRAND_IMAGES.studyNotes}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-xs text-[#76646A]">
                    {post.category} · {post.readTime || '5 min read'}
                  </div>
                  <h2 className="mt-1.5 font-editorial text-xl font-bold text-[#1D1014] group-hover:text-[#7A0F28]">
                    {post.title}
                  </h2>
                  <p className="mt-2 text-sm text-[#5E4B51] line-clamp-3">{post.excerpt}</p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#F0E6E9] text-xs font-semibold text-[#7A0F28]">
                  Read Full Guide →
                </div>
              </div>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}

/* ================= FEE CALCULATOR PAGE ================= */
export function FeeCalculatorPage({ boot }: { boot: BootstrapData }) {
  const [selectedClass, setSelectedClass] = useState<number>(10);
  const [cycle, setCycle] = useState<BillingCycleId>('yearly');
  const [scholarship, setScholarship] = useState<number>(0);

  const planCalc = calculateClassFeePlan(selectedClass, cycle);
  const scholarshipDiscount = Math.round((planCalc.totalPayable * Math.min(50, Math.max(0, scholarship))) / 100);
  const finalPayable = Math.max(0, planCalc.totalPayable - scholarshipDiscount);

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014] py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="max-w-3xl mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#7A0F28]">
            <Calculator className="w-4 h-4" aria-hidden="true" />
            <span>Class-Wise Tuition Structure · {BRAND_INFO.name}</span>
          </div>
          <h1 className="mt-2 font-editorial text-4xl font-bold text-[#1D1014]">
            Class-Wise Fee Structure &amp; Billing Calculator
          </h1>
          <p className="mt-2 text-sm text-[#5E4B51]">
            Transparent class-wise fees for Classes 6th to 12th across 1 Month, 3 Months, 6 Months, 9 Months, and Yearly (10% OFF) billing cycles.
          </p>
        </div>

        {/* Complete Class-Wise Fee Table */}
        <div className="rounded-2xl bg-white border border-[#EADFE2] overflow-hidden mb-10">
          <div className="px-6 py-4 border-b border-[#EADFE2] flex flex-wrap items-center justify-between gap-2 bg-[#FAF7F5]">
            <h2 className="text-base font-bold text-[#1D1014]">Official Class 6th – Class 12th Fee Structure</h2>
            <span className="text-xs font-semibold text-[#7A0F28]">Yearly Plan includes flat 10% OFF</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm" data-testid="class-fee-table">
              <thead>
                <tr className="border-b border-[#EADFE2] bg-[#FAF7F5]/70 text-xs uppercase tracking-wider text-[#5E4B51]">
                  <th className="py-3 px-4 font-bold">Class</th>
                  <th className="py-3 px-4 font-bold">1 Month</th>
                  <th className="py-3 px-4 font-bold">3 Months</th>
                  <th className="py-3 px-4 font-bold">6 Months</th>
                  <th className="py-3 px-4 font-bold">9 Months</th>
                  <th className="py-3 px-4 font-bold text-[#7A0F28]">Yearly (12m, 10% OFF)</th>
                </tr>
              </thead>
              <tbody>
                {CLASS_FEE_PLANS.map((row) => {
                  const isActive = row.classNumber === selectedClass;
                  return (
                    <tr
                      key={row.classNumber}
                      onClick={() => setSelectedClass(row.classNumber)}
                      className={`border-b border-[#F1E8EA] cursor-pointer transition-colors ${
                        isActive ? 'bg-[#7A0F28]/6 font-semibold' : 'hover:bg-[#FAF7F5]'
                      }`}
                    >
                      <td className="py-3 px-4 font-bold text-[#1D1014]">{row.classLabel}</td>
                      <td className="py-3 px-4 font-mono tabular-nums">{formatINR(row.m1)}</td>
                      <td className="py-3 px-4 font-mono tabular-nums">{formatINR(row.m3)}</td>
                      <td className="py-3 px-4 font-mono tabular-nums">{formatINR(row.m6)}</td>
                      <td className="py-3 px-4 font-mono tabular-nums">{formatINR(row.m9)}</td>
                      <td className="py-3 px-4 font-mono tabular-nums font-bold text-[#7A0F28]">
                        {formatINR(row.yearlyTotal)}{' '}
                        <span className="text-xs font-medium text-[#5E4B51]">(save {formatINR(row.yearlySavings)})</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 rounded-2xl bg-white border border-[#EADFE2] p-7 space-y-6">
            <div>
              <label htmlFor="fee-class-select" className="block text-xs font-bold text-[#4B3B40] mb-1.5">
                Select Class (6th – 12th)
              </label>
              <select
                id="fee-class-select"
                value={selectedClass}
                onChange={(e) => setSelectedClass(Number(e.target.value))}
                className="w-full rounded-xl border border-[#DFD1D5] bg-[#FAF7F5] px-4 py-3 text-sm font-medium text-[#1D1014]"
              >
                {CLASS_FEE_PLANS.map((p) => (
                  <option key={p.classNumber} value={p.classNumber}>
                    {p.classLabel} — {formatINR(p.monthly)}/month · Yearly {formatINR(p.yearlyTotal)} (10% OFF)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <span className="block text-xs font-bold text-[#4B3B40] mb-2">Billing Cycle</span>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {BILLING_CYCLES.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    data-testid={`billing-cycle-${opt.id}`}
                    onClick={() => setCycle(opt.id)}
                    className={`rounded-xl py-2.5 px-2.5 text-xs font-semibold border cursor-pointer transition-colors ${
                      cycle === opt.id
                        ? 'bg-[#7A0F28] text-white border-[#7A0F28]'
                        : 'bg-[#FAF7F5] text-[#1D1014] border-[#EADFE2]'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs font-bold text-[#4B3B40] mb-2">
                <label htmlFor="fee-schol">Optional Merit Scholarship Waiver</label>
                <span className="font-mono tabular-nums text-[#7A0F28]">{scholarship}% Off</span>
              </div>
              <input
                id="fee-schol"
                type="range"
                min={0}
                max={50}
                step={5}
                value={scholarship}
                onChange={(e) => setScholarship(Number(e.target.value))}
                className="w-full accent-[#7A0F28]"
              />
            </div>

            {/* Live Calculation Output */}
            <div className="rounded-2xl bg-[#24040C] text-white p-6 space-y-3" data-testid="fee-calc-summary">
              <div className="flex justify-between text-sm text-white/75">
                <span>
                  {planCalc.classLabel} × {planCalc.months} Month{planCalc.months > 1 ? 's' : ''} ({formatINR(planCalc.monthlyRate)}/mo)
                </span>
                <span className="font-mono tabular-nums">{formatINR(planCalc.subtotal)}</span>
              </div>
              {planCalc.discountAmount > 0 && (
                <div className="flex justify-between text-sm text-[#F3CF7A]">
                  <span>Yearly Plan Discount (10% OFF)</span>
                  <span className="font-mono tabular-nums">- {formatINR(planCalc.discountAmount)}</span>
                </div>
              )}
              {scholarshipDiscount > 0 && (
                <div className="flex justify-between text-sm text-[#F3CF7A]">
                  <span>Merit Scholarship Waiver ({scholarship}%)</span>
                  <span className="font-mono tabular-nums">- {formatINR(scholarshipDiscount)}</span>
                </div>
              )}
              <div className="pt-3 border-t border-white/15 flex items-baseline justify-between">
                <div>
                  <div className="text-xs text-white/70">Final Payable Total ({planCalc.cycleLabel})</div>
                  <div className="font-mono tabular-nums text-3xl font-bold text-[#F3CF7A]" data-testid="fee-calc-total">
                    {formatINR(finalPayable)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-white/70">Effective Monthly</div>
                  <div className="font-mono tabular-nums text-lg font-bold text-white">
                    {formatINR(Math.round(finalPayable / planCalc.months))}/mo
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <EnquiryForm
              heading="Lock Your Class Fee Plan"
              subheading={`${planCalc.classLabel} · ${planCalc.cycleLabel} · ${formatINR(finalPayable)}`}
              ctaLabel="Request Official Fee Sheet"
              defaultCourse={`${planCalc.classLabel} (${planCalc.cycleLabel})`}
              source="fee_calculator"
              courses={boot.courses}
              branches={boot.branches}
              compact
            />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= SCHOLARSHIP PAGE ================= */
export function ScholarshipPage({ boot }: { boot: BootstrapData }) {
  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      <section className="bg-[#24040C] text-white py-14 border-b border-[#4A0817]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#E6B450]">
            <Sparkles className="w-4 h-4" aria-hidden="true" />
            <span>Yuitor Smart Classes · Merit &amp; Need-Based Grants</span>
          </div>
          <h1 className="mt-2 font-editorial text-4xl sm:text-5xl font-bold text-white">
            Up to 50% Merit Scholarship for Deserving Students
          </h1>
          <p className="mt-3 text-base text-white/80 max-w-2xl">
            Awarded based on previous school marks, Class 10/12 board percentages, or our 30-minute Yuitor Scholarship Diagnostic Test at our Muradnagar campus.
          </p>
        </div>
      </section>

      <section className="py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7 space-y-4">
            {[
              {
                tier: 'Tier 1 · 50% Tuition Waiver',
                req: '95%+ in Class 9/10/11/12 School or Board Exams, or Top 5% score in Yuitor Scholarship Test.',
              },
              {
                tier: 'Tier 2 · 30% Tuition Waiver',
                req: '85%+ Academic Aggregate in CBSE / UP Board / ICSE / State Board exams or strong diagnostic score.',
              },
              {
                tier: 'Tier 3 · 15% Sibling & Early-Bird Support',
                req: 'Two or more siblings enrolling together, early-session admission, or single-parent support.',
              },
            ].map((s) => (
              <div key={s.tier} className="rounded-2xl bg-white border border-[#EADFE2] p-6">
                <div className="flex items-center gap-2 text-[#7A0F28] font-bold text-base">
                  <Award className="w-5 h-5" aria-hidden="true" />
                  <span>{s.tier}</span>
                </div>
                <p className="mt-2 text-sm text-[#5E4B51]">{s.req}</p>
              </div>
            ))}
          </div>

          <div className="lg:col-span-5">
            <EnquiryForm
              heading="Apply for Merit Scholarship Test"
              subheading="Schedule your free 30-minute assessment at Trimurti Vihar, Muradnagar."
              ctaLabel="Register for Scholarship"
              defaultCourse="Yuitor Merit Scholarship Test"
              source="scholarship_page"
              courses={boot.courses}
              branches={boot.branches}
              compact
            />
          </div>
        </div>
      </section>
    </div>
  );
}

/* ================= COMPARISON PAGE ================= */
export function ComparisonPage({ onOpenEnquiry }: { onOpenEnquiry: (course?: string) => void }) {
  return (
    <div className="bg-[#FAF7F5] text-[#1D1014] py-14">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">Side-by-Side Comparison</p>
        <h1 className="mt-2 font-editorial text-4xl font-bold text-[#1D1014]">
          Why Families Choose {BRAND_INFO.name}
        </h1>
        <p className="mt-2 text-base text-[#5E4B51] max-w-2xl">
          Compare batch sizes, board + competitive exam alignment, practical computer/coding labs, AI study support, and Parent ERP transparency.
        </p>

        <div className="mt-8 rounded-2xl bg-white border border-[#EADFE2] overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-[#24040C] text-white">
                <th className="py-4 px-5 font-semibold">Feature</th>
                <th className="py-4 px-5 font-semibold text-[#F3CF7A]">{BRAND_INFO.name}</th>
                <th className="py-4 px-5 font-semibold text-white/70">Traditional Coaching</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F0E6E9]">
              {COMPARISON_ROWS.map((row) => (
                <tr key={row.feature}>
                  <td className="py-4 px-5 font-semibold text-[#1D1014]">{row.feature}</td>
                  <td className="py-4 px-5 font-semibold text-[#7A0F28]">✓ {row.ours}</td>
                  <td className="py-4 px-5 text-[#76646A]">{row.others}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-8 text-center">
          <button
            type="button"
            onClick={() => onOpenEnquiry('Free 2-Day Demo Class')}
            className="inline-flex items-center gap-2 rounded-full bg-[#7A0F28] hover:bg-[#58091B] px-7 py-3 text-sm font-semibold text-white cursor-pointer"
          >
            <span>Book a Free 2-Day Demo Class in Muradnagar</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ================= FAQS PAGE ================= */
export function FaqsPage({ boot }: { boot: BootstrapData }) {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  const fallbackFaqs = [
    {
      id: 'f1',
      question: 'Which classes and boards are taught at Yuitor Smart Classes?',
      answer:
        'We offer dedicated small-batch coaching for Class 6, Class 7, Class 8, Class 9, Class 10, Class 11, and Class 12 across UP Board (Hindi & English medium), ICSE/ISC, and State Boards.',
    },
    {
      id: 'f2',
      question: 'Which competitive exams and skill courses are available?',
      answer:
        'Alongside school academics, we run dedicated NEET Coaching, JEE Coaching, CUET Coaching, NDA Coaching, SSC Coaching, and Banking Coaching batches, plus 1-to-1 practical Computer Classes (DCA, Tally Prime + GST, CCC), Spoken English, and Coding Classes (Python & Web Dev).',
    },
    {
      id: 'f3',
      question: 'Where is the Yuitor Smart Classes campus located?',
      answer: `Our campus is located at ${BRAND_INFO.address}. You can call or WhatsApp us at ${BRAND_INFO.phoneDisplay} or email ${BRAND_INFO.email}.`,
    },
    {
      id: 'f4',
      question: 'How do students and parents track daily attendance, homework, and Sunday test marks?',
      answer:
        'Every admitted student and parent receives login access to our unified ERP Portal (/login) showing live QR attendance, chapter notes, weekly test scorecards, fee receipts, and faculty remarks.',
    },
    {
      id: 'f5',
      question: 'Can my child attend a free demo class before taking admission?',
      answer:
        'Yes! Every new learner gets 2 free offline or live demo classes so both student and parents can experience our teaching quality and small batch discipline first.',
    },
  ];
  const allFaqs = [...(boot.faqs || []), ...fallbackFaqs];

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014] py-14">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">Knowledge Base</p>
        <h1 className="mt-2 font-editorial text-4xl font-bold text-[#1D1014]">
          Frequently Asked Questions
        </h1>
        <div className="mt-8 space-y-3">
          {allFaqs.map((faq, idx) => {
            const open = openIdx === idx;
            return (
              <div key={faq.id} className="rounded-xl bg-white border border-[#EADFE2] overflow-hidden">
                <button
                  type="button"
                  aria-expanded={open}
                  onClick={() => setOpenIdx(open ? null : idx)}
                  className="w-full px-5 py-4 flex items-center justify-between gap-4 text-left font-semibold text-sm sm:text-base text-[#1D1014] cursor-pointer"
                >
                  <span>{faq.question}</span>
                  {open ? (
                    <ChevronUp className="w-4 h-4 text-[#7A0F28]" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-[#76646A]" />
                  )}
                </button>
                {open && (
                  <div className="px-5 pb-4 pt-3 border-t border-[#F0E6E9] text-sm text-[#5E4B51] leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ================= LEGAL POLICIES PAGE ================= */
export function LegalPage({ doc }: { doc: 'privacy' | 'terms' | 'refund' | 'cookies' }) {
  const map = {
    privacy: {
      title: 'Privacy Policy',
      body: [
        `${BRAND_INFO.name} (${BRAND_INFO.address}) respects your privacy and safeguards personal details submitted through our admission enquiry forms, student registrations, teacher applications, and unified Student/Parent ERP portals.`,
        'Information collected (such as student name, parent contact number, email, class/board stream, and attendance/fee records) is used strictly for academic counselling, classroom communication, test result alerts, and portal security.',
        `We never sell student or parent phone numbers to third-party marketers. For privacy requests or grievance redressal, write to ${BRAND_INFO.email} or ${BRAND_INFO.complaintsEmail}.`,
      ],
    },
    terms: {
      title: 'Terms of Service',
      body: [
        `Enrollment in ${BRAND_INFO.name} batches (Classes 6–12, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer Classes, Spoken English, and Coding Classes) grants personal access to classroom sessions, printed/digital study notes, weekly tests, and ERP portal login.`,
        'Students are expected to maintain regular attendance, submit weekly assignments honestly, and protect campus lab equipment and personal portal credentials.',
      ],
    },
    refund: {
      title: 'Refund & Cancellation Policy',
      body: [
        `Every prospective learner at ${BRAND_INFO.name} is invited to attend a free 2-day demo class before paying tuition fees.`,
        `Any fee adjustment or cancellation request submitted within 7 calendar days of admission is reviewed transparently by our Muradnagar administrative desk. For assistance or formal escalation, email ${BRAND_INFO.complaintsEmail} or call ${BRAND_INFO.phoneDisplay}.`,
      ],
    },
    cookies: {
      title: 'Cookie Policy',
      body: [
        `The ${BRAND_INFO.name} web application uses strictly necessary session cookies to keep Student, Teacher, Parent, Staff, and Admin ERP sessions authenticated securely, along with local preferences for shopping cart continuity.`,
      ],
    },
  };

  const content = map[doc];
  return (
    <div className="bg-[#FAF7F5] text-[#1D1014] py-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 bg-white border border-[#EADFE2] rounded-2xl p-8 sm:p-10">
        <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">
          {BRAND_INFO.name} · Legal &amp; Governance
        </p>
        <h1 className="mt-2 font-editorial text-3xl sm:text-4xl font-bold text-[#1D1014]">
          {content.title}
        </h1>
        <div className="mt-6 space-y-4 text-sm sm:text-base text-[#4B3B40] leading-relaxed">
          {content.body.map((p, idx) => (
            <p key={idx}>{p}</p>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-[#F0E6E9] flex flex-wrap gap-4 text-xs text-[#5E4B51]">
          <a href={BRAND_INFO.phoneHref} className="inline-flex items-center gap-1.5 font-semibold text-[#7A0F28]">
            <Phone className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{BRAND_INFO.phoneDisplay}</span>
          </a>
          <a href={`mailto:${BRAND_INFO.email}`} className="inline-flex items-center gap-1.5 hover:text-[#7A0F28]">
            <Mail className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{BRAND_INFO.email}</span>
          </a>
          <a href={`mailto:${BRAND_INFO.complaintsEmail}`} className="inline-flex items-center gap-1.5 hover:text-[#7A0F28]">
            <Mail className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Complaints: {BRAND_INFO.complaintsEmail}</span>
          </a>
        </div>
      </div>
    </div>
  );
}
