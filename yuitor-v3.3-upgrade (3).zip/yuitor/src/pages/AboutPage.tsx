import React from 'react';
import { ArrowRight, Target, Eye, Compass } from 'lucide-react';
import type { BootstrapData } from '../types';
import {
  BRAND_IMAGES,
  BRAND_INFO,
  COMMUNITY_STATS,
  COMPARISON_ROWS,
  LEADERSHIP_COUNCIL,
} from '../data/siteContent';
import { SafeImage } from '../components/SafeImage';

interface AboutPageProps {
  boot: BootstrapData;
  defaultTab?: 'about' | 'teachers';
  onNavigate: (path: string) => void;
  onOpenEnquiry: (course?: string) => void;
}

export function AboutPage({ boot, defaultTab = 'about', onNavigate, onOpenEnquiry }: AboutPageProps) {
  function go(e: React.MouseEvent, path: string) {
    e.preventDefault();
    onNavigate(path);
  }

  const liveTeachers = boot.teachers || [];

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      {/* Hero */}
      <section className="bg-[#24040C] text-white py-16 lg:py-22 border-b border-[#4A0817]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7">
            <p className="text-xs font-semibold tracking-wider text-[#E6B450]">
              {defaultTab === 'teachers' ? 'Experienced Subject Faculty' : `About ${BRAND_INFO.name}`}
            </p>
            <h1 className="mt-2 font-editorial text-4xl sm:text-5xl font-bold text-white leading-tight">
              {defaultTab === 'teachers'
                ? 'Learn From Dedicated Board, Entrance & Skill Mentors'
                : 'Smart Technology. Personal Mentorship. Real Results.'}
            </h1>
            <p className="mt-4 text-base text-white/80 leading-relaxed max-w-2xl">
              Based at Trimurti Vihar, Near Venus Academy in Muradnagar, Yuitor Smart Classes empowers Classes 6–12 students across UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer Classes, Spoken English, and Coding Classes with disciplined teaching and transparent parent ERP tracking.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => onOpenEnquiry()}
                className="inline-flex items-center gap-2 rounded-full bg-[#8C102B] hover:bg-[#A61434] px-6 py-3 text-sm font-semibold text-white transition-colors cursor-pointer"
              >
                <span>Book a Free Demo Class</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <a
                href="/courses"
                onClick={(e) => go(e, '/courses')}
                className="rounded-full border border-white/30 hover:border-[#F3CF7A] px-6 py-3 text-sm font-semibold text-white transition-colors"
              >
                Explore All Courses
              </a>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="rounded-2xl overflow-hidden border border-white/15 aspect-[4/3]">
              <SafeImage
                src={BRAND_IMAGES.campusExterior}
                alt="Yuitor Smart Classes Campus in Trimurti Vihar, Muradnagar"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Purpose */}
      <section className="py-16 bg-white border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: Target,
              title: 'Our Mission',
              body: 'Deliver high-discipline, concept-first coaching for Classes 6–12, UP Board/ICSE/State Boards, competitive exams, and practical Computer, Spoken English & Coding courses right in Muradnagar at fair monthly fees.',
            },
            {
              icon: Eye,
              title: 'Our Vision',
              body: 'To be Muradnagar’s most trusted smart learning campus — combining personal teacher mentorship with AI-assisted practice and 100% transparent parent visibility.',
            },
            {
              icon: Compass,
              title: 'Our Teaching Philosophy',
              body: 'Small batches of 15–20 learners, daily homework accountability, Sunday written/OMR tests, and zero student left behind.',
            },
          ].map((pillar) => {
            const Icon = pillar.icon;
            return (
              <div key={pillar.title} className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-7">
                <Icon className="w-6 h-6 text-[#7A0F28]" aria-hidden="true" />
                <h2 className="mt-4 font-editorial text-2xl font-bold text-[#1D1014]">
                  {pillar.title}
                </h2>
                <p className="mt-2.5 text-sm text-[#4B3B40] leading-relaxed">{pillar.body}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Faculty & Leadership */}
      <section className="py-16 bg-[#FAF7F5] border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">Academic Mentors</p>
          <h2 className="mt-1.5 font-editorial text-3xl sm:text-4xl font-bold text-[#1D1014]">
            Director &amp; Senior Subject Faculty
          </h2>

          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {LEADERSHIP_COUNCIL.map((leader) => (
              <div
                key={leader.name}
                className="rounded-2xl bg-white border border-[#EADFE2] overflow-hidden flex flex-col"
              >
                <div className="aspect-[4/3] overflow-hidden bg-[#24040C]">
                  <SafeImage
                    src={leader.image}
                    alt={leader.name}
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <div className="p-5 flex-1">
                  <h3 className="font-editorial text-lg font-bold text-[#1D1014]">{leader.name}</h3>
                  <div className="text-xs font-semibold text-[#7A0F28] mt-0.5">{leader.role}</div>
                  <p className="mt-2 text-xs text-[#5E4B51] leading-relaxed">{leader.bio}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Live Backend Registered Faculty from SQLite */}
          {liveTeachers.length > 0 && (
            <div className="mt-14">
              <h3 className="font-editorial text-2xl font-bold text-[#1D1014]">
                Verified Portal Teachers
              </h3>
              <div className="mt-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {liveTeachers.map((t) => (
                  <div key={t.id} className="rounded-2xl bg-white border border-[#EADFE2] p-5">
                    <div className="text-base font-bold text-[#1D1014]">{t.full_name}</div>
                    <div className="text-xs font-semibold text-[#7A0F28] mt-0.5">
                      {t.qualification || 'Subject Specialist'}
                      {t.experience_years ? ` · ${t.experience_years}+ yrs exp` : ''}
                    </div>
                    <p className="mt-2 text-xs text-[#5E4B51] leading-relaxed">
                      {t.bio || 'Dedicated classroom & portal mentor guiding students through structured weekly tests.'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Metrics & Comparison */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 text-center mb-14">
            {COMMUNITY_STATS.map((s) => (
              <div key={s.label} className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] p-4">
                <div className="font-mono tabular-nums text-2xl font-bold text-[#7A0F28]">
                  {s.value}
                </div>
                <div className="text-xs text-[#5E4B51] mt-1">{s.label}</div>
              </div>
            ))}
          </div>

          <h2 className="font-editorial text-3xl font-bold text-[#1D1014] mb-6">
            Why Families Choose {BRAND_INFO.name}
          </h2>
          <div className="rounded-2xl bg-white border border-[#EADFE2] overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-[#24040C] text-white">
                  <th className="py-3.5 px-4 font-semibold">Criterion</th>
                  <th className="py-3.5 px-4 font-semibold text-[#F3CF7A]">{BRAND_INFO.name}</th>
                  <th className="py-3.5 px-4 font-semibold text-white/70">Typical Coaching</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F0E6E9]">
                {COMPARISON_ROWS.map((row) => (
                  <tr key={row.feature}>
                    <td className="py-3.5 px-4 font-semibold text-[#1D1014]">{row.feature}</td>
                    <td className="py-3.5 px-4 font-semibold text-[#7A0F28]">✓ {row.ours}</td>
                    <td className="py-3.5 px-4 text-[#76646A]">{row.others}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
}
