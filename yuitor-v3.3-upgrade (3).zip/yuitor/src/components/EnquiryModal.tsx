import { useEffect } from 'react';
import { X } from 'lucide-react';
import { EnquiryForm } from './EnquiryForm';
import type { BackendBranch, BackendCourse } from '../types';

interface EnquiryModalProps {
  open: boolean;
  defaultCourse?: string;
  courses: BackendCourse[];
  branches: BackendBranch[];
  onClose: () => void;
}

export function EnquiryModal({
  open,
  defaultCourse,
  courses,
  branches,
  onClose,
}: EnquiryModalProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Course Enquiry and Counselling"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4 backdrop-blur-[2px]"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close enquiry modal"
          className="absolute top-4 right-4 z-10 inline-flex items-center justify-center w-9 h-9 rounded-full bg-[#F7F1F2] text-[#1D1014] hover:bg-[#7A0F28] hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <EnquiryForm
          heading="Book Free Demo Class & Counselling"
          subheading="Get personalized batch timings, monthly fee structure, and up to 50% scholarship guidance."
          ctaLabel="Book Free Demo"
          defaultCourse={defaultCourse || 'Class 10'}
          source="header_enquiry_modal"
          courses={courses}
          branches={branches}
          showDemoFields
        />
      </div>
    </div>
  );
}
