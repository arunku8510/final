import { Router } from "express";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import type { DatabaseSync } from "node:sqlite";
import { APP_ROOT, BACKUPS_DIR, createDatabaseBackup } from "../db.js";
import {
  cleanText,
  clientIp,
  createSession,
  getSessionContext,
  hashPassword,
  isValidEmail,
  isValidPhone,
  normalizeEmail,
  normalizePhone,
  nowIso,
  setSessionCookie,
  writeAuditLog,
} from "../security.js";

export function createAdminRouter(db: DatabaseSync): Router {
  const router = Router();

  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Admin sign-in required." });
      return;
    }
    if (ctx.user.role !== "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    (req as any).ctx = ctx;
    next();
  });

  router.get("/dashboard", (_req, res) => {
    const totalStudents = (db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'student'").get() as { c: number }).c;
    const totalTeachers = (db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'teacher'").get() as { c: number }).c;
    const pendingApprovals = (
      db
        .prepare(
          "SELECT COUNT(*) as c FROM users WHERE role IN ('student', 'teacher') AND verification_status IN ('pending_approval', 'otp_verified')"
        )
        .get() as { c: number }
    ).c;
    const totalCourses = (db.prepare("SELECT COUNT(*) as c FROM courses WHERE is_active = 1").get() as { c: number }).c;
    const totalAdmissions = (
      db.prepare("SELECT COUNT(*) as c FROM enrollments WHERE status IN ('active', 'completed')").get() as { c: number }
    ).c;
    const newInquiries = (db.prepare("SELECT COUNT(*) as c FROM inquiries WHERE status = 'new'").get() as { c: number }).c;
    const unresolvedChats = (
      db
        .prepare("SELECT COUNT(*) as c FROM chatbot_conversations WHERE status IN ('unresolved', 'escalated')")
        .get() as { c: number }
    ).c;

    const totalCollected = (
      db
        .prepare("SELECT COALESCE(SUM(amount), 0) as s FROM payments WHERE verification_status = 'verified'")
        .get() as { s: number }
    ).s;
    const totalPending = (
      db
        .prepare(
          "SELECT COALESCE(SUM(MAX(0, total_amount - discount_amount - paid_amount)), 0) as s FROM fee_records WHERE status != 'refunded'"
        )
        .get() as { s: number }
    ).s;

    const recentActivities = db
      .prepare("SELECT id, action, actor_name, target_name, details, created_at FROM audit_logs ORDER BY id DESC LIMIT 20")
      .all();

    res.json({
      counts: {
        totalStudents,
        totalTeachers,
        pendingApprovals,
        totalCourses,
        totalAdmissions,
        newInquiries,
        unresolvedChats,
      },
      feeSummary: {
        totalCollected: Number(totalCollected || 0),
        totalPending: Number(totalPending || 0),
      },
      recentActivities,
    });
  });

  router.get("/users", (req, res) => {
    const role = String(req.query.role || "all");
    const status = String(req.query.status || "all");
    const search = cleanText(req.query.search, 120).toLowerCase();
    const page = Math.max(1, Number(req.query.page || 1));
    const pageSize = Math.min(50, Math.max(1, Number(req.query.pageSize || 12)));

    const where: string[] = [];
    const params: any[] = [];
    if (role !== "all") {
      where.push("u.role = ?");
      params.push(role);
    }
    if (status !== "all") {
      where.push("u.verification_status = ?");
      params.push(status);
    }
    if (search) {
      where.push("(LOWER(u.full_name) LIKE ? OR LOWER(u.email) LIKE ? OR u.phone LIKE ?)");
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    const whereSql = where.length ? "WHERE " + where.join(" AND ") : "";
    const total = (
      db.prepare(`SELECT COUNT(*) as c FROM users u ${whereSql}`).get(...params) as { c: number }
    ).c;

    const users = db
      .prepare(
        `SELECT u.id, u.role, u.full_name, u.email, u.phone, u.avatar_url, u.mobile_verified,
                u.verification_status, u.is_active, u.marketing_opt_in, u.last_login_at, u.created_at,
                sp.class_level, tp.qualification
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         ${whereSql}
         ORDER BY u.id DESC
         LIMIT ? OFFSET ?`
      )
      .all(...params, pageSize, (page - 1) * pageSize);

    res.json({ users, total, page, pageSize });
  });

  router.post("/users", (req, res) => {
    const ctx = (req as any).ctx;
    const role = String(req.body?.role || "student");
    if (!["student", "teacher", "admin"].includes(role)) {
      res.status(400).json({ error: "Invalid role." });
      return;
    }
    if (role === "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Only Super Admin can create Admin accounts." });
      return;
    }
    const fullName = cleanText(req.body?.fullName, 120);
    const email = normalizeEmail(req.body?.email);
    const phone = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || "");

    if (fullName.length < 2 || !isValidEmail(email) || !isValidPhone(phone) || password.length < 8) {
      res.status(400).json({ error: "Provide valid name, email, phone, and min 8-char password." });
      return;
    }
    if (db.prepare("SELECT id FROM users WHERE email = ?").get(email)) {
      res.status(409).json({ error: "An account already exists with this email." });
      return;
    }

    const now = nowIso();
    const resIns = db
      .prepare(
        `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 1, 'approved', 1, 1, ?, ?, ?)`
      )
      .run(role, fullName, email, phone, hashPassword(password), crypto.randomBytes(18).toString("hex"), now, now);

    const uid = Number(resIns.lastInsertRowid);
    if (role === "student") {
      db.prepare(
        "INSERT INTO student_profiles (user_id, class_level, board, course_duration_months, admission_date, enrollment_status) VALUES (?, ?, 'CBSE', 12, ?, 'active')"
      ).run(uid, cleanText(req.body?.classLevel || "Class 10", 60), now.slice(0, 10));
    } else if (role === "teacher") {
      db.prepare(
        "INSERT INTO teacher_profiles (user_id, qualification, experience_years, availability_status) VALUES (?, ?, 2, 'available')"
      ).run(uid, cleanText(req.body?.qualification || "Subject Faculty", 120));
    }

    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: fullName,
      action: "admin_created_user",
      details: `Created approved ${role} (${email})`,
      ipAddress: clientIp(req),
    });

    res.status(201).json({ id: uid, created: true });
  });

  router.get("/users/:id", (req, res) => {
    const uid = Number(req.params.id);
    const user = db
      .prepare(
        `SELECT id, role, full_name, email, phone, avatar_url, mobile_verified,
                verification_status, is_active, marketing_opt_in, last_login_at, created_at
         FROM users WHERE id = ?`
      )
      .get(uid) as any;
    if (!user) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    const studentProfile = db.prepare("SELECT * FROM student_profiles WHERE user_id = ?").get(uid) || null;
    const teacherProfile = db.prepare("SELECT * FROM teacher_profiles WHERE user_id = ?").get(uid) || null;
    const otpSummary = db
      .prepare("SELECT purpose, attempts, consumed_at, created_at FROM otp_tokens WHERE user_id = ? ORDER BY id DESC LIMIT 10")
      .all(uid);
    const history = db
      .prepare("SELECT action, details, ip_address, created_at FROM audit_logs WHERE target_id = ? OR actor_id = ? ORDER BY id DESC LIMIT 20")
      .all(uid, uid);

    res.json({ user, studentProfile, teacherProfile, otpSummary, history });
  });

  router.patch("/users/:id", (req, res) => {
    const ctx = (req as any).ctx;
    const uid = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM users WHERE id = ?").get(uid) as any;
    if (!existing) {
      res.status(404).json({ error: "User not found." });
      return;
    }

    const fullName = cleanText(req.body?.fullName ?? existing.full_name, 120);
    const email = normalizeEmail(req.body?.email ?? existing.email);
    const phone = normalizePhone(req.body?.phone ?? existing.phone);
    if (fullName.length < 2 || !isValidEmail(email) || !isValidPhone(phone)) {
      res.status(400).json({ error: "Valid name, email, and phone are required." });
      return;
    }

    db.prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, updated_at = ? WHERE id = ?").run(
      fullName,
      email,
      phone,
      nowIso(),
      uid
    );

    if (req.body?.studentProfile && existing.role === "student") {
      const sp = req.body.studentProfile;
      db.prepare(
        `INSERT INTO student_profiles (user_id, class_level, board, course_duration_months)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET class_level = excluded.class_level, board = excluded.board, course_duration_months = excluded.course_duration_months`
      ).run(
        uid,
        cleanText(sp.classLevel || "Class 10", 60),
        cleanText(sp.board || "CBSE", 40),
        Math.min(60, Math.max(1, Number(sp.courseDurationMonths || 12)))
      );
    }

    if (req.body?.teacherProfile && existing.role === "teacher") {
      const tp = req.body.teacherProfile;
      db.prepare(
        `INSERT INTO teacher_profiles (user_id, qualification, experience_years)
         VALUES (?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET qualification = excluded.qualification, experience_years = excluded.experience_years`
      ).run(uid, cleanText(tp.qualification || "", 120), Math.max(0, Number(tp.experienceYears || 0)));
    }

    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: fullName,
      action: "admin_edited_user",
      details: "Updated profile details",
      ipAddress: clientIp(req),
    });

    res.json({ updated: true });
  });

  router.post("/users/:id/status", (req, res) => {
    const ctx = (req as any).ctx;
    const uid = Number(req.params.id);
    const action = String(req.body?.action || "").toLowerCase();
    const reason = cleanText(req.body?.reason, 300);
    const target = db.prepare("SELECT * FROM users WHERE id = ?").get(uid) as any;
    if (!target) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    if (target.role === "super_admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Cannot modify a Super Admin account." });
      return;
    }

    let nextStatus = target.verification_status;
    let isActive = Number(target.is_active);
    if (action === "approve") {
      nextStatus = "approved";
      isActive = 1;
      if (target.role === "student") {
        db.prepare(
          "UPDATE student_profiles SET enrollment_status = 'active', admission_date = COALESCE(admission_date, ?) WHERE user_id = ?"
        ).run(nowIso().slice(0, 10), uid);
      }
    } else if (action === "activate") {
      isActive = 1;
      if (nextStatus === "suspended") nextStatus = "approved";
    } else if (action === "suspend") {
      nextStatus = "suspended";
      isActive = 0;
      db.prepare("DELETE FROM sessions WHERE user_id = ?").run(uid);
    } else if (action === "reject") {
      nextStatus = "rejected";
      isActive = 0;
      db.prepare("DELETE FROM sessions WHERE user_id = ?").run(uid);
    } else {
      res.status(400).json({ error: "Invalid status action." });
      return;
    }

    db.prepare("UPDATE users SET verification_status = ?, is_active = ?, updated_at = ? WHERE id = ?").run(
      nextStatus,
      isActive,
      nowIso(),
      uid
    );

    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(
      uid,
      `Account ${nextStatus}`,
      reason || `Your Yuitor Smart Classes account status is now ${nextStatus}.`,
      nowIso()
    );

    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: target.full_name,
      action: `user_${action}`,
      details: reason || `Status updated to ${nextStatus}`,
      ipAddress: clientIp(req),
    });

    res.json({ updated: true, verificationStatus: nextStatus, isActive });
  });

  router.post("/impersonate", (req, res) => {
    const ctx = (req as any).ctx;
    const targetId = Number(req.body?.userId);
    const reason = cleanText(req.body?.reason, 200);
    if (reason.length < 4) {
      res.status(400).json({ error: "Provide a clear troubleshooting reason (min 4 characters)." });
      return;
    }

    const target = db.prepare("SELECT id, role, full_name FROM users WHERE id = ?").get(targetId) as any;
    if (!target || !["student", "teacher"].includes(target.role)) {
      res.status(400).json({ error: "Admins can only impersonate Student or Teacher panels." });
      return;
    }

    const now = nowIso();
    db.prepare("INSERT INTO impersonation_logs (admin_id, target_user_id, reason, started_at) VALUES (?, ?, ?, ?)").run(
      ctx.user.id,
      target.id,
      reason,
      now
    );

    // Separate short-lived 30-minute session
    const impSid = createSession(db, target.id, {
      impersonatorId: ctx.user.id,
      reason,
      ttlSeconds: 1800,
    });
    setSessionCookie(res, req, impSid, 1800);

    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: target.id,
      targetName: target.full_name,
      action: "impersonation_started",
      details: reason,
      ipAddress: clientIp(req),
    });

    res.json({ redirectTo: target.role === "teacher" ? "/teacher/" : "/student/" });
  });

  // Courses & Subjects
  router.get("/courses", (_req, res) => {
    const courses = db
      .prepare(
        `SELECT c.*, u.full_name as teacher_name,
                (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id AND e.status IN ('active', 'completed')) as active_students
         FROM courses c
         LEFT JOIN users u ON u.id = c.teacher_id
         ORDER BY c.id DESC`
      )
      .all();
    const subjects = db.prepare("SELECT * FROM subjects ORDER BY id DESC").all();
    const teachers = db
      .prepare("SELECT id, full_name, email FROM users WHERE role = 'teacher' AND verification_status = 'approved' ORDER BY full_name")
      .all();
    res.json({ courses, subjects, teachers });
  });

  router.post("/courses", (req, res) => {
    const title = cleanText(req.body?.title, 160);
    if (title.length < 3) {
      res.status(400).json({ error: "Course title is required." });
      return;
    }
    const slug = `${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${Date.now().toString(36)}`;
    const resIns = db
      .prepare(
        `INSERT INTO courses (title, slug, category, class_range, board, description, duration_months, monthly_fee, yearly_fee, teacher_id, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
      )
      .run(
        title,
        slug,
        cleanText(req.body?.category || "Classes 6-12", 60),
        cleanText(req.body?.classRange || "Classes 9–10", 60),
        cleanText(req.body?.board || "CBSE", 60),
        cleanText(req.body?.description || "", 1000),
        Math.min(60, Math.max(1, Number(req.body?.durationMonths || 12))),
        Math.max(0, Number(req.body?.monthlyFee || 1400)),
        Math.max(0, Number(req.body?.yearlyFee || 14300)),
        req.body?.teacherId ? Number(req.body.teacherId) : null,
        nowIso()
      );
    res.status(201).json({ id: Number(resIns.lastInsertRowid) });
  });

  router.patch("/courses/:id", (req, res) => {
    const cid = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM courses WHERE id = ?").get(cid) as any;
    if (!existing) {
      res.status(404).json({ error: "Course not found." });
      return;
    }
    db.prepare(
      `UPDATE courses SET title = ?, category = ?, class_range = ?, monthly_fee = ?, yearly_fee = ?, teacher_id = ? WHERE id = ?`
    ).run(
      cleanText(req.body?.title ?? existing.title, 160),
      cleanText(req.body?.category ?? existing.category, 60),
      cleanText(req.body?.classRange ?? existing.class_range, 60),
      Math.max(0, Number(req.body?.monthlyFee ?? existing.monthly_fee)),
      Math.max(0, Number(req.body?.yearlyFee ?? existing.yearly_fee)),
      req.body?.teacherId === "" ? null : req.body?.teacherId ? Number(req.body.teacherId) : existing.teacher_id,
      cid
    );
    res.json({ updated: true });
  });

  router.delete("/courses/:id", (req, res) => {
    db.prepare("DELETE FROM courses WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });

  router.post("/subjects", (req, res) => {
    const name = cleanText(req.body?.name, 120);
    const code = cleanText(req.body?.code, 30).toUpperCase();
    if (!name || !code) {
      res.status(400).json({ error: "Subject name and code are required." });
      return;
    }
    db.prepare("INSERT INTO subjects (name, code, class_level, description, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(
      name,
      code,
      cleanText(req.body?.classLevel || "Classes 6–12", 80),
      cleanText(req.body?.description || "", 500),
      nowIso()
    );
    res.status(201).json({ created: true });
  });

  router.delete("/subjects/:id", (req, res) => {
    db.prepare("DELETE FROM subjects WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });

  // Payments & Coupons
  router.get("/payments", (_req, res) => {
    const payments = db
      .prepare(
        `SELECT p.*, u.full_name as student_name, u.email as student_email, c.title as course_title
         FROM payments p
         JOIN users u ON u.id = p.student_id
         JOIN courses c ON c.id = p.course_id
         ORDER BY p.id DESC`
      )
      .all();
    const coupons = db.prepare("SELECT * FROM coupons ORDER BY id DESC").all();
    res.json({ payments, coupons });
  });

  router.post("/coupons", (req, res) => {
    const code = cleanText(req.body?.code, 30).toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    const discountType = req.body?.discountType === "flat" ? "flat" : "percent";
    const discountValue = Math.max(1, Number(req.body?.discountValue || 10));
    const maxUses = Math.max(1, Number(req.body?.maxUses || 100));
    if (code.length < 3) {
      res.status(400).json({ error: "Coupon code must be at least 3 characters." });
      return;
    }
    db.prepare(
      "INSERT INTO coupons (code, discount_type, discount_value, max_uses, used_count, is_active, created_at) VALUES (?, ?, ?, ?, 0, 1, ?)"
    ).run(code, discountType, discountValue, maxUses, nowIso());
    res.status(201).json({ created: true });
  });

  router.post("/payments/:id/verify", (req, res) => {
    const ctx = (req as any).ctx;
    const pid = Number(req.params.id);
    const decision = String(req.body?.decision || "verify");
    const pay = db.prepare("SELECT * FROM payments WHERE id = ?").get(pid) as any;
    if (!pay) {
      res.status(404).json({ error: "Payment record not found." });
      return;
    }

    if (decision === "verify") {
      const receipt = pay.receipt_number || `YTR-RCP-${String(pid).padStart(5, "0")}`;
      const paidAt = nowIso();
      db.prepare("UPDATE payments SET verification_status = 'verified', receipt_number = ?, paid_at = ? WHERE id = ?").run(
        receipt,
        paidAt,
        pid
      );
      if (pay.enrollment_id) {
        db.prepare("UPDATE enrollments SET status = 'active' WHERE id = ?").run(pay.enrollment_id);
      }
      db.prepare("UPDATE fee_records SET paid_amount = total_amount - discount_amount, status = 'paid' WHERE student_id = ? AND course_id = ?").run(
        pay.student_id,
        pay.course_id
      );
      db.prepare("INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)").run(
        pay.student_id,
        "Payment Verified",
        `Your fee payment of ₹${pay.amount} (Receipt ${receipt}) is verified. Course access is now active.`,
        paidAt
      );
    } else {
      db.prepare("UPDATE payments SET verification_status = 'failed' WHERE id = ?").run(pid);
    }

    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: pay.student_id,
      targetName: `Payment #${pid}`,
      action: `payment_${decision}`,
      details: `Amount ₹${pay.amount}`,
      ipAddress: clientIp(req),
    });

    res.json({ updated: true });
  });

  router.post("/payments/:id/refund", (req, res) => {
    const ctx = (req as any).ctx;
    const pid = Number(req.params.id);
    const pay = db.prepare("SELECT * FROM payments WHERE id = ?").get(pid) as any;
    if (!pay) {
      res.status(404).json({ error: "Payment record not found." });
      return;
    }
    db.prepare("UPDATE payments SET verification_status = 'refunded', refund_status = 'processed' WHERE id = ?").run(pid);
    if (pay.enrollment_id) {
      db.prepare("UPDATE enrollments SET status = 'cancelled' WHERE id = ?").run(pay.enrollment_id);
    }
    db.prepare("UPDATE fee_records SET status = 'refunded' WHERE student_id = ? AND course_id = ?").run(
      pay.student_id,
      pay.course_id
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: pay.student_id,
      targetName: `Payment #${pid}`,
      action: "payment_refunded",
      details: `Refunded ₹${pay.amount}`,
      ipAddress: clientIp(req),
    });
    res.json({ refunded: true });
  });

  // Inquiries & CMS
  router.get("/inquiries", (_req, res) => {
    const inquiries = db.prepare("SELECT * FROM inquiries ORDER BY id DESC").all();
    res.json({ inquiries });
  });

  router.patch("/inquiries/:id", (req, res) => {
    const status = String(req.body?.status || "new");
    if (!["new", "contacted", "admitted", "closed"].includes(status)) {
      res.status(400).json({ error: "Invalid inquiry status." });
      return;
    }
    db.prepare("UPDATE inquiries SET status = ? WHERE id = ?").run(status, Number(req.params.id));
    res.json({ updated: true });
  });

  router.delete("/inquiries/:id", (req, res) => {
    db.prepare("DELETE FROM inquiries WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });

  router.get("/cms", (_req, res) => {
    res.json({
      announcements: db.prepare("SELECT * FROM announcements ORDER BY id DESC").all(),
      banners: db.prepare("SELECT * FROM banners ORDER BY id DESC").all(),
      blogPosts: db.prepare("SELECT * FROM blog_posts ORDER BY id DESC").all(),
      faqs: db.prepare("SELECT * FROM faqs ORDER BY sort_order ASC, id DESC").all(),
      testimonials: db.prepare("SELECT * FROM testimonials ORDER BY id DESC").all(),
    });
  });

  router.post("/cms/announcements", (req, res) => {
    const ctx = (req as any).ctx;
    db.prepare("INSERT INTO announcements (title, body, audience, created_by, created_at) VALUES (?, ?, ?, ?, ?)").run(
      cleanText(req.body?.title, 180),
      cleanText(req.body?.body, 2000),
      ["all", "students", "teachers", "public"].includes(req.body?.audience) ? req.body.audience : "all",
      ctx.user.id,
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/announcements/:id", (req, res) => {
    db.prepare("DELETE FROM announcements WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });

  router.post("/cms/banners", (req, res) => {
    db.prepare("INSERT INTO banners (title, subtitle, cta_label, cta_href, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(
      cleanText(req.body?.title, 180),
      cleanText(req.body?.subtitle, 300),
      cleanText(req.body?.ctaLabel || "Apply for Admission", 60),
      cleanText(req.body?.ctaHref || "/admission", 200),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/banners/:id", (req, res) => {
    db.prepare("DELETE FROM banners WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });

  router.post("/cms/blog", (req, res) => {
    const title = cleanText(req.body?.title, 200);
    const slug = `${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${Date.now().toString(36)}`;
    db.prepare("INSERT INTO blog_posts (title, slug, category, excerpt, content, is_published, created_at) VALUES (?, ?, ?, ?, ?, 1, ?)").run(
      title,
      slug,
      cleanText(req.body?.category || "Study Tips", 60),
      cleanText(req.body?.excerpt, 400),
      cleanText(req.body?.content, 10000),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/blog/:id", (req, res) => {
    db.prepare("DELETE FROM blog_posts WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });

  router.post("/cms/faqs", (req, res) => {
    db.prepare("INSERT INTO faqs (question, answer, sort_order, is_active, created_at) VALUES (?, ?, 99, 1, ?)").run(
      cleanText(req.body?.question, 300),
      cleanText(req.body?.answer, 2000),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/faqs/:id", (req, res) => {
    db.prepare("DELETE FROM faqs WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });

  router.post("/cms/testimonials", (req, res) => {
    db.prepare("INSERT INTO testimonials (author_name, author_role, outcome_metric, quote, is_approved, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(
      cleanText(req.body?.authorName, 120),
      cleanText(req.body?.authorRole || "Student", 120),
      cleanText(req.body?.outcomeMetric, 120),
      cleanText(req.body?.quote, 1000),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/testimonials/:id", (req, res) => {
    db.prepare("DELETE FROM testimonials WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });

  // Shreya Chatbot Management
  router.get("/chatbot", (req, res) => {
    const status = String(req.query.status || "all");
    const search = cleanText(req.query.search, 120).toLowerCase();
    const minRating = Number(req.query.minRating || 0);

    const where: string[] = [];
    const params: any[] = [];
    if (status !== "all") {
      where.push("status = ?");
      params.push(status);
    }
    if (minRating > 0) {
      where.push("rating >= ?");
      params.push(minRating);
    }
    if (search) {
      where.push(
        "(LOWER(visitor_name) LIKE ? OR visitor_phone LIKE ? OR LOWER(visitor_email) LIKE ? OR LOWER(last_message) LIKE ? OR id IN (SELECT conversation_id FROM chatbot_messages WHERE LOWER(message) LIKE ?))"
      );
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }

    const whereSql = where.length ? "WHERE " + where.join(" AND ") : "";
    const conversations = db
      .prepare(`SELECT * FROM chatbot_conversations ${whereSql} ORDER BY updated_at DESC LIMIT 100`)
      .all(...params);
    res.json({ conversations });
  });

  router.get("/chatbot/:id", (req, res) => {
    const conversation = db.prepare("SELECT * FROM chatbot_conversations WHERE id = ?").get(req.params.id);
    if (!conversation) {
      res.status(404).json({ error: "Conversation not found." });
      return;
    }
    const messages = db
      .prepare("SELECT * FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC")
      .all(req.params.id);
    res.json({ conversation, messages });
  });

  router.patch("/chatbot/:id", (req, res) => {
    const status = String(req.body?.status || "resolved");
    if (!["active", "unresolved", "escalated", "resolved"].includes(status)) {
      res.status(400).json({ error: "Invalid conversation status." });
      return;
    }
    db.prepare("UPDATE chatbot_conversations SET status = ?, updated_at = ? WHERE id = ?").run(
      status,
      nowIso(),
      req.params.id
    );
    res.json({ updated: true });
  });

  // Notifications
  router.get("/notifications", (_req, res) => {
    const notifications = db
      .prepare("SELECT * FROM notifications WHERE role_target = 'admin' OR role_target = 'all' ORDER BY id DESC LIMIT 30")
      .all();
    res.json({ notifications });
  });

  router.post("/notifications/read-all", (_req, res) => {
    db.prepare("UPDATE notifications SET is_read = 1 WHERE role_target = 'admin'").run();
    res.json({ updated: true });
  });

  // Backups
  router.get("/backups", (_req, res) => {
    fs.mkdirSync(BACKUPS_DIR, { recursive: true });
    const files = fs
      .readdirSync(BACKUPS_DIR)
      .filter((f) => f.endsWith(".db"))
      .map((f) => {
        const st = fs.statSync(path.join(BACKUPS_DIR, f));
        return { filename: f, sizeBytes: st.size, createdAt: st.mtime.toISOString() };
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    res.json({ backups: files });
  });

  router.post("/backups", (req, res) => {
    const ctx = (req as any).ctx;
    const backup = createDatabaseBackup(db, "admin");
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      action: "database_backup_created",
      details: backup.filename,
      ipAddress: clientIp(req),
    });
    res.status(201).json({ backup });
  });

  router.get("/backups/:filename", (req, res) => {
    const safeName = path.basename(req.params.filename);
    if (!/^[a-zA-Z0-9._-]+\.db$/.test(safeName)) {
      res.status(400).json({ error: "Invalid backup filename." });
      return;
    }
    const full = path.join(BACKUPS_DIR, safeName);
    if (!fs.existsSync(full)) {
      res.status(404).json({ error: "Backup file not found." });
      return;
    }
    res.download(full, safeName);
  });

  router.get("/project-zip", (_req, res) => {
    const zipPath = path.join(APP_ROOT, "yuitor-smart-classes-final.zip");
    if (!fs.existsSync(zipPath)) {
      res.status(404).json({ error: "Final project ZIP archive not found." });
      return;
    }
    res.download(zipPath, "yuitor-smart-classes-final.zip");
  });

  return router;
}
