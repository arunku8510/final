import { Router } from "express";
import crypto from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { cleanText, getSessionContext, nowIso } from "../security.js";

export function createStudentRouter(db: DatabaseSync): Router {
  const router = Router();

  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Student sign-in required." });
      return;
    }
    if (ctx.user.role !== "student") {
      res.status(403).json({ error: "Student portal access only." });
      return;
    }
    if (ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Your account is awaiting Yuitor Team approval." });
      return;
    }
    (req as any).ctx = ctx;
    next();
  });

  router.get("/dashboard", (req, res) => {
    const ctx = (req as any).ctx;
    const uid = ctx.user.id;
    const today = nowIso().slice(0, 10);

    const profile =
      (db.prepare("SELECT * FROM student_profiles WHERE user_id = ?").get(uid) as any) || {
        class_level: "Class 10",
        board: "CBSE",
        course_duration_months: 12,
        admission_date: null,
        enrollment_status: "active",
      };

    const rawEnrollments = db
      .prepare(
        `SELECT e.*, c.title, c.category, c.board
         FROM enrollments e
         JOIN courses c ON c.id = e.course_id
         WHERE e.student_id = ?
         ORDER BY e.id DESC`
      )
      .all(uid) as any[];

    const enrollments = rawEnrollments.map((e) => ({
      ...e,
      is_expired: Boolean(e.expires_at && e.expires_at < today),
    }));

    const enrolledCourseIds = enrollments
      .filter((e) => ["active", "completed"].includes(e.status) && !e.is_expired)
      .map((e) => Number(e.course_id));

    let upcomingClasses: any[] = [];
    let assignments: any[] = [];
    let quizzes: any[] = [];

    if (enrolledCourseIds.length > 0) {
      const ph = enrolledCourseIds.map(() => "?").join(",");
      upcomingClasses = db
        .prepare(
          `SELECT cs.*, c.title as course_title
           FROM class_schedules cs
           JOIN courses c ON c.id = cs.course_id
           WHERE cs.course_id IN (${ph}) AND cs.scheduled_date >= ?
           ORDER BY cs.scheduled_date ASC, cs.start_time ASC LIMIT 20`
        )
        .all(...enrolledCourseIds, today);

      assignments = db
        .prepare(
          `SELECT a.*, c.title as course_title,
                  sub.status as submission_status, sub.marks_obtained, sub.feedback
           FROM assignments a
           JOIN courses c ON c.id = a.course_id
           LEFT JOIN assignment_submissions sub ON sub.assignment_id = a.id AND sub.student_id = ?
           WHERE a.course_id IN (${ph})
           ORDER BY a.due_date ASC, a.id DESC`
        )
        .all(uid, ...enrolledCourseIds);

      quizzes = db
        .prepare(
          `SELECT q.*, c.title as course_title,
                  (SELECT qa.score FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ? ORDER BY qa.id DESC LIMIT 1) as score
           FROM quizzes q
           JOIN courses c ON c.id = q.course_id
           WHERE q.course_id IN (${ph})
           ORDER BY q.id DESC`
        )
        .all(uid, ...enrolledCourseIds);
    }

    const announcements = db
      .prepare(
        `SELECT * FROM announcements
         WHERE audience IN ('all', 'students')
         ORDER BY id DESC LIMIT 15`
      )
      .all();

    const feeRecords = db
      .prepare(
        `SELECT f.*, COALESCE(c.title, f.title) as course_title,
                COALESCE(
                  (SELECT p.invoice_number FROM payments p WHERE p.student_id = f.student_id AND p.course_id = f.course_id ORDER BY p.id DESC LIMIT 1),
                  'YTR-FEE-' || f.id
                ) as invoice_number
         FROM fee_records f
         LEFT JOIN courses c ON c.id = f.course_id
         WHERE f.student_id = ?
         ORDER BY f.id DESC`
      )
      .all(uid);

    const payments = db
      .prepare(
        `SELECT p.*, c.title as course_title
         FROM payments p
         JOIN courses c ON c.id = p.course_id
         WHERE p.student_id = ?
         ORDER BY p.id DESC`
      )
      .all(uid);

    const attendance = db
      .prepare(
        `SELECT a.*, c.title as course_title
         FROM attendance a
         JOIN courses c ON c.id = a.course_id
         WHERE a.student_id = ?
         ORDER BY a.att_date DESC, a.id DESC LIMIT 60`
      )
      .all(uid);

    const notifications = db
      .prepare(
        `SELECT * FROM notifications
         WHERE user_id = ? OR role_target IN ('student', 'all')
         ORDER BY id DESC LIMIT 20`
      )
      .all(uid);

    const supportMessages = db
      .prepare("SELECT * FROM support_messages WHERE user_id = ? ORDER BY id DESC LIMIT 20")
      .all(uid);

    res.json({
      profile,
      enrollments,
      upcomingClasses,
      announcements,
      feeRecords,
      payments,
      assignments,
      quizzes,
      attendance,
      notifications,
      supportMessages,
    });
  });

  router.get("/courses/:courseId/lessons", (req, res) => {
    const ctx = (req as any).ctx;
    const courseId = Number(req.params.courseId);
    const today = nowIso().slice(0, 10);

    const enrollment = db
      .prepare("SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?")
      .get(ctx.user.id, courseId) as any;

    if (!enrollment || !["active", "completed"].includes(enrollment.status)) {
      res.status(403).json({ error: "Active course enrollment is required to access lessons." });
      return;
    }
    if (enrollment.expires_at && enrollment.expires_at < today) {
      res.status(403).json({ error: "This course enrollment has expired. Contact Yuitor Team to renew." });
      return;
    }

    const lessons = db
      .prepare(
        `SELECT l.*, CASE WHEN lp.completed_at IS NOT NULL THEN 1 ELSE 0 END as completed
         FROM lessons l
         LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.student_id = ?
         WHERE l.course_id = ? AND l.is_visible = 1
         ORDER BY l.sort_order ASC, l.id ASC`
      )
      .all(ctx.user.id, courseId);

    res.json({ enrollment, lessons });
  });

  router.post("/lessons/:lessonId/complete", (req, res) => {
    const ctx = (req as any).ctx;
    const lessonId = Number(req.params.lessonId);
    const mins = Math.min(240, Math.max(1, Number(req.body?.timeSpentMinutes || 20)));

    const lesson = db.prepare("SELECT * FROM lessons WHERE id = ? AND is_visible = 1").get(lessonId) as any;
    if (!lesson) {
      res.status(404).json({ error: "Lesson not found." });
      return;
    }

    const enrollment = db
      .prepare("SELECT * FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')")
      .get(ctx.user.id, lesson.course_id) as any;
    if (!enrollment) {
      res.status(403).json({ error: "Not enrolled in this course." });
      return;
    }

    const now = nowIso();
    db.prepare(
      `INSERT OR IGNORE INTO lesson_progress (student_id, lesson_id, completed_at, time_spent_minutes)
       VALUES (?, ?, ?, ?)`
    ).run(ctx.user.id, lessonId, now, mins);

    const totalVisible = (
      db.prepare("SELECT COUNT(*) as c FROM lessons WHERE course_id = ? AND is_visible = 1").get(lesson.course_id) as {
        c: number;
      }
    ).c;
    const completedCount = (
      db
        .prepare(
          `SELECT COUNT(*) as c FROM lesson_progress lp
           JOIN lessons l ON l.id = lp.lesson_id
           WHERE lp.student_id = ? AND l.course_id = ? AND l.is_visible = 1`
        )
        .get(ctx.user.id, lesson.course_id) as { c: number }
    ).c;

    const progress = totalVisible > 0 ? Math.min(100, Math.round((completedCount / totalVisible) * 100)) : 100;
    const certCode =
      progress === 100
        ? enrollment.certificate_code || `YTR-CERT-${ctx.user.id}-${lesson.course_id}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`
        : enrollment.certificate_code || "";
    const nextStatus = progress === 100 ? "completed" : enrollment.status;

    db.prepare(
      `UPDATE enrollments
       SET progress_percent = ?, learning_minutes = learning_minutes + ?, status = ?, certificate_code = ?
       WHERE id = ?`
    ).run(progress, mins, nextStatus, certCode, enrollment.id);

    res.json({ completed: true, progressPercent: progress, certificateCode: certCode });
  });

  router.post("/assignments/:assignmentId/submit", (req, res) => {
    const ctx = (req as any).ctx;
    const aid = Number(req.params.assignmentId);
    const assignment = db.prepare("SELECT * FROM assignments WHERE id = ?").get(aid) as any;
    if (!assignment) {
      res.status(404).json({ error: "Assignment not found." });
      return;
    }

    const enrolled = db
      .prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')")
      .get(ctx.user.id, assignment.course_id);
    if (!enrolled) {
      res.status(403).json({ error: "You are not enrolled in this course." });
      return;
    }

    const submissionText = cleanText(req.body?.submissionText, 4000);
    const fileUrl = cleanText(req.body?.fileUrl, 300);
    if (!submissionText && !fileUrl) {
      res.status(400).json({ error: "Enter answer text or upload a file." });
      return;
    }

    db.prepare(
      `INSERT INTO assignment_submissions (assignment_id, student_id, submission_text, file_url, status, submitted_at)
       VALUES (?, ?, ?, ?, 'submitted', ?)
       ON CONFLICT(assignment_id, student_id) DO UPDATE SET
         submission_text = excluded.submission_text,
         file_url = CASE WHEN excluded.file_url != '' THEN excluded.file_url ELSE assignment_submissions.file_url END,
         status = 'submitted',
         submitted_at = excluded.submitted_at`
    ).run(aid, ctx.user.id, submissionText, fileUrl, nowIso());

    res.status(201).json({ submitted: true });
  });

  router.post("/quizzes/:quizId/attempt", (req, res) => {
    const ctx = (req as any).ctx;
    const qid = Number(req.params.quizId);
    const quiz = db.prepare("SELECT * FROM quizzes WHERE id = ?").get(qid) as any;
    if (!quiz) {
      res.status(404).json({ error: "Quiz not found." });
      return;
    }

    const enrolled = db
      .prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')")
      .get(ctx.user.id, quiz.course_id);
    if (!enrolled) {
      res.status(403).json({ error: "You are not enrolled in this course." });
      return;
    }

    let questions: Array<{ correctIndex: number }> = [];
    try {
      questions = JSON.parse(quiz.questions_json || "[]");
    } catch {
      questions = [];
    }
    const answers = Array.isArray(req.body?.answers) ? req.body.answers.map(Number) : [];
    let correct = 0;
    questions.forEach((q, idx) => {
      if (answers[idx] === Number(q.correctIndex)) correct++;
    });

    const maxMarks = Number(quiz.max_marks || 10);
    const score = questions.length > 0 ? Math.round((correct / questions.length) * maxMarks) : 0;

    db.prepare(
      "INSERT INTO quiz_attempts (quiz_id, student_id, answers_json, score, max_marks, attempted_at) VALUES (?, ?, ?, ?, ?, ?)"
    ).run(qid, ctx.user.id, JSON.stringify(answers), score, maxMarks, nowIso());

    res.json({ score, maxMarks });
  });

  router.post("/reviews", (req, res) => {
    const ctx = (req as any).ctx;
    const courseId = Number(req.body?.courseId);
    const rating = Math.min(5, Math.max(1, Number(req.body?.rating || 5)));
    const comment = cleanText(req.body?.comment, 1000);
    if (!courseId || comment.length < 3) {
      res.status(400).json({ error: "Select a course and write a short review." });
      return;
    }

    db.prepare(
      `INSERT INTO course_reviews (student_id, course_id, rating, comment, created_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(student_id, course_id) DO UPDATE SET rating = excluded.rating, comment = excluded.comment`
    ).run(ctx.user.id, courseId, rating, comment, nowIso());

    res.status(201).json({ saved: true });
  });

  router.post("/support", (req, res) => {
    const ctx = (req as any).ctx;
    const subject = cleanText(req.body?.subject, 180);
    const body = cleanText(req.body?.body, 2000);
    if (subject.length < 2 || body.length < 5) {
      res.status(400).json({ error: "Enter subject and message." });
      return;
    }
    const now = nowIso();
    db.prepare("INSERT INTO support_messages (user_id, subject, body, status, created_at) VALUES (?, ?, ?, 'open', ?)").run(
      ctx.user.id,
      subject,
      body,
      now
    );
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(`Student Support: ${subject}`, `${ctx.user.full_name} sent a support message.`, now);

    res.status(201).json({ sent: true });
  });

  router.post("/notifications/read-all", (req, res) => {
    const ctx = (req as any).ctx;
    db.prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?").run(ctx.user.id);
    res.json({ updated: true });
  });

  return router;
}
