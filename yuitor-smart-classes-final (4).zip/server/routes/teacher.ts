import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { cleanText, getSessionContext, nowIso } from "../security.js";

export function createTeacherRouter(db: DatabaseSync): Router {
  const router = Router();

  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Teacher sign-in required." });
      return;
    }
    if (ctx.user.role !== "teacher") {
      res.status(403).json({ error: "Teacher portal access only." });
      return;
    }
    if (ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Your teacher account is pending Yuitor Team approval." });
      return;
    }
    (req as any).ctx = ctx;
    next();
  });

  function ownsCourse(teacherId: number, courseId: number): boolean {
    const row = db.prepare("SELECT id FROM courses WHERE id = ? AND teacher_id = ?").get(courseId, teacherId);
    return Boolean(row);
  }

  router.get("/dashboard", (req, res) => {
    const ctx = (req as any).ctx;
    const tid = ctx.user.id;

    const profile =
      (db.prepare("SELECT * FROM teacher_profiles WHERE user_id = ?").get(tid) as any) || {
        qualification: "",
        experience_years: 0,
        availability_status: "available",
        vacation_note: "",
        monthly_payout_rate: 0,
        payout_upi: "",
      };

    const courses = db.prepare("SELECT * FROM courses WHERE teacher_id = ? ORDER BY id ASC").all(tid) as any[];
    const courseIds = courses.map((c) => Number(c.id));

    let students: any[] = [];
    let schedules: any[] = [];
    let assignments: any[] = [];

    if (courseIds.length > 0) {
      const ph = courseIds.map(() => "?").join(",");
      students = db
        .prepare(
          `SELECT u.id, u.full_name, u.phone, u.email, e.course_id, c.title as course_title, e.progress_percent
           FROM enrollments e
           JOIN users u ON u.id = e.student_id
           JOIN courses c ON c.id = e.course_id
           WHERE e.course_id IN (${ph}) AND e.status IN ('active', 'completed')
           ORDER BY c.title ASC, u.full_name ASC`
        )
        .all(...courseIds);

      schedules = db
        .prepare(
          `SELECT cs.*, c.title as course_title
           FROM class_schedules cs
           JOIN courses c ON c.id = cs.course_id
           WHERE cs.course_id IN (${ph})
           ORDER BY cs.scheduled_date DESC LIMIT 30`
        )
        .all(...courseIds);

      assignments = db
        .prepare(
          `SELECT a.*, c.title as course_title,
                  (SELECT COUNT(*) FROM assignment_submissions s WHERE s.assignment_id = a.id) as submissions_count
           FROM assignments a
           JOIN courses c ON c.id = a.course_id
           WHERE a.course_id IN (${ph})
           ORDER BY a.id DESC`
        )
        .all(...courseIds);
    }

    const notifications = db
      .prepare("SELECT * FROM notifications WHERE user_id = ? OR role_target IN ('teacher', 'all') ORDER BY id DESC LIMIT 20")
      .all(tid);

    res.json({
      profile,
      courses,
      students,
      schedules,
      assignments,
      notifications,
      earningsSummary: {
        monthlyPayoutRate: Number(profile.monthly_payout_rate || 0),
        activeStudentsCount: students.length,
        payoutUpi: profile.payout_upi || "",
        limitationNote:
          Number(profile.monthly_payout_rate || 0) === 0
            ? "Faculty payout schedules are finalized directly by the Yuitor Finance Team."
            : "",
      },
    });
  });

  router.patch("/profile", (req, res) => {
    const ctx = (req as any).ctx;
    const tid = ctx.user.id;
    const fullName = cleanText(req.body?.fullName || ctx.user.full_name, 120);
    const qualification = cleanText(req.body?.qualification, 120);
    const availabilityStatus = req.body?.availabilityStatus === "vacation" ? "vacation" : "available";
    const vacationNote = cleanText(req.body?.vacationNote, 300);
    const payoutUpi = cleanText(req.body?.payoutUpi, 100);

    db.prepare("UPDATE users SET full_name = ?, updated_at = ? WHERE id = ?").run(fullName, nowIso(), tid);
    db.prepare(
      `INSERT INTO teacher_profiles (user_id, qualification, availability_status, vacation_note, payout_upi)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET
         qualification = excluded.qualification,
         availability_status = excluded.availability_status,
         vacation_note = excluded.vacation_note,
         payout_upi = excluded.payout_upi`
    ).run(tid, qualification, availabilityStatus, vacationNote, payoutUpi);

    res.json({ updated: true });
  });

  router.post("/announcements", (req, res) => {
    const ctx = (req as any).ctx;
    const courseId = req.body?.courseId ? Number(req.body.courseId) : null;
    if (courseId && !ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "You can only post announcements to your assigned courses." });
      return;
    }
    db.prepare(
      "INSERT INTO announcements (title, body, audience, course_id, created_by, created_at) VALUES (?, ?, 'students', ?, ?, ?)"
    ).run(cleanText(req.body?.title, 180), cleanText(req.body?.body, 2000), courseId, ctx.user.id, nowIso());
    res.status(201).json({ created: true });
  });

  router.patch("/courses/:courseId", (req, res) => {
    const ctx = (req as any).ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const existing = db.prepare("SELECT * FROM courses WHERE id = ?").get(cid) as any;
    db.prepare("UPDATE courses SET description = ?, duration_months = ?, thumbnail_url = ? WHERE id = ?").run(
      cleanText(req.body?.description ?? existing.description, 1000),
      Math.min(60, Math.max(1, Number(req.body?.durationMonths ?? existing.duration_months))),
      cleanText(req.body?.thumbnailUrl || existing.thumbnail_url, 300),
      cid
    );
    res.json({ updated: true });
  });

  router.get("/courses/:courseId/lessons", (req, res) => {
    const ctx = (req as any).ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const lessons = db.prepare("SELECT * FROM lessons WHERE course_id = ? ORDER BY sort_order ASC, id ASC").all(cid);
    res.json({ lessons });
  });

  router.post("/courses/:courseId/lessons", (req, res) => {
    const ctx = (req as any).ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const title = cleanText(req.body?.title, 200);
    if (title.length < 2) {
      res.status(400).json({ error: "Lesson title is required." });
      return;
    }
    const maxSort = (
      db.prepare("SELECT COALESCE(MAX(sort_order), 0) as m FROM lessons WHERE course_id = ?").get(cid) as { m: number }
    ).m;
    const lessonType = ["text", "video", "pdf"].includes(req.body?.lessonType) ? req.body.lessonType : "text";
    db.prepare(
      `INSERT INTO lessons (course_id, title, lesson_type, material_url, content, duration_minutes, sort_order, is_visible, created_at)
       VALUES (?, ?, ?, ?, ?, 30, ?, 1, ?)`
    ).run(
      cid,
      title,
      lessonType,
      cleanText(req.body?.materialUrl, 400),
      cleanText(req.body?.content, 5000),
      maxSort + 1,
      nowIso()
    );
    res.status(201).json({ created: true });
  });

  router.post("/courses/:courseId/lessons/reorder", (req, res) => {
    const ctx = (req as any).ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const orderedIds = Array.isArray(req.body?.orderedIds) ? req.body.orderedIds.map(Number) : [];
    const upd = db.prepare("UPDATE lessons SET sort_order = ? WHERE id = ? AND course_id = ?");
    orderedIds.forEach((id: number, idx: number) => {
      upd.run(idx + 1, id, cid);
    });
    res.json({ reordered: true });
  });

  router.patch("/lessons/:lessonId", (req, res) => {
    const ctx = (req as any).ctx;
    const lid = Number(req.params.lessonId);
    const lesson = db
      .prepare("SELECT l.*, c.teacher_id FROM lessons l JOIN courses c ON c.id = l.course_id WHERE l.id = ?")
      .get(lid) as any;
    if (!lesson || Number(lesson.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Lesson not found or unauthorized." });
      return;
    }

    const title = req.body?.title !== undefined ? cleanText(req.body.title, 200) : lesson.title;
    const lessonType = ["text", "video", "pdf"].includes(req.body?.lessonType) ? req.body.lessonType : lesson.lesson_type;
    const materialUrl = req.body?.materialUrl !== undefined ? cleanText(req.body.materialUrl, 400) : lesson.material_url;
    const content = req.body?.content !== undefined ? cleanText(req.body.content, 5000) : lesson.content;
    const isVisible = req.body?.isVisible !== undefined ? (req.body.isVisible ? 1 : 0) : lesson.is_visible;

    db.prepare("UPDATE lessons SET title = ?, lesson_type = ?, material_url = ?, content = ?, is_visible = ? WHERE id = ?").run(
      title,
      lessonType,
      materialUrl,
      content,
      isVisible,
      lid
    );
    res.json({ updated: true });
  });

  router.delete("/lessons/:lessonId", (req, res) => {
    const ctx = (req as any).ctx;
    const lid = Number(req.params.lessonId);
    const lesson = db
      .prepare("SELECT l.id, c.teacher_id FROM lessons l JOIN courses c ON c.id = l.course_id WHERE l.id = ?")
      .get(lid) as any;
    if (!lesson || Number(lesson.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Unauthorized." });
      return;
    }
    db.prepare("DELETE FROM lessons WHERE id = ?").run(lid);
    res.json({ deleted: true });
  });

  router.post("/attendance", (req, res) => {
    const ctx = (req as any).ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    const attDate = cleanText(req.body?.attDate || nowIso().slice(0, 10), 10);
    const records = Array.isArray(req.body?.records) ? req.body.records : [];
    const stmt = db.prepare(
      `INSERT INTO attendance (course_id, student_id, teacher_id, att_date, status, remarks, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(course_id, student_id, att_date) DO UPDATE SET status = excluded.status, remarks = excluded.remarks`
    );
    for (const r of records) {
      const st = ["present", "absent", "late"].includes(r.status) ? r.status : "present";
      stmt.run(courseId, Number(r.studentId), ctx.user.id, attDate, st, cleanText(r.remarks || "", 200), nowIso());
    }
    res.json({ saved: true });
  });

  router.post("/schedules", (req, res) => {
    const ctx = (req as any).ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    db.prepare(
      `INSERT INTO class_schedules (course_id, teacher_id, title, scheduled_date, start_time, end_time, mode, meeting_link, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      courseId,
      ctx.user.id,
      cleanText(req.body?.title, 180),
      cleanText(req.body?.scheduledDate, 10),
      cleanText(req.body?.startTime, 10),
      cleanText(req.body?.endTime, 10),
      req.body?.mode === "online" ? "online" : "offline",
      cleanText(req.body?.meetingLink, 300),
      nowIso()
    );
    res.status(201).json({ created: true });
  });

  router.post("/assignments", (req, res) => {
    const ctx = (req as any).ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    db.prepare(
      "INSERT INTO assignments (course_id, teacher_id, title, description, due_date, max_marks, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run(
      courseId,
      ctx.user.id,
      cleanText(req.body?.title, 180),
      cleanText(req.body?.description, 2000),
      cleanText(req.body?.dueDate, 10),
      Math.max(1, Number(req.body?.maxMarks || 50)),
      nowIso()
    );
    res.status(201).json({ created: true });
  });

  router.get("/assignments/:assignmentId/submissions", (req, res) => {
    const ctx = (req as any).ctx;
    const aid = Number(req.params.assignmentId);
    const assign = db
      .prepare("SELECT a.*, c.teacher_id FROM assignments a JOIN courses c ON c.id = a.course_id WHERE a.id = ?")
      .get(aid) as any;
    if (!assign || Number(assign.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Unauthorized." });
      return;
    }
    const submissions = db
      .prepare(
        `SELECT s.*, u.full_name as student_name
         FROM assignment_submissions s
         JOIN users u ON u.id = s.student_id
         WHERE s.assignment_id = ?
         ORDER BY s.submitted_at DESC`
      )
      .all(aid);
    res.json({ submissions });
  });

  router.post("/submissions/:submissionId/grade", (req, res) => {
    const ctx = (req as any).ctx;
    const sid = Number(req.params.submissionId);
    const sub = db
      .prepare(
        `SELECT s.id, c.teacher_id
         FROM assignment_submissions s
         JOIN assignments a ON a.id = s.assignment_id
         JOIN courses c ON c.id = a.course_id
         WHERE s.id = ?`
      )
      .get(sid) as any;
    if (!sub || Number(sub.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Unauthorized." });
      return;
    }
    db.prepare("UPDATE assignment_submissions SET marks_obtained = ?, feedback = ?, status = 'graded', graded_at = ? WHERE id = ?").run(
      Number(req.body?.marksObtained || 0),
      cleanText(req.body?.feedback, 500),
      nowIso(),
      sid
    );
    res.json({ graded: true });
  });

  router.post("/quizzes", (req, res) => {
    const ctx = (req as any).ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    const questions = Array.isArray(req.body?.questions) ? req.body.questions : [];
    db.prepare(
      "INSERT INTO quizzes (course_id, teacher_id, title, max_marks, duration_minutes, questions_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run(
      courseId,
      ctx.user.id,
      cleanText(req.body?.title, 180),
      Math.max(1, Number(req.body?.maxMarks || 10)),
      Math.max(1, Number(req.body?.durationMinutes || 15)),
      JSON.stringify(questions),
      nowIso()
    );
    res.status(201).json({ created: true });
  });

  return router;
}
