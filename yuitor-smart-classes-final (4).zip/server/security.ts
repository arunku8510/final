import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import type { Request, Response, NextFunction } from "express";
import type { DatabaseSync } from "node:sqlite";

export const BRAND_PENDING_MSG =
  "Your mobile number has been successfully verified. Your account verification is currently pending from the Yuitor Team. We will try to contact you soon. Thank you for your patience.";

export const SESSION_COOKIE = "yu_session";
const SESSION_TTL_SECONDS = 60 * 60 * 12; // 12 hours
const IMPERSONATION_TTL_SECONDS = 60 * 30; // 30 minutes
const OTP_TTL_SECONDS = 60 * 10; // 10 minutes
const SESSION_SECRET =
  process.env.SESSION_SECRET && process.env.SESSION_SECRET !== "replace-with-64-char-random-hex-secret"
    ? process.env.SESSION_SECRET
    : crypto.createHash("sha256").update(process.cwd() + "|yuitor-session-key").digest("hex");

export function nowIso(): string {
  return new Date().toISOString();
}

export function clientIp(req: Request): string {
  const fwd = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return fwd || req.ip || req.socket.remoteAddress || "0.0.0.0";
}

export function normalizePhone(raw: unknown): string {
  const digits = String(raw ?? "").replace(/\D+/g, "");
  if (digits.length === 12 && digits.startsWith("91")) {
    return digits.slice(2);
  }
  if (digits.length === 11 && digits.startsWith("0")) {
    return digits.slice(1);
  }
  return digits;
}

export function isValidIndianMobile(phone: string): boolean {
  return /^[6-9]\d{9}$/.test(phone);
}

export function isValidPhone(raw: string): boolean {
  const digits = String(raw ?? "").replace(/\D+/g, "");
  return digits.length >= 10 && digits.length <= 15;
}

export function normalizeEmail(raw: unknown): string {
  return String(raw ?? "").trim().toLowerCase();
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) && email.length <= 254;
}

export function cleanText(raw: unknown, maxLen = 500): string {
  return String(raw ?? "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
    .trim()
    .slice(0, maxLen);
}

export function hashPassword(password: string): string {
  return bcrypt.hashSync(password, 10);
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash || !password) return false;
  // PHP password_hash uses $2y$, while bcryptjs uses $2a$/$2b$ — same algorithm
  const normalizedHash = storedHash.startsWith("$2y$")
    ? "$2b$" + storedHash.slice(4)
    : storedHash;
  try {
    return bcrypt.compareSync(password, normalizedHash);
  } catch {
    return false;
  }
}

export function hashOtp(phoneOrEmail: string, purpose: string, otp: string): string {
  return crypto
    .createHmac("sha256", SESSION_SECRET)
    .update(`${phoneOrEmail}|${purpose}|${otp}`)
    .digest("hex");
}

export function generateOtpCode(): string {
  return String(crypto.randomInt(100000, 999999));
}

export function verifySetupKey(providedKey: string): boolean {
  const expected = (process.env.YU_ADMIN_SETUP_KEY || "").trim();
  if (!expected) return true;
  const a = Buffer.from(providedKey.trim());
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export function signSessionToken(sessionId: string): string {
  const sig = crypto.createHmac("sha256", SESSION_SECRET).update(sessionId).digest("hex");
  return `${sessionId}.${sig}`;
}

export function verifySessionToken(cookieVal: unknown): string | null {
  if (typeof cookieVal !== "string" || !cookieVal.includes(".")) return null;
  const [sid, sig] = cookieVal.split(".", 2);
  if (!sid || !sig || !/^[a-f0-9]{32,64}$/i.test(sid)) return null;
  const expected = crypto.createHmac("sha256", SESSION_SECRET).update(sid).digest("hex");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return null;
  return crypto.timingSafeEqual(a, b) ? sid : null;
}

export function setSessionCookie(res: Response, req: Request, sessionId: string, ttlSeconds = SESSION_TTL_SECONDS): void {
  const isHttps = req.secure || req.headers["x-forwarded-proto"] === "https";
  res.cookie(SESSION_COOKIE, signSessionToken(sessionId), {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: ttlSeconds * 1000,
  });
}

export function clearSessionCookie(res: Response): void {
  res.clearCookie(SESSION_COOKIE, { path: "/" });
}

export function createSession(
  db: DatabaseSync,
  userId: number,
  options?: { impersonatorId?: number; reason?: string; ttlSeconds?: number }
): string {
  const sid = crypto.randomBytes(24).toString("hex");
  const now = Math.floor(Date.now() / 1000);
  const ttl = options?.ttlSeconds ?? (options?.impersonatorId ? IMPERSONATION_TTL_SECONDS : SESSION_TTL_SECONDS);
  db.prepare(
    `INSERT INTO sessions (id, user_id, impersonator_id, impersonation_reason, expires_at, created_at, last_seen_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(
    sid,
    userId,
    options?.impersonatorId ?? null,
    options?.reason ?? "",
    now + ttl,
    now,
    now
  );
  return sid;
}

export function checkRateLimit(
  db: DatabaseSync,
  key: string,
  maxAttempts: number,
  windowSeconds: number,
  lockSeconds = 300
): { allowed: boolean; retryAfterSeconds?: number } {
  const now = Math.floor(Date.now() / 1000);
  const row = db.prepare("SELECT key, window_started, attempts, locked_until FROM rate_limits WHERE key = ?").get(key) as
    | { key: string; window_started: number; attempts: number; locked_until: number | null }
    | undefined;

  if (!row) {
    return { allowed: true };
  }
  if (row.locked_until && row.locked_until > now) {
    return { allowed: false, retryAfterSeconds: row.locked_until - now };
  }
  if (now - row.window_started > windowSeconds) {
    db.prepare("DELETE FROM rate_limits WHERE key = ?").run(key);
    return { allowed: true };
  }
  if (row.attempts >= maxAttempts) {
    const until = now + lockSeconds;
    db.prepare("UPDATE rate_limits SET locked_until = ? WHERE key = ?").run(until, key);
    return { allowed: false, retryAfterSeconds: lockSeconds };
  }
  return { allowed: true };
}

export function recordRateLimitHit(
  db: DatabaseSync,
  key: string,
  windowSeconds: number
): void {
  const now = Math.floor(Date.now() / 1000);
  const row = db.prepare("SELECT window_started, attempts FROM rate_limits WHERE key = ?").get(key) as
    | { window_started: number; attempts: number }
    | undefined;

  if (!row || now - row.window_started > windowSeconds) {
    db.prepare(
      "INSERT OR REPLACE INTO rate_limits (key, window_started, attempts, locked_until) VALUES (?, ?, 1, NULL)"
    ).run(key, now);
  } else {
    db.prepare("UPDATE rate_limits SET attempts = attempts + 1 WHERE key = ?").run(key);
  }
}

export function clearRateLimit(db: DatabaseSync, key: string): void {
  db.prepare("DELETE FROM rate_limits WHERE key = ?").run(key);
}

export function issueOtp(
  db: DatabaseSync,
  params: { userId: number | null; phone: string; email?: string; purpose: "registration" | "password_reset" | "admin_2fa" }
): { otp: string; expiresAt: number } {
  const now = Math.floor(Date.now() / 1000);
  const otp = generateOtpCode();
  const target = params.phone || params.email || "";
  const otpHash = hashOtp(target, params.purpose, otp);
  const expiresAt = now + OTP_TTL_SECONDS;
  db.prepare(
    `INSERT INTO otp_tokens (user_id, phone, email, purpose, otp_hash, attempts, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?, 0, ?, ?)`
  ).run(params.userId, params.phone, params.email ?? "", params.purpose, otpHash, expiresAt, now);
  return { otp, expiresAt };
}

export function verifyOtpToken(
  db: DatabaseSync,
  params: { target: string; purpose: "registration" | "password_reset" | "admin_2fa"; otp: string }
): { ok: true; tokenRow: any } | { ok: false; error: string } {
  const now = Math.floor(Date.now() / 1000);
  const row = db
    .prepare(
      `SELECT * FROM otp_tokens
       WHERE (phone = ? OR email = ?) AND purpose = ? AND consumed_at IS NULL
       ORDER BY id DESC LIMIT 1`
    )
    .get(params.target, params.target, params.purpose) as any;

  if (!row) {
    return { ok: false, error: "No active OTP request found. Please request a new OTP." };
  }
  if (row.expires_at < now) {
    return { ok: false, error: "This OTP has expired. Please request a new OTP." };
  }
  if (row.attempts >= 5) {
    return { ok: false, error: "Too many incorrect OTP attempts. Please request a new OTP." };
  }

  const candidateTarget = row.phone || row.email || params.target;
  const candidateHash = hashOtp(candidateTarget, params.purpose, params.otp.trim());
  const altHash = hashOtp(params.target, params.purpose, params.otp.trim());
  const match = candidateHash === row.otp_hash || altHash === row.otp_hash;

  if (!match) {
    db.prepare("UPDATE otp_tokens SET attempts = attempts + 1 WHERE id = ?").run(row.id);
    return { ok: false, error: "Invalid OTP code. Please check and try again." };
  }

  db.prepare("UPDATE otp_tokens SET consumed_at = ? WHERE id = ?").run(now, row.id);
  return { ok: true, tokenRow: row };
}

export function writeAuditLog(
  db: DatabaseSync,
  entry: {
    actorId?: number | null;
    actorName?: string;
    targetId?: number | null;
    targetName?: string;
    action: string;
    details?: string;
    ipAddress?: string;
  }
): void {
  db.prepare(
    `INSERT INTO audit_logs (actor_id, actor_name, target_id, target_name, action, details, ip_address, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    entry.actorId ?? null,
    entry.actorName ?? "",
    entry.targetId ?? null,
    entry.targetName ?? "",
    entry.action,
    entry.details ?? "",
    entry.ipAddress ?? "",
    nowIso()
  );
}

export interface SessionContext {
  sessionId: string;
  user: {
    id: number;
    role: "super_admin" | "admin" | "teacher" | "student";
    full_name: string;
    email: string;
    phone: string;
    avatar_url: string;
    mobile_verified: number;
    verification_status: string;
    is_active: number;
    marketing_opt_in: number;
  };
  impersonation: {
    active: boolean;
    adminId?: number;
    reason?: string;
  };
}

export function getSessionContext(db: DatabaseSync, req: Request): SessionContext | null {
  const sid = verifySessionToken(req.cookies?.[SESSION_COOKIE]);
  if (!sid) return null;
  const now = Math.floor(Date.now() / 1000);
  const row = db
    .prepare(
      `SELECT s.id as session_id, s.impersonator_id, s.impersonation_reason, s.expires_at,
              u.id, u.role, u.full_name, u.email, u.phone, u.avatar_url,
              u.mobile_verified, u.verification_status, u.is_active, u.marketing_opt_in
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.id = ?`
    )
    .get(sid) as any;

  if (!row || row.expires_at < now) {
    db.prepare("DELETE FROM sessions WHERE id = ?").run(sid);
    return null;
  }
  db.prepare("UPDATE sessions SET last_seen_at = ? WHERE id = ?").run(now, sid);
  return {
    sessionId: row.session_id,
    user: {
      id: Number(row.id),
      role: row.role,
      full_name: row.full_name,
      email: row.email,
      phone: row.phone,
      avatar_url: row.avatar_url || "",
      mobile_verified: Number(row.mobile_verified),
      verification_status: row.verification_status,
      is_active: Number(row.is_active),
      marketing_opt_in: Number(row.marketing_opt_in),
    },
    impersonation: row.impersonator_id
      ? {
          active: true,
          adminId: Number(row.impersonator_id),
          reason: row.impersonation_reason || "Support troubleshooting",
        }
      : { active: false },
  };
}

export function sameOriginGuard(req: Request, res: Response, next: NextFunction): void {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) {
    next();
    return;
  }
  const origin = req.headers.origin;
  if (origin) {
    try {
      const originHost = new URL(origin).hostname.toLowerCase().replace(/^www\./, "");
      const candidates = [
        req.headers["x-forwarded-host"],
        req.headers.host,
        req.hostname,
      ]
        .flatMap((v) => String(v || "").split(","))
        .map((s) => s.trim().split(":")[0].toLowerCase().replace(/^www\./, ""))
        .filter(Boolean);

      const appUrl = (process.env.APP_URL || "").trim();
      if (appUrl && !appUrl.includes("MY_APP_URL")) {
        try {
          candidates.push(new URL(appUrl).hostname.toLowerCase().replace(/^www\./, ""));
        } catch {
          // Ignore invalid APP_URL
        }
      }

      if (candidates.length > 0 && !candidates.includes(originHost)) {
        res.status(403).json({ error: "Cross-origin state-changing request blocked." });
        return;
      }
    } catch {
      res.status(403).json({ error: "Invalid request origin." });
      return;
    }
  }
  next();
}

export function signReleaseDownload(expiresUnix: number): string {
  return crypto.createHmac("sha256", SESSION_SECRET).update(`release-zip|${expiresUnix}`).digest("hex");
}

export function verifyReleaseDownload(expiresRaw: unknown, sigRaw: unknown): boolean {
  const expires = Number(expiresRaw);
  const sig = String(sigRaw || "").trim();
  if (!Number.isFinite(expires) || expires < Math.floor(Date.now() / 1000) || !/^[a-f0-9]{64}$/i.test(sig)) {
    return false;
  }
  const expected = signReleaseDownload(expires);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

