// server.ts
import "dotenv/config";
import fs5 from "node:fs";
import path5 from "node:path";
import zlib from "node:zlib";
import express from "express";
import cookieParser from "cookie-parser";

// server/db.ts
import fs from "node:fs";
import path from "node:path";
import crypto2 from "node:crypto";
import { DatabaseSync } from "node:sqlite";

// server/security.ts
import crypto from "node:crypto";
import bcrypt from "bcryptjs";
var BRAND_PENDING_MSG = "Your mobile number has been successfully verified. Your account verification is currently pending from the Yuitor Team. We will try to contact you soon. Thank you for your patience.";
var SESSION_COOKIE = "yu_session";
var SESSION_TTL_SECONDS = 60 * 60 * 12;
var IMPERSONATION_TTL_SECONDS = 60 * 30;
var OTP_TTL_SECONDS = 60 * 10;
var SESSION_SECRET = process.env.SESSION_SECRET && process.env.SESSION_SECRET !== "replace-with-64-char-random-hex-secret" ? process.env.SESSION_SECRET : crypto.createHash("sha256").update(process.cwd() + "|yuitor-session-key").digest("hex");
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function clientIp(req) {
  const fwd = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return fwd || req.ip || req.socket.remoteAddress || "0.0.0.0";
}
function normalizePhone(raw) {
  const digits = String(raw ?? "").replace(/\D+/g, "");
  if (digits.length === 12 && digits.startsWith("91")) {
    return digits.slice(2);
  }
  if (digits.length === 11 && digits.startsWith("0")) {
    return digits.slice(1);
  }
  return digits;
}
function isValidIndianMobile(phone) {
  return /^[6-9]\d{9}$/.test(phone);
}
function isValidPhone(raw) {
  const digits = String(raw ?? "").replace(/\D+/g, "");
  return digits.length >= 10 && digits.length <= 15;
}
function normalizeEmail(raw) {
  return String(raw ?? "").trim().toLowerCase();
}
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) && email.length <= 254;
}
function cleanText(raw, maxLen = 500) {
  return String(raw ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim().slice(0, maxLen);
}
function hashPassword(password) {
  return bcrypt.hashSync(password, 10);
}
function verifyPassword(password, storedHash) {
  if (!storedHash || !password) return false;
  const normalizedHash = storedHash.startsWith("$2y$") ? "$2b$" + storedHash.slice(4) : storedHash;
  try {
    return bcrypt.compareSync(password, normalizedHash);
  } catch {
    return false;
  }
}
function hashOtp(phoneOrEmail, purpose, otp) {
  return crypto.createHmac("sha256", SESSION_SECRET).update(`${phoneOrEmail}|${purpose}|${otp}`).digest("hex");
}
function generateOtpCode() {
  return String(crypto.randomInt(1e5, 999999));
}
function verifySetupKey(providedKey) {
  const expected = (process.env.YU_ADMIN_SETUP_KEY || "").trim();
  if (!expected) return true;
  const a = Buffer.from(providedKey.trim());
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}
function signSessionToken(sessionId) {
  const sig = crypto.createHmac("sha256", SESSION_SECRET).update(sessionId).digest("hex");
  return `${sessionId}.${sig}`;
}
function verifySessionToken(cookieVal) {
  if (typeof cookieVal !== "string" || !cookieVal.includes(".")) return null;
  const [sid, sig] = cookieVal.split(".", 2);
  if (!sid || !sig || !/^[a-f0-9]{32,64}$/i.test(sid)) return null;
  const expected = crypto.createHmac("sha256", SESSION_SECRET).update(sid).digest("hex");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return null;
  return crypto.timingSafeEqual(a, b) ? sid : null;
}
function setSessionCookie(res, req, sessionId, ttlSeconds = SESSION_TTL_SECONDS) {
  const isHttps = req.secure || req.headers["x-forwarded-proto"] === "https";
  res.cookie(SESSION_COOKIE, signSessionToken(sessionId), {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: ttlSeconds * 1e3
  });
}
function clearSessionCookie(res) {
  res.clearCookie(SESSION_COOKIE, { path: "/" });
}
function createSession(db, userId, options) {
  const sid = crypto.randomBytes(24).toString("hex");
  const now = Math.floor(Date.now() / 1e3);
  const ttl = options?.ttlSeconds ?? (options?.impersonatorId ? IMPERSONATION_TTL_SECONDS : SESSION_TTL_SECONDS);
  db.prepare(
    `INSERT INTO sessions (id, user_id, impersonator_id, impersonation_reason, expires_at, created_at, last_seen_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(
    sid,
    userId,
    options?.impersonatorId ?? null,
    options?.reason ?? "",
    now + ttl,
    now,
    now
  );
  return sid;
}
function checkRateLimit(db, key, maxAttempts, windowSeconds, lockSeconds = 300) {
  const now = Math.floor(Date.now() / 1e3);
  const row = db.prepare("SELECT key, window_started, attempts, locked_until FROM rate_limits WHERE key = ?").get(key);
  if (!row) {
    return { allowed: true };
  }
  if (row.locked_until && row.locked_until > now) {
    return { allowed: false, retryAfterSeconds: row.locked_until - now };
  }
  if (now - row.window_started > windowSeconds) {
    db.prepare("DELETE FROM rate_limits WHERE key = ?").run(key);
    return { allowed: true };
  }
  if (row.attempts >= maxAttempts) {
    const until = now + lockSeconds;
    db.prepare("UPDATE rate_limits SET locked_until = ? WHERE key = ?").run(until, key);
    return { allowed: false, retryAfterSeconds: lockSeconds };
  }
  return { allowed: true };
}
function recordRateLimitHit(db, key, windowSeconds) {
  const now = Math.floor(Date.now() / 1e3);
  const row = db.prepare("SELECT window_started, attempts FROM rate_limits WHERE key = ?").get(key);
  if (!row || now - row.window_started > windowSeconds) {
    db.prepare(
      "INSERT OR REPLACE INTO rate_limits (key, window_started, attempts, locked_until) VALUES (?, ?, 1, NULL)"
    ).run(key, now);
  } else {
    db.prepare("UPDATE rate_limits SET attempts = attempts + 1 WHERE key = ?").run(key);
  }
}
function clearRateLimit(db, key) {
  db.prepare("DELETE FROM rate_limits WHERE key = ?").run(key);
}
function issueOtp(db, params) {
  const now = Math.floor(Date.now() / 1e3);
  const otp = generateOtpCode();
  const target = params.phone || params.email || "";
  const otpHash = hashOtp(target, params.purpose, otp);
  const expiresAt = now + OTP_TTL_SECONDS;
  db.prepare(
    `INSERT INTO otp_tokens (user_id, phone, email, purpose, otp_hash, attempts, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?, 0, ?, ?)`
  ).run(params.userId, params.phone, params.email ?? "", params.purpose, otpHash, expiresAt, now);
  return { otp, expiresAt };
}
function verifyOtpToken(db, params) {
  const now = Math.floor(Date.now() / 1e3);
  const row = db.prepare(
    `SELECT * FROM otp_tokens
       WHERE (phone = ? OR email = ?) AND purpose = ? AND consumed_at IS NULL
       ORDER BY id DESC LIMIT 1`
  ).get(params.target, params.target, params.purpose);
  if (!row) {
    return { ok: false, error: "No active OTP request found. Please request a new OTP." };
  }
  if (row.expires_at < now) {
    return { ok: false, error: "This OTP has expired. Please request a new OTP." };
  }
  if (row.attempts >= 5) {
    return { ok: false, error: "Too many incorrect OTP attempts. Please request a new OTP." };
  }
  const candidateTarget = row.phone || row.email || params.target;
  const candidateHash = hashOtp(candidateTarget, params.purpose, params.otp.trim());
  const altHash = hashOtp(params.target, params.purpose, params.otp.trim());
  const match = candidateHash === row.otp_hash || altHash === row.otp_hash;
  if (!match) {
    db.prepare("UPDATE otp_tokens SET attempts = attempts + 1 WHERE id = ?").run(row.id);
    return { ok: false, error: "Invalid OTP code. Please check and try again." };
  }
  db.prepare("UPDATE otp_tokens SET consumed_at = ? WHERE id = ?").run(now, row.id);
  return { ok: true, tokenRow: row };
}
function writeAuditLog(db, entry) {
  db.prepare(
    `INSERT INTO audit_logs (actor_id, actor_name, target_id, target_name, action, details, ip_address, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    entry.actorId ?? null,
    entry.actorName ?? "",
    entry.targetId ?? null,
    entry.targetName ?? "",
    entry.action,
    entry.details ?? "",
    entry.ipAddress ?? "",
    nowIso()
  );
}
function getSessionContext(db, req) {
  const sid = verifySessionToken(req.cookies?.[SESSION_COOKIE]);
  if (!sid) return null;
  const now = Math.floor(Date.now() / 1e3);
  const row = db.prepare(
    `SELECT s.id as session_id, s.impersonator_id, s.impersonation_reason, s.expires_at,
              u.id, u.role, u.full_name, u.email, u.phone, u.avatar_url,
              u.mobile_verified, u.verification_status, u.is_active, u.marketing_opt_in
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.id = ?`
  ).get(sid);
  if (!row || row.expires_at < now) {
    db.prepare("DELETE FROM sessions WHERE id = ?").run(sid);
    return null;
  }
  db.prepare("UPDATE sessions SET last_seen_at = ? WHERE id = ?").run(now, sid);
  return {
    sessionId: row.session_id,
    user: {
      id: Number(row.id),
      role: row.role,
      full_name: row.full_name,
      email: row.email,
      phone: row.phone,
      avatar_url: row.avatar_url || "",
      mobile_verified: Number(row.mobile_verified),
      verification_status: row.verification_status,
      is_active: Number(row.is_active),
      marketing_opt_in: Number(row.marketing_opt_in)
    },
    impersonation: row.impersonator_id ? {
      active: true,
      adminId: Number(row.impersonator_id),
      reason: row.impersonation_reason || "Support troubleshooting"
    } : { active: false }
  };
}
function sameOriginGuard(req, res, next) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) {
    next();
    return;
  }
  const origin = req.headers.origin;
  if (origin) {
    try {
      const originHost = new URL(origin).hostname.toLowerCase().replace(/^www\./, "");
      const candidates = [
        req.headers["x-forwarded-host"],
        req.headers.host,
        req.hostname
      ].flatMap((v) => String(v || "").split(",")).map((s) => s.trim().split(":")[0].toLowerCase().replace(/^www\./, "")).filter(Boolean);
      const appUrl = (process.env.APP_URL || "").trim();
      if (appUrl && !appUrl.includes("MY_APP_URL")) {
        try {
          candidates.push(new URL(appUrl).hostname.toLowerCase().replace(/^www\./, ""));
        } catch {
        }
      }
      if (candidates.length > 0 && !candidates.includes(originHost)) {
        res.status(403).json({ error: "Cross-origin state-changing request blocked." });
        return;
      }
    } catch {
      res.status(403).json({ error: "Invalid request origin." });
      return;
    }
  }
  next();
}
function signReleaseDownload(expiresUnix) {
  return crypto.createHmac("sha256", SESSION_SECRET).update(`release-zip|${expiresUnix}`).digest("hex");
}
function verifyReleaseDownload(expiresRaw, sigRaw) {
  const expires = Number(expiresRaw);
  const sig = String(sigRaw || "").trim();
  if (!Number.isFinite(expires) || expires < Math.floor(Date.now() / 1e3) || !/^[a-f0-9]{64}$/i.test(sig)) {
    return false;
  }
  const expected = signReleaseDownload(expires);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// server/db.ts
function resolveAppRoot() {
  const cwd = process.cwd();
  if (fs.existsSync(path.join(cwd, "public")) && fs.existsSync(path.join(cwd, "database"))) {
    return cwd;
  }
  const argvDir = process.argv[1] ? path.dirname(path.resolve(process.argv[1])) : cwd;
  if (fs.existsSync(path.join(argvDir, "public")) && fs.existsSync(path.join(argvDir, "database"))) {
    return argvDir;
  }
  return cwd;
}
var APP_ROOT = resolveAppRoot();
var DATA_DIR = path.join(APP_ROOT, "data");
var BACKUPS_DIR = path.join(APP_ROOT, "backups");
var UPLOADS_DIR = path.join(APP_ROOT, "uploads");
var DB_PATH = path.join(DATA_DIR, "yuitor.db");
var LEGACY_DB_PATH = path.join(DATA_DIR, "legacy-portal.sqlite");
var MIGRATION_PATH = path.join(APP_ROOT, "database", "migrations", "001_unified_portal.sql");
var dbInstance = null;
function getDb() {
  if (dbInstance) return dbInstance;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  const db = new DatabaseSync(DB_PATH);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec("PRAGMA foreign_keys = ON;");
  db.exec("PRAGMA busy_timeout = 5000;");
  const schemaSql = fs.readFileSync(MIGRATION_PATH, "utf8");
  db.exec(schemaSql);
  migrateLegacySqliteIfNeeded(db);
  seedDefaultContent(db);
  ensureStartupBackup(db);
  dbInstance = db;
  return db;
}
function migrateLegacySqliteIfNeeded(db) {
  const migratedFlag = db.prepare("SELECT value FROM schema_meta WHERE key = 'legacy_portal_migrated'").get();
  if (migratedFlag?.value === "1") return;
  if (!fs.existsSync(LEGACY_DB_PATH)) {
    db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('legacy_portal_migrated', '1')").run();
    return;
  }
  try {
    const legacy = new DatabaseSync(LEGACY_DB_PATH, { readOnly: true });
    const now = nowIso();
    const admins = legacy.prepare("SELECT * FROM admins").all();
    for (const a of admins) {
      const email = normalizeEmail(a.email);
      if (!email) continue;
      const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
      if (!existing) {
        db.prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at)
           VALUES ('super_admin', ?, ?, ?, ?, 1, 'approved', ?, 0, ?, ?, ?, ?)`
        ).run(
          a.display_name || "Admin",
          email,
          normalizePhone(a.phone || "7827289292"),
          a.password_hash,
          Number(a.is_active ?? 1),
          crypto2.randomBytes(18).toString("hex"),
          a.last_login_at || null,
          a.created_at || now,
          now
        );
      }
    }
    const students = legacy.prepare("SELECT * FROM students").all();
    for (const s of students) {
      const email = normalizeEmail(s.email);
      if (!email) continue;
      const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
      if (!existing) {
        const vStatus = s.registration_status === "active" || s.registration_status === "completed" ? "approved" : s.registration_status === "inactive" ? "suspended" : "pending_approval";
        const res = db.prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at)
             VALUES ('student', ?, ?, ?, ?, 1, ?, ?, 1, ?, ?, ?, ?)`
        ).run(
          s.full_name || "Student",
          email,
          normalizePhone(s.phone || ""),
          s.password_hash,
          vStatus,
          Number(s.is_active ?? 1),
          crypto2.randomBytes(18).toString("hex"),
          s.last_login_at || null,
          s.created_at || now,
          s.updated_at || now
        );
        const uid = Number(res.lastInsertRowid);
        db.prepare(
          `INSERT OR IGNORE INTO student_profiles (user_id, class_level, board, subjects_json, course_duration_months, admission_date, enrollment_status)
           VALUES (?, ?, 'CBSE', ?, ?, ?, ?)`
        ).run(
          uid,
          s.class_level ? `Class ${s.class_level}`.replace(/^Class Class /i, "Class ") : "Class 10",
          JSON.stringify(s.selected_subject ? [s.selected_subject] : ["Mathematics", "Science"]),
          Number(s.course_duration_months || 12),
          s.admission_date || null,
          s.registration_status || "active"
        );
      }
    }
    const inqs = legacy.prepare("SELECT * FROM inquiries").all();
    for (const q of inqs) {
      const exists = db.prepare("SELECT id FROM inquiries WHERE name = ? AND phone = ? AND created_at = ?").get(q.name || "", q.phone || "", q.received_at || now);
      if (!exists) {
        const mappedStatus = q.status === "converted" ? "admitted" : ["new", "contacted", "admitted", "closed"].includes(q.status) ? q.status : "new";
        db.prepare(
          `INSERT INTO inquiries (name, phone, email, class_or_course, message, source, status, created_at)
           VALUES (?, ?, ?, ?, ?, 'legacy_import', ?, ?)`
        ).run(
          q.name || "Visitor",
          q.phone || "",
          q.email || "",
          q.course || "General Inquiry",
          q.message || "",
          mappedStatus,
          q.received_at || now
        );
      }
    }
    const fest = legacy.prepare("SELECT * FROM festival_settings WHERE id = 1").get();
    if (fest) {
      db.prepare(
        `INSERT OR REPLACE INTO festival_settings (id, mode, manual_festival_id, simulated_date_ist, overrides_json, updated_at)
         VALUES (1, ?, ?, ?, ?, ?)`
      ).run(
        fest.mode || "automatic",
        fest.manual_festival_id || null,
        fest.simulated_date_ist || null,
        fest.overrides_json || "{}",
        fest.updated_at || now
      );
    }
    legacy.close();
  } catch (err) {
    console.warn("[Yuitor DB] Legacy SQLite migration skipped:", err);
  }
  db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('legacy_portal_migrated', '1')").run();
}
function seedDefaultContent(db) {
  const now = nowIso();
  const courseCount = db.prepare("SELECT COUNT(*) as c FROM courses").get().c;
  if (courseCount === 0) {
    const courses = [
      {
        title: "Class 6th\u20138th Foundation Batch",
        slug: "class-6-8-foundation",
        category: "Classes 6-12",
        class_range: "Classes 6\u20138",
        board: "CBSE / ICSE / UP Board",
        description: "Strong conceptual foundation in Mathematics, Science, English, and Social Studies with weekly unit tests and doubt-clearing sessions.",
        duration_months: 12,
        monthly_fee: 1e3,
        yearly_fee: 10200,
        thumbnail_url: "/assets/images/teacher-led-class.webp"
      },
      {
        title: "Class 9th\u201310th Board Mastery Batch",
        slug: "class-9-10-board-mastery",
        category: "Classes 6-12",
        class_range: "Classes 9\u201310",
        board: "CBSE / UP Board / ICSE",
        description: "Complete NCERT + reference syllabus coverage, board sample papers, practical prep, and personal mentor tracking in Muradnagar.",
        duration_months: 12,
        monthly_fee: 1400,
        yearly_fee: 14300,
        thumbnail_url: "/assets/images/math-board.webp"
      },
      {
        title: "Class 11th\u201312th Science & Commerce",
        slug: "class-11-12-board-stream",
        category: "Classes 6-12",
        class_range: "Classes 11\u201312",
        board: "CBSE / UP Board",
        description: "In-depth coaching for Physics, Chemistry, Mathematics, Biology, Accountancy, and Economics with full board mock series.",
        duration_months: 12,
        monthly_fee: 1700,
        yearly_fee: 17300,
        thumbnail_url: "/assets/images/science-lab.webp"
      },
      {
        title: "NEET UG & JEE Foundation / Target",
        slug: "neet-jee-target",
        category: "Competitive",
        class_range: "Classes 11\u201312 & Dropper",
        board: "NTA / Competitive",
        description: "Structured Physics, Chemistry, Biology & Mathematics coaching with daily DPPs, OMR/CBT mock tests, and error analysis.",
        duration_months: 12,
        monthly_fee: 2400,
        yearly_fee: 24500,
        thumbnail_url: "/assets/images/exam-writing.webp"
      },
      {
        title: "CUET UG Entrance Preparation",
        slug: "cuet-ug-prep",
        category: "Competitive",
        class_range: "Class 12 & Graduates",
        board: "NTA CUET",
        description: "Domain subjects, General Test (Quant & Reasoning), and English Language speed-accuracy drills for top central universities.",
        duration_months: 6,
        monthly_fee: 1800,
        yearly_fee: 18400,
        thumbnail_url: "/assets/images/group-study.webp"
      },
      {
        title: "Computer Courses (DCA, Tally Prime & Web)",
        slug: "computer-dca-tally",
        category: "Computer",
        class_range: "Students & Job Seekers",
        board: "Practical Certification",
        description: "Hands-on training in MS Office, Tally Prime with GST, CCC, HTML/CSS, and practical computer lab sessions.",
        duration_months: 6,
        monthly_fee: 1e3,
        yearly_fee: 10200,
        thumbnail_url: "/assets/images/computer-class.webp"
      },
      {
        title: "AI Learning & Python Coding Lab",
        slug: "ai-learning-python",
        category: "AI Learning",
        class_range: "Class 6th to College",
        board: "Applied Tech Track",
        description: "Learn Python programming, AI prompt engineering, automation workflows, and real student mini-projects in our guided lab.",
        duration_months: 6,
        monthly_fee: 1500,
        yearly_fee: 15300,
        thumbnail_url: "/assets/images/coding-workshop.webp"
      },
      {
        title: "Spoken English & Communication Skills",
        slug: "spoken-english-fluency",
        category: "English Speaking",
        class_range: "All Age Groups",
        board: "Fluency & Confidence",
        description: "Daily speaking practice, grammar correction, pronunciation drills, group discussions, and interview readiness.",
        duration_months: 3,
        monthly_fee: 900,
        yearly_fee: 9200,
        thumbnail_url: "/assets/images/student-project-presentation.webp"
      }
    ];
    const insertCourse = db.prepare(
      `INSERT INTO courses (title, slug, category, class_range, board, description, duration_months, monthly_fee, yearly_fee, thumbnail_url, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    );
    for (const c of courses) {
      insertCourse.run(
        c.title,
        c.slug,
        c.category,
        c.class_range,
        c.board,
        c.description,
        c.duration_months,
        c.monthly_fee,
        c.yearly_fee,
        c.thumbnail_url,
        now
      );
    }
    const firstCourses = db.prepare("SELECT id, title FROM courses ORDER BY id ASC LIMIT 4").all();
    const insLesson = db.prepare(
      `INSERT INTO lessons (course_id, title, lesson_type, material_url, content, duration_minutes, sort_order, is_visible, created_at)
       VALUES (?, ?, ?, '', ?, 35, ?, 1, ?)`
    );
    for (const fc of firstCourses) {
      insLesson.run(fc.id, `Orientation & Syllabus Roadmap \u2014 ${fc.title}`, "text", "Complete chapter weightage, study calendar, and weekly test schedule.", 1, now);
      insLesson.run(fc.id, "Core Concepts & Formula Sheet (Module 1)", "pdf", "Structured concept notes and solved board-level practice questions.", 2, now);
    }
  }
  const subjCount = db.prepare("SELECT COUNT(*) as c FROM subjects").get().c;
  if (subjCount === 0) {
    const subjects = [
      ["Mathematics", "MATH-612", "Classes 6\u201312", "NCERT concept clarity, shortcut methods, and weekly chapter tests for CBSE, ICSE, and UP Board."],
      ["Science (Foundation)", "SCI-610", "Classes 6\u201310", "Integrated Physics, Chemistry, and Biology with visual demonstrations and diagram practice."],
      ["Physics", "PHY-1112", "Classes 11\u201312 / JEE / NEET", "Mechanics, Electrostatics, Optics, and numerical problem solving for Boards and competitive exams."],
      ["Chemistry", "CHEM-1112", "Classes 11\u201312 / JEE / NEET", "Physical, Organic, and Inorganic Chemistry with reaction mechanisms and NCERT line-by-line mastery."],
      ["Biology", "BIO-1112", "Classes 11\u201312 / NEET", "Botany & Zoology diagrams, NCERT assertion-reason drills, and NEET PYQ practice."],
      ["English & Spoken Communication", "ENG-ALL", "Classes 6\u201312 & Spoken", "Reading comprehension, board writing formats, grammar accuracy, and daily speaking fluency."],
      ["Computer Applications & DCA", "COMP-DCA", "Classes 6\u201312 & Skill Track", "MS Office, Tally Prime with GST, Internet tools, and fundamentals of computing."],
      ["AI Learning & Python Coding", "AI-PY", "Classes 6\u201312 & Tech", "Python syntax, logic building, responsible AI tools, and practical project creation."]
    ];
    const insSubj = db.prepare(
      "INSERT INTO subjects (name, code, class_level, description, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)"
    );
    for (const s of subjects) insSubj.run(s[0], s[1], s[2], s[3], now);
  }
  const faqCount = db.prepare("SELECT COUNT(*) as c FROM faqs").get().c;
  if (faqCount === 0) {
    const faqs = [
      ["Where is Yuitor Smart Classes located?", "Our coaching centre is at Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh, India."],
      ["Which classes and boards do you teach?", "We offer coaching for Classes 5th to 12th across CBSE, UP Board, and ICSE, alongside JEE, NEET, CUET, Computer Courses, AI Learning, and Spoken English."],
      ["Can students attend a demo class before admission?", "Yes! You can book a free counselling and demo session by submitting the Admission form or calling +91 78-2728-9292."],
      ["How does portal registration and approval work?", "Students and teachers register online, verify their 6-digit mobile OTP, and then the Yuitor Team reviews and approves the account for portal access."],
      ["What is your refund policy?", "Yuitor offers a transparent 7-day refund policy subject to the published admission and refund terms on our website."]
    ];
    const insFaq = db.prepare("INSERT INTO faqs (question, answer, sort_order, is_active, created_at) VALUES (?, ?, ?, 1, ?)");
    faqs.forEach((f, idx) => insFaq.run(f[0], f[1], idx + 1, now));
  }
  const testCount = db.prepare("SELECT COUNT(*) as c FROM testimonials").get().c;
  if (testCount === 0) {
    const tests = [
      ["Aarav Verma", "Class 10 CBSE Student", "95.4% in Board Exams", "Weekly tests and personal doubt sessions at Yuitor Muradnagar made Mathematics and Science much easier to score high in."],
      ["Ananya Tyagi", "Class 12 Science Student", "94% in Physics & Chemistry", "Small batch sizes meant our teachers checked every answer sheet and guided us step by step before boards."],
      ["Mrs. Sunita Chaudhary", "Parent, Muradnagar", "Consistent Academic Growth", "Regular attendance updates and transparent fee tracking keep parents completely informed throughout the session."]
    ];
    const insTest = db.prepare(
      "INSERT INTO testimonials (author_name, author_role, outcome_metric, quote, is_approved, created_at) VALUES (?, ?, ?, ?, 1, ?)"
    );
    for (const t of tests) insTest.run(t[0], t[1], t[2], t[3], now);
  }
  const couponCount = db.prepare("SELECT COUNT(*) as c FROM coupons").get().c;
  if (couponCount === 0) {
    db.prepare(
      "INSERT INTO coupons (code, discount_type, discount_value, max_uses, used_count, is_active, created_at) VALUES ('YUITOR10', 'percent', 10, 500, 0, 1, ?)"
    ).run(now);
  }
  const tmplCount = db.prepare("SELECT COUNT(*) as c FROM email_templates").get().c;
  if (tmplCount === 0) {
    const templates = [
      ["New Batch Admission Open", "Admission", "Admissions Open at Yuitor Smart Classes, Muradnagar!", "Limited seats for Classes 6th\u201312th, JEE, NEET & Skills.", "<p>Dear {{name}},</p><p>Admissions are now open for our upcoming batches at <strong>Yuitor Smart Classes, Muradnagar</strong> (Classes 6th\u201312th, JEE/NEET/CUET, Computer, AI Learning &amp; Spoken English).</p><p>Book your counselling or demo session today at Trimurti Vihar, Near Venus Academy.</p>"],
      ["Skill & AI Course Promotion", "Course Promotion", "Upgrade Your Skills: AI Learning, Coding & Spoken English", "Practical weekend & weekday batches in Muradnagar.", "<p>Dear {{name}},</p><p>Build future-ready skills with Yuitor Smart Classes! Join our hands-on batches for <strong>AI Learning &amp; Python Coding</strong>, <strong>DCA + Tally Prime</strong>, and <strong>Spoken English</strong>.</p>"],
      ["Monthly Fee Reminder", "Fee Reminder", "Friendly Fee Schedule Reminder \u2014 Yuitor Smart Classes", "Check your fee status and downloadable receipt in Student Portal.", "<p>Dear {{name}},</p><p>This is a gentle reminder to review your current fee schedule in your Student Portal or at the Muradnagar centre desk. Kindly ignore if already settled.</p>"],
      ["Unit & Board Exam Announcement", "Exam Announcement", "Upcoming Test Series & Exam Schedule \u2014 Yuitor Smart Classes", "Important dates and revision checklist inside.", "<p>Dear {{name}},</p><p>Our upcoming weekly evaluation and mock test schedule has been published. Please review your syllabus notes in the Student Portal and arrive 10 minutes early.</p>"],
      ["Student Important Notice", "Student Notice", "Important Student Notice \u2014 Yuitor Smart Classes", "Batch timing and study material update.", "<p>Dear {{name}},</p><p>Please check your Student Dashboard for the latest batch timing updates and newly uploaded PDF notes from your faculty.</p>"],
      ["Faculty & Teacher Notice", "Teacher Notice", "Faculty Coordination Notice \u2014 Yuitor Smart Classes", "Academic schedule and attendance update reminder.", "<p>Dear {{name}},</p><p>Kindly ensure daily batch attendance and weekly assignment grades are updated in the Teacher Portal before 7:00 PM.</p>"],
      ["Festive Wishes from Yuitor", "Festival", "Warm Festive Wishes from Yuitor Smart Classes!", "Wishing you and your family joy, health, and success.", "<p>Dear {{name}},</p><p>Yuitor Smart Classes wishes you and your family a joyful and prosperous celebration! Keep learning and shining.</p>"],
      ["Yuitor Monthly Newsletter", "Newsletter", "Yuitor Monthly Academic Digest & Study Tips", "Highlights, topper strategies, and upcoming workshops.", "<p>Dear {{name}},</p><p>Here is your monthly summary of upcoming workshops, board preparation strategies, and new study resources at Yuitor Smart Classes, Muradnagar.</p>"],
      ["Special Workshop & Occasion", "Special Occasion", "Special Career & Scholarship Seminar \u2014 Yuitor Muradnagar", "Reserve your seat for our weekend seminar.", "<p>Dear {{name}},</p><p>You are invited to our upcoming Career Guidance &amp; Scholarship Evaluation Session at Yuitor Smart Classes, Trimurti Vihar, Muradnagar.</p>"]
    ];
    const insTmpl = db.prepare(
      "INSERT INTO email_templates (name, category, subject, preview_text, html_body, created_at) VALUES (?, ?, ?, ?, ?, ?)"
    );
    for (const t of templates) insTmpl.run(t[0], t[1], t[2], t[3], t[4], now);
  }
}
function createDatabaseBackup(db, label = "manual") {
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  const safeLabel = label.replace(/[^a-z0-9_-]/gi, "").slice(0, 20) || "backup";
  const filename = `yuitor-${safeLabel}-${stamp}.db`;
  const dest = path.join(BACKUPS_DIR, filename);
  const escaped = dest.replace(/'/g, "''");
  db.exec(`VACUUM INTO '${escaped}';`);
  const stat = fs.statSync(dest);
  return { filename, sizeBytes: stat.size, createdAt: nowIso() };
}
function ensureStartupBackup(db) {
  try {
    const files = fs.readdirSync(BACKUPS_DIR).filter((f) => f.endsWith(".db"));
    if (files.length === 0) {
      createDatabaseBackup(db, "startup");
    }
  } catch (err) {
    console.warn("[Yuitor DB] Startup backup warning:", err);
  }
}

// server/mailer.ts
import nodemailer from "nodemailer";
import path2 from "node:path";
import fs2 from "node:fs";
var SENDER_NAME = process.env.MAIL_FROM_NAME || "Yuitor Smart Classes";
var SENDER_EMAIL = process.env.MAIL_FROM_EMAIL || "info@yuitor.com";
var REPLY_TO_EMAIL = process.env.REPLY_TO_EMAIL || "inquiry@yuitor.com";
var ADMIN_NOTIFY_EMAIL = process.env.ADMIN_NOTIFY_EMAIL || "admission@yuitor.com";
function isSmtpConfigured() {
  const host = (process.env.SMTP_HOST || "").trim();
  const user = (process.env.SMTP_USER || "").trim();
  const pass = (process.env.SMTP_PASS || "").trim();
  return Boolean(host && host !== "smtp.example.com" && user && pass && !pass.startsWith("replace-with"));
}
function getTransporter() {
  const host = (process.env.SMTP_HOST || "").trim();
  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || "").toLowerCase() === "true" || port === 465;
  const user = (process.env.SMTP_USER || "").trim();
  const pass = (process.env.SMTP_PASS || "").trim();
  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: { user, pass },
    connectionTimeout: 1e4,
    greetingTimeout: 1e4,
    socketTimeout: 15e3
  });
}
function escapeHtml(v) {
  return String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] || c);
}
function renderBrandedEmailHtml(opts) {
  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  const personalized = opts.htmlBody.replace(/\{\{\s*name\s*\}\}/gi, escapeHtml(opts.recipientName || "Student"));
  const ctaBlock = opts.ctaLabel && opts.ctaUrl ? `<p style="margin:24px 0;"><a href="${escapeHtml(opts.ctaUrl)}" style="display:inline-block;background:#1677ff;color:#ffffff;text-decoration:none;font-weight:700;padding:12px 22px;border-radius:10px;">${escapeHtml(opts.ctaLabel)}</a></p>` : "";
  const unsubBlock = opts.unsubscribeUrl ? `<p style="margin-top:16px;font-size:12px;color:#64748b;">Prefer not to receive promotional updates? <a href="${escapeHtml(opts.unsubscribeUrl)}" style="color:#0f54c4;">Manage email preferences / Unsubscribe</a></p>` : "";
  return `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(opts.subject)}</title></head>
<body style="margin:0;padding:0;background:#f6f8fb;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#0f172a;">
  ${opts.previewText ? `<div style="display:none;max-height:0;overflow:hidden;">${escapeHtml(opts.previewText)}</div>` : ""}
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden;">
        <tr><td style="background:#0f172a;padding:20px 24px;color:#ffffff;">
          <table role="presentation" width="100%"><tr>
            <td><strong style="font-size:18px;letter-spacing:-0.01em;">Yuitor Smart Classes</strong><div style="font-size:12px;color:#78d3d3;margin-top:2px;">Muradnagar, Ghaziabad \xB7 Classes 6th\u201312th, JEE, NEET &amp; Skills</div></td>
            <td align="right"><img src="${siteUrl}/yuitor-icon-192.png" alt="Yuitor Smart Classes" width="40" height="40" style="border-radius:8px;display:block;"></td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:26px 24px;font-size:15px;line-height:1.65;">
          ${personalized}
          ${ctaBlock}
          <div style="margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0;font-size:13px;color:#475569;">
            <strong>Yuitor Smart Classes</strong><br>
            Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh<br>
            Call / WhatsApp: <a href="tel:+917827289292" style="color:#0f54c4;">+91 78-2728-9292</a> \xB7 Branch: +91 1232314337 \xB7 <a href="${siteUrl}/admission" style="color:#0f54c4;">Apply for Admission</a>
            ${unsubBlock}
          </div>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}
async function sendEmailDirect(opts) {
  if (!isSmtpConfigured()) {
    return { ok: false, error: "SMTP credentials (SMTP_HOST, SMTP_USER, SMTP_PASS) are not configured on the server." };
  }
  try {
    const transporter = getTransporter();
    const attachments = [];
    if (opts.attachmentUrl && opts.attachmentUrl.startsWith("/uploads/")) {
      const safeName = path2.basename(opts.attachmentUrl);
      const fullPath = path2.join(UPLOADS_DIR, safeName);
      if (fs2.existsSync(fullPath)) {
        attachments.push({ filename: safeName, path: fullPath });
      }
    }
    const info = await transporter.sendMail({
      from: `"${SENDER_NAME}" <${SENDER_EMAIL}>`,
      replyTo: REPLY_TO_EMAIL,
      to: opts.to,
      subject: opts.subject,
      html: opts.html,
      text: opts.text || opts.html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(),
      attachments
    });
    return { ok: true, messageId: info.messageId || "sent" };
  } catch (err) {
    return { ok: false, error: err?.message || "SMTP delivery failed." };
  }
}
async function dispatchSmsOtp(phone, otp, purposeLabel) {
  const fast2smsKey = (process.env.FAST2SMS_API_KEY || "").trim();
  if (!fast2smsKey) {
    return {
      sent: false,
      note: `SMS gateway (FAST2SMS_API_KEY) is not configured in this environment. Server generated a secure time-limited OTP for verification testing (${purposeLabel} OTP: ${otp}). Configure FAST2SMS_API_KEY for live SMS delivery.`
    };
  }
  try {
    const resp = await fetch("https://www.fast2sms.com/dev/bulkV2", {
      method: "POST",
      headers: {
        authorization: fast2smsKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        route: "q",
        message: `Your Yuitor Smart Classes ${purposeLabel} OTP is ${otp}. Valid for 10 minutes. Do not share it with anyone.`,
        language: "english",
        flash: 0,
        numbers: phone
      })
    });
    const data = await resp.json();
    if (resp.ok && data?.return === true) {
      return { sent: true, note: "OTP sent to your registered mobile number." };
    }
    return {
      sent: false,
      note: `SMS provider rejected delivery (${data?.message || resp.status}). Check FAST2SMS_API_KEY configuration.`
    };
  } catch (err) {
    return {
      sent: false,
      note: `SMS gateway connection error: ${err?.message || "network error"}.`
    };
  }
}
function resolveCampaignRecipients(db, filters) {
  const suppressedSet = new Set(
    db.prepare("SELECT email FROM email_suppressions").all().map((r) => normalizeEmail(r.email))
  );
  let users = [];
  if (Array.isArray(filters.selectedUserIds) && filters.selectedUserIds.length > 0) {
    const ids = filters.selectedUserIds.map(Number).filter((n) => Number.isInteger(n) && n > 0);
    if (ids.length > 0) {
      const ph = ids.map(() => "?").join(",");
      users = db.prepare(
        `SELECT u.*, sp.class_level, sp.subjects_json as student_subjects,
                  tp.subjects_json as teacher_subjects
           FROM users u
           LEFT JOIN student_profiles sp ON sp.user_id = u.id
           LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
           WHERE u.id IN (${ph}) AND u.role IN ('student', 'teacher')`
      ).all(...ids);
    }
  } else {
    users = db.prepare(
      `SELECT u.*, sp.class_level, sp.subjects_json as student_subjects,
                tp.subjects_json as teacher_subjects
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role IN ('student', 'teacher')`
    ).all();
  }
  let enrolledUserIds = null;
  if (filters.courseId && Number(filters.courseId) > 0) {
    const rows = db.prepare("SELECT student_id FROM enrollments WHERE course_id = ? AND status IN ('active', 'completed')").all(Number(filters.courseId));
    const courseTeacher = db.prepare("SELECT teacher_id FROM courses WHERE id = ?").get(Number(filters.courseId));
    enrolledUserIds = new Set(rows.map((r) => Number(r.student_id)));
    if (courseTeacher?.teacher_id) enrolledUserIds.add(Number(courseTeacher.teacher_id));
  }
  const thirtyDaysAgo = new Date(Date.now() - 30 * 86400 * 1e3).toISOString();
  const eligible = [];
  let excludedCount = 0;
  for (const u of users) {
    if (!filters.selectedUserIds?.length) {
      if (filters.audienceGroup === "all_students" && u.role !== "student") continue;
      if (filters.audienceGroup === "all_teachers" && u.role !== "teacher") continue;
      if (filters.audienceGroup === "recently_registered" && (u.role !== "student" || u.created_at < thirtyDaysAgo)) continue;
      if (filters.accountStatus === "approved" && u.verification_status !== "approved") continue;
      if (filters.accountStatus === "pending_approval" && u.verification_status !== "pending_approval") continue;
      if (filters.classLevel && u.role === "student" && !String(u.class_level || "").toLowerCase().includes(filters.classLevel.toLowerCase())) {
        continue;
      }
      if (filters.subject) {
        const subBlob = `${u.student_subjects || ""} ${u.teacher_subjects || ""}`.toLowerCase();
        if (!subBlob.includes(filters.subject.toLowerCase())) continue;
      }
      if (enrolledUserIds && !enrolledUserIds.has(Number(u.id))) continue;
      if (filters.registeredAfter && u.created_at < filters.registeredAfter) continue;
    }
    const email = normalizeEmail(u.email);
    const isSuppressed = suppressedSet.has(email) || Number(u.marketing_opt_in) !== 1 || Number(u.is_active) !== 1;
    if (isSuppressed) {
      excludedCount++;
      continue;
    }
    eligible.push({
      id: Number(u.id),
      full_name: u.full_name,
      email,
      role: u.role,
      unsubscribe_token: u.unsubscribe_token
    });
  }
  return { eligible, excludedCount };
}
async function processCampaignQueue(db, campaignId, batchSize = 25) {
  const camp = db.prepare("SELECT * FROM email_campaigns WHERE id = ?").get(campaignId);
  if (!camp || ["paused", "cancelled", "draft"].includes(camp.status)) {
    return { sent: 0, failed: 0 };
  }
  db.prepare("UPDATE email_campaigns SET status = 'sending', updated_at = ? WHERE id = ?").run(nowIso(), campaignId);
  const pendingRows = db.prepare(
    `SELECT d.*, u.unsubscribe_token
       FROM email_deliveries d
       LEFT JOIN users u ON u.id = d.user_id
       WHERE d.campaign_id = ? AND (d.status = 'pending' OR (d.status = 'failed' AND d.retry_count < 2))
       ORDER BY d.id ASC LIMIT ?`
  ).all(campaignId, batchSize);
  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  let sent = 0;
  let failed = 0;
  for (const row of pendingRows) {
    const latest = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId);
    if (!latest || latest.status === "paused" || latest.status === "cancelled") break;
    const unsubUrl = row.unsubscribe_token ? `${siteUrl}/unsubscribe/${row.unsubscribe_token}` : void 0;
    const html = renderBrandedEmailHtml({
      subject: camp.subject,
      previewText: camp.preview_text,
      htmlBody: camp.html_body,
      recipientName: row.recipient_name,
      ctaLabel: camp.cta_label,
      ctaUrl: camp.cta_url,
      unsubscribeUrl: unsubUrl
    });
    const result = await sendEmailDirect({
      to: row.recipient_email,
      subject: camp.subject,
      html,
      attachmentUrl: camp.attachment_url
    });
    if (result.ok) {
      db.prepare(
        "UPDATE email_deliveries SET status = 'sent', provider_message_id = ?, error_message = '', sent_at = ? WHERE id = ?"
      ).run(result.messageId, nowIso(), row.id);
      sent++;
    } else {
      db.prepare(
        "UPDATE email_deliveries SET status = 'failed', error_message = ?, retry_count = retry_count + 1 WHERE id = ?"
      ).run(result.error, row.id);
      failed++;
    }
    await new Promise((r) => setTimeout(r, 40));
  }
  const counts = db.prepare(
    `SELECT
         SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent_c,
         SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_c,
         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_c
       FROM email_deliveries WHERE campaign_id = ?`
  ).get(campaignId);
  const currentCamp = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId);
  let nextStatus = currentCamp?.status || "completed";
  if (nextStatus !== "paused" && nextStatus !== "cancelled") {
    nextStatus = Number(counts?.pending_c || 0) > 0 ? "queued" : Number(counts?.sent_c || 0) > 0 ? "completed" : "failed";
  }
  db.prepare(
    "UPDATE email_campaigns SET status = ?, sent_count = ?, failed_count = ?, updated_at = ? WHERE id = ?"
  ).run(nextStatus, Number(counts?.sent_c || 0), Number(counts?.failed_c || 0), nowIso(), campaignId);
  return { sent, failed };
}
function startEmailScheduler(db) {
  setInterval(() => {
    try {
      const now = nowIso();
      const due = db.prepare(
        `SELECT id FROM email_campaigns
           WHERE (status = 'queued' AND (scheduled_at IS NULL OR scheduled_at <= ?))
              OR (send_mode = 'scheduled' AND status = 'queued' AND scheduled_at <= ?)`
      ).all(now, now);
      for (const c of due) {
        void processCampaignQueue(db, c.id, 20);
      }
    } catch (err) {
      console.warn("[Yuitor Mailer] Scheduler error:", err);
    }
  }, 3e4);
}

// server/routes/auth.ts
import { Router } from "express";
import crypto3 from "node:crypto";
function createAuthRouter(db) {
  const router = Router();
  router.get("/setup-status", (_req, res) => {
    const adminCount = db.prepare("SELECT COUNT(*) as c FROM users WHERE role IN ('super_admin', 'admin')").get().c;
    const requiresSetupKey = Boolean((process.env.YU_ADMIN_SETUP_KEY || "").trim());
    res.json({
      needsFirstAdminSetup: adminCount === 0,
      requiresSetupKey
    });
  });
  router.post("/setup-admin", (req, res) => {
    const adminCount = db.prepare("SELECT COUNT(*) as c FROM users WHERE role IN ('super_admin', 'admin')").get().c;
    if (adminCount > 0) {
      res.status(409).json({ error: "Admin setup is already complete. Sign in via /admin/login.php." });
      return;
    }
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `setup:${ip}`, 5, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many setup attempts. Try again in ${rl.retryAfterSeconds}s.` });
      return;
    }
    const setupKey = cleanText(req.body?.setupKey, 200);
    if (!verifySetupKey(setupKey)) {
      recordRateLimitHit(db, `setup:${ip}`, 900);
      res.status(403).json({ error: "Invalid YU_ADMIN_SETUP_KEY. Configure the matching key in hosting environment variables." });
      return;
    }
    const fullName = cleanText(req.body?.fullName, 120);
    const email = normalizeEmail(req.body?.email);
    const phone = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || "");
    if (fullName.length < 2) {
      res.status(400).json({ error: "Enter full name (min 2 characters)." });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: "Enter a valid email address." });
      return;
    }
    if (!isValidIndianMobile(phone)) {
      res.status(400).json({ error: "Enter a valid 10-digit Indian mobile number starting with 6\u20139." });
      return;
    }
    if (password.length < 8 || password.length > 200) {
      res.status(400).json({ error: "Password must be between 8 and 200 characters." });
      return;
    }
    const now = nowIso();
    const unsubToken = crypto3.randomBytes(18).toString("hex");
    const result = db.prepare(
      `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
         VALUES ('super_admin', ?, ?, ?, ?, 1, 'approved', 1, 0, ?, ?, ?)`
    ).run(fullName, email, phone, hashPassword(password), unsubToken, now, now);
    const uid = Number(result.lastInsertRowid);
    clearRateLimit(db, `setup:${ip}`);
    writeAuditLog(db, {
      actorId: uid,
      actorName: fullName,
      targetId: uid,
      targetName: fullName,
      action: "first_admin_created",
      details: `Super Admin initialized (${email})`,
      ipAddress: ip
    });
    const sid = createSession(db, uid);
    setSessionCookie(res, req, sid);
    res.status(201).json({ created: true, role: "super_admin" });
  });
  router.post("/register", async (req, res) => {
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `reg:${ip}`, 8, 900, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many registration requests. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `reg:${ip}`, 900);
    const role = String(req.body?.role || "student").toLowerCase() === "teacher" ? "teacher" : "student";
    const fullName = cleanText(req.body?.fullName, 120);
    const email = normalizeEmail(req.body?.email);
    const phone = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || "");
    if (fullName.length < 2) {
      res.status(400).json({ error: "Please enter your full name." });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: "Please enter a valid email address." });
      return;
    }
    if (!isValidIndianMobile(phone)) {
      res.status(400).json({ error: "Enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9." });
      return;
    }
    if (password.length < 8 || password.length > 200) {
      res.status(400).json({ error: "Password must be at least 8 characters." });
      return;
    }
    const existing = db.prepare("SELECT id, verification_status FROM users WHERE email = ? OR phone = ?").get(email, phone);
    if (existing) {
      res.status(409).json({ error: "An account already exists with this email or mobile number. Try signing in instead." });
      return;
    }
    const now = nowIso();
    const unsubToken = crypto3.randomBytes(18).toString("hex");
    const insertUser = db.prepare(
      `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 0, 'pending_otp', 1, 1, ?, ?, ?)`
    ).run(role, fullName, email, phone, hashPassword(password), unsubToken, now, now);
    const uid = Number(insertUser.lastInsertRowid);
    const subjects = Array.isArray(req.body?.subjects) ? req.body.subjects.map((x) => cleanText(x, 60)).filter(Boolean) : [];
    if (role === "student") {
      const classLevel = cleanText(req.body?.classLevel || "Class 10", 60);
      const board = cleanText(req.body?.board || "CBSE", 40);
      const duration = Math.min(60, Math.max(1, Number(req.body?.courseDurationMonths || 12)));
      db.prepare(
        `INSERT INTO student_profiles (user_id, class_level, board, subjects_json, course_duration_months, enrollment_status)
         VALUES (?, ?, ?, ?, ?, 'pending')`
      ).run(uid, classLevel, board, JSON.stringify(subjects), duration);
    } else {
      const qualification = cleanText(req.body?.qualification || "", 120);
      if (qualification.length < 2) {
        db.prepare("DELETE FROM users WHERE id = ?").run(uid);
        res.status(400).json({ error: "Qualification is required for teacher registration." });
        return;
      }
      const experienceYears = Math.min(50, Math.max(0, Number(req.body?.experienceYears || 0)));
      const assignedClasses = Array.isArray(req.body?.assignedClasses) ? req.body.assignedClasses.map((x) => cleanText(x, 60)).filter(Boolean) : [];
      db.prepare(
        `INSERT INTO teacher_profiles (user_id, qualification, experience_years, subjects_json, assigned_classes_json, availability_status)
         VALUES (?, ?, ?, ?, ?, 'available')`
      ).run(uid, qualification, experienceYears, JSON.stringify(subjects), JSON.stringify(assignedClasses));
    }
    const { otp } = issueOtp(db, { userId: uid, phone, email, purpose: "registration" });
    const sms = await dispatchSmsOtp(phone, otp, "registration");
    writeAuditLog(db, {
      actorId: uid,
      actorName: fullName,
      targetId: uid,
      targetName: fullName,
      action: `${role}_registered`,
      details: `OTP issued to ${phone} (SMS sent: ${sms.sent})`,
      ipAddress: ip
    });
    res.status(201).json({
      registered: true,
      phone,
      smsSent: sms.sent,
      limitationNote: sms.sent ? "" : sms.note
    });
  });
  router.post("/verify-otp", async (req, res) => {
    const phone = normalizePhone(req.body?.phone);
    const otp = cleanText(req.body?.otp, 10);
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `otpverify:${ip}:${phone}`, 8, 600, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many OTP verification attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    if (!isValidIndianMobile(phone) || !/^\d{6}$/.test(otp)) {
      recordRateLimitHit(db, `otpverify:${ip}:${phone}`, 600);
      res.status(400).json({ error: "Enter a valid mobile number and 6-digit OTP." });
      return;
    }
    const check = verifyOtpToken(db, { target: phone, purpose: "registration", otp });
    if (!check.ok) {
      recordRateLimitHit(db, `otpverify:${ip}:${phone}`, 600);
      res.status(400).json({ error: check.error });
      return;
    }
    const user = db.prepare("SELECT * FROM users WHERE phone = ? OR id = ?").get(phone, check.tokenRow.user_id);
    if (!user) {
      res.status(404).json({ error: "Account not found." });
      return;
    }
    const nextStatus = user.verification_status === "approved" ? "approved" : "pending_approval";
    db.prepare("UPDATE users SET mobile_verified = 1, verification_status = ?, updated_at = ? WHERE id = ?").run(
      nextStatus,
      nowIso(),
      user.id
    );
    clearRateLimit(db, `otpverify:${ip}:${phone}`);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `New ${user.role} approval pending`,
      `${user.full_name} (${user.phone}) verified mobile OTP and is awaiting Yuitor Team approval.`,
      nowIso()
    );
    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "mobile_otp_verified",
      details: `Account moved to ${nextStatus}`,
      ipAddress: ip
    });
    if (isSmtpConfigured() && ADMIN_NOTIFY_EMAIL) {
      void sendEmailDirect({
        to: ADMIN_NOTIFY_EMAIL,
        subject: `Pending ${user.role} approval: ${user.full_name}`,
        html: `<p><strong>${user.full_name}</strong> (${user.role}, ${user.phone}, ${user.email}) completed mobile OTP verification and is awaiting admin approval.</p>`
      });
    }
    res.json({
      verified: true,
      verificationStatus: nextStatus,
      pendingMessage: BRAND_PENDING_MSG
    });
  });
  router.post("/resend-otp", async (req, res) => {
    const phone = normalizePhone(req.body?.phone);
    const ip = clientIp(req);
    if (!isValidIndianMobile(phone)) {
      res.status(400).json({ error: "Valid 10-digit mobile number is required." });
      return;
    }
    const rl = checkRateLimit(db, `otpresend:${ip}:${phone}`, 4, 3600, 900);
    if (!rl.allowed) {
      res.status(429).json({ error: `OTP resend limit reached. Try again in ${rl.retryAfterSeconds}s.` });
      return;
    }
    const user = db.prepare("SELECT * FROM users WHERE phone = ?").get(phone);
    if (!user) {
      res.status(404).json({ error: "No registration found for this mobile number." });
      return;
    }
    const latest = db.prepare("SELECT created_at FROM otp_tokens WHERE phone = ? AND purpose = 'registration' ORDER BY id DESC LIMIT 1").get(phone);
    const nowSec = Math.floor(Date.now() / 1e3);
    if (latest && nowSec - latest.created_at < 30) {
      res.status(429).json({ error: `Please wait ${30 - (nowSec - latest.created_at)}s before requesting another OTP.` });
      return;
    }
    recordRateLimitHit(db, `otpresend:${ip}:${phone}`, 3600);
    const { otp } = issueOtp(db, { userId: user.id, phone, email: user.email, purpose: "registration" });
    const sms = await dispatchSmsOtp(phone, otp, "verification");
    res.json({
      resent: true,
      smsSent: sms.sent,
      limitationNote: sms.sent ? "" : sms.note
    });
  });
  router.post("/login", (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const password = String(req.body?.password || "");
    const ip = clientIp(req);
    const rateKey = `login:${ip}:${identifier.toLowerCase()}`;
    const rl = checkRateLimit(db, rateKey, 6, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many failed sign-in attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    if (!identifier || !password) {
      res.status(400).json({ error: "Enter both email/mobile and password." });
      return;
    }
    const normalizedEmail = normalizeEmail(identifier);
    const normalizedPhone = normalizePhone(identifier);
    const user = db.prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1").get(normalizedEmail, normalizedPhone);
    const dummyHash = "$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy";
    const ok = verifyPassword(password, user ? user.password_hash : dummyHash);
    if (!user || !ok) {
      recordRateLimitHit(db, rateKey, 900);
      res.status(401).json({ error: "Incorrect email/mobile or password." });
      return;
    }
    if (Number(user.is_active) !== 1 || user.verification_status === "suspended" || user.verification_status === "rejected") {
      res.status(403).json({ error: `Your account is currently ${user.verification_status}. Contact Yuitor Team at +91 78-2728-9292.` });
      return;
    }
    if (user.verification_status === "pending_otp") {
      res.json({ authenticated: false, verificationStatus: "pending_otp", phone: user.phone });
      return;
    }
    if (user.verification_status === "pending_approval" || user.verification_status === "otp_verified") {
      res.json({
        authenticated: false,
        verificationStatus: user.verification_status,
        pendingMessage: BRAND_PENDING_MSG
      });
      return;
    }
    clearRateLimit(db, rateKey);
    db.prepare("UPDATE users SET last_login_at = ? WHERE id = ?").run(nowIso(), user.id);
    const sid = createSession(db, Number(user.id));
    setSessionCookie(res, req, sid);
    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "login_success",
      details: `${user.role} signed in`,
      ipAddress: ip
    });
    res.json({
      authenticated: true,
      role: user.role,
      verificationStatus: user.verification_status
    });
  });
  router.post("/logout", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (ctx) {
      db.prepare("DELETE FROM sessions WHERE id = ?").run(ctx.sessionId);
    }
    clearSessionCookie(res);
    res.json({ loggedOut: true });
  });
  router.get("/me", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.json({ authenticated: false, user: null });
      return;
    }
    const isPending = ctx.user.verification_status !== "approved";
    res.json({
      authenticated: true,
      user: ctx.user,
      impersonation: ctx.impersonation,
      pendingMessage: isPending ? BRAND_PENDING_MSG : void 0
    });
  });
  router.post("/forgot-password", async (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `forgot:${ip}`, 5, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many reset requests. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `forgot:${ip}`, 900);
    const user = db.prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1").get(normalizeEmail(identifier), normalizePhone(identifier));
    if (!user) {
      res.json({
        message: "If an account matches that email or mobile number, a 6-digit reset OTP has been generated.",
        limitationNote: "If no SMS/SMTP provider is configured, contact Yuitor Team at +91 78-2728-9292."
      });
      return;
    }
    const { otp } = issueOtp(db, {
      userId: user.id,
      phone: user.phone,
      email: user.email,
      purpose: "password_reset"
    });
    let note = "";
    if (user.phone && isValidIndianMobile(user.phone)) {
      const sms = await dispatchSmsOtp(user.phone, otp, "password reset");
      if (!sms.sent) note = sms.note;
    }
    if (isSmtpConfigured() && user.email) {
      void sendEmailDirect({
        to: user.email,
        subject: "Yuitor Smart Classes Password Reset OTP",
        html: `<p>Hello ${user.full_name},</p><p>Your password reset OTP is <strong>${otp}</strong>. It expires in 10 minutes.</p>`
      });
    }
    res.json({
      message: "6-digit password reset OTP dispatched.",
      limitationNote: note
    });
  });
  router.post("/reset-password", (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const otp = cleanText(req.body?.otp, 10);
    const newPassword = String(req.body?.newPassword || "");
    const ip = clientIp(req);
    if (newPassword.length < 8 || newPassword.length > 200) {
      res.status(400).json({ error: "New password must be at least 8 characters." });
      return;
    }
    const user = db.prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1").get(normalizeEmail(identifier), normalizePhone(identifier));
    if (!user) {
      res.status(400).json({ error: "Invalid OTP or account." });
      return;
    }
    const target = user.phone || user.email;
    const check = verifyOtpToken(db, { target, purpose: "password_reset", otp });
    if (!check.ok) {
      res.status(400).json({ error: check.error });
      return;
    }
    db.prepare("UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?").run(
      hashPassword(newPassword),
      nowIso(),
      user.id
    );
    db.prepare("DELETE FROM sessions WHERE user_id = ?").run(user.id);
    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "password_reset",
      details: "Password reset via OTP",
      ipAddress: ip
    });
    res.json({ message: "Password updated successfully. You can now sign in." });
  });
  router.patch("/avatar", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Authentication required." });
      return;
    }
    const avatarUrl = cleanText(req.body?.avatarUrl, 300);
    if (!avatarUrl.startsWith("/uploads/")) {
      res.status(400).json({ error: "Invalid uploaded avatar path." });
      return;
    }
    db.prepare("UPDATE users SET avatar_url = ?, updated_at = ? WHERE id = ?").run(avatarUrl, nowIso(), ctx.user.id);
    res.json({ updated: true, avatarUrl });
  });
  router.post("/exit-impersonation", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || !ctx.impersonation.active || !ctx.impersonation.adminId) {
      res.status(400).json({ error: "No active impersonation session." });
      return;
    }
    const adminId = ctx.impersonation.adminId;
    db.prepare("DELETE FROM sessions WHERE id = ?").run(ctx.sessionId);
    db.prepare(
      `UPDATE impersonation_logs SET ended_at = ?
       WHERE id = (SELECT id FROM impersonation_logs WHERE admin_id = ? AND target_user_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1)`
    ).run(nowIso(), adminId, ctx.user.id);
    const newSid = createSession(db, adminId);
    setSessionCookie(res, req, newSid);
    writeAuditLog(db, {
      actorId: adminId,
      actorName: "Admin",
      targetId: ctx.user.id,
      targetName: ctx.user.full_name,
      action: "impersonation_ended",
      details: "Exited troubleshooting view",
      ipAddress: clientIp(req)
    });
    res.json({ redirectTo: "/admin/" });
  });
  return router;
}

// server/routes/admin.ts
import { Router as Router2 } from "express";
import crypto4 from "node:crypto";
import fs3 from "node:fs";
import path3 from "node:path";
function createAdminRouter(db) {
  const router = Router2();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Admin sign-in required." });
      return;
    }
    if (ctx.user.role !== "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    req.ctx = ctx;
    next();
  });
  router.get("/dashboard", (_req, res) => {
    const totalStudents = db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'student'").get().c;
    const totalTeachers = db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'teacher'").get().c;
    const pendingApprovals = db.prepare(
      "SELECT COUNT(*) as c FROM users WHERE role IN ('student', 'teacher') AND verification_status IN ('pending_approval', 'otp_verified')"
    ).get().c;
    const totalCourses = db.prepare("SELECT COUNT(*) as c FROM courses WHERE is_active = 1").get().c;
    const totalAdmissions = db.prepare("SELECT COUNT(*) as c FROM enrollments WHERE status IN ('active', 'completed')").get().c;
    const newInquiries = db.prepare("SELECT COUNT(*) as c FROM inquiries WHERE status = 'new'").get().c;
    const unresolvedChats = db.prepare("SELECT COUNT(*) as c FROM chatbot_conversations WHERE status IN ('unresolved', 'escalated')").get().c;
    const totalCollected = db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM payments WHERE verification_status = 'verified'").get().s;
    const totalPending = db.prepare(
      "SELECT COALESCE(SUM(MAX(0, total_amount - discount_amount - paid_amount)), 0) as s FROM fee_records WHERE status != 'refunded'"
    ).get().s;
    const recentActivities = db.prepare("SELECT id, action, actor_name, target_name, details, created_at FROM audit_logs ORDER BY id DESC LIMIT 20").all();
    res.json({
      counts: {
        totalStudents,
        totalTeachers,
        pendingApprovals,
        totalCourses,
        totalAdmissions,
        newInquiries,
        unresolvedChats
      },
      feeSummary: {
        totalCollected: Number(totalCollected || 0),
        totalPending: Number(totalPending || 0)
      },
      recentActivities
    });
  });
  router.get("/users", (req, res) => {
    const role = String(req.query.role || "all");
    const status = String(req.query.status || "all");
    const search = cleanText(req.query.search, 120).toLowerCase();
    const page = Math.max(1, Number(req.query.page || 1));
    const pageSize = Math.min(50, Math.max(1, Number(req.query.pageSize || 12)));
    const where = [];
    const params = [];
    if (role !== "all") {
      where.push("u.role = ?");
      params.push(role);
    }
    if (status !== "all") {
      where.push("u.verification_status = ?");
      params.push(status);
    }
    if (search) {
      where.push("(LOWER(u.full_name) LIKE ? OR LOWER(u.email) LIKE ? OR u.phone LIKE ?)");
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    const whereSql = where.length ? "WHERE " + where.join(" AND ") : "";
    const total = db.prepare(`SELECT COUNT(*) as c FROM users u ${whereSql}`).get(...params).c;
    const users = db.prepare(
      `SELECT u.id, u.role, u.full_name, u.email, u.phone, u.avatar_url, u.mobile_verified,
                u.verification_status, u.is_active, u.marketing_opt_in, u.last_login_at, u.created_at,
                sp.class_level, tp.qualification
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         ${whereSql}
         ORDER BY u.id DESC
         LIMIT ? OFFSET ?`
    ).all(...params, pageSize, (page - 1) * pageSize);
    res.json({ users, total, page, pageSize });
  });
  router.post("/users", (req, res) => {
    const ctx = req.ctx;
    const role = String(req.body?.role || "student");
    if (!["student", "teacher", "admin"].includes(role)) {
      res.status(400).json({ error: "Invalid role." });
      return;
    }
    if (role === "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Only Super Admin can create Admin accounts." });
      return;
    }
    const fullName = cleanText(req.body?.fullName, 120);
    const email = normalizeEmail(req.body?.email);
    const phone = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || "");
    if (fullName.length < 2 || !isValidEmail(email) || !isValidPhone(phone) || password.length < 8) {
      res.status(400).json({ error: "Provide valid name, email, phone, and min 8-char password." });
      return;
    }
    if (db.prepare("SELECT id FROM users WHERE email = ?").get(email)) {
      res.status(409).json({ error: "An account already exists with this email." });
      return;
    }
    const now = nowIso();
    const resIns = db.prepare(
      `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 1, 'approved', 1, 1, ?, ?, ?)`
    ).run(role, fullName, email, phone, hashPassword(password), crypto4.randomBytes(18).toString("hex"), now, now);
    const uid = Number(resIns.lastInsertRowid);
    if (role === "student") {
      db.prepare(
        "INSERT INTO student_profiles (user_id, class_level, board, course_duration_months, admission_date, enrollment_status) VALUES (?, ?, 'CBSE', 12, ?, 'active')"
      ).run(uid, cleanText(req.body?.classLevel || "Class 10", 60), now.slice(0, 10));
    } else if (role === "teacher") {
      db.prepare(
        "INSERT INTO teacher_profiles (user_id, qualification, experience_years, availability_status) VALUES (?, ?, 2, 'available')"
      ).run(uid, cleanText(req.body?.qualification || "Subject Faculty", 120));
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: fullName,
      action: "admin_created_user",
      details: `Created approved ${role} (${email})`,
      ipAddress: clientIp(req)
    });
    res.status(201).json({ id: uid, created: true });
  });
  router.get("/users/:id", (req, res) => {
    const uid = Number(req.params.id);
    const user = db.prepare(
      `SELECT id, role, full_name, email, phone, avatar_url, mobile_verified,
                verification_status, is_active, marketing_opt_in, last_login_at, created_at
         FROM users WHERE id = ?`
    ).get(uid);
    if (!user) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    const studentProfile = db.prepare("SELECT * FROM student_profiles WHERE user_id = ?").get(uid) || null;
    const teacherProfile = db.prepare("SELECT * FROM teacher_profiles WHERE user_id = ?").get(uid) || null;
    const otpSummary = db.prepare("SELECT purpose, attempts, consumed_at, created_at FROM otp_tokens WHERE user_id = ? ORDER BY id DESC LIMIT 10").all(uid);
    const history = db.prepare("SELECT action, details, ip_address, created_at FROM audit_logs WHERE target_id = ? OR actor_id = ? ORDER BY id DESC LIMIT 20").all(uid, uid);
    res.json({ user, studentProfile, teacherProfile, otpSummary, history });
  });
  router.patch("/users/:id", (req, res) => {
    const ctx = req.ctx;
    const uid = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM users WHERE id = ?").get(uid);
    if (!existing) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    const fullName = cleanText(req.body?.fullName ?? existing.full_name, 120);
    const email = normalizeEmail(req.body?.email ?? existing.email);
    const phone = normalizePhone(req.body?.phone ?? existing.phone);
    if (fullName.length < 2 || !isValidEmail(email) || !isValidPhone(phone)) {
      res.status(400).json({ error: "Valid name, email, and phone are required." });
      return;
    }
    db.prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, updated_at = ? WHERE id = ?").run(
      fullName,
      email,
      phone,
      nowIso(),
      uid
    );
    if (req.body?.studentProfile && existing.role === "student") {
      const sp = req.body.studentProfile;
      db.prepare(
        `INSERT INTO student_profiles (user_id, class_level, board, course_duration_months)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET class_level = excluded.class_level, board = excluded.board, course_duration_months = excluded.course_duration_months`
      ).run(
        uid,
        cleanText(sp.classLevel || "Class 10", 60),
        cleanText(sp.board || "CBSE", 40),
        Math.min(60, Math.max(1, Number(sp.courseDurationMonths || 12)))
      );
    }
    if (req.body?.teacherProfile && existing.role === "teacher") {
      const tp = req.body.teacherProfile;
      db.prepare(
        `INSERT INTO teacher_profiles (user_id, qualification, experience_years)
         VALUES (?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET qualification = excluded.qualification, experience_years = excluded.experience_years`
      ).run(uid, cleanText(tp.qualification || "", 120), Math.max(0, Number(tp.experienceYears || 0)));
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: fullName,
      action: "admin_edited_user",
      details: "Updated profile details",
      ipAddress: clientIp(req)
    });
    res.json({ updated: true });
  });
  router.post("/users/:id/status", (req, res) => {
    const ctx = req.ctx;
    const uid = Number(req.params.id);
    const action = String(req.body?.action || "").toLowerCase();
    const reason = cleanText(req.body?.reason, 300);
    const target = db.prepare("SELECT * FROM users WHERE id = ?").get(uid);
    if (!target) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    if (target.role === "super_admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Cannot modify a Super Admin account." });
      return;
    }
    let nextStatus = target.verification_status;
    let isActive = Number(target.is_active);
    if (action === "approve") {
      nextStatus = "approved";
      isActive = 1;
      if (target.role === "student") {
        db.prepare(
          "UPDATE student_profiles SET enrollment_status = 'active', admission_date = COALESCE(admission_date, ?) WHERE user_id = ?"
        ).run(nowIso().slice(0, 10), uid);
      }
    } else if (action === "activate") {
      isActive = 1;
      if (nextStatus === "suspended") nextStatus = "approved";
    } else if (action === "suspend") {
      nextStatus = "suspended";
      isActive = 0;
      db.prepare("DELETE FROM sessions WHERE user_id = ?").run(uid);
    } else if (action === "reject") {
      nextStatus = "rejected";
      isActive = 0;
      db.prepare("DELETE FROM sessions WHERE user_id = ?").run(uid);
    } else {
      res.status(400).json({ error: "Invalid status action." });
      return;
    }
    db.prepare("UPDATE users SET verification_status = ?, is_active = ?, updated_at = ? WHERE id = ?").run(
      nextStatus,
      isActive,
      nowIso(),
      uid
    );
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(
      uid,
      `Account ${nextStatus}`,
      reason || `Your Yuitor Smart Classes account status is now ${nextStatus}.`,
      nowIso()
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: target.full_name,
      action: `user_${action}`,
      details: reason || `Status updated to ${nextStatus}`,
      ipAddress: clientIp(req)
    });
    res.json({ updated: true, verificationStatus: nextStatus, isActive });
  });
  router.post("/impersonate", (req, res) => {
    const ctx = req.ctx;
    const targetId = Number(req.body?.userId);
    const reason = cleanText(req.body?.reason, 200);
    if (reason.length < 4) {
      res.status(400).json({ error: "Provide a clear troubleshooting reason (min 4 characters)." });
      return;
    }
    const target = db.prepare("SELECT id, role, full_name FROM users WHERE id = ?").get(targetId);
    if (!target || !["student", "teacher"].includes(target.role)) {
      res.status(400).json({ error: "Admins can only impersonate Student or Teacher panels." });
      return;
    }
    const now = nowIso();
    db.prepare("INSERT INTO impersonation_logs (admin_id, target_user_id, reason, started_at) VALUES (?, ?, ?, ?)").run(
      ctx.user.id,
      target.id,
      reason,
      now
    );
    const impSid = createSession(db, target.id, {
      impersonatorId: ctx.user.id,
      reason,
      ttlSeconds: 1800
    });
    setSessionCookie(res, req, impSid, 1800);
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: target.id,
      targetName: target.full_name,
      action: "impersonation_started",
      details: reason,
      ipAddress: clientIp(req)
    });
    res.json({ redirectTo: target.role === "teacher" ? "/teacher/" : "/student/" });
  });
  router.get("/courses", (_req, res) => {
    const courses = db.prepare(
      `SELECT c.*, u.full_name as teacher_name,
                (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id AND e.status IN ('active', 'completed')) as active_students
         FROM courses c
         LEFT JOIN users u ON u.id = c.teacher_id
         ORDER BY c.id DESC`
    ).all();
    const subjects = db.prepare("SELECT * FROM subjects ORDER BY id DESC").all();
    const teachers = db.prepare("SELECT id, full_name, email FROM users WHERE role = 'teacher' AND verification_status = 'approved' ORDER BY full_name").all();
    res.json({ courses, subjects, teachers });
  });
  router.post("/courses", (req, res) => {
    const title = cleanText(req.body?.title, 160);
    if (title.length < 3) {
      res.status(400).json({ error: "Course title is required." });
      return;
    }
    const slug = `${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${Date.now().toString(36)}`;
    const resIns = db.prepare(
      `INSERT INTO courses (title, slug, category, class_range, board, description, duration_months, monthly_fee, yearly_fee, teacher_id, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    ).run(
      title,
      slug,
      cleanText(req.body?.category || "Classes 6-12", 60),
      cleanText(req.body?.classRange || "Classes 9\u201310", 60),
      cleanText(req.body?.board || "CBSE", 60),
      cleanText(req.body?.description || "", 1e3),
      Math.min(60, Math.max(1, Number(req.body?.durationMonths || 12))),
      Math.max(0, Number(req.body?.monthlyFee || 1400)),
      Math.max(0, Number(req.body?.yearlyFee || 14300)),
      req.body?.teacherId ? Number(req.body.teacherId) : null,
      nowIso()
    );
    res.status(201).json({ id: Number(resIns.lastInsertRowid) });
  });
  router.patch("/courses/:id", (req, res) => {
    const cid = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM courses WHERE id = ?").get(cid);
    if (!existing) {
      res.status(404).json({ error: "Course not found." });
      return;
    }
    db.prepare(
      `UPDATE courses SET title = ?, category = ?, class_range = ?, monthly_fee = ?, yearly_fee = ?, teacher_id = ? WHERE id = ?`
    ).run(
      cleanText(req.body?.title ?? existing.title, 160),
      cleanText(req.body?.category ?? existing.category, 60),
      cleanText(req.body?.classRange ?? existing.class_range, 60),
      Math.max(0, Number(req.body?.monthlyFee ?? existing.monthly_fee)),
      Math.max(0, Number(req.body?.yearlyFee ?? existing.yearly_fee)),
      req.body?.teacherId === "" ? null : req.body?.teacherId ? Number(req.body.teacherId) : existing.teacher_id,
      cid
    );
    res.json({ updated: true });
  });
  router.delete("/courses/:id", (req, res) => {
    db.prepare("DELETE FROM courses WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/subjects", (req, res) => {
    const name = cleanText(req.body?.name, 120);
    const code = cleanText(req.body?.code, 30).toUpperCase();
    if (!name || !code) {
      res.status(400).json({ error: "Subject name and code are required." });
      return;
    }
    db.prepare("INSERT INTO subjects (name, code, class_level, description, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(
      name,
      code,
      cleanText(req.body?.classLevel || "Classes 6\u201312", 80),
      cleanText(req.body?.description || "", 500),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/subjects/:id", (req, res) => {
    db.prepare("DELETE FROM subjects WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/payments", (_req, res) => {
    const payments = db.prepare(
      `SELECT p.*, u.full_name as student_name, u.email as student_email, c.title as course_title
         FROM payments p
         JOIN users u ON u.id = p.student_id
         JOIN courses c ON c.id = p.course_id
         ORDER BY p.id DESC`
    ).all();
    const coupons = db.prepare("SELECT * FROM coupons ORDER BY id DESC").all();
    res.json({ payments, coupons });
  });
  router.post("/coupons", (req, res) => {
    const code = cleanText(req.body?.code, 30).toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    const discountType = req.body?.discountType === "flat" ? "flat" : "percent";
    const discountValue = Math.max(1, Number(req.body?.discountValue || 10));
    const maxUses = Math.max(1, Number(req.body?.maxUses || 100));
    if (code.length < 3) {
      res.status(400).json({ error: "Coupon code must be at least 3 characters." });
      return;
    }
    db.prepare(
      "INSERT INTO coupons (code, discount_type, discount_value, max_uses, used_count, is_active, created_at) VALUES (?, ?, ?, ?, 0, 1, ?)"
    ).run(code, discountType, discountValue, maxUses, nowIso());
    res.status(201).json({ created: true });
  });
  router.post("/payments/:id/verify", (req, res) => {
    const ctx = req.ctx;
    const pid = Number(req.params.id);
    const decision = String(req.body?.decision || "verify");
    const pay = db.prepare("SELECT * FROM payments WHERE id = ?").get(pid);
    if (!pay) {
      res.status(404).json({ error: "Payment record not found." });
      return;
    }
    if (decision === "verify") {
      const receipt = pay.receipt_number || `YTR-RCP-${String(pid).padStart(5, "0")}`;
      const paidAt = nowIso();
      db.prepare("UPDATE payments SET verification_status = 'verified', receipt_number = ?, paid_at = ? WHERE id = ?").run(
        receipt,
        paidAt,
        pid
      );
      if (pay.enrollment_id) {
        db.prepare("UPDATE enrollments SET status = 'active' WHERE id = ?").run(pay.enrollment_id);
      }
      db.prepare("UPDATE fee_records SET paid_amount = total_amount - discount_amount, status = 'paid' WHERE student_id = ? AND course_id = ?").run(
        pay.student_id,
        pay.course_id
      );
      db.prepare("INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)").run(
        pay.student_id,
        "Payment Verified",
        `Your fee payment of \u20B9${pay.amount} (Receipt ${receipt}) is verified. Course access is now active.`,
        paidAt
      );
    } else {
      db.prepare("UPDATE payments SET verification_status = 'failed' WHERE id = ?").run(pid);
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: pay.student_id,
      targetName: `Payment #${pid}`,
      action: `payment_${decision}`,
      details: `Amount \u20B9${pay.amount}`,
      ipAddress: clientIp(req)
    });
    res.json({ updated: true });
  });
  router.post("/payments/:id/refund", (req, res) => {
    const ctx = req.ctx;
    const pid = Number(req.params.id);
    const pay = db.prepare("SELECT * FROM payments WHERE id = ?").get(pid);
    if (!pay) {
      res.status(404).json({ error: "Payment record not found." });
      return;
    }
    db.prepare("UPDATE payments SET verification_status = 'refunded', refund_status = 'processed' WHERE id = ?").run(pid);
    if (pay.enrollment_id) {
      db.prepare("UPDATE enrollments SET status = 'cancelled' WHERE id = ?").run(pay.enrollment_id);
    }
    db.prepare("UPDATE fee_records SET status = 'refunded' WHERE student_id = ? AND course_id = ?").run(
      pay.student_id,
      pay.course_id
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: pay.student_id,
      targetName: `Payment #${pid}`,
      action: "payment_refunded",
      details: `Refunded \u20B9${pay.amount}`,
      ipAddress: clientIp(req)
    });
    res.json({ refunded: true });
  });
  router.get("/inquiries", (_req, res) => {
    const inquiries = db.prepare("SELECT * FROM inquiries ORDER BY id DESC").all();
    res.json({ inquiries });
  });
  router.patch("/inquiries/:id", (req, res) => {
    const status = String(req.body?.status || "new");
    if (!["new", "contacted", "admitted", "closed"].includes(status)) {
      res.status(400).json({ error: "Invalid inquiry status." });
      return;
    }
    db.prepare("UPDATE inquiries SET status = ? WHERE id = ?").run(status, Number(req.params.id));
    res.json({ updated: true });
  });
  router.delete("/inquiries/:id", (req, res) => {
    db.prepare("DELETE FROM inquiries WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/cms", (_req, res) => {
    res.json({
      announcements: db.prepare("SELECT * FROM announcements ORDER BY id DESC").all(),
      banners: db.prepare("SELECT * FROM banners ORDER BY id DESC").all(),
      blogPosts: db.prepare("SELECT * FROM blog_posts ORDER BY id DESC").all(),
      faqs: db.prepare("SELECT * FROM faqs ORDER BY sort_order ASC, id DESC").all(),
      testimonials: db.prepare("SELECT * FROM testimonials ORDER BY id DESC").all()
    });
  });
  router.post("/cms/announcements", (req, res) => {
    const ctx = req.ctx;
    db.prepare("INSERT INTO announcements (title, body, audience, created_by, created_at) VALUES (?, ?, ?, ?, ?)").run(
      cleanText(req.body?.title, 180),
      cleanText(req.body?.body, 2e3),
      ["all", "students", "teachers", "public"].includes(req.body?.audience) ? req.body.audience : "all",
      ctx.user.id,
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/announcements/:id", (req, res) => {
    db.prepare("DELETE FROM announcements WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/cms/banners", (req, res) => {
    db.prepare("INSERT INTO banners (title, subtitle, cta_label, cta_href, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(
      cleanText(req.body?.title, 180),
      cleanText(req.body?.subtitle, 300),
      cleanText(req.body?.ctaLabel || "Apply for Admission", 60),
      cleanText(req.body?.ctaHref || "/admission", 200),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/banners/:id", (req, res) => {
    db.prepare("DELETE FROM banners WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/cms/blog", (req, res) => {
    const title = cleanText(req.body?.title, 200);
    const slug = `${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${Date.now().toString(36)}`;
    db.prepare("INSERT INTO blog_posts (title, slug, category, excerpt, content, is_published, created_at) VALUES (?, ?, ?, ?, ?, 1, ?)").run(
      title,
      slug,
      cleanText(req.body?.category || "Study Tips", 60),
      cleanText(req.body?.excerpt, 400),
      cleanText(req.body?.content, 1e4),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/blog/:id", (req, res) => {
    db.prepare("DELETE FROM blog_posts WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/cms/faqs", (req, res) => {
    db.prepare("INSERT INTO faqs (question, answer, sort_order, is_active, created_at) VALUES (?, ?, 99, 1, ?)").run(
      cleanText(req.body?.question, 300),
      cleanText(req.body?.answer, 2e3),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/faqs/:id", (req, res) => {
    db.prepare("DELETE FROM faqs WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/cms/testimonials", (req, res) => {
    db.prepare("INSERT INTO testimonials (author_name, author_role, outcome_metric, quote, is_approved, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(
      cleanText(req.body?.authorName, 120),
      cleanText(req.body?.authorRole || "Student", 120),
      cleanText(req.body?.outcomeMetric, 120),
      cleanText(req.body?.quote, 1e3),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/testimonials/:id", (req, res) => {
    db.prepare("DELETE FROM testimonials WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/chatbot", (req, res) => {
    const status = String(req.query.status || "all");
    const search = cleanText(req.query.search, 120).toLowerCase();
    const minRating = Number(req.query.minRating || 0);
    const where = [];
    const params = [];
    if (status !== "all") {
      where.push("status = ?");
      params.push(status);
    }
    if (minRating > 0) {
      where.push("rating >= ?");
      params.push(minRating);
    }
    if (search) {
      where.push(
        "(LOWER(visitor_name) LIKE ? OR visitor_phone LIKE ? OR LOWER(visitor_email) LIKE ? OR LOWER(last_message) LIKE ? OR id IN (SELECT conversation_id FROM chatbot_messages WHERE LOWER(message) LIKE ?))"
      );
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    const whereSql = where.length ? "WHERE " + where.join(" AND ") : "";
    const conversations = db.prepare(`SELECT * FROM chatbot_conversations ${whereSql} ORDER BY updated_at DESC LIMIT 100`).all(...params);
    res.json({ conversations });
  });
  router.get("/chatbot/:id", (req, res) => {
    const conversation = db.prepare("SELECT * FROM chatbot_conversations WHERE id = ?").get(req.params.id);
    if (!conversation) {
      res.status(404).json({ error: "Conversation not found." });
      return;
    }
    const messages = db.prepare("SELECT * FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC").all(req.params.id);
    res.json({ conversation, messages });
  });
  router.patch("/chatbot/:id", (req, res) => {
    const status = String(req.body?.status || "resolved");
    if (!["active", "unresolved", "escalated", "resolved"].includes(status)) {
      res.status(400).json({ error: "Invalid conversation status." });
      return;
    }
    db.prepare("UPDATE chatbot_conversations SET status = ?, updated_at = ? WHERE id = ?").run(
      status,
      nowIso(),
      req.params.id
    );
    res.json({ updated: true });
  });
  router.get("/notifications", (_req, res) => {
    const notifications = db.prepare("SELECT * FROM notifications WHERE role_target = 'admin' OR role_target = 'all' ORDER BY id DESC LIMIT 30").all();
    res.json({ notifications });
  });
  router.post("/notifications/read-all", (_req, res) => {
    db.prepare("UPDATE notifications SET is_read = 1 WHERE role_target = 'admin'").run();
    res.json({ updated: true });
  });
  router.get("/backups", (_req, res) => {
    fs3.mkdirSync(BACKUPS_DIR, { recursive: true });
    const files = fs3.readdirSync(BACKUPS_DIR).filter((f) => f.endsWith(".db")).map((f) => {
      const st = fs3.statSync(path3.join(BACKUPS_DIR, f));
      return { filename: f, sizeBytes: st.size, createdAt: st.mtime.toISOString() };
    }).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    res.json({ backups: files });
  });
  router.post("/backups", (req, res) => {
    const ctx = req.ctx;
    const backup = createDatabaseBackup(db, "admin");
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      action: "database_backup_created",
      details: backup.filename,
      ipAddress: clientIp(req)
    });
    res.status(201).json({ backup });
  });
  router.get("/backups/:filename", (req, res) => {
    const safeName = path3.basename(req.params.filename);
    if (!/^[a-zA-Z0-9._-]+\.db$/.test(safeName)) {
      res.status(400).json({ error: "Invalid backup filename." });
      return;
    }
    const full = path3.join(BACKUPS_DIR, safeName);
    if (!fs3.existsSync(full)) {
      res.status(404).json({ error: "Backup file not found." });
      return;
    }
    res.download(full, safeName);
  });
  router.get("/project-zip", (_req, res) => {
    const zipPath = path3.join(APP_ROOT, "yuitor-smart-classes-final.zip");
    if (!fs3.existsSync(zipPath)) {
      res.status(404).json({ error: "Final project ZIP archive not found." });
      return;
    }
    res.download(zipPath, "yuitor-smart-classes-final.zip");
  });
  return router;
}

// server/routes/marketing.ts
import { Router as Router3 } from "express";
function createMarketingRouter(db) {
  const router = Router3();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Admin sign-in required." });
      return;
    }
    if (ctx.user.role !== "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    req.ctx = ctx;
    next();
  });
  router.get("/overview", (_req, res) => {
    const campaigns = db.prepare("SELECT * FROM email_campaigns ORDER BY id DESC").all();
    const totalCampaigns = campaigns.length;
    const totalEligible = campaigns.reduce((acc, c) => acc + Number(c.total_recipients || 0), 0);
    const totalSent = campaigns.reduce((acc, c) => acc + Number(c.sent_count || 0), 0);
    const totalFailed = campaigns.reduce((acc, c) => acc + Number(c.failed_count || 0), 0);
    const templates = db.prepare("SELECT * FROM email_templates ORDER BY id ASC").all();
    const courses = db.prepare("SELECT id, title FROM courses WHERE is_active = 1 ORDER BY id ASC").all();
    const students = db.prepare("SELECT id, full_name, email, verification_status, marketing_opt_in FROM users WHERE role = 'student' ORDER BY full_name").all();
    const teachers = db.prepare("SELECT id, full_name, email, verification_status, marketing_opt_in FROM users WHERE role = 'teacher' ORDER BY full_name").all();
    const suppressions = db.prepare("SELECT * FROM email_suppressions ORDER BY id DESC LIMIT 100").all();
    res.json({
      summary: {
        totalCampaigns,
        totalEligible,
        totalSent,
        totalFailed,
        openClickTrackingNote: "Opens/clicks reported only when webhook/pixel tracking is enabled on your SMTP provider."
      },
      senderEmail: SENDER_EMAIL,
      replyToEmail: REPLY_TO_EMAIL,
      smtpConfigured: isSmtpConfigured(),
      templates,
      courses,
      students,
      teachers,
      campaigns,
      suppressions
    });
  });
  router.post("/preview-recipients", (req, res) => {
    const filters = req.body?.filters || {};
    const { eligible, excludedCount } = resolveCampaignRecipients(db, filters);
    res.json({
      eligibleCount: eligible.length,
      excludedCount
    });
  });
  router.post("/campaigns", async (req, res) => {
    const ctx = req.ctx;
    const name = cleanText(req.body?.name, 160);
    const subject = cleanText(req.body?.subject, 200).replace(/[\r\n]+/g, " ");
    const previewText = cleanText(req.body?.previewText, 240);
    const htmlBody = String(req.body?.htmlBody || "").trim();
    const ctaLabel = cleanText(req.body?.ctaLabel, 80);
    const ctaUrl = cleanText(req.body?.ctaUrl, 300);
    const attachmentUrl = cleanText(req.body?.attachmentUrl, 300);
    const sendMode = ["draft", "immediate", "scheduled"].includes(req.body?.sendMode) ? req.body.sendMode : "draft";
    const scheduledAt = req.body?.scheduledAt ? cleanText(req.body.scheduledAt, 40) : null;
    const templateId = req.body?.templateId ? Number(req.body.templateId) : null;
    const filters = req.body?.filters || {};
    if (!name || !subject || !htmlBody) {
      res.status(400).json({ error: "Campaign name, email subject, and HTML body are required." });
      return;
    }
    const { eligible, excludedCount } = resolveCampaignRecipients(db, filters);
    const initialStatus = sendMode === "draft" ? "draft" : "queued";
    const now = nowIso();
    const ins = db.prepare(
      `INSERT INTO email_campaigns
         (name, template_id, subject, preview_text, html_body, cta_label, cta_url, attachment_url,
          filters_json, send_mode, scheduled_at, status, total_recipients, excluded_count, created_by, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      name,
      templateId,
      subject,
      previewText,
      htmlBody,
      ctaLabel,
      ctaUrl,
      attachmentUrl,
      JSON.stringify(filters),
      sendMode,
      scheduledAt,
      initialStatus,
      eligible.length,
      excludedCount,
      ctx.user.id,
      now,
      now
    );
    const campaignId = Number(ins.lastInsertRowid);
    const insDelivery = db.prepare(
      `INSERT OR IGNORE INTO email_deliveries (campaign_id, user_id, recipient_name, recipient_email, status, created_at)
       VALUES (?, ?, ?, ?, 'pending', ?)`
    );
    for (const r of eligible) {
      insDelivery.run(campaignId, r.id, r.full_name, r.email, now);
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: campaignId,
      targetName: name,
      action: "email_campaign_created",
      details: `${sendMode} \xB7 ${eligible.length} eligible (${excludedCount} excluded)`,
      ipAddress: clientIp(req)
    });
    if (sendMode === "immediate" && eligible.length > 0) {
      void processCampaignQueue(db, campaignId, 25);
    }
    res.status(201).json({ id: campaignId, eligibleCount: eligible.length, excludedCount });
  });
  router.post("/campaigns/:id/action", async (req, res) => {
    const cid = Number(req.params.id);
    const action = String(req.body?.action || "");
    const camp = db.prepare("SELECT * FROM email_campaigns WHERE id = ?").get(cid);
    if (!camp) {
      res.status(404).json({ error: "Campaign not found." });
      return;
    }
    if (action === "pause") {
      db.prepare("UPDATE email_campaigns SET status = 'paused', updated_at = ? WHERE id = ?").run(nowIso(), cid);
      res.json({ status: "paused" });
      return;
    }
    if (action === "cancel") {
      db.prepare("UPDATE email_campaigns SET status = 'cancelled', updated_at = ? WHERE id = ?").run(nowIso(), cid);
      res.json({ status: "cancelled" });
      return;
    }
    if (action === "resume" || action === "process_now") {
      db.prepare("UPDATE email_campaigns SET status = 'queued', updated_at = ? WHERE id = ?").run(nowIso(), cid);
      const result = await processCampaignQueue(db, cid, 30);
      res.json({ processed: true, ...result });
      return;
    }
    res.status(400).json({ error: "Unsupported campaign action." });
  });
  router.get("/campaigns/:id/deliveries", (req, res) => {
    const deliveries = db.prepare("SELECT * FROM email_deliveries WHERE campaign_id = ? ORDER BY id ASC LIMIT 500").all(Number(req.params.id));
    res.json({ deliveries });
  });
  router.post("/test-send", async (req, res) => {
    const to = normalizeEmail(req.body?.to);
    const subject = cleanText(req.body?.subject || "Yuitor Smart Classes Test Email", 200).replace(/[\r\n]+/g, " ");
    const previewText = cleanText(req.body?.previewText, 240);
    const htmlBody = String(req.body?.htmlBody || "<p>Test campaign preview from Yuitor Smart Classes.</p>");
    const ctaLabel = cleanText(req.body?.ctaLabel, 80);
    const ctaUrl = cleanText(req.body?.ctaUrl, 300);
    if (!isValidEmail(to)) {
      res.status(400).json({ error: "Enter a valid recipient email address for test delivery." });
      return;
    }
    const html = renderBrandedEmailHtml({
      subject,
      previewText,
      htmlBody,
      recipientName: "Yuitor Team",
      ctaLabel,
      ctaUrl
    });
    const result = await sendEmailDirect({ to, subject: `[TEST] ${subject}`, html });
    if (!result.ok) {
      res.status(503).json({ error: result.error });
      return;
    }
    res.json({ sent: true, messageId: result.messageId });
  });
  router.post("/suppressions", (req, res) => {
    const email = normalizeEmail(req.body?.email);
    const reason = cleanText(req.body?.reason || "unsubscribed", 60);
    if (!isValidEmail(email)) {
      res.status(400).json({ error: "Enter a valid email address." });
      return;
    }
    db.prepare("INSERT OR REPLACE INTO email_suppressions (email, reason, created_at) VALUES (?, ?, ?)").run(
      email,
      reason,
      nowIso()
    );
    db.prepare("UPDATE users SET marketing_opt_in = 0, updated_at = ? WHERE email = ?").run(nowIso(), email);
    res.status(201).json({ suppressed: true });
  });
  return router;
}

// server/routes/student.ts
import { Router as Router4 } from "express";
import crypto5 from "node:crypto";
function createStudentRouter(db) {
  const router = Router4();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Student sign-in required." });
      return;
    }
    if (ctx.user.role !== "student") {
      res.status(403).json({ error: "Student portal access only." });
      return;
    }
    if (ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Your account is awaiting Yuitor Team approval." });
      return;
    }
    req.ctx = ctx;
    next();
  });
  router.get("/dashboard", (req, res) => {
    const ctx = req.ctx;
    const uid = ctx.user.id;
    const today = nowIso().slice(0, 10);
    const profile = db.prepare("SELECT * FROM student_profiles WHERE user_id = ?").get(uid) || {
      class_level: "Class 10",
      board: "CBSE",
      course_duration_months: 12,
      admission_date: null,
      enrollment_status: "active"
    };
    const rawEnrollments = db.prepare(
      `SELECT e.*, c.title, c.category, c.board
         FROM enrollments e
         JOIN courses c ON c.id = e.course_id
         WHERE e.student_id = ?
         ORDER BY e.id DESC`
    ).all(uid);
    const enrollments = rawEnrollments.map((e) => ({
      ...e,
      is_expired: Boolean(e.expires_at && e.expires_at < today)
    }));
    const enrolledCourseIds = enrollments.filter((e) => ["active", "completed"].includes(e.status) && !e.is_expired).map((e) => Number(e.course_id));
    let upcomingClasses = [];
    let assignments = [];
    let quizzes = [];
    if (enrolledCourseIds.length > 0) {
      const ph = enrolledCourseIds.map(() => "?").join(",");
      upcomingClasses = db.prepare(
        `SELECT cs.*, c.title as course_title
           FROM class_schedules cs
           JOIN courses c ON c.id = cs.course_id
           WHERE cs.course_id IN (${ph}) AND cs.scheduled_date >= ?
           ORDER BY cs.scheduled_date ASC, cs.start_time ASC LIMIT 20`
      ).all(...enrolledCourseIds, today);
      assignments = db.prepare(
        `SELECT a.*, c.title as course_title,
                  sub.status as submission_status, sub.marks_obtained, sub.feedback
           FROM assignments a
           JOIN courses c ON c.id = a.course_id
           LEFT JOIN assignment_submissions sub ON sub.assignment_id = a.id AND sub.student_id = ?
           WHERE a.course_id IN (${ph})
           ORDER BY a.due_date ASC, a.id DESC`
      ).all(uid, ...enrolledCourseIds);
      quizzes = db.prepare(
        `SELECT q.*, c.title as course_title,
                  (SELECT qa.score FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ? ORDER BY qa.id DESC LIMIT 1) as score
           FROM quizzes q
           JOIN courses c ON c.id = q.course_id
           WHERE q.course_id IN (${ph})
           ORDER BY q.id DESC`
      ).all(uid, ...enrolledCourseIds);
    }
    const announcements = db.prepare(
      `SELECT * FROM announcements
         WHERE audience IN ('all', 'students')
         ORDER BY id DESC LIMIT 15`
    ).all();
    const feeRecords = db.prepare(
      `SELECT f.*, COALESCE(c.title, f.title) as course_title,
                COALESCE(
                  (SELECT p.invoice_number FROM payments p WHERE p.student_id = f.student_id AND p.course_id = f.course_id ORDER BY p.id DESC LIMIT 1),
                  'YTR-FEE-' || f.id
                ) as invoice_number
         FROM fee_records f
         LEFT JOIN courses c ON c.id = f.course_id
         WHERE f.student_id = ?
         ORDER BY f.id DESC`
    ).all(uid);
    const payments = db.prepare(
      `SELECT p.*, c.title as course_title
         FROM payments p
         JOIN courses c ON c.id = p.course_id
         WHERE p.student_id = ?
         ORDER BY p.id DESC`
    ).all(uid);
    const attendance = db.prepare(
      `SELECT a.*, c.title as course_title
         FROM attendance a
         JOIN courses c ON c.id = a.course_id
         WHERE a.student_id = ?
         ORDER BY a.att_date DESC, a.id DESC LIMIT 60`
    ).all(uid);
    const notifications = db.prepare(
      `SELECT * FROM notifications
         WHERE user_id = ? OR role_target IN ('student', 'all')
         ORDER BY id DESC LIMIT 20`
    ).all(uid);
    const supportMessages = db.prepare("SELECT * FROM support_messages WHERE user_id = ? ORDER BY id DESC LIMIT 20").all(uid);
    res.json({
      profile,
      enrollments,
      upcomingClasses,
      announcements,
      feeRecords,
      payments,
      assignments,
      quizzes,
      attendance,
      notifications,
      supportMessages
    });
  });
  router.get("/courses/:courseId/lessons", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.params.courseId);
    const today = nowIso().slice(0, 10);
    const enrollment = db.prepare("SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?").get(ctx.user.id, courseId);
    if (!enrollment || !["active", "completed"].includes(enrollment.status)) {
      res.status(403).json({ error: "Active course enrollment is required to access lessons." });
      return;
    }
    if (enrollment.expires_at && enrollment.expires_at < today) {
      res.status(403).json({ error: "This course enrollment has expired. Contact Yuitor Team to renew." });
      return;
    }
    const lessons = db.prepare(
      `SELECT l.*, CASE WHEN lp.completed_at IS NOT NULL THEN 1 ELSE 0 END as completed
         FROM lessons l
         LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.student_id = ?
         WHERE l.course_id = ? AND l.is_visible = 1
         ORDER BY l.sort_order ASC, l.id ASC`
    ).all(ctx.user.id, courseId);
    res.json({ enrollment, lessons });
  });
  router.post("/lessons/:lessonId/complete", (req, res) => {
    const ctx = req.ctx;
    const lessonId = Number(req.params.lessonId);
    const mins = Math.min(240, Math.max(1, Number(req.body?.timeSpentMinutes || 20)));
    const lesson = db.prepare("SELECT * FROM lessons WHERE id = ? AND is_visible = 1").get(lessonId);
    if (!lesson) {
      res.status(404).json({ error: "Lesson not found." });
      return;
    }
    const enrollment = db.prepare("SELECT * FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')").get(ctx.user.id, lesson.course_id);
    if (!enrollment) {
      res.status(403).json({ error: "Not enrolled in this course." });
      return;
    }
    const now = nowIso();
    db.prepare(
      `INSERT OR IGNORE INTO lesson_progress (student_id, lesson_id, completed_at, time_spent_minutes)
       VALUES (?, ?, ?, ?)`
    ).run(ctx.user.id, lessonId, now, mins);
    const totalVisible = db.prepare("SELECT COUNT(*) as c FROM lessons WHERE course_id = ? AND is_visible = 1").get(lesson.course_id).c;
    const completedCount = db.prepare(
      `SELECT COUNT(*) as c FROM lesson_progress lp
           JOIN lessons l ON l.id = lp.lesson_id
           WHERE lp.student_id = ? AND l.course_id = ? AND l.is_visible = 1`
    ).get(ctx.user.id, lesson.course_id).c;
    const progress = totalVisible > 0 ? Math.min(100, Math.round(completedCount / totalVisible * 100)) : 100;
    const certCode = progress === 100 ? enrollment.certificate_code || `YTR-CERT-${ctx.user.id}-${lesson.course_id}-${crypto5.randomBytes(2).toString("hex").toUpperCase()}` : enrollment.certificate_code || "";
    const nextStatus = progress === 100 ? "completed" : enrollment.status;
    db.prepare(
      `UPDATE enrollments
       SET progress_percent = ?, learning_minutes = learning_minutes + ?, status = ?, certificate_code = ?
       WHERE id = ?`
    ).run(progress, mins, nextStatus, certCode, enrollment.id);
    res.json({ completed: true, progressPercent: progress, certificateCode: certCode });
  });
  router.post("/assignments/:assignmentId/submit", (req, res) => {
    const ctx = req.ctx;
    const aid = Number(req.params.assignmentId);
    const assignment = db.prepare("SELECT * FROM assignments WHERE id = ?").get(aid);
    if (!assignment) {
      res.status(404).json({ error: "Assignment not found." });
      return;
    }
    const enrolled = db.prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')").get(ctx.user.id, assignment.course_id);
    if (!enrolled) {
      res.status(403).json({ error: "You are not enrolled in this course." });
      return;
    }
    const submissionText = cleanText(req.body?.submissionText, 4e3);
    const fileUrl = cleanText(req.body?.fileUrl, 300);
    if (!submissionText && !fileUrl) {
      res.status(400).json({ error: "Enter answer text or upload a file." });
      return;
    }
    db.prepare(
      `INSERT INTO assignment_submissions (assignment_id, student_id, submission_text, file_url, status, submitted_at)
       VALUES (?, ?, ?, ?, 'submitted', ?)
       ON CONFLICT(assignment_id, student_id) DO UPDATE SET
         submission_text = excluded.submission_text,
         file_url = CASE WHEN excluded.file_url != '' THEN excluded.file_url ELSE assignment_submissions.file_url END,
         status = 'submitted',
         submitted_at = excluded.submitted_at`
    ).run(aid, ctx.user.id, submissionText, fileUrl, nowIso());
    res.status(201).json({ submitted: true });
  });
  router.post("/quizzes/:quizId/attempt", (req, res) => {
    const ctx = req.ctx;
    const qid = Number(req.params.quizId);
    const quiz = db.prepare("SELECT * FROM quizzes WHERE id = ?").get(qid);
    if (!quiz) {
      res.status(404).json({ error: "Quiz not found." });
      return;
    }
    const enrolled = db.prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')").get(ctx.user.id, quiz.course_id);
    if (!enrolled) {
      res.status(403).json({ error: "You are not enrolled in this course." });
      return;
    }
    let questions = [];
    try {
      questions = JSON.parse(quiz.questions_json || "[]");
    } catch {
      questions = [];
    }
    const answers = Array.isArray(req.body?.answers) ? req.body.answers.map(Number) : [];
    let correct = 0;
    questions.forEach((q, idx) => {
      if (answers[idx] === Number(q.correctIndex)) correct++;
    });
    const maxMarks = Number(quiz.max_marks || 10);
    const score = questions.length > 0 ? Math.round(correct / questions.length * maxMarks) : 0;
    db.prepare(
      "INSERT INTO quiz_attempts (quiz_id, student_id, answers_json, score, max_marks, attempted_at) VALUES (?, ?, ?, ?, ?, ?)"
    ).run(qid, ctx.user.id, JSON.stringify(answers), score, maxMarks, nowIso());
    res.json({ score, maxMarks });
  });
  router.post("/reviews", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    const rating = Math.min(5, Math.max(1, Number(req.body?.rating || 5)));
    const comment = cleanText(req.body?.comment, 1e3);
    if (!courseId || comment.length < 3) {
      res.status(400).json({ error: "Select a course and write a short review." });
      return;
    }
    db.prepare(
      `INSERT INTO course_reviews (student_id, course_id, rating, comment, created_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(student_id, course_id) DO UPDATE SET rating = excluded.rating, comment = excluded.comment`
    ).run(ctx.user.id, courseId, rating, comment, nowIso());
    res.status(201).json({ saved: true });
  });
  router.post("/support", (req, res) => {
    const ctx = req.ctx;
    const subject = cleanText(req.body?.subject, 180);
    const body = cleanText(req.body?.body, 2e3);
    if (subject.length < 2 || body.length < 5) {
      res.status(400).json({ error: "Enter subject and message." });
      return;
    }
    const now = nowIso();
    db.prepare("INSERT INTO support_messages (user_id, subject, body, status, created_at) VALUES (?, ?, ?, 'open', ?)").run(
      ctx.user.id,
      subject,
      body,
      now
    );
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(`Student Support: ${subject}`, `${ctx.user.full_name} sent a support message.`, now);
    res.status(201).json({ sent: true });
  });
  router.post("/notifications/read-all", (req, res) => {
    const ctx = req.ctx;
    db.prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?").run(ctx.user.id);
    res.json({ updated: true });
  });
  return router;
}

// server/routes/teacher.ts
import { Router as Router5 } from "express";
function createTeacherRouter(db) {
  const router = Router5();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Teacher sign-in required." });
      return;
    }
    if (ctx.user.role !== "teacher") {
      res.status(403).json({ error: "Teacher portal access only." });
      return;
    }
    if (ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Your teacher account is pending Yuitor Team approval." });
      return;
    }
    req.ctx = ctx;
    next();
  });
  function ownsCourse(teacherId, courseId) {
    const row = db.prepare("SELECT id FROM courses WHERE id = ? AND teacher_id = ?").get(courseId, teacherId);
    return Boolean(row);
  }
  router.get("/dashboard", (req, res) => {
    const ctx = req.ctx;
    const tid = ctx.user.id;
    const profile = db.prepare("SELECT * FROM teacher_profiles WHERE user_id = ?").get(tid) || {
      qualification: "",
      experience_years: 0,
      availability_status: "available",
      vacation_note: "",
      monthly_payout_rate: 0,
      payout_upi: ""
    };
    const courses = db.prepare("SELECT * FROM courses WHERE teacher_id = ? ORDER BY id ASC").all(tid);
    const courseIds = courses.map((c) => Number(c.id));
    let students = [];
    let schedules = [];
    let assignments = [];
    if (courseIds.length > 0) {
      const ph = courseIds.map(() => "?").join(",");
      students = db.prepare(
        `SELECT u.id, u.full_name, u.phone, u.email, e.course_id, c.title as course_title, e.progress_percent
           FROM enrollments e
           JOIN users u ON u.id = e.student_id
           JOIN courses c ON c.id = e.course_id
           WHERE e.course_id IN (${ph}) AND e.status IN ('active', 'completed')
           ORDER BY c.title ASC, u.full_name ASC`
      ).all(...courseIds);
      schedules = db.prepare(
        `SELECT cs.*, c.title as course_title
           FROM class_schedules cs
           JOIN courses c ON c.id = cs.course_id
           WHERE cs.course_id IN (${ph})
           ORDER BY cs.scheduled_date DESC LIMIT 30`
      ).all(...courseIds);
      assignments = db.prepare(
        `SELECT a.*, c.title as course_title,
                  (SELECT COUNT(*) FROM assignment_submissions s WHERE s.assignment_id = a.id) as submissions_count
           FROM assignments a
           JOIN courses c ON c.id = a.course_id
           WHERE a.course_id IN (${ph})
           ORDER BY a.id DESC`
      ).all(...courseIds);
    }
    const notifications = db.prepare("SELECT * FROM notifications WHERE user_id = ? OR role_target IN ('teacher', 'all') ORDER BY id DESC LIMIT 20").all(tid);
    res.json({
      profile,
      courses,
      students,
      schedules,
      assignments,
      notifications,
      earningsSummary: {
        monthlyPayoutRate: Number(profile.monthly_payout_rate || 0),
        activeStudentsCount: students.length,
        payoutUpi: profile.payout_upi || "",
        limitationNote: Number(profile.monthly_payout_rate || 0) === 0 ? "Faculty payout schedules are finalized directly by the Yuitor Finance Team." : ""
      }
    });
  });
  router.patch("/profile", (req, res) => {
    const ctx = req.ctx;
    const tid = ctx.user.id;
    const fullName = cleanText(req.body?.fullName || ctx.user.full_name, 120);
    const qualification = cleanText(req.body?.qualification, 120);
    const availabilityStatus = req.body?.availabilityStatus === "vacation" ? "vacation" : "available";
    const vacationNote = cleanText(req.body?.vacationNote, 300);
    const payoutUpi = cleanText(req.body?.payoutUpi, 100);
    db.prepare("UPDATE users SET full_name = ?, updated_at = ? WHERE id = ?").run(fullName, nowIso(), tid);
    db.prepare(
      `INSERT INTO teacher_profiles (user_id, qualification, availability_status, vacation_note, payout_upi)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET
         qualification = excluded.qualification,
         availability_status = excluded.availability_status,
         vacation_note = excluded.vacation_note,
         payout_upi = excluded.payout_upi`
    ).run(tid, qualification, availabilityStatus, vacationNote, payoutUpi);
    res.json({ updated: true });
  });
  router.post("/announcements", (req, res) => {
    const ctx = req.ctx;
    const courseId = req.body?.courseId ? Number(req.body.courseId) : null;
    if (courseId && !ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "You can only post announcements to your assigned courses." });
      return;
    }
    db.prepare(
      "INSERT INTO announcements (title, body, audience, course_id, created_by, created_at) VALUES (?, ?, 'students', ?, ?, ?)"
    ).run(cleanText(req.body?.title, 180), cleanText(req.body?.body, 2e3), courseId, ctx.user.id, nowIso());
    res.status(201).json({ created: true });
  });
  router.patch("/courses/:courseId", (req, res) => {
    const ctx = req.ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const existing = db.prepare("SELECT * FROM courses WHERE id = ?").get(cid);
    db.prepare("UPDATE courses SET description = ?, duration_months = ?, thumbnail_url = ? WHERE id = ?").run(
      cleanText(req.body?.description ?? existing.description, 1e3),
      Math.min(60, Math.max(1, Number(req.body?.durationMonths ?? existing.duration_months))),
      cleanText(req.body?.thumbnailUrl || existing.thumbnail_url, 300),
      cid
    );
    res.json({ updated: true });
  });
  router.get("/courses/:courseId/lessons", (req, res) => {
    const ctx = req.ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const lessons = db.prepare("SELECT * FROM lessons WHERE course_id = ? ORDER BY sort_order ASC, id ASC").all(cid);
    res.json({ lessons });
  });
  router.post("/courses/:courseId/lessons", (req, res) => {
    const ctx = req.ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const title = cleanText(req.body?.title, 200);
    if (title.length < 2) {
      res.status(400).json({ error: "Lesson title is required." });
      return;
    }
    const maxSort = db.prepare("SELECT COALESCE(MAX(sort_order), 0) as m FROM lessons WHERE course_id = ?").get(cid).m;
    const lessonType = ["text", "video", "pdf"].includes(req.body?.lessonType) ? req.body.lessonType : "text";
    db.prepare(
      `INSERT INTO lessons (course_id, title, lesson_type, material_url, content, duration_minutes, sort_order, is_visible, created_at)
       VALUES (?, ?, ?, ?, ?, 30, ?, 1, ?)`
    ).run(
      cid,
      title,
      lessonType,
      cleanText(req.body?.materialUrl, 400),
      cleanText(req.body?.content, 5e3),
      maxSort + 1,
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.post("/courses/:courseId/lessons/reorder", (req, res) => {
    const ctx = req.ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const orderedIds = Array.isArray(req.body?.orderedIds) ? req.body.orderedIds.map(Number) : [];
    const upd = db.prepare("UPDATE lessons SET sort_order = ? WHERE id = ? AND course_id = ?");
    orderedIds.forEach((id, idx) => {
      upd.run(idx + 1, id, cid);
    });
    res.json({ reordered: true });
  });
  router.patch("/lessons/:lessonId", (req, res) => {
    const ctx = req.ctx;
    const lid = Number(req.params.lessonId);
    const lesson = db.prepare("SELECT l.*, c.teacher_id FROM lessons l JOIN courses c ON c.id = l.course_id WHERE l.id = ?").get(lid);
    if (!lesson || Number(lesson.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Lesson not found or unauthorized." });
      return;
    }
    const title = req.body?.title !== void 0 ? cleanText(req.body.title, 200) : lesson.title;
    const lessonType = ["text", "video", "pdf"].includes(req.body?.lessonType) ? req.body.lessonType : lesson.lesson_type;
    const materialUrl = req.body?.materialUrl !== void 0 ? cleanText(req.body.materialUrl, 400) : lesson.material_url;
    const content = req.body?.content !== void 0 ? cleanText(req.body.content, 5e3) : lesson.content;
    const isVisible = req.body?.isVisible !== void 0 ? req.body.isVisible ? 1 : 0 : lesson.is_visible;
    db.prepare("UPDATE lessons SET title = ?, lesson_type = ?, material_url = ?, content = ?, is_visible = ? WHERE id = ?").run(
      title,
      lessonType,
      materialUrl,
      content,
      isVisible,
      lid
    );
    res.json({ updated: true });
  });
  router.delete("/lessons/:lessonId", (req, res) => {
    const ctx = req.ctx;
    const lid = Number(req.params.lessonId);
    const lesson = db.prepare("SELECT l.id, c.teacher_id FROM lessons l JOIN courses c ON c.id = l.course_id WHERE l.id = ?").get(lid);
    if (!lesson || Number(lesson.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Unauthorized." });
      return;
    }
    db.prepare("DELETE FROM lessons WHERE id = ?").run(lid);
    res.json({ deleted: true });
  });
  router.post("/attendance", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    const attDate = cleanText(req.body?.attDate || nowIso().slice(0, 10), 10);
    const records = Array.isArray(req.body?.records) ? req.body.records : [];
    const stmt = db.prepare(
      `INSERT INTO attendance (course_id, student_id, teacher_id, att_date, status, remarks, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(course_id, student_id, att_date) DO UPDATE SET status = excluded.status, remarks = excluded.remarks`
    );
    for (const r of records) {
      const st = ["present", "absent", "late"].includes(r.status) ? r.status : "present";
      stmt.run(courseId, Number(r.studentId), ctx.user.id, attDate, st, cleanText(r.remarks || "", 200), nowIso());
    }
    res.json({ saved: true });
  });
  router.post("/schedules", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    db.prepare(
      `INSERT INTO class_schedules (course_id, teacher_id, title, scheduled_date, start_time, end_time, mode, meeting_link, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      courseId,
      ctx.user.id,
      cleanText(req.body?.title, 180),
      cleanText(req.body?.scheduledDate, 10),
      cleanText(req.body?.startTime, 10),
      cleanText(req.body?.endTime, 10),
      req.body?.mode === "online" ? "online" : "offline",
      cleanText(req.body?.meetingLink, 300),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.post("/assignments", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    db.prepare(
      "INSERT INTO assignments (course_id, teacher_id, title, description, due_date, max_marks, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run(
      courseId,
      ctx.user.id,
      cleanText(req.body?.title, 180),
      cleanText(req.body?.description, 2e3),
      cleanText(req.body?.dueDate, 10),
      Math.max(1, Number(req.body?.maxMarks || 50)),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.get("/assignments/:assignmentId/submissions", (req, res) => {
    const ctx = req.ctx;
    const aid = Number(req.params.assignmentId);
    const assign = db.prepare("SELECT a.*, c.teacher_id FROM assignments a JOIN courses c ON c.id = a.course_id WHERE a.id = ?").get(aid);
    if (!assign || Number(assign.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Unauthorized." });
      return;
    }
    const submissions = db.prepare(
      `SELECT s.*, u.full_name as student_name
         FROM assignment_submissions s
         JOIN users u ON u.id = s.student_id
         WHERE s.assignment_id = ?
         ORDER BY s.submitted_at DESC`
    ).all(aid);
    res.json({ submissions });
  });
  router.post("/submissions/:submissionId/grade", (req, res) => {
    const ctx = req.ctx;
    const sid = Number(req.params.submissionId);
    const sub = db.prepare(
      `SELECT s.id, c.teacher_id
         FROM assignment_submissions s
         JOIN assignments a ON a.id = s.assignment_id
         JOIN courses c ON c.id = a.course_id
         WHERE s.id = ?`
    ).get(sid);
    if (!sub || Number(sub.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Unauthorized." });
      return;
    }
    db.prepare("UPDATE assignment_submissions SET marks_obtained = ?, feedback = ?, status = 'graded', graded_at = ? WHERE id = ?").run(
      Number(req.body?.marksObtained || 0),
      cleanText(req.body?.feedback, 500),
      nowIso(),
      sid
    );
    res.json({ graded: true });
  });
  router.post("/quizzes", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    const questions = Array.isArray(req.body?.questions) ? req.body.questions : [];
    db.prepare(
      "INSERT INTO quizzes (course_id, teacher_id, title, max_marks, duration_minutes, questions_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run(
      courseId,
      ctx.user.id,
      cleanText(req.body?.title, 180),
      Math.max(1, Number(req.body?.maxMarks || 10)),
      Math.max(1, Number(req.body?.durationMinutes || 15)),
      JSON.stringify(questions),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  return router;
}

// server/routes/payments.ts
import { Router as Router6 } from "express";
import crypto6 from "node:crypto";
function createPaymentsRouter(db) {
  const router = Router6();
  router.post("/enroll", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student" || ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Approved Student sign-in is required to enroll." });
      return;
    }
    const courseId = Number(req.body?.courseId);
    const plan = req.body?.plan === "yearly" ? "yearly" : "monthly";
    const paymentMethod = ["upi", "cash", "gateway"].includes(req.body?.paymentMethod) ? req.body.paymentMethod : "upi";
    const utrReference = cleanText(req.body?.utrReference, 80);
    const couponCode = cleanText(req.body?.couponCode, 30).toUpperCase();
    const course = db.prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1").get(courseId);
    if (!course) {
      res.status(404).json({ error: "Selected course not found." });
      return;
    }
    const baseAmount = plan === "yearly" ? Number(course.yearly_fee) : Number(course.monthly_fee);
    let discountAmount = 0;
    if (couponCode) {
      const coupon = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(couponCode);
      if (!coupon || Number(coupon.used_count) >= Number(coupon.max_uses)) {
        res.status(400).json({ error: "Invalid or expired coupon code." });
        return;
      }
      discountAmount = coupon.discount_type === "percent" ? Math.round(baseAmount * Number(coupon.discount_value) / 100) : Math.min(baseAmount, Number(coupon.discount_value));
      db.prepare("UPDATE coupons SET used_count = used_count + 1 WHERE id = ?").run(coupon.id);
    }
    const finalAmount = Math.max(0, baseAmount - discountAmount);
    const now = nowIso();
    const months = plan === "yearly" ? 12 : 1;
    const expiresDate = /* @__PURE__ */ new Date();
    expiresDate.setMonth(expiresDate.getMonth() + months);
    const expiresAt = expiresDate.toISOString().slice(0, 10);
    let verificationStatus = "pending_verification";
    let receiptNumber = "";
    let paidAt = null;
    let enrollmentStatus = "pending";
    let message = "";
    if (paymentMethod === "gateway") {
      const rzpSecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
      const gOrder = cleanText(req.body?.gatewayOrderId, 100);
      const gPay = cleanText(req.body?.gatewayPaymentId, 100);
      const gSig = cleanText(req.body?.gatewaySignature, 200);
      if (rzpSecret && gOrder && gPay && gSig) {
        const expectedSig = crypto6.createHmac("sha256", rzpSecret).update(`${gOrder}|${gPay}`).digest("hex");
        const a = Buffer.from(gSig);
        const b = Buffer.from(expectedSig);
        if (a.length === b.length && crypto6.timingSafeEqual(a, b)) {
          verificationStatus = "verified";
          enrollmentStatus = "active";
          paidAt = now;
          receiptNumber = `YTR-RCP-${Date.now().toString().slice(-6)}`;
          message = "Gateway signature verified! Your enrollment and fee receipt are now active.";
        } else {
          res.status(400).json({ error: "Payment gateway signature verification failed." });
          return;
        }
      } else {
        message = "Online payment gateway credentials (RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET) are not configured on this server. Enrollment saved as Pending Verification \u2014 submit UTR or pay at the Muradnagar desk.";
      }
    } else {
      message = "Enrollment submitted! Your payment is marked Pending Verification until confirmed by the Yuitor Team.";
    }
    db.prepare(
      `INSERT INTO enrollments (student_id, course_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
       VALUES (?, ?, ?, ?, 0, 0, ?, ?)
       ON CONFLICT(student_id, course_id) DO UPDATE SET plan = excluded.plan, status = excluded.status, expires_at = excluded.expires_at`
    ).run(ctx.user.id, courseId, plan, enrollmentStatus, expiresAt, now);
    const enrollment = db.prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?").get(ctx.user.id, courseId);
    const invoiceNumber = `YTR-INV-${Date.now().toString().slice(-6)}`;
    db.prepare(
      `INSERT INTO payments
       (student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount, coupon_code, payment_method,
        utr_reference, verification_status, invoice_number, receipt_number, paid_at, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      ctx.user.id,
      courseId,
      enrollment.id,
      plan,
      baseAmount,
      discountAmount,
      finalAmount,
      couponCode,
      paymentMethod,
      utrReference,
      verificationStatus,
      invoiceNumber,
      receiptNumber,
      paidAt,
      now
    );
    db.prepare(
      `INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      ctx.user.id,
      courseId,
      `${course.title} (${plan})`,
      baseAmount,
      discountAmount,
      verificationStatus === "verified" ? finalAmount : 0,
      now.slice(0, 10),
      verificationStatus === "verified" ? "paid" : "pending",
      now
    );
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `New Enrollment Payment (${paymentMethod.toUpperCase()})`,
      `${ctx.user.full_name} enrolled in ${course.title} (\u20B9${finalAmount}, ${verificationStatus}).`,
      now
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: courseId,
      targetName: course.title,
      action: "enrollment_submitted",
      details: `${plan} \u20B9${finalAmount} (${verificationStatus})`,
      ipAddress: clientIp(req)
    });
    res.status(201).json({
      enrolled: true,
      verificationStatus,
      invoiceNumber,
      receiptNumber,
      amount: finalAmount,
      message
    });
  });
  router.post("/refund-request", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student") {
      res.status(403).json({ error: "Student sign-in required." });
      return;
    }
    const paymentId = Number(req.body?.paymentId);
    const reason = cleanText(req.body?.reason, 500);
    if (reason.length < 5) {
      res.status(400).json({ error: "Provide a refund reason (min 5 characters)." });
      return;
    }
    const pay = db.prepare("SELECT * FROM payments WHERE id = ? AND student_id = ?").get(paymentId, ctx.user.id);
    if (!pay || pay.verification_status !== "verified") {
      res.status(404).json({ error: "Verified payment record not found." });
      return;
    }
    db.prepare("UPDATE payments SET refund_status = 'requested', refund_reason = ? WHERE id = ?").run(reason, paymentId);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run("Refund Request", `${ctx.user.full_name} requested refund for payment #${paymentId}: ${reason}`, nowIso());
    res.json({ requested: true });
  });
  return router;
}

// server/routes/public.ts
import { Router as Router7 } from "express";
import crypto7 from "node:crypto";
import fs4 from "node:fs";
import path4 from "node:path";
import multer from "multer";

// server/chatbot.ts
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
var SHREYA_INTRO = "Hello! My name is Shreya, and I am Yuitor Smart Classes\u2019 Smart AI Assistant. How can I help you?";
function redactSensitiveText(text) {
  return text.replace(/\b(password|passwd|pwd)\s*(?:is|was|:|=)\s*\S+/gi, "$1: [REDACTED]").replace(/\b(otp|code|pin)\s*(?:is|was|:|=)?\s*\d{4,8}\b/gi, "$1 [REDACTED]");
}
function buildKnowledgeContext(db) {
  const courses = db.prepare("SELECT title, category, class_range, board, duration_months, monthly_fee, yearly_fee FROM courses WHERE is_active = 1 ORDER BY id").all();
  const subjects = db.prepare("SELECT name, class_level FROM subjects WHERE is_active = 1 ORDER BY id").all();
  const faqs = db.prepare("SELECT question, answer FROM faqs WHERE is_active = 1 ORDER BY sort_order").all();
  const courseLines = courses.map(
    (c) => `- ${c.title} (${c.category}, ${c.class_range}, ${c.board}, ${c.duration_months} months): \u20B9${c.monthly_fee}/month or \u20B9${c.yearly_fee}/year`
  ).join("\n");
  const subjectLines = subjects.map((s) => `- ${s.name} (${s.class_level})`).join("\n");
  const faqLines = faqs.map((f) => `Q: ${f.question} | A: ${f.answer}`).join("\n");
  return `OFFICIAL YUITOR SMART CLASSES DATA (Source of truth \u2014 NEVER invent fees, discounts, or policies):
- Brand: Yuitor Smart Classes
- Address: Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh, India
- Call / WhatsApp: +91 78-2728-9292 | Branch: +91 1232314337
- Admission Email: admission@yuitor.com | Inquiry Email: inquiry@yuitor.com
- Website: https://yuitor.com (Admission form: /admission, Fee calculator: /fee-calculator, Register: /register, Login: /login)
- Registration & Approval Flow: Students & Teachers register online -> verify 6-digit mobile OTP -> account enters Pending Yuitor Team Approval -> Admin approves account for portal access.
- Fee & Refund Policy: 100% fee refund within 7 days subject to published admission terms (/refund). Never promise unpublished discounts.

COURSES & FEES:
${courseLines}

SUBJECTS:
${subjectLines}

FAQs:
${faqLines}`;
}
function safeEvalArithmetic(exprRaw) {
  const cleaned = exprRaw.replace(/×/g, "*").replace(/÷/g, "/").replace(/\^/g, "**").replace(/[^0-9+\-*/().%\s*]/g, "").trim();
  if (!cleaned || !/\d/.test(cleaned) || !/[+\-*/%]/.test(cleaned)) return null;
  if (cleaned.length > 64) return null;
  try {
    const val = Function(`"use strict"; return (${cleaned});`)();
    return typeof val === "number" && Number.isFinite(val) ? Number(val.toFixed(6)) : null;
  } catch {
    return null;
  }
}
function tryDynamicAcademicSolver(userMsg, isHindi) {
  const q = userMsg.trim();
  const ql = q.toLowerCase();
  const pctMatch = ql.match(/(\d+(?:\.\d+)?)\s*(?:%|percent)\s*(?:of|ka|on)\s*(\d+(?:\.\d+)?)/i);
  if (pctMatch) {
    const p = Number(pctMatch[1]);
    const base = Number(pctMatch[2]);
    const ans = Number((p / 100 * base).toFixed(4));
    return isHindi ? `${base} ka ${p}% = ${ans} hota hai.` : `${p}% of ${base} = ${ans}.`;
  }
  const tableMatch = ql.match(/(?:table\s+of|pahada\s+of|(\d+)\s+ka\s+pahada)\s*(\d+)?/i);
  if (tableMatch) {
    const n = Number(tableMatch[1] || tableMatch[2]);
    if (Number.isFinite(n) && n >= 1 && n <= 1e3) {
      const rows = Array.from({ length: 10 }, (_, i) => `${n}\xD7${i + 1}=${n * (i + 1)}`).join(", ");
      return `Table of ${n}: ${rows}.`;
    }
  }
  const sqrtMatch = ql.match(/(?:square\s*root|sqrt|vargmul)\s*(?:of|ka)?\s*(\d+(?:\.\d+)?)/i);
  if (sqrtMatch) {
    const n = Number(sqrtMatch[1]);
    if (n >= 0) {
      return `\u221A${n} = ${Number(Math.sqrt(n).toFixed(6))}.`;
    }
  }
  const sqMatch = ql.match(/(?:square|varg)\s*(?:of|ka)?\s*(\d+(?:\.\d+)?)/i);
  if (sqMatch) {
    const n = Number(sqMatch[1]);
    return `${n}\xB2 = ${Number((n * n).toFixed(6))}.`;
  }
  const cubeMatch = ql.match(/(?:cube|ghan)\s*(?:of|ka)?\s*(\d+(?:\.\d+)?)/i);
  if (cubeMatch) {
    const n = Number(cubeMatch[1]);
    return `${n}\xB3 = ${Number((n * n * n).toFixed(6))}.`;
  }
  const cToF = ql.match(/(-?\d+(?:\.\d+)?)\s*(?:c|celsius)\s*(?:to|in)\s*(?:f|fahrenheit)/i);
  if (cToF) {
    const c = Number(cToF[1]);
    return `${c}\xB0C = ${Number((c * 9 / 5 + 32).toFixed(2))}\xB0F.`;
  }
  const fToC = ql.match(/(-?\d+(?:\.\d+)?)\s*(?:f|fahrenheit)\s*(?:to|in)\s*(?:c|celsius)/i);
  if (fToC) {
    const f = Number(fToC[1]);
    return `${f}\xB0F = ${Number(((f - 32) * 5 / 9).toFixed(2))}\xB0C.`;
  }
  const kmhToMs = ql.match(/(\d+(?:\.\d+)?)\s*km\/?h\s*(?:to|in)\s*m\/?s/i);
  if (kmhToMs) {
    const v = Number(kmhToMs[1]);
    return `${v} km/h = ${Number((v * 5 / 18).toFixed(3))} m/s.`;
  }
  const siMatch = ql.match(/(?:si|simple interest)\s*(?:of|on)?\s*(\d+(?:\.\d+)?)\s*(?:at|rate)?\s*(\d+(?:\.\d+)?)%?\s*(?:for|time)?\s*(\d+(?:\.\d+)?)/i);
  if (siMatch) {
    const p = Number(siMatch[1]);
    const r = Number(siMatch[2]);
    const t = Number(siMatch[3]);
    const si = Number((p * r * t / 100).toFixed(2));
    return `Simple Interest = (P\xD7R\xD7T)/100 = \u20B9${si} (Total Amount: \u20B9${Number((p + si).toFixed(2))}).`;
  }
  const arithCandidate = ql.replace(/^(?:what is|calculate|solve|eval|evaluate|kitna hota hai|batao)\s+/i, "").replace(/\?+$/, "").trim();
  if (/^[\d\s+\-*/().^×÷]+$/.test(arithCandidate) && /[+\-*/^×÷]/.test(arithCandidate)) {
    const res = safeEvalArithmetic(arithCandidate);
    if (res !== null) {
      return `${arithCandidate} = ${res}`;
    }
  }
  return null;
}
var ACADEMIC_CONCEPTS = [
  {
    keys: /\b(newton|laws of motion|f=ma|force formula)\b/i,
    answer: "Newton's Laws: (1) Inertia \u2014 object stays at rest/motion unless external force acts; (2) F = m \xD7 a (Force = mass \xD7 acceleration, SI unit: Newton); (3) Every action has an equal and opposite reaction."
  },
  {
    keys: /\b(ohm'?s law|v=ir|resistance formula)\b/i,
    answer: "Ohm's Law states V = I \xD7 R (at constant temperature, current I is directly proportional to voltage V). SI units: Voltage (Volt), Current (Ampere), Resistance (Ohm \u03A9)."
  },
  {
    keys: /\b(pythagoras|hypotenuse)\b/i,
    answer: "Pythagoras Theorem (right triangle): Hypotenuse\xB2 = Base\xB2 + Perpendicular\xB2 (c\xB2 = a\xB2 + b\xB2)."
  },
  {
    keys: /\b(quadratic|sridharacharya|discriminant)\b/i,
    answer: "Quadratic Formula for ax\xB2 + bx + c = 0: x = [-b \xB1 \u221A(b\xB2 - 4ac)] / (2a), where Discriminant D = b\xB2 - 4ac determines real/equal/complex roots."
  },
  {
    keys: /\b(photosynthesis)\b/i,
    answer: "Photosynthesis equation: 6CO\u2082 + 6H\u2082O + Sunlight (Chlorophyll) \u2192 C\u2086H\u2081\u2082O\u2086 (Glucose) + 6O\u2082. Plants convert light energy into chemical energy inside chloroplasts."
  },
  {
    keys: /\b(periodic table|atomic number|valency)\b/i,
    answer: "Modern Periodic Law (Moseley): Properties of elements are periodic functions of their atomic number (Z). E.g., H(1), He(2), C(6), N(7), O(8), Na(11), Cl(17), Ca(20)."
  },
  {
    keys: /\b(trigonometry|sin|cos|tan|identity)\b/i,
    answer: "Core Trigonometry Identities: sin\xB2\u03B8 + cos\xB2\u03B8 = 1, 1 + tan\xB2\u03B8 = sec\xB2\u03B8, 1 + cot\xB2\u03B8 = cosec\xB2\u03B8. Standard values: sin30\xB0 = 1/2, sin45\xB0 = 1/\u221A2, sin60\xB0 = \u221A3/2, sin90\xB0 = 1."
  },
  {
    keys: /\b(lens formula|mirror formula|magnification)\b/i,
    answer: "Mirror Formula: 1/f = 1/v + 1/u (m = -v/u). Lens Formula: 1/f = 1/v - 1/u (m = v/u), Power P = 1/f (in metres, Dioptre D)."
  },
  {
    keys: /\b(tense|grammar|parts of speech|noun|verb|active passive)\b/i,
    answer: "English Grammar Basics: 3 main tenses (Present, Past, Future), each with Simple, Continuous, Perfect & Perfect Continuous forms. Yuitor's Spoken English & Class 6\u201312 batches cover grammar, fluency & interview skills."
  },
  {
    keys: /\b(python|loop|function|html|javascript|sql)\b/i,
    answer: "Python uses `def` for functions and `for`/`while` for loops; SQL uses `SELECT/INSERT/UPDATE/DELETE`; HTML structures web pages and JS adds interactivity. All of these are taught practically in Yuitor's Computer & AI Coding tracks!"
  }
];
function ruleBasedFallback(userMsg, history, db) {
  const q = userMsg.toLowerCase();
  const isHindi = /[\u0900-\u097F]|\b(kya|kaise|kitni|fees|batayein|batao|chahiye|karna|nahi|ho raha|madad|admission lena|namaste|kab|kahan|kaun)\b/i.test(
    userMsg
  );
  if (/^(hi|hello|hey|namaste|hlo|good morning|good evening|good afternoon)[!.\s]*$/i.test(q.trim())) {
    return { reply: SHREYA_INTRO, escalate: false };
  }
  if (/\b(who are you|your name|kaun ho|aap kaun|shreya)\b/i.test(q) && q.length < 45) {
    return { reply: SHREYA_INTRO, escalate: false };
  }
  if (/\b(complaint|refund issue|speak to human|talk to sir|call me|human|manager|principal|unresolved|team se baat)\b/i.test(q)) {
    return {
      reply: isHindi ? "Main aapki query Yuitor Team ko transfer kar rahi hoon. Aap kripya +91 78-2728-9292 par call/WhatsApp karein ya Info tab mein apna number share karein." : "I have flagged this for the Yuitor Team. You can also call or WhatsApp +91 78-2728-9292 or leave your contact in the Info box so our team can reach out.",
      escalate: true
    };
  }
  const solved = tryDynamicAcademicSolver(userMsg, isHindi);
  if (solved) {
    return { reply: solved, escalate: false };
  }
  for (const item of ACADEMIC_CONCEPTS) {
    if (item.keys.test(q)) {
      return { reply: item.answer, escalate: false };
    }
  }
  if (/^\s*(i want admission|admission|apply|join|enroll|daakhila)\b/i.test(q) && !/\b(class|neet|jee|cuet|computer|english|ai|python|6|7|8|9|10|11|12)\b/i.test(q)) {
    return {
      reply: isHindi ? "Bilkul! Aap kis class ya course mein admission lena chahte hain?" : "Sure! Which class or course are you interested in?",
      escalate: false
    };
  }
  if (/\b(fee|fees|price|charges|kitni|paisa|amount)\b/i.test(q) && !/\b(5|6|7|8|9|10|11|12|neet|jee|cuet|computer|english|ai|python|spoken|nda|ssc|banking)\b/i.test(q)) {
    return {
      reply: isHindi ? "Aap kis class ya course ki fees jaanna chahte hain?" : "Which class or course would you like to know the fees for?",
      escalate: false
    };
  }
  if (/\b(cannot log in|can't login|cant login|login problem|login issue|otp|sign in|unable to login|log in)\b/i.test(q)) {
    return {
      reply: isHindi ? "Kya aapko OTP verification mein dikkat aa rahi hai ya account login karne mein?" : "Are you having trouble with OTP verification or logging into your account?",
      escalate: false
    };
  }
  const courses = db.prepare("SELECT title, category, class_range, monthly_fee, yearly_fee FROM courses WHERE is_active = 1").all();
  if (/\b(class\s*5|5th)\b/i.test(q)) {
    return {
      reply: isHindi ? "Class 5th Foundation fees CBSE \u20B91,000/month (\u20B910,200/year), UP Board \u20B9900/month, ICSE \u20B91,200/month hai. Kya aap free demo class book karna chahenge?" : "Class 5th coaching fees start at \u20B9900\u2013\u20B91,200/month depending on board (CBSE/UP/ICSE). Would you like to book a free demo class?",
      escalate: false
    };
  }
  if (/\b(class\s*6|class\s*7|class\s*8|6th|7th|8th)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("6th\u20138th"));
    if (c) {
      return {
        reply: `${c.title} fees: \u20B9${c.monthly_fee}/month (or \u20B9${c.yearly_fee}/year). Would you like to book a demo class?`,
        escalate: false
      };
    }
  }
  if (/\b(class\s*9|class\s*10|9th|10th)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("9th\u201310th"));
    if (c) {
      return {
        reply: `${c.title} fees: \u20B9${c.monthly_fee}/month (or \u20B9${c.yearly_fee}/year). Would you like to apply via /admission?`,
        escalate: false
      };
    }
  }
  if (/\b(class\s*11|class\s*12|11th|12th)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("11th\u201312th"));
    if (c) {
      return {
        reply: `${c.title} fees: \u20B9${c.monthly_fee}/month (or \u20B9${c.yearly_fee}/year). Which stream or board are you looking for?`,
        escalate: false
      };
    }
  }
  if (/\b(neet|jee)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("NEET"));
    if (c) {
      return {
        reply: `${c.title} fees: \u20B9${c.monthly_fee}/month (or \u20B9${c.yearly_fee}/year). Are you preparing for NEET or JEE?`,
        escalate: false
      };
    }
  }
  if (/\b(cuet|nda|ssc|banking)\b/i.test(q)) {
    const c = courses.find((x) => x.title.includes("CUET"));
    const base = c ? `\u20B9${c.monthly_fee}/month (\u20B9${c.yearly_fee}/year)` : "\u20B91,800\u2013\u20B92,200/month";
    return {
      reply: `Competitive & CUET batch fees start at ${base}. Would you like to know the Muradnagar batch timings?`,
      escalate: false
    };
  }
  if (/\b(computer|dca|tally|ccc|ms office)\b/i.test(q)) {
    const c = courses.find((x) => x.category === "Computer");
    if (c) {
      return {
        reply: `${c.title} fees: \u20B9${c.monthly_fee}/month (or \u20B9${c.yearly_fee}/year). Would you like details on DCA or Tally Prime?`,
        escalate: false
      };
    }
  }
  if (/\b(ai|python|coding|web development|full stack)\b/i.test(q)) {
    const c = courses.find((x) => x.category === "AI Learning");
    if (c) {
      return {
        reply: `${c.title} fees: \u20B9${c.monthly_fee}/month (or \u20B9${c.yearly_fee}/year). Which class or skill level are you in?`,
        escalate: false
      };
    }
  }
  if (/\b(english|spoken)\b/i.test(q)) {
    const c = courses.find((x) => x.category === "English Speaking");
    if (c) {
      return {
        reply: `${c.title} fees: \u20B9${c.monthly_fee}/month (or \u20B9${c.yearly_fee}/year). Would you like to join the next batch?`,
        escalate: false
      };
    }
  }
  if (/\b(coupon|discount|scholarship|offer|festival)\b/i.test(q)) {
    return {
      reply: "You can check scholarship tests on /scholarship or use active festival/enrollment promo codes (such as YUITOR10 for eligible batches) in your Student Portal or Fee Calculator (/fee-calculator).",
      escalate: false
    };
  }
  if (/\b(demo|trial|timing|batch|schedule)\b/i.test(q)) {
    return {
      reply: "Morning and evening batches run Monday to Saturday at Yuitor Smart Classes, Muradnagar. You can request a free demo class via /contact or /admission.",
      escalate: false
    };
  }
  if (/\b(teacher|faculty|staff|sir|mam)\b/i.test(q)) {
    return {
      reply: "Yuitor Smart Classes is led by experienced Physics, Chemistry, Biology, Mathematics, Computer & English faculty (visit /teachers for full profiles). Interested in applying as a teacher? Visit /teacher/register.php.",
      escalate: false
    };
  }
  if (/\b(refund|certificate|receipt|invoice)\b/i.test(q)) {
    return {
      reply: "Yuitor provides a 100% fee refund within 7 days subject to published terms (/refund). Verified payments generate downloadable YTR-RCP receipts, and 100% course completion unlocks YTR-CERT certificates in your Student Portal.",
      escalate: false
    };
  }
  if (/\b(address|location|where|muradnagar|kahan|center|centre)\b/i.test(q)) {
    return {
      reply: "Yuitor Smart Classes is at Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh. Call/WhatsApp: +91 78-2728-9292.",
      escalate: false
    };
  }
  if (/\b(contact|phone|number|whatsapp|email|call)\b/i.test(q)) {
    return {
      reply: "Call/WhatsApp: +91 78-2728-9292 \xB7 Branch: +91 1232314337 \xB7 Admission: admission@yuitor.com \xB7 Inquiry: inquiry@yuitor.com.",
      escalate: false
    };
  }
  if (/\b(pending|approval|verify|verification)\b/i.test(q)) {
    return {
      reply: "After mobile OTP verification, your account stays in Pending Yuitor Team Approval until reviewed by an administrator. You can call +91 78-2728-9292 for urgent verification.",
      escalate: false
    };
  }
  const faqs = db.prepare("SELECT question, answer FROM faqs WHERE is_active = 1").all();
  const words = q.split(/\W+/).filter((w) => w.length >= 4);
  if (words.length > 0) {
    let bestFaq = null;
    for (const f of faqs) {
      const hay = `${f.question} ${f.answer}`.toLowerCase();
      const score = words.reduce((acc, w) => acc + (hay.includes(w) ? 1 : 0), 0);
      if (score >= 2 && (!bestFaq || score > bestFaq.score)) {
        bestFaq = { answer: f.answer, score };
      }
    }
    if (bestFaq) {
      return { reply: bestFaq.answer, escalate: false };
    }
  }
  const prevAssistant = [...history].reverse().find((h) => h.sender === "assistant")?.message || "";
  if (prevAssistant.includes("Which class or course") && q.length <= 40) {
    return {
      reply: `Thanks! You can view exact fees on /fee-calculator or submit an enquiry on /admission, or call +91 78-2728-9292 for ${userMsg} batch timings.`,
      escalate: false
    };
  }
  return {
    reply: isHindi ? "Main aapki madad Yuitor Smart Classes ke courses, fees, admission, portal login aur Class 6\u201312 study doubts mein kar sakti hoon. Kya aap kisi specific class ya topic ke baare mein poochna chahte hain?" : "I can help with Yuitor Smart Classes courses, fees, Muradnagar admissions, portal support, and Class 6\u201312 Math/Science study doubts. Which class, course, or topic would you like help with?",
    escalate: history.length > 6
  };
}
async function generateShreyaReply(db, conversationId, userMessage) {
  const safeQuestion = redactSensitiveText(cleanText(userMessage, 500));
  const history = db.prepare("SELECT sender, message FROM chatbot_messages WHERE conversation_id = ? ORDER BY id DESC LIMIT 10").all(conversationId);
  history.reverse();
  const quickMatch = ruleBasedFallback(safeQuestion, history, db);
  const isSpecificQuery = tryDynamicAcademicSolver(safeQuestion, false) !== null || /^(hi|hello|hey|namaste|hlo)[!.\s]*$/i.test(safeQuestion.trim());
  if (isSpecificQuery) {
    return quickMatch;
  }
  const apiKey = (process.env.GEMINI_API_KEY || "").trim();
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return quickMatch;
  }
  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
    const knowledge = buildKnowledgeContext(db);
    const systemInstruction = `You are Shreya, Yuitor Smart Classes' Smart AI Assistant.
Exact intro if asked who you are: "${SHREYA_INTRO}"

STRICT RULES:
1. Understand Hindi, English, and Hinglish; reply in the same language as the user.
2. Give short, direct, natural answers (1-3 sentences max). Answer ONLY what the visitor asks.
3. Maintain conversation context from prior messages; never repeat unnecessary explanations.
4. Ask at most ONE relevant follow-up question when clarification is needed.
5. NEVER invent fees, discounts, batches, or policies not listed in OFFICIAL DATA below.
6. Never ask for or repeat passwords or OTPs.
7. You can also answer Class 5\u201312 academic doubts (Math, Science, English, Computer/AI) clearly.
8. If the user has an unresolved complaint or asks to talk to staff, politely transfer to the Yuitor Team (+91 78-2728-9292 / inquiry@yuitor.com) and end your message with [ESCALATE].

${knowledge}`;
    const transcript = history.map((m) => `${m.sender === "user" ? "Visitor" : "Shreya"}: ${m.message}`).join("\n");
    const response = await Promise.race([
      ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents: transcript ? `${transcript}
Visitor: ${safeQuestion}` : `Visitor: ${safeQuestion}`,
        config: {
          systemInstruction,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
        }
      }),
      new Promise(
        (_, reject) => setTimeout(() => reject(new Error("Gemini response timeout")), 6500)
      )
    ]);
    let raw = (response.text || "").trim();
    if (!raw) return quickMatch;
    const escalate = raw.includes("[ESCALATE]");
    raw = raw.replace(/\[ESCALATE\]/g, "").trim();
    return { reply: raw, escalate };
  } catch (err) {
    console.warn("[Shreya AI] Gemini fallback triggered:", err?.message || err);
    return quickMatch;
  }
}
function sanitizeChatTextForStorage(text) {
  return redactSensitiveText(cleanText(text, 2e3));
}
function saveChatTurn(db, conversationId, visitorMsg, assistantMsg, escalated) {
  const safeUser = sanitizeChatTextForStorage(visitorMsg);
  const safeBot = sanitizeChatTextForStorage(assistantMsg);
  const now = nowIso();
  db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'user', ?, ?)").run(
    conversationId,
    safeUser,
    now
  );
  db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'assistant', ?, ?)").run(
    conversationId,
    safeBot,
    now
  );
  db.prepare(
    `UPDATE chatbot_conversations
     SET last_message = ?, status = CASE WHEN ? = 1 THEN 'escalated' ELSE status END, updated_at = ?
     WHERE id = ?`
  ).run(safeUser.slice(0, 240), escalated ? 1 : 0, now, conversationId);
}

// server/routes/public.ts
var ALLOWED_EXTENSIONS = /* @__PURE__ */ new Set([".pdf", ".png", ".jpg", ".jpeg", ".webp"]);
var upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
    filename: (_req, file, cb) => {
      const ext = path4.extname(file.originalname || "").toLowerCase();
      const safeExt = ALLOWED_EXTENSIONS.has(ext) ? ext : ".bin";
      cb(null, `yu-${Date.now()}-${crypto7.randomBytes(6).toString("hex")}${safeExt}`);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path4.extname(file.originalname || "").toLowerCase();
    if (!ALLOWED_EXTENSIONS.has(ext)) {
      cb(new Error("Only PDF, PNG, JPG, and WebP files up to 5 MB are allowed."));
      return;
    }
    cb(null, true);
  }
});
function createPublicRouter(db) {
  const router = Router7();
  router.get("/public/bootstrap", (_req, res) => {
    const courses = db.prepare("SELECT * FROM courses WHERE is_active = 1 ORDER BY id ASC").all();
    const subjects = db.prepare("SELECT * FROM subjects WHERE is_active = 1 ORDER BY id ASC").all();
    const teachers = db.prepare(
      `SELECT u.id, u.full_name, u.avatar_url, tp.qualification, tp.experience_years, tp.bio
         FROM users u
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role = 'teacher' AND u.verification_status = 'approved' AND u.is_active = 1
         ORDER BY u.id ASC`
    ).all();
    const faqs = db.prepare("SELECT * FROM faqs WHERE is_active = 1 ORDER BY sort_order ASC, id ASC").all();
    const testimonials = db.prepare("SELECT * FROM testimonials WHERE is_approved = 1 ORDER BY id DESC").all();
    const banners = db.prepare("SELECT * FROM banners WHERE is_active = 1 ORDER BY id DESC").all();
    const announcements = db.prepare("SELECT * FROM announcements WHERE audience IN ('all', 'public') ORDER BY id DESC LIMIT 10").all();
    res.json({ courses, subjects, teachers, faqs, testimonials, banners, announcements });
  });
  const handleInquirySubmit = (req, res) => {
    if (String(req.body?.website || "").trim() !== "" || String(req.body?.website_url || "").trim() !== "") {
      res.status(201).json({ accepted: true, success: true, message: "Thank you. Your enquiry has been received." });
      return;
    }
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `inq:${ip}`, 6, 300, 120);
    if (!rl.allowed) {
      res.status(429).json({ error: "Please wait a few seconds before sending another enquiry." });
      return;
    }
    const name = cleanText(req.body?.name, 120);
    const phone = cleanText(req.body?.phone, 24);
    const email = cleanText(req.body?.email, 254);
    const classOrCourse = cleanText(req.body?.class_or_course || req.body?.course || "General Inquiry", 120);
    const message = cleanText(req.body?.message, 2e3);
    const source = cleanText(req.body?.source || "website", 40);
    if (name.length < 2) {
      res.status(400).json({ error: "Please enter your name." });
      return;
    }
    if (!isValidPhone(phone)) {
      res.status(400).json({ error: "Please enter a valid mobile or phone number." });
      return;
    }
    if (email && !isValidEmail(email)) {
      res.status(400).json({ error: "Please enter a valid email address." });
      return;
    }
    recordRateLimitHit(db, `inq:${ip}`, 300);
    const now = nowIso();
    db.prepare(
      `INSERT INTO inquiries (name, phone, email, class_or_course, message, source, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'new', ?)`
    ).run(name, phone, email, classOrCourse, message, source, now);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(`New Inquiry: ${classOrCourse}`, `${name} (${phone}) submitted an inquiry.`, now);
    if (isSmtpConfigured() && ADMIN_NOTIFY_EMAIL) {
      void sendEmailDirect({
        to: ADMIN_NOTIFY_EMAIL,
        subject: `New Yuitor Inquiry (${classOrCourse}) \u2014 ${name}`,
        html: `<p><strong>Name:</strong> ${name}<br><strong>Phone:</strong> ${phone}<br><strong>Email:</strong> ${email || "N/A"}<br><strong>Course:</strong> ${classOrCourse}<br><strong>Message:</strong> ${message || "N/A"}</p>`
      });
    }
    res.status(201).json({
      accepted: true,
      success: true,
      message: "Thank you! Your enquiry has been saved. Our Muradnagar team will contact you shortly."
    });
  };
  router.post("/public/inquiries", handleInquirySubmit);
  router.post("/inquiries", handleInquirySubmit);
  router.get("/public/unsubscribe/:token", (req, res) => {
    const token = cleanText(req.params.token, 100);
    const user = db.prepare("SELECT email, marketing_opt_in FROM users WHERE unsubscribe_token = ?").get(token);
    if (!user) {
      res.status(404).json({ error: "Invalid or expired unsubscribe token." });
      return;
    }
    res.json({
      email: user.email,
      reason: user.marketing_opt_in ? "Subscribed to Yuitor updates" : "Unsubscribed from marketing emails"
    });
  });
  router.post("/public/unsubscribe/:token", (req, res) => {
    const token = cleanText(req.params.token, 100);
    const optIn = Boolean(req.body?.marketingOptIn);
    const user = db.prepare("SELECT id, email FROM users WHERE unsubscribe_token = ?").get(token);
    if (!user) {
      res.status(404).json({ error: "Invalid unsubscribe token." });
      return;
    }
    db.prepare("UPDATE users SET marketing_opt_in = ?, updated_at = ? WHERE id = ?").run(optIn ? 1 : 0, nowIso(), user.id);
    if (optIn) {
      db.prepare("DELETE FROM email_suppressions WHERE email = ?").run(user.email);
    } else {
      db.prepare("INSERT OR REPLACE INTO email_suppressions (email, reason, created_at) VALUES (?, 'unsubscribed', ?)").run(
        user.email,
        nowIso()
      );
    }
    res.json({ updated: true, marketingOptIn: optIn });
  });
  router.post("/public/chatbot/session", (req, res) => {
    try {
      const existingId = cleanText(req.body?.conversationId, 80);
      const visitorId = cleanText(req.body?.visitorId || `v-${crypto7.randomBytes(4).toString("hex")}`, 80);
      if (existingId) {
        const conv2 = db.prepare("SELECT * FROM chatbot_conversations WHERE id = ?").get(existingId);
        if (conv2) {
          const messages2 = db.prepare("SELECT sender, message, created_at FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC").all(existingId);
          res.json({ conversation: conv2, messages: messages2 });
          return;
        }
      }
      const newId = `chat-${crypto7.randomUUID()}`;
      const now = nowIso();
      db.prepare(
        `INSERT INTO chatbot_conversations (id, visitor_id, status, last_message, created_at, updated_at)
         VALUES (?, ?, 'active', ?, ?, ?)`
      ).run(newId, visitorId, SHREYA_INTRO, now, now);
      db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'assistant', ?, ?)").run(
        newId,
        SHREYA_INTRO,
        now
      );
      const conv = db.prepare("SELECT * FROM chatbot_conversations WHERE id = ?").get(newId);
      const messages = db.prepare("SELECT sender, message, created_at FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC").all(newId);
      res.json({ conversation: conv, messages });
    } catch (err) {
      res.status(500).json({ error: err?.message || "Unable to initialize chat session." });
    }
  });
  router.post("/public/chatbot/message", async (req, res) => {
    try {
      const ip = clientIp(req);
      const rl = checkRateLimit(db, `chat:${ip}`, 30, 300, 120);
      if (!rl.allowed) {
        res.status(429).json({ error: "Too many messages. Please wait a moment." });
        return;
      }
      recordRateLimitHit(db, `chat:${ip}`, 300);
      let conversationId = cleanText(req.body?.conversationId, 80);
      const message = cleanText(req.body?.message, 500);
      if (!message) {
        res.status(400).json({ error: "Message is required." });
        return;
      }
      const now = nowIso();
      if (!conversationId || !db.prepare("SELECT id FROM chatbot_conversations WHERE id = ?").get(conversationId)) {
        conversationId = `chat-${crypto7.randomUUID()}`;
        db.prepare(
          "INSERT INTO chatbot_conversations (id, visitor_id, status, last_message, created_at, updated_at) VALUES (?, 'visitor', 'active', ?, ?, ?)"
        ).run(conversationId, SHREYA_INTRO, now, now);
        db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'assistant', ?, ?)").run(
          conversationId,
          SHREYA_INTRO,
          now
        );
      }
      const vName = cleanText(req.body?.visitorName, 120);
      const vPhone = cleanText(req.body?.visitorPhone, 24);
      const vEmail = cleanText(req.body?.visitorEmail, 254);
      if (vName || vPhone || vEmail) {
        db.prepare(
          `UPDATE chatbot_conversations
           SET visitor_name = COALESCE(NULLIF(?, ''), visitor_name),
               visitor_phone = COALESCE(NULLIF(?, ''), visitor_phone),
               visitor_email = COALESCE(NULLIF(?, ''), visitor_email),
               updated_at = ?
           WHERE id = ?`
        ).run(vName, vPhone, vEmail, now, conversationId);
      }
      const { reply, escalate } = await generateShreyaReply(db, conversationId, message);
      saveChatTurn(db, conversationId, message, reply, escalate);
      if (escalate) {
        db.prepare(
          "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
        ).run("Shreya Escalation", `Visitor query requires Yuitor Team follow-up: "${message.slice(0, 120)}"`, now);
      }
      const messages = db.prepare("SELECT sender, message, created_at FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC").all(conversationId);
      res.json({ conversationId, reply, escalated: escalate, messages });
    } catch (err) {
      res.status(500).json({ error: err?.message || "Chatbot request failed." });
    }
  });
  router.post("/public/chatbot/feedback", (req, res) => {
    const conversationId = cleanText(req.body?.conversationId, 80);
    const rating = Math.min(5, Math.max(1, Number(req.body?.rating || 5)));
    const feedback = cleanText(req.body?.feedback, 500);
    const resolved = Boolean(req.body?.resolved);
    if (!conversationId) {
      res.status(400).json({ error: "Conversation ID required." });
      return;
    }
    const status = resolved ? "resolved" : "unresolved";
    db.prepare(
      "UPDATE chatbot_conversations SET rating = ?, feedback = ?, status = ?, updated_at = ? WHERE id = ?"
    ).run(rating, feedback, status, nowIso(), conversationId);
    res.json({ saved: true });
  });
  const formatFestivalConfig = (row) => {
    let overrides = {};
    try {
      overrides = row?.overrides_json ? JSON.parse(row.overrides_json) : {};
    } catch {
      overrides = {};
    }
    const mode = row?.mode || "automatic";
    const manualFestivalId = row?.manual_festival_id || null;
    const simulatedDateIST = row?.simulated_date_ist || null;
    return {
      mode,
      manualFestivalId,
      simulatedDateIST,
      overrides,
      manual_festival_id: manualFestivalId,
      simulated_date_ist: simulatedDateIST,
      overrides_json: JSON.stringify(overrides)
    };
  };
  router.get("/festival", (_req, res) => {
    const row = db.prepare("SELECT * FROM festival_settings WHERE id = 1").get();
    res.json({ config: formatFestivalConfig(row) });
  });
  router.get("/festival.php", (_req, res) => {
    const row = db.prepare("SELECT * FROM festival_settings WHERE id = 1").get();
    res.json({ config: formatFestivalConfig(row) });
  });
  router.post("/uploads", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Authentication required to upload files." });
      return;
    }
    upload.single("file")(req, res, (err) => {
      if (err) {
        res.status(400).json({ error: err.message || "Upload failed." });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: "No file uploaded." });
        return;
      }
      res.status(201).json({ url: `/uploads/${req.file.filename}`, filename: req.file.filename });
    });
  });
  router.get("/download-release", (req, res) => {
    if (!verifyReleaseDownload(req.query.expires, req.query.sig)) {
      res.status(403).json({ error: "Invalid or expired download signature." });
      return;
    }
    const zipPath = path4.join(APP_ROOT, "yuitor-smart-classes-final.zip");
    if (!fs4.existsSync(zipPath)) {
      res.status(404).json({ error: "Release ZIP archive not found." });
      return;
    }
    res.download(zipPath, "yuitor-smart-classes-final.zip");
  });
  return router;
}

// server.ts
var PUBLIC_DIR = path5.join(APP_ROOT, "public");
var PORT = Number(process.env.PORT || 3e3);
var HOST = "0.0.0.0";
var STATIC_EXT_RE = /\.(?:js|mjs|css|map|png|jpe?g|webp|gif|svg|ico|woff2?|ttf|eot|json|xml|txt|pdf|sqlite|db|zip|tar|gz|bak|sql|env|log)$/i;
var PRIVATE_ROUTE_RE = /^\/(?:admin(?:-setup)?|student|teacher|teacher-apply\.php|login|register|unsubscribe|erp)(?:\/|$|\.)/i;
var COMPRESSIBLE_CT_RE = /^(?:text\/|application\/(?:javascript|ecmascript|json|xml|xhtml\+xml)|image\/svg\+xml)/i;
var HASHED_ASSET_RE = /\/assets\/.*-[A-Za-z0-9_-]{8}\.(?:js|css)$/i;
function applyStaticCacheHeaders(res, filePath) {
  if (/\.html$/i.test(filePath)) {
    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
  } else if (filePath.includes(`${path5.sep}assets${path5.sep}images${path5.sep}`) || HASHED_ASSET_RE.test(filePath)) {
    res.setHeader("Cache-Control", "public, max-age=604800, immutable");
  } else if (/\.(?:js|css|json|svg|png|jpe?g|webp|ico|woff2?)$/i.test(filePath)) {
    res.setHeader("Cache-Control", "public, max-age=3600, must-revalidate");
  }
}
function gzipResponseMiddleware(req, res, next) {
  const acceptEncoding = String(req.headers["accept-encoding"] || "");
  if (!/\bgzip\b/i.test(acceptEncoding) || req.method === "HEAD") {
    next();
    return;
  }
  let gzipStream = null;
  let bypass = false;
  const origWrite = res.write.bind(res);
  const origEnd = res.end.bind(res);
  const origWriteHead = res.writeHead.bind(res);
  function decide() {
    if (gzipStream || bypass) return;
    if (res.getHeader("Content-Encoding") || res.getHeader("Content-Range") || res.statusCode === 204 || res.statusCode === 206 || res.statusCode === 304) {
      bypass = true;
      return;
    }
    const ct = String(res.getHeader("Content-Type") || "");
    if (!COMPRESSIBLE_CT_RE.test(ct)) {
      bypass = true;
      return;
    }
    const len = Number(res.getHeader("Content-Length") || 0);
    if (len > 0 && len < 1024) {
      bypass = true;
      return;
    }
    res.removeHeader("Content-Length");
    res.setHeader("Content-Encoding", "gzip");
    res.setHeader("Vary", "Accept-Encoding");
    gzipStream = zlib.createGzip({ level: 6 });
    gzipStream.on("data", (chunk) => origWrite(chunk));
    gzipStream.on("drain", () => res.emit("drain"));
    gzipStream.on("error", () => origEnd());
    gzipStream.on("end", () => origEnd());
  }
  res.writeHead = ((statusCode, reasonOrHeaders, maybeHeaders) => {
    const hdrObj = typeof reasonOrHeaders === "object" && reasonOrHeaders !== null ? reasonOrHeaders : maybeHeaders;
    if (hdrObj && typeof hdrObj === "object") {
      for (const [k, v] of Object.entries(hdrObj)) {
        if (v !== void 0) res.setHeader(k, v);
      }
    }
    res.statusCode = statusCode;
    decide();
    if (typeof reasonOrHeaders === "string") {
      return origWriteHead(statusCode, reasonOrHeaders);
    }
    return origWriteHead(statusCode);
  });
  res.write = ((chunk, encoding, cb) => {
    decide();
    if (gzipStream) {
      if (typeof encoding === "function") return gzipStream.write(chunk, encoding);
      return gzipStream.write(chunk, encoding, cb);
    }
    return origWrite(chunk, encoding, cb);
  });
  res.end = ((chunk, encoding, cb) => {
    decide();
    if (gzipStream) {
      if (typeof chunk === "function") {
        gzipStream.end(chunk);
      } else if (typeof encoding === "function") {
        gzipStream.end(chunk, encoding);
      } else if (chunk !== void 0) {
        gzipStream.end(chunk, encoding, cb);
      } else {
        gzipStream.end();
      }
      return res;
    }
    return origEnd(chunk, encoding, cb);
  });
  next();
}
function createApp() {
  const db = getDb();
  startEmailScheduler(db);
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", 1);
  app.use((_req, res, next) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    next();
  });
  app.use(gzipResponseMiddleware);
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ extended: true, limit: "1mb" }));
  app.use(cookieParser());
  app.use("/api", (_req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    next();
  });
  app.use("/api", sameOriginGuard);
  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "yuitor-smart-classes", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.use("/api/auth", createAuthRouter(db));
  app.use("/api/admin", createAdminRouter(db));
  app.use("/api/marketing", createMarketingRouter(db));
  app.use("/api/student", createStudentRouter(db));
  app.use("/api/teacher", createTeacherRouter(db));
  app.use("/api/payments", createPaymentsRouter(db));
  app.use("/api", createPublicRouter(db));
  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "API endpoint not found." });
  });
  app.get(["/erp", "/erp/index.php"], (req, res) => {
    const role = String(req.query.role || "").toLowerCase();
    res.redirect(302, role === "teacher" ? "/teacher/" : "/student/");
  });
  app.use("/uploads", express.static(UPLOADS_DIR, { dotfiles: "deny", index: false, fallthrough: false }));
  app.get("*", (req, res, next) => {
    const reqPath = req.path || "/";
    if (STATIC_EXT_RE.test(reqPath) && !reqPath.endsWith(".php")) {
      next();
      return;
    }
    if (PRIVATE_ROUTE_RE.test(reqPath)) {
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.setHeader("Cache-Control", "no-store");
    } else {
      res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    }
    const safeRel = reqPath.replace(/^\/+|\/+$/g, "");
    if (safeRel && !safeRel.includes("..")) {
      const candidate = path5.join(PUBLIC_DIR, safeRel, "index.html");
      if (candidate.startsWith(PUBLIC_DIR) && fs5.existsSync(candidate)) {
        res.sendFile(candidate);
        return;
      }
    }
    next();
  });
  app.use(
    express.static(PUBLIC_DIR, {
      dotfiles: "deny",
      index: "index.html",
      extensions: ["html"],
      redirect: false,
      setHeaders: applyStaticCacheHeaders
    })
  );
  app.get("*", (req, res) => {
    const reqPath = req.path || "/";
    if (STATIC_EXT_RE.test(reqPath) && !reqPath.endsWith(".php")) {
      res.status(404).type("text/plain").send("Not Found");
      return;
    }
    if (PRIVATE_ROUTE_RE.test(reqPath)) {
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.setHeader("Cache-Control", "no-store");
      res.sendFile(path5.join(PUBLIC_DIR, "index.html"));
      return;
    }
    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    const safeRel = reqPath.replace(/^\/+|\/+$/g, "");
    if (safeRel && !safeRel.includes("..")) {
      const candidate = path5.join(PUBLIC_DIR, safeRel, "index.html");
      if (candidate.startsWith(PUBLIC_DIR) && fs5.existsSync(candidate)) {
        res.sendFile(candidate);
        return;
      }
    }
    res.sendFile(path5.join(PUBLIC_DIR, "index.html"));
  });
  app.use((err, req, res, _next) => {
    console.error("[Yuitor Server Error]", err?.message || err);
    if (req.path.startsWith("/api")) {
      res.status(Number(err?.status || 500)).json({ error: err?.message || "Internal server error." });
      return;
    }
    res.status(500).type("text/plain").send("Server error");
  });
  return { app, db };
}
var shouldAutoListen = process.env.YUITOR_NO_LISTEN !== "1" && process.env.NODE_ENV !== "test" && !process.env.VITEST;
var serverApp = shouldAutoListen ? createApp().app : null;
if (serverApp) {
  serverApp.listen(PORT, HOST, () => {
    console.log(`Yuitor Smart Classes unified server listening on http://${HOST}:${PORT}`);
  });
}
export {
  createApp,
  serverApp
};
