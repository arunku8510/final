(() => {
  "use strict";
  const root = document.getElementById("root");
  if (!root) return;

  const BRAND_PENDING_MSG =
    "Your mobile number has been successfully verified. Your account verification is currently pending from the Yuitor Team. We will try to contact you soon. Thank you for your patience.";

  const escapeHtml = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const escAttr = (v) => escapeHtml(v);

  const ICONS = {
    dashboard: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    book: '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
    wallet: '<path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>',
    megaphone: '<path d="m3 11 18-5v12L3 13v-2z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
    bot: '<path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/>',
    mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5"/><path d="M3 12a9 3 0 0 0 18 0"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
    moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
    menu: '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',
    sidebar: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
    user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    calendar: '<rect width="18" height="18" x="3" y="4" rx="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
    arrowUp: '<path d="m18 15-6-6-6 6"/>',
    arrowDown: '<path d="m6 9 6 6 6-6"/>',
    award: '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
  };

  function icon(name, cls = "portal-icon-svg") {
    return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.dashboard}</svg>`;
  }

  async function api(url, options = {}) {
    const headers = { Accept: "application/json", ...(options.headers || {}) };
    const opts = { credentials: "same-origin", cache: "no-store", ...options, headers };
    if (options.body && !(options.body instanceof FormData) && typeof options.body !== "string") {
      headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(options.body);
    }
    const res = await fetch(url, opts);
    let data = {};
    try {
      data = await res.json();
    } catch {
      data = {};
    }
    if (!res.ok) {
      const err = new Error(data.error || `Request failed (${res.status})`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  async function uploadFile(file) {
    const fd = new FormData();
    fd.append("file", file);
    return api("/api/uploads", { method: "POST", body: fd });
  }

  function getMain() {
    return root.querySelector("main");
  }

  function applyThemePreference(main) {
    const dark = localStorage.getItem("yuitor_portal_dark") === "1";
    main.classList.toggle("portal-dark", dark);
    return dark;
  }

  function mountShell(html) {
    const main = getMain();
    if (!main) return null;
    main.classList.add("portal-main");
    applyThemePreference(main);
    main.dataset.yuPortalMounted = "true";
    main.innerHTML = `<div class="portal-shell">${html}</div>`;
    return main;
  }

  function statusBadge(st) {
    const s = String(st || "").toLowerCase();
    let mod = "pending";
    if (["approved", "active", "verified", "paid", "completed", "resolved", "present", "graded", "available", "sent"].includes(s)) {
      mod = "paid";
    } else if (["rejected", "suspended", "inactive", "failed", "absent", "refunded", "cancelled", "closed"].includes(s)) {
      mod = "overdue";
    }
    return `<span class="portal-status portal-status--${mod}">${escapeHtml(s.replace(/_/g, " "))}</span>`;
  }

  function impersonationBanner(session) {
    if (!session?.impersonation?.active) return "";
    return `
      <div class="portal-alert">
        <div>
          <strong>Admin viewing as user: ${escapeHtml(session.user.full_name)} (${escapeHtml(session.user.role)})</strong>
          · Reason: ${escapeHtml(session.impersonation.reason)}
        </div>
        <button type="button" class="portal-button portal-button--small" data-exit-impersonation>Exit Impersonation</button>
      </div>`;
  }

  function bindGlobalImpersonationExit(container) {
    const btn = container.querySelector("[data-exit-impersonation]");
    if (!btn) return;
    btn.addEventListener("click", async () => {
      try {
        const res = await api("/api/auth/exit-impersonation", { method: "POST" });
        window.location.assign(res.redirectTo || "/admin/");
      } catch (err) {
        btn.textContent = err.message || "Exit failed";
      }
    });
  }

  function openPromptModal({ title, label, placeholder = "", defaultValue = "", minLength = 1 }) {
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      overlay.className = "yu-festival-popup-overlay";
      overlay.style.cssText =
        "position:fixed;inset:0;z-index:10050;background:rgba(15,23,42,.56);display:flex;align-items:center;justify-content:center;padding:16px;";
      overlay.innerHTML = `
        <div class="portal-card portal-profile" role="dialog" aria-modal="true" style="max-width:440px;width:100%;margin:0;">
          <h3 class="portal-section-title" style="margin-bottom:8px;">${escapeHtml(title)}</h3>
          <form class="portal-form" data-modal-prompt-form>
            <div class="portal-field">
              <label>${escapeHtml(label)}</label>
              <input name="value" value="${escAttr(defaultValue)}" placeholder="${escAttr(placeholder)}" minlength="${minLength}" required>
            </div>
            <div class="portal-actions" style="justify-content:flex-end;margin-top:12px;">
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-modal-cancel>Cancel</button>
              <button type="submit" class="portal-button portal-button--small">Confirm</button>
            </div>
          </form>
        </div>`;
      const cleanup = (val) => {
        overlay.remove();
        resolve(val);
      };
      overlay.querySelector("[data-modal-cancel]")?.addEventListener("click", () => cleanup(""));
      overlay.addEventListener("click", (ev) => {
        if (ev.target === overlay) cleanup("");
      });
      overlay.querySelector("[data-modal-prompt-form]")?.addEventListener("submit", (ev) => {
        ev.preventDefault();
        const val = String(new FormData(ev.currentTarget).get("value") || "").trim();
        if (val.length < minLength) return;
        cleanup(val);
      });
      document.body.appendChild(overlay);
      overlay.querySelector('input[name="value"]')?.focus();
    });
  }

  function formatINR(n) {
    return `₹${Number(n || 0).toLocaleString("en-IN")}`;
  }

  function renderWorkspace({ session, portalTitle, navItems, activeTab, onTabChange, notifications = [], onReadNotifs, bodyHtml }) {
    const main = getMain();
    if (!main) return null;
    main.classList.add("portal-main");
    const isDark = applyThemePreference(main);
    const isCollapsed = localStorage.getItem("yuitor_portal_collapsed") === "1";
    main.dataset.yuPortalMounted = "true";

    const activeLabel = (navItems.find((n) => n[0] === activeTab) || navItems[0])[1];
    const unreadCount = notifications.filter((n) => !n.is_read).length;
    const avatarSrc = session.user.avatar_url || "/yuitor-icon-192.png";

    main.innerHTML = `
      <div class="portal-workspace ${isCollapsed ? "is-collapsed" : ""}" data-portal-ws>
        <div class="portal-sidebar-backdrop" data-sb-close></div>
        <aside class="portal-sidebar" aria-label="Portal Navigation">
          <div class="portal-sidebar-head">
            <div class="portal-sidebar-brand">
              <img src="/yuitor-icon-192.png" alt="Yuitor Smart Classes logo">
              <div>
                <strong>Yuitor Portal</strong>
                <span>${escapeHtml(portalTitle)}</span>
              </div>
            </div>
            <button type="button" class="portal-icon-btn portal-collapse-btn" title="Toggle sidebar" data-sb-collapse>
              ${icon("sidebar")}
            </button>
          </div>
          <nav class="portal-nav-list">
            ${navItems
              .map(
                ([id, label, iconName]) => `
              <button type="button" class="portal-nav-item" aria-current="${activeTab === id ? "page" : "false"}" data-ws-tab="${escAttr(id)}">
                ${icon(iconName)}
                <span class="portal-nav-label">${escapeHtml(label)}</span>
              </button>`
              )
              .join("")}
          </nav>
          <div style="margin-top:auto;padding-top:10px;border-top:1px solid var(--pt-border);">
            <button type="button" class="portal-nav-item" data-portal-logout>
              ${icon("logout")}
              <span class="portal-nav-label">Sign Out</span>
            </button>
          </div>
        </aside>

        <div class="portal-main-area">
          ${impersonationBanner(session)}
          <div class="portal-topbar">
            <div class="portal-topbar-left">
              <button type="button" class="portal-icon-btn portal-mobile-menu-btn" title="Open navigation" data-sb-mobile>
                ${icon("menu")}
              </button>
              <div class="portal-breadcrumb">
                <span>${escapeHtml(portalTitle)}</span>
                <span>/</span>
                <strong>${escapeHtml(activeLabel)}</strong>
              </div>
            </div>
            <div class="portal-topbar-right">
              <button type="button" class="portal-icon-btn" title="Toggle Light/Dark theme" data-theme-toggle>
                ${icon(isDark ? "sun" : "moon")}
                <span>${isDark ? "Light" : "Dark"}</span>
              </button>
              <div class="portal-notif-wrap">
                <button type="button" class="portal-icon-btn" title="Notifications" data-notif-toggle>
                  ${icon("bell")}
                  ${unreadCount > 0 ? `<span class="portal-notif-dot">${unreadCount}</span>` : ""}
                </button>
                <div class="portal-notif-dropdown" data-notif-menu hidden>
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                    <strong style="font-size:12px;">Notifications (${notifications.length})</strong>
                    ${onReadNotifs ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-ws-read-notifs>Mark Read</button>` : ""}
                  </div>
                  ${
                    notifications.slice(0, 6).map((n) => `
                    <div class="portal-detail" style="margin-bottom:6px;padding:8px 10px;">
                      <span>${escapeHtml(n.created_at)} · ${n.is_read ? "Read" : "New"}</span>
                      <strong>${escapeHtml(n.title)}</strong>
                      <div style="font-size:12px;color:var(--pt-muted);">${escapeHtml(n.message)}</div>
                    </div>`).join("") || `<p class="portal-hint">No notifications right now.</p>`
                  }
                </div>
              </div>
              <div style="display:flex;align-items:center;gap:8px;padding-left:6px;border-left:1px solid var(--pt-border);">
                <img src="${escAttr(avatarSrc)}" alt="${escAttr(session.user.full_name)}" class="portal-avatar" style="width:32px;height:32px;border-radius:8px;">
                <div style="line-height:1.2;">
                  <strong style="font-size:12px;display:block;">${escapeHtml(session.user.full_name)}</strong>
                  <span style="font-size:11px;color:var(--pt-muted);">${escapeHtml(session.user.role)}</span>
                </div>
              </div>
            </div>
          </div>

          <div data-ws-body>${bodyHtml}</div>
        </div>
      </div>`;

    const ws = main.querySelector("[data-portal-ws]");
    bindGlobalImpersonationExit(main);

    main.querySelector("[data-sb-collapse]")?.addEventListener("click", () => {
      const next = !ws.classList.contains("is-collapsed");
      ws.classList.toggle("is-collapsed", next);
      localStorage.setItem("yuitor_portal_collapsed", next ? "1" : "0");
    });

    main.querySelector("[data-sb-mobile]")?.addEventListener("click", () => {
      ws.classList.add("is-mobile-open");
    });

    main.querySelector("[data-sb-close]")?.addEventListener("click", () => {
      ws.classList.remove("is-mobile-open");
    });

    main.querySelector("[data-theme-toggle]")?.addEventListener("click", () => {
      const next = !main.classList.contains("portal-dark");
      localStorage.setItem("yuitor_portal_dark", next ? "1" : "0");
      main.classList.toggle("portal-dark", next);
      onTabChange(activeTab);
    });

    const notifMenu = main.querySelector("[data-notif-menu]");
    main.querySelector("[data-notif-toggle]")?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (notifMenu) notifMenu.hidden = !notifMenu.hidden;
    });

    main.querySelector("[data-ws-read-notifs]")?.addEventListener("click", async () => {
      if (onReadNotifs) await onReadNotifs();
    });

    main.querySelectorAll("[data-ws-tab]").forEach((b) => {
      b.addEventListener("click", () => {
        ws.classList.remove("is-mobile-open");
        onTabChange(b.getAttribute("data-ws-tab"));
      });
    });

    main.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
      await api("/api/auth/logout", { method: "POST" });
      window.location.assign("/login");
    });

    return main;
  }

  // ==================== PUBLIC COMPLEMENTARY PAGES ====================
  async function renderPublicExtension(path) {
    if (path.startsWith("/unsubscribe/")) {
      const token = path.split("/unsubscribe/")[1].split("/")[0];
      mountShell(`<div class="portal-card portal-login-card"><p class="portal-kicker">Email Preferences</p><div class="portal-heading"><h1>Loading preferences…</h1></div></div>`);
      try {
        const info = await api(`/api/public/unsubscribe/${encodeURIComponent(token)}`);
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Yuitor Email Preferences</p>
            <div class="portal-heading"><h1>Manage Email Subscription</h1></div>
            <p class="portal-subtitle">Email: <strong>${escapeHtml(info.email)}</strong> · Current status: <strong>${escapeHtml(info.reason)}</strong></p>
            <div class="portal-actions" style="margin-top:20px;">
              <button type="button" class="portal-button" data-unsub-opt="false">Unsubscribe from Marketing Emails</button>
              <button type="button" class="portal-button portal-button--quiet" data-unsub-opt="true">Re-subscribe</button>
            </div>
            <div class="portal-message" data-unsub-fb hidden style="margin-top:16px;"></div>
          </div>`);
        main.querySelectorAll("[data-unsub-opt]").forEach((b) => {
          b.addEventListener("click", async () => {
            const opt = b.getAttribute("data-unsub-opt") === "true";
            const fb = main.querySelector("[data-unsub-fb]");
            try {
              await api(`/api/public/unsubscribe/${encodeURIComponent(token)}`, {
                method: "POST",
                body: { marketingOptIn: opt },
              });
              fb.className = "portal-message portal-message--success";
              fb.textContent = opt ? "Subscribed to Yuitor updates." : "You have been unsubscribed from Yuitor marketing emails.";
              fb.hidden = false;
            } catch (err) {
              fb.className = "portal-message portal-message--error";
              fb.textContent = err.message;
              fb.hidden = false;
            }
          });
        });
      } catch (err) {
        mountShell(`<div class="portal-card portal-login-card"><div class="portal-message portal-message--error">${escapeHtml(err.message)}</div></div>`);
      }
      return;
    }

    const boot = await api("/api/public/bootstrap");
    const courses = boot.courses || [];
    const subjects = boot.subjects || [];
    const teachers = boot.teachers || [];
    const faqs = boot.faqs || [];
    const testimonials = boot.testimonials || [];

    if (path === "/admission") {
      const main = mountShell(`
        <p class="portal-kicker">Admissions Open · Muradnagar</p>
        <div class="portal-heading">
          <div>
            <h1>Apply for Admission</h1>
            <p class="portal-subtitle">Yuitor Smart Classes · Trimurti Vihar, Near Venus Academy, Muradnagar - 201206 · Call/WhatsApp +91 78-2728-9292 · admission@yuitor.com</p>
          </div>
          <a href="/register" class="portal-button portal-button--quiet">Student Portal Registration</a>
        </div>
        <div class="portal-card portal-profile">
          <form class="portal-form" data-adm-form>
            <div class="portal-form-grid">
              <div class="portal-field"><label>Student Full Name *</label><input name="name" required placeholder="Full Name"></div>
              <div class="portal-field"><label>Mobile / WhatsApp Number *</label><input name="phone" required placeholder="10-digit number"></div>
              <div class="portal-field"><label>Email Address</label><input name="email" type="email" placeholder="student@example.com"></div>
              <div class="portal-field"><label>Class / Course *</label>
                <select name="class_or_course" required>
                  <option value="">Select Class or Course</option>
                  ${courses.map((c) => `<option value="${escAttr(c.title)}">${escapeHtml(c.title)} (${formatINR(c.monthly_fee)}/mo)</option>`).join("")}
                </select>
              </div>
            </div>
            <div class="portal-field"><label>Notes / Demo Class Preference</label><textarea name="message" placeholder="Preferred batch timing or questions..."></textarea></div>
            <div class="portal-message" data-adm-fb hidden></div>
            <div class="portal-actions"><button type="submit" class="portal-button">Submit Admission Inquiry</button></div>
          </form>
        </div>`);
      const form = main.querySelector("[data-adm-form]");
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const btn = form.querySelector('button[type="submit"]');
        const fd = new FormData(form);
        const fb = main.querySelector("[data-adm-fb]");
        btn.disabled = true;
        try {
          const res = await api("/api/public/inquiries", {
            method: "POST",
            body: {
              name: fd.get("name"),
              phone: fd.get("phone"),
              email: fd.get("email"),
              class_or_course: fd.get("class_or_course"),
              message: fd.get("message"),
              source: "admission_form",
            },
          });
          fb.className = "portal-message portal-message--success";
          fb.textContent = res.message;
          fb.hidden = false;
          form.reset();
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
        } finally {
          btn.disabled = false;
        }
      });
      return;
    }

    if (path === "/subjects") {
      mountShell(`
        <p class="portal-kicker">Academic Directory</p>
        <div class="portal-heading"><h1>Subjects Offered (Classes 6th–12th &amp; Skills)</h1><a href="/admission" class="portal-button">Book Demo Class</a></div>
        <div class="portal-student-grid">
          ${subjects.map((s) => `<div class="portal-card portal-profile"><strong>${escapeHtml(s.name)}</strong><p class="portal-hint" style="margin-top:4px;">${escapeHtml(s.code)} · ${escapeHtml(s.class_level)}</p><p class="portal-subtitle" style="font-size:13px;margin-top:8px;">${escapeHtml(s.description)}</p></div>`).join("")}
        </div>`);
      return;
    }

    if (path === "/ai-learning" || path === "/computer-courses" || path === "/english-speaking" || path === "/courses") {
      const initialCat =
        path === "/ai-learning"
          ? "AI Learning"
          : path === "/computer-courses"
            ? "Computer"
            : path === "/english-speaking"
              ? "English Speaking"
              : "All";
      let activeCat = initialCat;

      const drawCourses = () => {
        const list = activeCat === "All" ? courses : courses.filter((c) => c.category === activeCat);
        const heading = activeCat === "All" ? "All Courses & Fee Directory" : `${activeCat} Programmes`;
        const cats = ["All", "Classes 6-12", "Competitive", "Computer", "AI Learning", "English Speaking"];
        const main = mountShell(`
          <p class="portal-kicker">Yuitor Smart Classes Programmes</p>
          <div class="portal-heading"><h1>${escapeHtml(heading)}</h1><a href="/admission" class="portal-button">Apply for Admission</a></div>
          ${
            path === "/courses"
              ? `<div class="portal-actions" style="margin-bottom:18px;">
                  ${cats.map((c) => `<button type="button" class="portal-button portal-button--small ${activeCat === c ? "" : "portal-button--quiet"}" data-cat-pick="${escAttr(c)}">${escapeHtml(c)}</button>`).join("")}
                </div>`
              : ""
          }
          <div class="portal-form-grid">
            ${list
              .map(
                (c) => `
              <div class="portal-card portal-profile" style="overflow:hidden;">
                ${c.thumbnail_url ? `<img src="${escAttr(c.thumbnail_url)}" alt="${escAttr(c.title)} classroom at Yuitor Smart Classes" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:10px;margin-bottom:12px;">` : ""}
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px;">
                  <span class="portal-status">${escapeHtml(c.category)}</span>
                  <span class="portal-hint">${c.duration_months} months · ${escapeHtml(c.board)}</span>
                </div>
                <h2 style="margin:0 0 8px;font-size:19px;">${escapeHtml(c.title)}</h2>
                <p class="portal-subtitle" style="font-size:13px;margin:0 0 12px;">${escapeHtml(c.description)}</p>
                <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--pt-border);padding-top:12px;">
                  <div><strong>${formatINR(c.monthly_fee)}/mo</strong> <span class="portal-hint">or ${formatINR(c.yearly_fee)}/yr</span></div>
                  <a href="/admission" class="portal-button portal-button--small">Enroll</a>
                </div>
              </div>`
              )
              .join("")}
          </div>`);
        main?.querySelectorAll("[data-cat-pick]").forEach((b) => {
          b.addEventListener("click", () => {
            activeCat = b.getAttribute("data-cat-pick");
            drawCourses();
          });
        });
      };
      drawCourses();
      return;
    }

    if (path === "/teachers") {
      mountShell(`
        <p class="portal-kicker">Faculty &amp; Mentors</p>
        <div class="portal-heading"><div><h1>Approved Faculty &amp; Teachers</h1><p class="portal-subtitle">Experienced educators teaching at Yuitor Smart Classes, Muradnagar.</p></div><a href="/teacher/register.php" class="portal-button portal-button--quiet">Join as Teacher</a></div>
        ${
          teachers.length === 0
            ? `<div class="portal-card portal-empty">Verified teacher profiles appear automatically once approved by the Yuitor Team.</div>`
            : `<div class="portal-student-grid">
            ${teachers.map((t) => `<div class="portal-card portal-profile">${t.avatar_url ? `<img src="${escAttr(t.avatar_url)}" alt="${escAttr(t.full_name)}" class="portal-avatar" style="margin-bottom:10px;">` : ""}<h3 style="margin:0 0 4px;">${escapeHtml(t.full_name)}</h3><p class="portal-hint">${escapeHtml(t.qualification || "Faculty Member")} · ${Number(t.experience_years || 0)} yrs exp</p><p class="portal-subtitle" style="font-size:13px;margin-top:8px;">${escapeHtml(t.bio || "")}</p></div>`).join("")}
          </div>`
        }`);
      return;
    }

    if (path === "/faqs") {
      mountShell(`
        <p class="portal-kicker">Questions &amp; Answers</p>
        <div class="portal-heading"><h1>Frequently Asked Questions</h1></div>
        <div class="portal-form">
          ${faqs.map((f) => `<div class="portal-card portal-profile"><h3 style="margin:0 0 6px;">${escapeHtml(f.question)}</h3><p class="portal-subtitle" style="font-size:14px;margin:0;">${escapeHtml(f.answer)}</p></div>`).join("")}
        </div>`);
      return;
    }

    if (path === "/testimonials") {
      mountShell(`
        <p class="portal-kicker">Student &amp; Parent Stories</p>
        <div class="portal-heading"><h1>Verified Reviews &amp; Testimonials</h1></div>
        <div class="portal-student-grid">
          ${testimonials.map((t) => `<div class="portal-card portal-profile"><p style="margin:0 0 12px;line-height:1.6;">“${escapeHtml(t.quote)}”</p><strong>${escapeHtml(t.author_name)}</strong><div class="portal-hint">${escapeHtml(t.author_role)}${t.outcome_metric ? " · " + escapeHtml(t.outcome_metric) : ""}</div></div>`).join("")}
        </div>`);
    }
  }

  // ==================== AUTHENTICATION, OTP & PASSWORD RESET ====================
  async function renderAdminSetup() {
    const st = await api("/api/auth/setup-status");
    if (!st.needsFirstAdminSetup) {
      window.location.replace("/admin/login.php");
      return;
    }
    const main = mountShell(`
      <div class="portal-card portal-login-card">
        <p class="portal-kicker">Initial Setup</p>
        <div class="portal-heading"><h1>Create First Super Admin</h1></div>
        <p class="portal-subtitle">Runs once when zero admin accounts exist. Automatically locks after creation.</p>
        <form class="portal-form" data-setup-form style="margin-top:16px;">
          <div class="portal-field"><label>Full Name</label><input name="fullName" required placeholder="Admin Name"></div>
          <div class="portal-field"><label>Email Address</label><input name="email" type="email" required placeholder="admin@yuitor.com"></div>
          <div class="portal-field"><label>Mobile Number</label><input name="phone" required placeholder="+91 78-2728-9292"></div>
          <div class="portal-field"><label>Password (min 8 chars)</label><input name="password" type="password" minlength="8" required></div>
          ${
            st.requiresSetupKey
              ? '<div class="portal-field"><label>Server Setup Key (YU_ADMIN_SETUP_KEY)</label><input name="setupKey" type="password" required placeholder="Enter server setup key"></div>'
              : ""
          }
          <div class="portal-message" data-setup-fb hidden></div>
          <button type="submit" class="portal-button">Create Super Admin</button>
        </form>
      </div>`);
    const form = main.querySelector("[data-setup-form]");
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const fb = main.querySelector("[data-setup-fb]");
      try {
        await api("/api/auth/setup-admin", {
          method: "POST",
          body: Object.fromEntries(fd.entries()),
        });
        window.location.assign("/admin/");
      } catch (err) {
        fb.className = "portal-message portal-message--error";
        fb.textContent = err.message;
        fb.hidden = false;
      }
    });
  }

  function renderLogin(defaultRole = "student", initialError = "") {
    let mode = "login"; // 'login' | 'forgot' | 'reset'
    let resetIdentifier = "";
    let resetNote = "";

    function draw() {
      const titleMap = { admin: "Admin Login", teacher: "Teacher Login", student: "Portal Sign In" };

      if (mode === "forgot") {
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Account Recovery</p>
            <div class="portal-heading"><h1>Reset Password</h1></div>
            <p class="portal-subtitle">Enter your registered email or mobile number to request a 6-digit reset OTP.</p>
            <form class="portal-form" data-forgot-form style="margin-top:14px;">
              <div class="portal-field"><label>Registered Email or Mobile</label><input name="identifier" required placeholder="email@example.com or 10-digit mobile"></div>
              <div class="portal-message" data-forgot-fb hidden></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button">Request Reset OTP</button>
                <button type="button" class="portal-button portal-button--quiet" data-back-login>Back to Sign In</button>
              </div>
            </form>
          </div>`);
        main.querySelector("[data-back-login]")?.addEventListener("click", () => {
          mode = "login";
          draw();
        });
        main.querySelector("[data-forgot-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const identifier = String(new FormData(e.target).get("identifier") || "").trim();
          const fb = main.querySelector("[data-forgot-fb]");
          try {
            const res = await api("/api/auth/forgot-password", { method: "POST", body: { identifier } });
            resetIdentifier = identifier;
            resetNote = res.limitationNote || res.message || "";
            mode = "reset";
            draw();
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        return;
      }

      if (mode === "reset") {
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Step 2 · Verify Reset OTP</p>
            <div class="portal-heading"><h1>Choose New Password</h1></div>
            <p class="portal-subtitle">Account: <strong>${escapeHtml(resetIdentifier)}</strong></p>
            ${resetNote ? `<div class="portal-message" style="margin-top:12px;">${escapeHtml(resetNote)}</div>` : ""}
            <form class="portal-form" data-reset-form style="margin-top:14px;">
              <div class="portal-field"><label>6-Digit Reset OTP</label><input name="otp" maxlength="6" required placeholder="Enter 6-digit OTP"></div>
              <div class="portal-field"><label>New Password (min 8 chars)</label><input name="newPassword" type="password" minlength="8" required></div>
              <div class="portal-message" data-reset-fb hidden></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button">Update Password</button>
                <button type="button" class="portal-button portal-button--quiet" data-back-login>Back to Sign In</button>
              </div>
            </form>
          </div>`);
        main.querySelector("[data-back-login]")?.addEventListener("click", () => {
          mode = "login";
          draw();
        });
        main.querySelector("[data-reset-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const fb = main.querySelector("[data-reset-fb]");
          try {
            const res = await api("/api/auth/reset-password", {
              method: "POST",
              body: { identifier: resetIdentifier, otp: fd.get("otp"), newPassword: fd.get("newPassword") },
            });
            fb.className = "portal-message portal-message--success";
            fb.textContent = res.message;
            fb.hidden = false;
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        return;
      }

      const main = mountShell(`
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Yuitor Smart Classes Portal</p>
          <div class="portal-heading"><h1>${titleMap[defaultRole] || "Portal Sign In"}</h1></div>
          ${initialError ? `<div class="portal-message portal-message--error">${escapeHtml(initialError)}</div>` : ""}
          <form class="portal-form" data-login-form>
            <div class="portal-field"><label>Registered Email or Mobile</label><input name="identifier" required placeholder="email@example.com or mobile number"></div>
            <div class="portal-field"><label>Password</label><input name="password" type="password" required></div>
            <div class="portal-message" data-login-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button">Sign In</button>
              <button type="button" class="portal-button portal-button--quiet portal-button--small" data-go-forgot>Forgot Password?</button>
            </div>
          </form>
          <div class="portal-inline-links">
            <a href="/student/register.php">Student Registration</a>
            <a href="/teacher/register.php">Teacher Registration</a>
            <a href="/contact">Need Help? Call +91 78-2728-9292</a>
          </div>
        </div>`);

      main.querySelector("[data-go-forgot]")?.addEventListener("click", () => {
        mode = "forgot";
        draw();
      });

      const form = main.querySelector("[data-login-form]");
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(form);
        const fb = main.querySelector("[data-login-fb]");
        try {
          const res = await api("/api/auth/login", {
            method: "POST",
            body: { identifier: fd.get("identifier"), password: fd.get("password") },
          });
          if (res.verificationStatus === "pending_otp") {
            fb.className = "portal-message portal-message--error";
            fb.textContent = "Please complete mobile OTP verification before continuing.";
            fb.hidden = false;
            return;
          }
          if (res.verificationStatus === "pending_approval" || res.verificationStatus === "otp_verified") {
            fb.className = "portal-message portal-message--success";
            fb.textContent = res.pendingMessage || BRAND_PENDING_MSG;
            fb.hidden = false;
            return;
          }
          const dest =
            res.role === "super_admin" || res.role === "admin"
              ? "/admin/"
              : res.role === "teacher"
                ? "/teacher/"
                : "/student/";
          window.location.assign(dest);
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
        }
      });
    }
    draw();
  }

  function renderRegister(defaultRole = "student") {
    let role = defaultRole === "teacher" ? "teacher" : "student";
    let step = "form";
    let registeredPhone = "";
    let limitationMsg = "";

    function draw() {
      if (step === "pending") {
        mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Account Verification Pending</p>
            <div class="portal-heading"><h1>Mobile Verified</h1></div>
            <div class="portal-message portal-message--success">${escapeHtml(BRAND_PENDING_MSG)}</div>
            <div class="portal-inline-links"><a href="/login">Go to Sign In</a><a href="/">Return Home</a></div>
          </div>`);
        return;
      }

      if (step === "otp") {
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Step 2 of 2 · Mobile OTP</p>
            <div class="portal-heading"><h1>Verify Mobile Number</h1></div>
            <p class="portal-subtitle">Enter the 6-digit OTP sent to <strong>${escapeHtml(registeredPhone)}</strong>.</p>
            ${limitationMsg ? `<div class="portal-message" style="margin-top:12px;">${escapeHtml(limitationMsg)}</div>` : ""}
            <form class="portal-form" data-otp-form style="margin-top:16px;">
              <div class="portal-field"><label>6-Digit OTP</label><input name="otp" maxlength="6" required placeholder="Enter 6-digit OTP"></div>
              <div class="portal-message" data-otp-fb hidden></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button">Verify OTP</button>
                <button type="button" class="portal-button portal-button--quiet" data-resend-otp>Resend OTP</button>
              </div>
            </form>
          </div>`);
        main.querySelector("[data-otp-form]").addEventListener("submit", async (e) => {
          e.preventDefault();
          const otp = new FormData(e.target).get("otp");
          const fb = main.querySelector("[data-otp-fb]");
          try {
            await api("/api/auth/verify-otp", { method: "POST", body: { phone: registeredPhone, otp } });
            step = "pending";
            draw();
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        main.querySelector("[data-resend-otp]").addEventListener("click", async () => {
          const fb = main.querySelector("[data-otp-fb]");
          try {
            const res = await api("/api/auth/resend-otp", { method: "POST", body: { phone: registeredPhone } });
            fb.className = "portal-message portal-message--success";
            fb.textContent = res.limitationNote || "A fresh OTP has been dispatched.";
            fb.hidden = false;
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        return;
      }

      const main = mountShell(`
        <div class="portal-card portal-profile" style="max-width:740px;margin:0 auto;">
          <p class="portal-kicker">Unified Registration · OTP &amp; Yuitor Approval</p>
          <div class="portal-heading">
            <h1>${role === "teacher" ? "Teacher Registration" : "Student Registration"}</h1>
            <div class="portal-actions">
              <button type="button" class="portal-button portal-button--small ${role === "student" ? "" : "portal-button--quiet"}" data-reg-role="student">Student</button>
              <button type="button" class="portal-button portal-button--small ${role === "teacher" ? "" : "portal-button--quiet"}" data-reg-role="teacher">Teacher</button>
            </div>
          </div>
          <form class="portal-form" data-reg-form>
            <div class="portal-form-grid">
              <div class="portal-field"><label>Full Name *</label><input name="fullName" required></div>
              <div class="portal-field"><label>Email Address *</label><input name="email" type="email" required></div>
              <div class="portal-field"><label>Mobile Number *</label><input name="phone" required placeholder="10-digit mobile"></div>
              <div class="portal-field"><label>Password (min 8 chars) *</label><input name="password" type="password" minlength="8" required></div>
              ${
                role === "student"
                  ? `
                <div class="portal-field"><label>Class / Level</label>
                  <select name="classLevel">${["Class 6", "Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12", "JEE / NEET / CUET", "Computer / AI", "Spoken English"].map((c) => `<option>${c}</option>`).join("")}</select>
                </div>
                <div class="portal-field"><label>Board / Track</label>
                  <select name="board"><option>CBSE</option><option>ICSE</option><option>UP Board</option><option>Skill / Competitive</option></select>
                </div>
                <div class="portal-field"><label>Subjects (comma separated)</label><input name="subjects" value="Mathematics, Science"></div>
                <div class="portal-field"><label>Course Duration (months)</label><input name="courseDurationMonths" type="number" value="12" min="1" max="60"></div>
              `
                  : `
                <div class="portal-field"><label>Qualification *</label><input name="qualification" required placeholder="e.g. M.Sc Physics, B.Ed"></div>
                <div class="portal-field"><label>Experience (Years)</label><input name="experienceYears" type="number" min="0" max="50" value="2"></div>
                <div class="portal-field"><label>Teaching Subjects (comma separated)</label><input name="subjects" placeholder="Physics, Mathematics"></div>
                <div class="portal-field"><label>Assigned Classes (comma separated)</label><input name="assignedClasses" placeholder="Class 9, Class 10"></div>
              `
              }
            </div>
            <div class="portal-message" data-reg-fb hidden></div>
            <button type="submit" class="portal-button">Register &amp; Request Mobile OTP</button>
          </form>
          <div class="portal-inline-links"><a href="/login">Already registered? Sign in</a></div>
        </div>`);

      main.querySelectorAll("[data-reg-role]").forEach((b) => {
        b.addEventListener("click", () => {
          role = b.getAttribute("data-reg-role");
          draw();
        });
      });

      main.querySelector("[data-reg-form]").addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const fb = main.querySelector("[data-reg-fb]");
        try {
          const splitCsv = (v) => String(v || "").split(",").map((x) => x.trim()).filter(Boolean);
          const payload = {
            role,
            fullName: fd.get("fullName"),
            email: fd.get("email"),
            phone: fd.get("phone"),
            password: fd.get("password"),
            classLevel: fd.get("classLevel"),
            board: fd.get("board"),
            courseDurationMonths: Number(fd.get("courseDurationMonths") || 12),
            qualification: fd.get("qualification"),
            experienceYears: Number(fd.get("experienceYears") || 0),
            subjects: splitCsv(fd.get("subjects")),
            assignedClasses: splitCsv(fd.get("assignedClasses")),
          };
          const res = await api("/api/auth/register", { method: "POST", body: payload });
          registeredPhone = res.phone;
          limitationMsg = res.limitationNote || "";
          step = "otp";
          draw();
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
        }
      });
    }
    draw();
  }

  // ==================== ADMIN PANEL ====================
  async function renderAdminPanel(session) {
    let tab = "dashboard";
    let userFilterStatus = "all";
    let userFilterRole = "all";
    let userSearch = "";
    let userPage = 1;
    let showCreateUser = false;
    let selectedUserDetail = null;
    let editingCourse = null;
    let chatFilterStatus = "all";
    let chatSearch = "";
    let chatMinRating = 0;
    let selectedChatDetail = null;
    let selectedCampaignDeliveries = null;
    let feedbackMsg = "";

    async function loadAndDraw() {
      const [dash, usersRes, coursesRes, paymentsRes, inquiriesRes, cmsRes, chatsRes, mktRes, notifsRes, backupsRes] = await Promise.all([
        api("/api/admin/dashboard"),
        api(`/api/admin/users?role=${encodeURIComponent(userFilterRole)}&status=${encodeURIComponent(userFilterStatus)}&search=${encodeURIComponent(userSearch)}&page=${userPage}&pageSize=12`),
        api("/api/admin/courses"),
        api("/api/admin/payments"),
        api("/api/admin/inquiries"),
        api("/api/admin/cms"),
        api(`/api/admin/chatbot?status=${encodeURIComponent(chatFilterStatus)}&search=${encodeURIComponent(chatSearch)}&minRating=${chatMinRating}`),
        api("/api/marketing/overview"),
        api("/api/admin/notifications"),
        api("/api/admin/backups"),
      ]);

      const navItems = [
        ["dashboard", "Dashboard Overview", "dashboard"],
        ["users", "Users & Approvals", "users"],
        ["courses", "Courses & Subjects", "book"],
        ["payments", "Fees & Payments", "wallet"],
        ["cms", "Inquiries & CMS", "megaphone"],
        ["chatbot", "Shreya Chatbot", "bot"],
        ["marketing", "Email Marketing", "mail"],
        ["backups", "Database Backups", "database"],
      ];

      let bodyHtml = feedbackMsg ? `<div class="portal-message portal-message--success">${escapeHtml(feedbackMsg)}</div>` : "";
      feedbackMsg = "";

      if (tab === "dashboard") {
        const c = dash.counts;
        const f = dash.feeSummary;
        bodyHtml += `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${c.totalStudents}</strong><span>Total Students</span></div><div class="portal-stat-icon">${icon("users")}</div></div>
            <div class="portal-stat"><div><strong>${c.totalTeachers}</strong><span>Total Teachers</span></div><div class="portal-stat-icon">${icon("user")}</div></div>
            <div class="portal-stat"><div><strong>${c.pendingApprovals}</strong><span>Pending Approvals</span></div><div class="portal-stat-icon">${icon("shield")}</div></div>
            <div class="portal-stat"><div><strong>${c.totalCourses}</strong><span>Active Courses</span></div><div class="portal-stat-icon">${icon("book")}</div></div>
            <div class="portal-stat"><div><strong>${c.totalAdmissions}</strong><span>Confirmed Admissions</span></div><div class="portal-stat-icon">${icon("award")}</div></div>
            <div class="portal-stat"><div><strong>${c.newInquiries}</strong><span>New Website Inquiries</span></div><div class="portal-stat-icon">${icon("megaphone")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(f.totalCollected)}</strong><span>Verified Fees (${formatINR(f.totalPending)} pending)</span></div><div class="portal-stat-icon">${icon("wallet")}</div></div>
            <div class="portal-stat"><div><strong>${c.unresolvedChats}</strong><span>Unresolved Shreya Chats</span></div><div class="portal-stat-icon">${icon("bot")}</div></div>
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Recent Audit Activity</div>
            <div class="portal-table-scroll">
              <table class="portal-table">
                <thead><tr><th>Action</th><th>Actor</th><th>Target</th><th>Details</th><th>Timestamp</th></tr></thead>
                <tbody>
                  ${(dash.recentActivities || []).map((a) => `<tr><td>${escapeHtml(a.action)}</td><td>${escapeHtml(a.actor_name || "-")}</td><td>${escapeHtml(a.target_name || "-")}</td><td>${escapeHtml(a.details || "")}</td><td>${escapeHtml(a.created_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No activity logs yet.</td></tr>`}
                </tbody>
              </table>
            </div>
          </div>`;
      } else if (tab === "users") {
        if (selectedUserDetail) {
          const u = selectedUserDetail.user;
          const sp = selectedUserDetail.studentProfile || {};
          const tp = selectedUserDetail.teacherProfile || {};
          bodyHtml += `
            <div class="portal-card portal-profile">
              <div class="portal-profile-head">
                <div><h2>${escapeHtml(u.full_name)}</h2><p>${escapeHtml(u.role)} · ${escapeHtml(u.email)} · ${escapeHtml(u.phone)}</p></div>
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-back-users>← Back to Users</button>
              </div>
              <div class="portal-personal-grid" style="margin-bottom:16px;">
                <div class="portal-detail"><span>Verification Status</span><strong>${statusBadge(u.verification_status)}</strong></div>
                <div class="portal-detail"><span>Mobile OTP Verified</span><strong>${u.mobile_verified ? "Yes" : "No"}</strong></div>
                <div class="portal-detail"><span>Account Active</span><strong>${u.is_active ? "Yes" : "Disabled"}</strong></div>
              </div>
              <div class="portal-actions" style="margin-bottom:20px;">
                <button type="button" class="portal-button portal-button--small" data-user-act="approve" data-uid="${u.id}">Approve</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-user-act="activate" data-uid="${u.id}">Activate</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-user-act="suspend" data-uid="${u.id}">Suspend</button>
                <button type="button" class="portal-button portal-button--small portal-button--danger" data-user-act="reject" data-uid="${u.id}">Reject</button>
                ${["student", "teacher"].includes(u.role) ? `<button type="button" class="portal-button portal-button--small" data-impersonate-uid="${u.id}">Impersonate Panel</button>` : ""}
              </div>
              <h3 class="portal-section-title">Edit Account &amp; Profile</h3>
              <form class="portal-form" data-edit-user-form="${u.id}" style="margin-bottom:20px;">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Full Name</label><input name="fullName" value="${escAttr(u.full_name)}" required></div>
                  <div class="portal-field"><label>Email</label><input name="email" type="email" value="${escAttr(u.email)}" required></div>
                  <div class="portal-field"><label>Phone</label><input name="phone" value="${escAttr(u.phone)}" required></div>
                  ${
                    u.role === "student"
                      ? `<div class="portal-field"><label>Class / Level</label><input name="classLevel" value="${escAttr(sp.class_level || "")}"></div>
                         <div class="portal-field"><label>Board</label><input name="board" value="${escAttr(sp.board || "CBSE")}"></div>
                         <div class="portal-field"><label>Duration (months)</label><input name="courseDurationMonths" type="number" value="${Number(sp.course_duration_months || 12)}"></div>`
                      : u.role === "teacher"
                        ? `<div class="portal-field"><label>Qualification</label><input name="qualification" value="${escAttr(tp.qualification || "")}"></div>
                           <div class="portal-field"><label>Experience (years)</label><input name="experienceYears" type="number" value="${Number(tp.experience_years || 0)}"></div>`
                        : ""
                  }
                </div>
                <div><button type="submit" class="portal-button portal-button--small">Save Profile Changes</button></div>
              </form>
              <h3 class="portal-section-title">OTP Summary</h3>
              <div class="portal-table-scroll" style="margin-bottom:20px;"><table class="portal-table"><thead><tr><th>Purpose</th><th>Attempts</th><th>Consumed</th><th>Created</th></tr></thead><tbody>
                ${(selectedUserDetail.otpSummary || []).map((o) => `<tr><td>${escapeHtml(o.purpose)}</td><td>${o.attempts}</td><td>${o.consumed_at ? "Yes" : "Pending"}</td><td>${new Date(Number(o.created_at) * 1000).toLocaleString()}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No OTP logs.</td></tr>`}
              </tbody></table></div>
              <h3 class="portal-section-title">Account Audit History</h3>
              <div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Action</th><th>Details</th><th>IP</th><th>Date</th></tr></thead><tbody>
                ${(selectedUserDetail.history || []).map((h) => `<tr><td>${escapeHtml(h.action)}</td><td>${escapeHtml(h.details)}</td><td>${escapeHtml(h.ip_address)}</td><td>${escapeHtml(h.created_at)}</td></tr>`).join("")}
              </tbody></table></div>
            </div>`;
        } else {
          const totalPages = Math.max(1, Math.ceil((usersRes.total || 0) / (usersRes.pageSize || 12)));
          bodyHtml += `
            <div class="portal-toolbar">
              <input type="search" data-admin-usearch value="${escAttr(userSearch)}" placeholder="Search name, email, phone...">
              <div class="portal-toolbar-actions">
                <select data-admin-urole style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  ${[["all", "All Roles"], ["student", "Students"], ["teacher", "Teachers"], ["admin", "Admins"], ["super_admin", "Super Admins"]].map(([k, l]) => `<option value="${k}"${userFilterRole === k ? " selected" : ""}>${l}</option>`).join("")}
                </select>
                <select data-admin-ustatus style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  ${[["all", "All Statuses"], ["pending_approval", "Pending Approval"], ["pending_otp", "Pending OTP"], ["approved", "Approved"], ["suspended", "Suspended"], ["rejected", "Rejected"]].map(([k, l]) => `<option value="${k}"${userFilterStatus === k ? " selected" : ""}>${l}</option>`).join("")}
                </select>
                <button type="button" class="portal-button portal-button--small" data-toggle-new-user>${showCreateUser ? "Close Form" : "+ Create User"}</button>
              </div>
            </div>
            ${
              showCreateUser
                ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                    <h3 class="portal-section-title">Create Approved Account (Student / Teacher / Admin)</h3>
                    <form class="portal-form" data-admin-create-user>
                      <div class="portal-form-grid">
                        <div class="portal-field"><label>Role</label><select name="role"><option value="student">Student</option><option value="teacher">Teacher</option>${session.user.role === "super_admin" ? `<option value="admin">Admin</option>` : ""}</select></div>
                        <div class="portal-field"><label>Full Name *</label><input name="fullName" required></div>
                        <div class="portal-field"><label>Email *</label><input name="email" type="email" required></div>
                        <div class="portal-field"><label>Phone *</label><input name="phone" required></div>
                        <div class="portal-field"><label>Password (min 8 chars) *</label><input name="password" type="password" minlength="8" required></div>
                        <div class="portal-field"><label>Class / Qualification</label><input name="extra" placeholder="Class 10 or M.Sc"></div>
                      </div>
                      <button type="submit" class="portal-button portal-button--small">Create Approved User</button>
                    </form>
                  </div>`
                : ""
            }
            <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Name</th><th>Contact</th><th>Role</th><th>OTP</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                ${(usersRes.users || []).map((u) => `<tr>
                  <td><span class="portal-cell-title">${escapeHtml(u.full_name)}</span><span class="portal-cell-sub">${escapeHtml(u.class_level || u.qualification || "")}</span></td>
                  <td>${escapeHtml(u.email)}<span class="portal-cell-sub">${escapeHtml(u.phone)}</span></td>
                  <td>${escapeHtml(u.role)}</td>
                  <td>${u.mobile_verified ? "Verified" : "Unverified"}</td>
                  <td>${statusBadge(u.verification_status)}</td>
                  <td>
                    <div class="portal-actions">
                      <button type="button" class="portal-button portal-button--small portal-button--quiet" data-view-uid="${u.id}">Manage</button>
                      ${u.verification_status !== "approved" && u.role !== "super_admin" ? `<button type="button" class="portal-button portal-button--small" data-user-act="approve" data-uid="${u.id}">Approve</button>` : ""}
                      ${["student", "teacher"].includes(u.role) ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-impersonate-uid="${u.id}">Impersonate</button>` : ""}
                    </div>
                  </td>
                </tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No users match the filter.</td></tr>`}
              </tbody>
            </table></div>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-top:1px solid var(--pt-border);font-size:12px;">
              <span>Showing page ${userPage} of ${totalPages} (${usersRes.total || 0} total)</span>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-upage="${userPage - 1}" ${userPage <= 1 ? "disabled" : ""}>Prev</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-upage="${userPage + 1}" ${userPage >= totalPages ? "disabled" : ""}>Next</button>
              </div>
            </div></div>`;
        }
      } else if (tab === "courses") {
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">${editingCourse ? `Edit Course: ${escapeHtml(editingCourse.title)}` : "Create Course"}</h3>
            <form class="portal-form" ${editingCourse ? `data-edit-course-form="${editingCourse.id}"` : "data-new-course-form"}>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Title *</label><input name="title" required value="${escAttr(editingCourse?.title || "")}"></div>
                <div class="portal-field"><label>Category</label><select name="category">${["Classes 6-12", "Competitive", "Computer", "AI Learning", "English Speaking"].map((cat) => `<option${editingCourse?.category === cat ? " selected" : ""}>${cat}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Class / Level</label><input name="classRange" value="${escAttr(editingCourse?.class_range || "Classes 9–10")}"></div>
                <div class="portal-field"><label>Monthly Fee (₹)</label><input name="monthlyFee" type="number" value="${editingCourse?.monthly_fee ?? 1400}" required></div>
                <div class="portal-field"><label>Yearly Fee (₹)</label><input name="yearlyFee" type="number" value="${editingCourse?.yearly_fee ?? 14300}" required></div>
                <div class="portal-field"><label>Assign Teacher</label><select name="teacherId"><option value="">Unassigned</option>${(coursesRes.teachers || []).map((t) => `<option value="${t.id}"${Number(editingCourse?.teacher_id) === Number(t.id) ? " selected" : ""}>${escapeHtml(t.full_name)}</option>`).join("")}</select></div>
              </div>
              <div class="portal-actions">
                <button type="submit" class="portal-button portal-button--small">${editingCourse ? "Update Course" : "Create Course"}</button>
                ${editingCourse ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-edit-course>Cancel</button>` : ""}
              </div>
            </form>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Course</th><th>Category</th><th>Teacher</th><th>Monthly / Yearly</th><th>Students</th><th>Actions</th></tr></thead>
            <tbody>
              ${(coursesRes.courses || []).map((c) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(c.title)}</span><span class="portal-cell-sub">${escapeHtml(c.class_range)}</span></td>
                <td>${escapeHtml(c.category)}</td>
                <td>${escapeHtml(c.teacher_name || "Unassigned")}</td>
                <td>${formatINR(c.monthly_fee)} / ${formatINR(c.yearly_fee)}</td>
                <td>${c.active_students}</td>
                <td><div class="portal-actions">
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-edit-course="${c.id}">Edit</button>
                  <button type="button" class="portal-button portal-button--small portal-button--danger" data-del-course="${c.id}">Delete</button>
                </div></td>
              </tr>`).join("")}
            </tbody>
          </table></div></div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Manage Subjects (${(coursesRes.subjects || []).length})</h3>
            <form class="portal-form" data-new-subject-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Subject Name *</label><input name="name" required placeholder="e.g. Organic Chemistry"></div>
                <div class="portal-field"><label>Subject Code *</label><input name="code" required placeholder="CHEM-12"></div>
                <div class="portal-field"><label>Class Level</label><input name="classLevel" value="Classes 11–12"></div>
                <div class="portal-field"><label>Description</label><input name="description" placeholder="Short syllabus overview"></div>
              </div>
              <div><button type="submit" class="portal-button portal-button--small">Add Subject</button></div>
            </form>
            <div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Subject</th><th>Code</th><th>Class</th><th>Action</th></tr></thead><tbody>
              ${(coursesRes.subjects || []).map((s) => `<tr><td>${escapeHtml(s.name)}</td><td>${escapeHtml(s.code)}</td><td>${escapeHtml(s.class_level)}</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-subject="${s.id}">Delete</button></td></tr>`).join("")}
            </tbody></table></div>
          </div>`;
      } else if (tab === "payments") {
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Discount Coupons (${(paymentsRes.coupons || []).length})</h3>
            <form class="portal-form" data-coupon-form style="margin-bottom:12px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Code *</label><input name="code" required placeholder="YUITOR15"></div>
                <div class="portal-field"><label>Type</label><select name="discountType"><option value="percent">Percentage (%)</option><option value="flat">Flat (₹)</option></select></div>
                <div class="portal-field"><label>Value *</label><input name="discountValue" type="number" required value="10"></div>
                <div class="portal-field"><label>Max Uses</label><input name="maxUses" type="number" value="100"></div>
              </div>
              <div><button type="submit" class="portal-button portal-button--small">Add Coupon</button></div>
            </form>
            ${(paymentsRes.coupons || []).map((cp) => `<span class="portal-status" style="margin-right:6px;">${escapeHtml(cp.code)} (${cp.discount_type === "percent" ? cp.discount_value + "%" : formatINR(cp.discount_value)} · ${cp.used_count}/${cp.max_uses})</span>`).join("")}
          </div>
          <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Student</th><th>Course</th><th>Amount</th><th>Method / Ref</th><th>Status</th><th>Receipt</th><th>Actions</th></tr></thead>
            <tbody>
              ${(paymentsRes.payments || []).map((p) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(p.student_name)}</span><span class="portal-cell-sub">${escapeHtml(p.student_phone)}</span></td>
                <td>${escapeHtml(p.course_title)}</td>
                <td>${formatINR(p.amount)}</td>
                <td>${escapeHtml(p.payment_method)} ${p.gateway_payment_id ? "· " + escapeHtml(p.gateway_payment_id) : ""}</td>
                <td>${statusBadge(p.verification_status)}</td>
                <td>${escapeHtml(p.receipt_number || "-")}</td>
                <td><div class="portal-actions">
                  ${p.verification_status === "pending_verification" ? `<button type="button" class="portal-button portal-button--small" data-pay-verify="${p.id}" data-dec="verify">Verify</button><button type="button" class="portal-button portal-button--small portal-button--quiet" data-pay-verify="${p.id}" data-dec="fail">Reject</button>` : ""}
                  ${p.verification_status === "verified" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-pay-refund="${p.id}">Refund</button>` : ""}
                </div></td>
              </tr>`).join("") || `<tr><td colspan="7" class="portal-empty">No payments submitted yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
      } else if (tab === "cms") {
        bodyHtml += `
          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Website Inquiries (${(inquiriesRes.inquiries || []).length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Name</th><th>Phone</th><th>Course</th><th>Message</th><th>Status</th><th>Update / Delete</th></tr></thead>
              <tbody>
                ${(inquiriesRes.inquiries || []).map((q) => `<tr>
                  <td><span class="portal-cell-title">${escapeHtml(q.name)}</span><span class="portal-cell-sub">${escapeHtml(q.email)}</span></td>
                  <td>${escapeHtml(q.phone)}</td>
                  <td>${escapeHtml(q.class_or_course)}</td>
                  <td><span class="portal-cell-message">${escapeHtml(q.message)}</span></td>
                  <td>${statusBadge(q.status)}</td>
                  <td><div class="portal-actions">
                    <select data-inq-status="${q.id}" style="min-height:32px;border:1px solid var(--pt-border);border-radius:8px;padding:2px 6px;">
                      ${["new", "contacted", "admitted", "closed"].map((st) => `<option value="${st}"${q.status === st ? " selected" : ""}>${st}</option>`).join("")}
                    </select>
                    <button type="button" class="portal-button portal-button--small portal-button--danger" data-del-inq="${q.id}">Delete</button>
                  </div></td>
                </tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No inquiries yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>

          <div class="portal-form-grid" style="margin-bottom:16px;">
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Publish Notice / Announcement</h3>
              <form class="portal-form" data-ann-form>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
                <div class="portal-field"><label>Audience</label><select name="audience"><option value="all">All Users</option><option value="students">Students</option><option value="teachers">Teachers</option><option value="public">Public</option></select></div>
                <div class="portal-field"><label>Message</label><textarea name="body" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Publish Notice</button>
              </form>
              <div style="margin-top:12px;">
                ${(cmsRes.announcements || []).map((a) => `<div class="portal-detail" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(a.title)}</strong><span>${escapeHtml(a.audience)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-ann="${a.id}">Delete</button></div>`).join("")}
              </div>
            </div>

            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Homepage / Promo Banners</h3>
              <form class="portal-form" data-banner-form>
                <div class="portal-field"><label>Headline</label><input name="title" required></div>
                <div class="portal-field"><label>Subtitle</label><input name="subtitle"></div>
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Button Label</label><input name="ctaLabel" value="Apply for Admission"></div>
                  <div class="portal-field"><label>Link</label><input name="ctaHref" value="/admission"></div>
                </div>
                <button type="submit" class="portal-button portal-button--small">Add Banner</button>
              </form>
              <div style="margin-top:12px;">
                ${(cmsRes.banners || []).map((b) => `<div class="portal-detail" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(b.title)}</strong><span>${escapeHtml(b.cta_href)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-banner="${b.id}">Delete</button></div>`).join("")}
              </div>
            </div>
          </div>

          <div class="portal-form-grid">
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Blog Posts (${(cmsRes.blogPosts || []).length})</h3>
              <form class="portal-form" data-blog-form>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
                <div class="portal-field"><label>Category</label><input name="category" value="Study Tips"></div>
                <div class="portal-field"><label>Excerpt</label><input name="excerpt"></div>
                <div class="portal-field"><label>Article Content</label><textarea name="content" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Publish Article</button>
              </form>
              <div style="margin-top:12px;">
                ${(cmsRes.blogPosts || []).map((p) => `<div class="portal-detail" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(p.title)}</strong><span>${escapeHtml(p.category)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-blog="${p.id}">Delete</button></div>`).join("")}
              </div>
            </div>

            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">FAQs &amp; Testimonials</h3>
              <form class="portal-form" data-faq-form style="margin-bottom:14px;">
                <div class="portal-field"><label>FAQ Question</label><input name="question" required></div>
                <div class="portal-field"><label>Answer</label><textarea name="answer" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Add FAQ</button>
              </form>
              ${(cmsRes.faqs || []).map((f) => `<div class="portal-detail" style="margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(f.question)}</strong></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-faq="${f.id}">Delete</button></div>`).join("")}
              <form class="portal-form" data-test-form style="margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Author Name</label><input name="authorName" required></div>
                  <div class="portal-field"><label>Role / Batch</label><input name="authorRole" required placeholder="Class 12 Student"></div>
                </div>
                <div class="portal-field"><label>Outcome Metric</label><input name="outcomeMetric" placeholder="95% in Boards"></div>
                <div class="portal-field"><label>Quote</label><textarea name="quote" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Add Testimonial</button>
              </form>
              <div style="margin-top:10px;">
                ${(cmsRes.testimonials || []).map((t) => `<div class="portal-detail" style="margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(t.author_name)}</strong><span>${escapeHtml(t.outcome_metric)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-test="${t.id}">Delete</button></div>`).join("")}
              </div>
            </div>
          </div>`;
      } else if (tab === "chatbot") {
        if (selectedChatDetail) {
          bodyHtml += `
            <div class="portal-card portal-profile">
              <div class="portal-profile-head">
                <div><h2>Shreya Transcript</h2><p>${escapeHtml(selectedChatDetail.conversation.visitor_name || "Visitor")} · ${statusBadge(selectedChatDetail.conversation.status)}</p></div>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-chat-back>← All Conversations</button>
              </div>
              <div style="display:grid;gap:10px;margin-bottom:16px;">
                ${(selectedChatDetail.messages || []).map((m) => `<div class="portal-detail"><span>${escapeHtml(m.sender)} · ${escapeHtml(m.created_at)}</span><strong style="font-weight:500;">${escapeHtml(m.message)}</strong></div>`).join("")}
              </div>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--small" data-chat-status="${escAttr(selectedChatDetail.conversation.id)}" data-st="resolved">Mark Resolved</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-chat-status="${escAttr(selectedChatDetail.conversation.id)}" data-st="escalated">Escalate to Team</button>
              </div>
            </div>`;
        } else {
          bodyHtml += `
            <div class="portal-toolbar">
              <input type="search" data-chat-search value="${escAttr(chatSearch)}" placeholder="Search transcripts, visitor name/phone...">
              <div class="portal-toolbar-actions">
                <select data-chat-status-filter style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  ${[["all", "All Statuses"], ["active", "Active"], ["unresolved", "Unresolved"], ["escalated", "Escalated"], ["resolved", "Resolved"]].map(([k, l]) => `<option value="${k}"${chatFilterStatus === k ? " selected" : ""}>${l}</option>`).join("")}
                </select>
                <select data-chat-rating-filter style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  <option value="0"${chatMinRating === 0 ? " selected" : ""}>Any Rating</option>
                  ${[1, 2, 3, 4, 5].map((r) => `<option value="${r}"${chatMinRating === r ? " selected" : ""}>${r}+ Stars</option>`).join("")}
                </select>
              </div>
            </div>
            <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Visitor</th><th>Last Message</th><th>Status</th><th>Rating</th><th>View</th></tr></thead>
              <tbody>
                ${(chatsRes.conversations || []).map((c) => `<tr>
                  <td><span class="portal-cell-title">${escapeHtml(c.visitor_name || "Anonymous Visitor")}</span><span class="portal-cell-sub">${escapeHtml(c.visitor_phone || c.visitor_email || c.visitor_id)}</span></td>
                  <td><span class="portal-cell-message">${escapeHtml(c.last_message || "")}</span></td>
                  <td>${statusBadge(c.status)}</td>
                  <td>${c.rating ? `${c.rating}/5` : "-"}</td>
                  <td><button type="button" class="portal-button portal-button--small portal-button--quiet" data-open-chat="${escAttr(c.id)}">Transcript</button></td>
                </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No Shreya chatbot conversations match.</td></tr>`}
              </tbody>
            </table></div></div>`;
        }
      } else if (tab === "marketing") {
        const mktSum = mktRes.summary || { totalCampaigns: 0, totalEligible: 0, totalSent: 0, totalFailed: 0 };
        const recipientsList = [...(mktRes.students || []).map((u) => ({ ...u, role: "Student" })), ...(mktRes.teachers || []).map((u) => ({ ...u, role: "Teacher" }))];
        bodyHtml += `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${mktSum.totalCampaigns}</strong><span>Campaigns</span></div><div class="portal-stat-icon">${icon("mail")}</div></div>
            <div class="portal-stat"><div><strong>${mktSum.totalEligible}</strong><span>Queued Recipients</span></div><div class="portal-stat-icon">${icon("users")}</div></div>
            <div class="portal-stat"><div><strong>${mktSum.totalSent}</strong><span>Emails Sent</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${mktSum.totalFailed}</strong><span>Failed / Pending SMTP</span></div><div class="portal-stat-icon">${icon("megaphone")}</div></div>
          </div>
          <div class="portal-message">Sender: <strong>${escapeHtml(mktRes.senderEmail)}</strong> · Reply-To: <strong>${escapeHtml(mktRes.replyToEmail)}</strong> · SMTP Status: <strong>${mktRes.smtpConfigured ? "Configured" : "Not Configured (configure SMTP_* in .env before sending live emails)"}</strong>${mktSum.openClickTrackingNote ? ` · ${escapeHtml(mktSum.openClickTrackingNote)}` : ""}</div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Create &amp; Send Email Campaign</h3>
            <form class="portal-form" data-mkt-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Campaign Name *</label><input name="name" required placeholder="e.g. Board Exam Batch Alert"></div>
                <div class="portal-field"><label>Load Reusable Template (${(mktRes.templates || []).length})</label>
                  <select data-mkt-tmpl><option value="">Custom Email</option>${(mktRes.templates || []).map((t) => `<option value="${t.id}">${escapeHtml(t.name)} (${escapeHtml(t.category)})</option>`).join("")}</select>
                </div>
                <div class="portal-field"><label>Segment Audience</label>
                  <select name="audienceGroup">
                    <option value="all_students">All Eligible Students</option>
                    <option value="all_teachers">All Eligible Teachers</option>
                    <option value="all_opted_in">All Students &amp; Teachers</option>
                    <option value="recently_registered">Recently Registered (30 days)</option>
                  </select>
                </div>
                <div class="portal-field"><label>Account Status Filter</label>
                  <select name="accountStatus"><option value="all">Any</option><option value="approved">Approved Only</option><option value="pending_approval">Pending Approval</option></select>
                </div>
                <div class="portal-field"><label>Class Filter (Optional)</label><input name="classLevel" placeholder="e.g. Class 10"></div>
                <div class="portal-field"><label>Subject Keyword (Optional)</label><input name="subjectFilter" placeholder="e.g. Mathematics"></div>
                <div class="portal-field"><label>Course Filter</label><select name="courseId"><option value="">Any Course</option>${(mktRes.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Registered After</label><input name="registeredAfter" type="date"></div>
                <div class="portal-field"><label>Email Subject *</label><input name="subject" required></div>
                <div class="portal-field"><label>Preview Text (Optional)</label><input name="previewText" placeholder="Inbox snippet line..."></div>
                <div class="portal-field"><label>CTA Button Label (Optional)</label><input name="ctaLabel" placeholder="e.g. Apply for Admission"></div>
                <div class="portal-field"><label>CTA Link URL (Optional)</label><input name="ctaUrl" placeholder="https://yuitor.com/admission"></div>
                <div class="portal-field"><label>Send Mode</label><select name="sendMode"><option value="draft">Save Draft</option><option value="immediate">Send Immediately</option><option value="scheduled">Schedule</option></select></div>
                <div class="portal-field"><label>Schedule Date &amp; Time (if Scheduled)</label><input name="scheduledAt" type="datetime-local"></div>
                <div class="portal-field"><label>Optional Attachment (PDF / Image, max 5 MB)</label><input name="attachmentFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
              </div>
              <div class="portal-field">
                <label>Or Select Specific Recipients (Optional — leave unchecked to use segment filters)</label>
                <div class="portal-email-recipient-list">
                  ${recipientsList.map((u) => `<label class="portal-email-recipient"><input type="checkbox" name="selectedUid" value="${u.id}"><span><strong>${escapeHtml(u.full_name)}</strong> (${u.role})<br><span style="color:var(--pt-muted);">${escapeHtml(u.email)}</span></span></label>`).join("") || `<span class="portal-hint">No contacts found.</span>`}
                </div>
              </div>
              <div class="portal-field"><label>HTML Body (supports {{name}}) *</label><textarea name="htmlBody" rows="5" required><p>Dear {{name}},</p><p>Admissions are open at Yuitor Smart Classes, Muradnagar.</p></textarea></div>
              <div class="portal-message" data-mkt-preview hidden></div>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-mkt-check>Preview Eligible Recipients</button>
                <button type="submit" class="portal-button portal-button--small">Create Campaign</button>
              </div>
            </form>
            <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
              <h4 style="margin:0 0 8px;font-size:13px;">Send Test Email</h4>
              <div class="portal-actions">
                <input type="email" data-test-email placeholder="recipient@example.com" style="min-height:36px;border:1px solid var(--pt-border);border-radius:8px;padding:0 10px;">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-test-send-btn>Send Test</button>
              </div>
              <div class="portal-message" data-test-fb hidden style="margin-top:8px;"></div>
            </div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Campaign</th><th>Recipients</th><th>Sent / Failed</th><th>Status</th><th>Controls</th></tr></thead>
            <tbody>
              ${(mktRes.campaigns || []).map((cp) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(cp.name)}</span><span class="portal-cell-sub">${escapeHtml(cp.subject)}</span></td>
                <td>${cp.total_recipients} eligible (${cp.excluded_count} excluded)</td>
                <td>${cp.sent_count} sent / ${cp.failed_count} failed</td>
                <td>${statusBadge(cp.status)}</td>
                <td><div class="portal-actions">
                  ${cp.status !== "cancelled" && cp.status !== "completed" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-camp-act="${cp.id}" data-act="pause">Pause</button><button type="button" class="portal-button portal-button--small" data-camp-act="${cp.id}" data-act="process_now">Process</button>` : ""}
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-camp-deliveries="${cp.id}">Logs</button>
                </div></td>
              </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No campaigns yet.</td></tr>`}
            </tbody>
          </table></div></div>
          ${
            selectedCampaignDeliveries
              ? `<div class="portal-card portal-table-card" style="margin-bottom:16px;"><div style="padding:12px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Delivery Logs</div><div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Recipient</th><th>Status</th><th>Error / ID</th><th>Timestamp</th></tr></thead><tbody>
                ${selectedCampaignDeliveries.map((d) => `<tr><td>${escapeHtml(d.recipient_name)} (${escapeHtml(d.recipient_email)})</td><td>${statusBadge(d.status)}</td><td>${escapeHtml(d.error_message || d.provider_message_id || "-")}</td><td>${escapeHtml(d.sent_at || d.created_at || "")}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No deliveries queued.</td></tr>`}
              </tbody></table></div></div>`
              : ""
          }
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Email Suppression List (${(mktRes.suppressions || []).length})</h3>
            <form class="portal-form" data-supp-form style="margin-bottom:10px;">
              <div class="portal-actions">
                <input name="email" type="email" required placeholder="optout@example.com" style="min-height:36px;border:1px solid var(--pt-border);border-radius:8px;padding:0 10px;">
                <select name="reason" style="min-height:36px;border:1px solid var(--pt-border);border-radius:8px;padding:0 8px;"><option value="unsubscribed">Unsubscribed</option><option value="bounced">Bounced</option><option value="complaint">Complaint</option></select>
                <button type="submit" class="portal-button portal-button--small portal-button--quiet">Add Suppression</button>
              </div>
            </form>
            <p class="portal-hint">${(mktRes.suppressions || []).map((s) => `${escapeHtml(s.email)} (${escapeHtml(s.reason)})`).join(" · ") || "No suppressed addresses."}</p>
          </div>`;
      } else if (tab === "backups") {
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;">
            <div>
              <h3 class="portal-section-title" style="margin:0;">SQLite Database Backups</h3>
              <p class="portal-hint">Atomic VACUUM INTO snapshots stored safely inside /backups (auto-created on server startup + on demand).</p>
            </div>
            <div class="portal-actions">
              <a href="/api/admin/project-zip" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download Final Project ZIP</a>
              <button type="button" class="portal-button portal-button--small" data-create-backup>${icon("database")} Create Backup Now</button>
            </div>
          </div>
          <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Filename</th><th>Size</th><th>Created</th><th>Download</th></tr></thead>
            <tbody>
              ${(backupsRes.backups || []).map((b) => `<tr><td><strong>${escapeHtml(b.filename)}</strong></td><td>${(b.sizeBytes / 1024).toFixed(1)} KB</td><td>${escapeHtml(b.createdAt)}</td><td><a href="/api/admin/backups/${escAttr(b.filename)}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download .db</a></td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No backups recorded yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
      }

      const main = renderWorkspace({
        session,
        portalTitle: "Admin Console",
        navItems,
        activeTab: tab,
        onTabChange: (next) => {
          tab = next;
          selectedUserDetail = null;
          selectedChatDetail = null;
          editingCourse = null;
          loadAndDraw();
        },
        notifications: notifsRes.notifications || [],
        onReadNotifs: async () => {
          await api("/api/admin/notifications/read-all", { method: "POST" });
          loadAndDraw();
        },
        bodyHtml,
      });

      // Users handlers
      main.querySelector("[data-admin-usearch]")?.addEventListener("change", (e) => {
        userSearch = e.target.value;
        userPage = 1;
        loadAndDraw();
      });
      main.querySelector("[data-admin-urole]")?.addEventListener("change", (e) => {
        userFilterRole = e.target.value;
        userPage = 1;
        loadAndDraw();
      });
      main.querySelector("[data-admin-ustatus]")?.addEventListener("change", (e) => {
        userFilterStatus = e.target.value;
        userPage = 1;
        loadAndDraw();
      });
      main.querySelectorAll("[data-upage]").forEach((b) => {
        b.addEventListener("click", () => {
          userPage = Math.max(1, Number(b.getAttribute("data-upage")));
          loadAndDraw();
        });
      });
      main.querySelector("[data-toggle-new-user]")?.addEventListener("click", () => {
        showCreateUser = !showCreateUser;
        loadAndDraw();
      });
      main.querySelector("[data-admin-create-user]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const role = fd.get("role");
        await api("/api/admin/users", {
          method: "POST",
          body: {
            role,
            fullName: fd.get("fullName"),
            email: fd.get("email"),
            phone: fd.get("phone"),
            password: fd.get("password"),
            classLevel: role === "student" ? fd.get("extra") || "Class 10" : undefined,
            qualification: role === "teacher" ? fd.get("extra") || "" : undefined,
          },
        });
        showCreateUser = false;
        feedbackMsg = "User created & approved successfully.";
        loadAndDraw();
      });
      main.querySelectorAll("[data-view-uid]").forEach((b) => {
        b.addEventListener("click", async () => {
          selectedUserDetail = await api(`/api/admin/users/${b.getAttribute("data-view-uid")}`);
          loadAndDraw();
        });
      });
      main.querySelector("[data-back-users]")?.addEventListener("click", () => {
        selectedUserDetail = null;
        loadAndDraw();
      });
      main.querySelector("[data-edit-user-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const uid = e.target.getAttribute("data-edit-user-form");
        const fd = new FormData(e.target);
        await api(`/api/admin/users/${uid}`, {
          method: "PATCH",
          body: {
            fullName: fd.get("fullName"),
            email: fd.get("email"),
            phone: fd.get("phone"),
            studentProfile: fd.has("classLevel")
              ? { classLevel: fd.get("classLevel"), board: fd.get("board"), courseDurationMonths: Number(fd.get("courseDurationMonths") || 12) }
              : undefined,
            teacherProfile: fd.has("qualification")
              ? { qualification: fd.get("qualification"), experienceYears: Number(fd.get("experienceYears") || 0) }
              : undefined,
          },
        });
        selectedUserDetail = await api(`/api/admin/users/${uid}`);
        feedbackMsg = "Account changes saved.";
        loadAndDraw();
      });
      main.querySelectorAll("[data-user-act]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = b.getAttribute("data-uid");
          const action = b.getAttribute("data-user-act");
          await api(`/api/admin/users/${uid}/status`, { method: "POST", body: { action, reason: "" } });
          if (selectedUserDetail) selectedUserDetail = await api(`/api/admin/users/${uid}`);
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-impersonate-uid]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = Number(b.getAttribute("data-impersonate-uid"));
          const reason = await openPromptModal({
            title: "Start Troubleshooting Session",
            label: "Reason for impersonation (min 4 characters)",
            defaultValue: "Support check",
            minLength: 4,
          });
          if (reason.trim().length < 4) return;
          try {
            const res = await api("/api/admin/impersonate", { method: "POST", body: { userId: uid, reason } });
            window.location.assign(res.redirectTo || "/student/");
          } catch (err) {
            feedbackMsg = err.message;
            loadAndDraw();
          }
        });
      });

      // Courses & Subjects
      main.querySelector("[data-new-course-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await api("/api/admin/courses", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        feedbackMsg = "Course created.";
        loadAndDraw();
      });
      main.querySelector("[data-edit-course-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const cid = e.target.getAttribute("data-edit-course-form");
        await api(`/api/admin/courses/${cid}`, { method: "PATCH", body: Object.fromEntries(new FormData(e.target).entries()) });
        editingCourse = null;
        feedbackMsg = "Course updated.";
        loadAndDraw();
      });
      main.querySelector("[data-cancel-edit-course]")?.addEventListener("click", () => {
        editingCourse = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-edit-course]").forEach((b) => {
        b.addEventListener("click", () => {
          const cid = Number(b.getAttribute("data-edit-course"));
          editingCourse = (coursesRes.courses || []).find((c) => Number(c.id) === cid) || null;
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-del-course]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/courses/${b.getAttribute("data-del-course")}`, { method: "DELETE" });
          loadAndDraw();
        });
      });
      main.querySelector("[data-new-subject-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await api("/api/admin/subjects", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        loadAndDraw();
      });
      main.querySelectorAll("[data-del-subject]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/subjects/${b.getAttribute("data-del-subject")}`, { method: "DELETE" });
          loadAndDraw();
        });
      });

      // Payments
      main.querySelector("[data-coupon-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await api("/api/admin/coupons", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        loadAndDraw();
      });
      main.querySelectorAll("[data-pay-verify]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/payments/${b.getAttribute("data-pay-verify")}/verify`, { method: "POST", body: { decision: b.getAttribute("data-dec") } });
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-pay-refund]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/payments/${b.getAttribute("data-pay-refund")}/refund`, { method: "POST" });
          loadAndDraw();
        });
      });

      // Inquiries & CMS
      main.querySelectorAll("[data-inq-status]").forEach((sel) => {
        sel.addEventListener("change", async () => {
          await api(`/api/admin/inquiries/${sel.getAttribute("data-inq-status")}`, { method: "PATCH", body: { status: sel.value } });
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-del-inq]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/inquiries/${b.getAttribute("data-del-inq")}`, { method: "DELETE" });
          loadAndDraw();
        });
      });
      main.querySelector("[data-ann-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await api("/api/admin/cms/announcements", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        loadAndDraw();
      });
      main.querySelectorAll("[data-del-ann]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/cms/announcements/${b.getAttribute("data-del-ann")}`, { method: "DELETE" });
          loadAndDraw();
        });
      });
      main.querySelector("[data-banner-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await api("/api/admin/cms/banners", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        loadAndDraw();
      });
      main.querySelectorAll("[data-del-banner]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/cms/banners/${b.getAttribute("data-del-banner")}`, { method: "DELETE" });
          loadAndDraw();
        });
      });
      main.querySelector("[data-blog-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await api("/api/admin/cms/blog", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        loadAndDraw();
      });
      main.querySelectorAll("[data-del-blog]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/cms/blog/${b.getAttribute("data-del-blog")}`, { method: "DELETE" });
          loadAndDraw();
        });
      });
      main.querySelector("[data-faq-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await api("/api/admin/cms/faqs", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        loadAndDraw();
      });
      main.querySelectorAll("[data-del-faq]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/cms/faqs/${b.getAttribute("data-del-faq")}`, { method: "DELETE" });
          loadAndDraw();
        });
      });
      main.querySelector("[data-test-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await api("/api/admin/cms/testimonials", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        loadAndDraw();
      });
      main.querySelectorAll("[data-del-test]").forEach((b) => {
        b.addEventListener("click", async () => {
          await api(`/api/admin/cms/testimonials/${b.getAttribute("data-del-test")}`, { method: "DELETE" });
          loadAndDraw();
        });
      });

      // Chatbot handlers
      main.querySelector("[data-chat-search]")?.addEventListener("change", (e) => {
        chatSearch = e.target.value;
        loadAndDraw();
      });
      main.querySelector("[data-chat-status-filter]")?.addEventListener("change", (e) => {
        chatFilterStatus = e.target.value;
        loadAndDraw();
      });
      main.querySelector("[data-chat-rating-filter]")?.addEventListener("change", (e) => {
        chatMinRating = Number(e.target.value || 0);
        loadAndDraw();
      });
      main.querySelectorAll("[data-open-chat]").forEach((b) => {
        b.addEventListener("click", async () => {
          selectedChatDetail = await api(`/api/admin/chatbot/${encodeURIComponent(b.getAttribute("data-open-chat"))}`);
          loadAndDraw();
        });
      });
      main.querySelector("[data-chat-back]")?.addEventListener("click", () => {
        selectedChatDetail = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-chat-status]").forEach((b) => {
        b.addEventListener("click", async () => {
          const cid = b.getAttribute("data-chat-status");
          await api(`/api/admin/chatbot/${encodeURIComponent(cid)}`, { method: "PATCH", body: { status: b.getAttribute("data-st") } });
          selectedChatDetail = await api(`/api/admin/chatbot/${encodeURIComponent(cid)}`);
          loadAndDraw();
        });
      });

      // Marketing handlers
      const mktForm = main.querySelector("[data-mkt-form]");
      const buildMktFilters = () => {
        const fd = new FormData(mktForm);
        const selectedUserIds = Array.from(mktForm.querySelectorAll('input[name="selectedUid"]:checked')).map((el) => Number(el.value));
        return {
          audienceGroup: fd.get("audienceGroup"),
          accountStatus: fd.get("accountStatus"),
          classLevel: String(fd.get("classLevel") || "").trim() || undefined,
          subject: String(fd.get("subjectFilter") || "").trim() || undefined,
          courseId: fd.get("courseId") ? Number(fd.get("courseId")) : undefined,
          registeredAfter: fd.get("registeredAfter") || undefined,
          selectedUserIds: selectedUserIds.length ? selectedUserIds : undefined,
        };
      };
      if (mktForm) {
        main.querySelector("[data-mkt-tmpl]")?.addEventListener("change", (e) => {
          const t = (mktRes.templates || []).find((x) => String(x.id) === e.target.value);
          if (t) {
            mktForm.querySelector('[name="subject"]').value = t.subject;
            mktForm.querySelector('[name="previewText"]').value = t.preview_text || "";
            mktForm.querySelector('[name="htmlBody"]').value = t.html_body;
          }
        });
        main.querySelector("[data-mkt-check]")?.addEventListener("click", async () => {
          const pv = await api("/api/marketing/preview-recipients", { method: "POST", body: { filters: buildMktFilters() } });
          const box = main.querySelector("[data-mkt-preview]");
          box.className = "portal-message portal-message--success";
          box.textContent = `Eligible recipients: ${pv.eligibleCount} · Excluded (opted-out/suppressed/unverified): ${pv.excludedCount}`;
          box.hidden = false;
        });
        mktForm.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(mktForm);
          let attachmentUrl = "";
          const attFile = fd.get("attachmentFile");
          if (attFile instanceof File && attFile.size > 0) {
            const up = await uploadFile(attFile);
            attachmentUrl = up.url;
          }
          await api("/api/marketing/campaigns", {
            method: "POST",
            body: {
              name: fd.get("name"),
              templateId: main.querySelector("[data-mkt-tmpl]")?.value || undefined,
              subject: fd.get("subject"),
              previewText: fd.get("previewText"),
              ctaLabel: fd.get("ctaLabel"),
              ctaUrl: fd.get("ctaUrl"),
              scheduledAt: fd.get("scheduledAt") || undefined,
              attachmentUrl,
              htmlBody: fd.get("htmlBody"),
              sendMode: fd.get("sendMode"),
              filters: buildMktFilters(),
            },
          });
          feedbackMsg = "Campaign created.";
          loadAndDraw();
        });
        main.querySelector("[data-test-send-btn]")?.addEventListener("click", async () => {
          const to = main.querySelector("[data-test-email]")?.value || "";
          const fb = main.querySelector("[data-test-fb]");
          try {
            const res = await api("/api/marketing/test-send", {
              method: "POST",
              body: {
                to,
                subject: mktForm.querySelector('[name="subject"]').value,
                previewText: mktForm.querySelector('[name="previewText"]').value,
                ctaLabel: mktForm.querySelector('[name="ctaLabel"]').value,
                ctaUrl: mktForm.querySelector('[name="ctaUrl"]').value,
                htmlBody: mktForm.querySelector('[name="htmlBody"]').value,
              },
            });
            fb.className = "portal-message portal-message--success";
            fb.textContent = `Test email sent (ID: ${res.messageId || "ok"}).`;
            fb.hidden = false;
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        main.querySelectorAll("[data-camp-act]").forEach((b) => {
          b.addEventListener("click", async () => {
            await api(`/api/marketing/campaigns/${b.getAttribute("data-camp-act")}/action`, {
              method: "POST",
              body: { action: b.getAttribute("data-act") },
            });
            loadAndDraw();
          });
        });
        main.querySelectorAll("[data-camp-deliveries]").forEach((b) => {
          b.addEventListener("click", async () => {
            const res = await api(`/api/marketing/campaigns/${b.getAttribute("data-camp-deliveries")}/deliveries`);
            selectedCampaignDeliveries = res.deliveries || [];
            loadAndDraw();
          });
        });
        main.querySelector("[data-supp-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          await api("/api/marketing/suppressions", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
          loadAndDraw();
        });
      }

      // Backups
      main.querySelector("[data-create-backup]")?.addEventListener("click", async () => {
        const res = await api("/api/admin/backups", { method: "POST" });
        feedbackMsg = `Backup created: ${res.backup?.filename}`;
        loadAndDraw();
      });
    }
    await loadAndDraw();
  }

  // ==================== STUDENT PANEL ====================
  async function renderStudentPanel(session) {
    if (session.user.verification_status !== "approved") {
      mountShell(`
        ${impersonationBanner(session)}
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Account Status</p>
          <div class="portal-heading"><h1>Verification Pending</h1></div>
          <div class="portal-message">${escapeHtml(session.pendingMessage || BRAND_PENDING_MSG)}</div>
          <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
        </div>`);
      root.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
        await api("/api/auth/logout", { method: "POST" });
        window.location.assign("/login");
      });
      return;
    }

    let tab = "overview";
    let activeLessons = null;
    let studentNotice = "";

    async function loadAndDraw() {
      const [dash, boot] = await Promise.all([api("/api/student/dashboard"), api("/api/public/bootstrap")]);
      const navItems = [
        ["overview", "Dashboard", "dashboard"],
        ["courses", "Courses & Learning", "book"],
        ["fees", "Fees & Receipts", "wallet"],
        ["assignments", "Assignments & Quizzes", "award"],
        ["attendance", "Attendance Record", "calendar"],
        ["support", "Profile & Support", "user"],
      ];

      let bodyHtml = "";
      if (tab === "overview") {
        const p = dash.profile || {};
        const totalLearningMins = (dash.enrollments || []).reduce((acc, e) => acc + Number(e.learning_minutes || 0), 0);
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${(dash.enrollments || []).length}</strong><span>Enrolled Courses</span></div><div class="portal-stat-icon">${icon("book")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.assignments || []).length}</strong><span>Assignments</span></div><div class="portal-stat-icon">${icon("award")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.attendance || []).filter((a) => a.status === "present").length}</strong><span>Present Days</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
            <div class="portal-stat"><div><strong>${totalLearningMins} min</strong><span>Learning Time</span></div><div class="portal-stat-icon">${icon("dashboard")}</div></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Student Profile</h3>
            <div class="portal-personal-grid">
              <div class="portal-detail"><span>Class &amp; Board</span><strong>${escapeHtml(p.class_level || "Student")} · ${escapeHtml(p.board || "CBSE")}</strong></div>
              <div class="portal-detail"><span>Admission Date</span><strong>${escapeHtml(p.admission_date || "Pending assignment")}</strong></div>
              <div class="portal-detail"><span>Course Duration</span><strong>${Number(p.course_duration_months || 12)} months</strong></div>
              <div class="portal-detail"><span>Enrollment Status</span><strong>${statusBadge(p.enrollment_status || "active")}</strong></div>
            </div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Upcoming Classes</h3>
            ${(dash.upcomingClasses || []).map((c) => `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(c.scheduled_date)} · ${escapeHtml(c.start_time)}–${escapeHtml(c.end_time)} (${escapeHtml(c.mode)})</span><strong>${escapeHtml(c.title)} · ${escapeHtml(c.course_title)}</strong>${c.meeting_link ? `<div><a href="${escAttr(c.meeting_link)}" target="_blank" rel="noopener">Join Online Class</a></div>` : ""}</div>`).join("") || `<p class="portal-hint">No upcoming classes scheduled right now.</p>`}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Announcements</h3>
            ${(dash.announcements || []).map((a) => `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(a.created_at)}</span><strong>${escapeHtml(a.title)}</strong><div>${escapeHtml(a.body)}</div></div>`).join("") || `<p class="portal-hint">No recent announcements.</p>`}
          </div>`;
      } else if (tab === "courses") {
        bodyHtml = `
          ${studentNotice ? `<div class="portal-message portal-message--error" style="margin-bottom:14px;">${escapeHtml(studentNotice)}</div>` : ""}
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">My Enrolled Courses</h3>
            ${(dash.enrollments || []).map((e) => `
              <div class="portal-detail" style="margin-bottom:10px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;">
                <div>
                  <strong>${escapeHtml(e.title)} (${e.progress_percent || 0}% complete)</strong>
                  <span>Status: ${escapeHtml(e.is_expired ? "expired" : e.status)}${e.expires_at ? " · Valid until " + escapeHtml(e.expires_at) : ""}${e.certificate_code ? " · Certificate: " + escapeHtml(e.certificate_code) : ""}</span>
                </div>
                <div class="portal-actions">
                  ${["active", "completed"].includes(e.status) && !e.is_expired ? `<button type="button" class="portal-button portal-button--small" data-open-course="${e.course_id}">Open Lessons</button>` : statusBadge(e.is_expired ? "expired" : e.status)}
                  ${e.certificate_code ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-print-cert="${escAttr(JSON.stringify({ code: e.certificate_code, student: session.user.full_name, course: e.title }))}">Certificate</button>` : ""}
                </div>
              </div>`).join("") || `<p class="portal-hint">No enrolled courses yet. Enroll below.</p>`}
          </div>
          ${
            activeLessons
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
              <h3 class="portal-section-title">Course Lessons</h3>
              ${(activeLessons.lessons || []).map((l) => `
                <div class="portal-detail" style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
                  <div><strong>${escapeHtml(l.title)}</strong><span>${escapeHtml(l.lesson_type)} · ${l.duration_minutes} mins · ${escapeHtml(l.content)}</span>${l.material_url ? `<div><a href="${escAttr(l.material_url)}" target="_blank" rel="noopener">Open Study Material</a></div>` : ""}</div>
                  ${l.completed ? statusBadge("completed") : `<button type="button" class="portal-button portal-button--small" data-complete-lesson="${l.id}">Mark Complete</button>`}
                </div>`).join("")}
            </div>`
              : ""
          }
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Enroll in a Course</h3>
            <form class="portal-form" data-enroll-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(boot.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)} (${formatINR(c.monthly_fee)}/mo)</option>`).join("")}</select></div>
                <div class="portal-field"><label>Plan</label><select name="plan"><option value="monthly">Monthly</option><option value="yearly">Yearly</option></select></div>
                <div class="portal-field"><label>Payment Method</label><select name="paymentMethod"><option value="upi">UPI / Desk Transfer</option><option value="cash">Centre Cash Desk</option><option value="gateway">Online Gateway</option></select></div>
                <div class="portal-field"><label>UTR / Reference No.</label><input name="utrReference" placeholder="UTR or desk receipt ref"></div>
                <div class="portal-field"><label>Coupon Code (Optional)</label><input name="couponCode" placeholder="e.g. YUITOR10"></div>
              </div>
              <div class="portal-message" data-enroll-fb hidden></div>
              <button type="submit" class="portal-button portal-button--small">Submit Enrollment</button>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Rate an Enrolled Course</h3>
            <form class="portal-form" data-review-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(boot.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Rating</label><select name="rating"><option value="5">5 - Excellent</option><option value="4">4 - Good</option><option value="3">3 - Average</option><option value="2">2 - Fair</option><option value="1">1 - Needs Improvement</option></select></div>
              </div>
              <div class="portal-field"><label>Review</label><textarea name="comment" required placeholder="Share your learning experience..."></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Submit Review</button>
            </form>
          </div>`;
      } else if (tab === "fees") {
        const totalNetFee = (dash.feeRecords || []).reduce((acc, f) => acc + Math.max(0, Number(f.total_amount || 0) - Number(f.discount_amount || 0)), 0);
        const totalPaidFee = (dash.feeRecords || []).reduce((acc, f) => acc + Number(f.paid_amount || 0), 0);
        const pendingFee = Math.max(0, totalNetFee - totalPaidFee);
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${formatINR(totalNetFee)}</strong><span>Total Net Fee</span></div><div class="portal-stat-icon">${icon("wallet")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(totalPaidFee)}</strong><span>Paid Amount</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(pendingFee)}</strong><span>Pending Balance</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Invoice</th><th>Course</th><th>Total</th><th>Paid</th><th>Due Date</th><th>Status</th></tr></thead>
            <tbody>
              ${(dash.feeRecords || []).map((f) => `<tr><td>${escapeHtml(f.invoice_number)}</td><td>${escapeHtml(f.course_title)}</td><td>${formatINR(f.total_amount - f.discount_amount)}</td><td>${formatINR(f.paid_amount)}</td><td>${escapeHtml(f.due_date || "-")}</td><td>${statusBadge(f.status)}</td></tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No fee records yet.</td></tr>`}
            </tbody>
          </table></div></div>
          <div class="portal-card portal-table-card"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Payment Receipts &amp; Refunds</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Receipt #</th><th>Course</th><th>Amount</th><th>Method</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              ${(dash.payments || []).map((p) => `<tr>
                <td>${escapeHtml(p.receipt_number || "Pending")}</td>
                <td>${escapeHtml(p.course_title)}</td>
                <td>${formatINR(p.amount)}</td>
                <td>${escapeHtml(p.payment_method)}</td>
                <td>${statusBadge(p.verification_status)}</td>
                <td><div class="portal-actions">
                  ${p.receipt_number ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-print-receipt="${escAttr(JSON.stringify({ receipt: p.receipt_number, student: session.user.full_name, course: p.course_title, amount: p.amount, date: p.paid_at || p.created_at, invoice: p.invoice_number }))}">Print Receipt</button>` : ""}
                  ${p.verification_status === "verified" && p.refund_status === "none" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-req-refund="${p.id}">Request Refund</button>` : escapeHtml(p.refund_status !== "none" ? `Refund: ${p.refund_status}` : "")}
                </div></td>
              </tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No payment transactions yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
      } else if (tab === "assignments") {
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Assignments</h3>
            ${(dash.assignments || []).map((a) => `
              <div class="portal-detail" style="margin-bottom:10px;">
                <strong>${escapeHtml(a.title)} (${escapeHtml(a.course_title)})</strong>
                <span>Due: ${escapeHtml(a.due_date)} · Status: ${escapeHtml(a.submission_status || "Pending")} ${a.marks_obtained !== null ? "· Score: " + a.marks_obtained + "/" + a.max_marks : ""}</span>
                <form class="portal-form" data-sub-assign="${a.id}" style="margin-top:8px;">
                  <div class="portal-form-grid">
                    <div class="portal-field"><label>Answer Text</label><input name="submissionText" placeholder="Write answer or notes..."></div>
                    <div class="portal-field"><label>Upload File (PDF / Image, max 5 MB)</label><input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
                  </div>
                  <button type="submit" class="portal-button portal-button--small">Submit Assignment</button>
                </form>
              </div>`).join("") || `<p class="portal-hint">No pending assignments.</p>`}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Quizzes &amp; Tests</h3>
            ${(dash.quizzes || []).map((q) => {
              let qs = [];
              try { qs = JSON.parse(q.questions_json || "[]"); } catch { qs = []; }
              return `<div class="portal-detail" style="margin-bottom:12px;">
                <strong>${escapeHtml(q.title)} (${escapeHtml(q.course_title)})</strong>
                <span>${q.duration_minutes} mins · Max ${q.max_marks} marks ${q.score !== null && q.score !== undefined ? "· Last Score: " + q.score + "/" + q.max_marks : ""}</span>
                ${qs.length ? `<form class="portal-form" data-quiz-form="${q.id}" style="margin-top:10px;">
                  ${qs.map((item, idx) => `<div style="margin-bottom:8px;"><div><strong>Q${idx + 1}:</strong> ${escapeHtml(item.question)}</div><select name="q_${idx}">${(item.options || []).map((opt, oi) => `<option value="${oi}">${escapeHtml(opt)}</option>`).join("")}</select></div>`).join("")}
                  <button type="submit" class="portal-button portal-button--small">Submit Quiz</button>
                </form>` : ""}
              </div>`;
            }).join("") || `<p class="portal-hint">No quizzes published for your enrolled courses yet.</p>`}
          </div>`;
      } else if (tab === "attendance") {
        const present = (dash.attendance || []).filter((a) => a.status === "present").length;
        const absent = (dash.attendance || []).filter((a) => a.status === "absent").length;
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${present}</strong><span>Present Sessions</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${absent}</strong><span>Absent Sessions</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
          </div>
          <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Date</th><th>Course</th><th>Status</th><th>Remarks</th></tr></thead>
            <tbody>
              ${(dash.attendance || []).map((a) => `<tr><td>${escapeHtml(a.att_date)}</td><td>${escapeHtml(a.course_title)}</td><td>${statusBadge(a.status)}</td><td>${escapeHtml(a.remarks || "-")}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No attendance marked yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
      } else {
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Profile Photo</h3>
            <form class="portal-form" data-stu-avatar-form>
              <div class="portal-actions">
                <img src="${escAttr(session.user.avatar_url || "/yuitor-icon-192.png")}" alt="Avatar" class="portal-avatar">
                <input type="file" name="file" accept=".png,.jpg,.jpeg,.webp" required>
                <button type="submit" class="portal-button portal-button--small">${icon("upload")} Upload Photo</button>
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Contact Yuitor Support</h3>
            <form class="portal-form" data-support-form>
              <div class="portal-field"><label>Subject</label><input name="subject" required></div>
              <div class="portal-field"><label>Message</label><textarea name="body" required></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Send Message</button>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Recent Support Thread</h3>
            ${(dash.supportMessages || []).map((m) => `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(m.created_at)}</span><strong>${escapeHtml(m.subject)}</strong><div>${escapeHtml(m.body)}</div></div>`).join("") || `<p class="portal-hint">No support messages sent yet.</p>`}
          </div>`;
      }

      const main = renderWorkspace({
        session,
        portalTitle: "Student Portal",
        navItems,
        activeTab: tab,
        onTabChange: (next) => {
          tab = next;
          loadAndDraw();
        },
        notifications: dash.notifications || [],
        onReadNotifs: async () => {
          await api("/api/student/notifications/read-all", { method: "POST" });
          loadAndDraw();
        },
        bodyHtml,
      });

      main.querySelectorAll("[data-open-course]").forEach((b) => {
        b.addEventListener("click", async () => {
          studentNotice = "";
          try {
            activeLessons = await api(`/api/student/courses/${b.getAttribute("data-open-course")}/lessons`);
          } catch (err) {
            activeLessons = null;
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-complete-lesson]").forEach((b) => {
        b.addEventListener("click", async () => {
          try {
            await api(`/api/student/lessons/${b.getAttribute("data-complete-lesson")}/complete`, { method: "POST", body: { timeSpentMinutes: 20 } });
            if (activeLessons?.enrollment?.course_id) {
              activeLessons = await api(`/api/student/courses/${activeLessons.enrollment.course_id}/lessons`);
            }
          } catch (err) {
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelector("[data-enroll-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fb = main.querySelector("[data-enroll-fb]");
        try {
          const res = await api("/api/payments/enroll", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
          fb.className = "portal-message portal-message--success";
          fb.textContent = res.message;
          fb.hidden = false;
          loadAndDraw();
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
        }
      });
      main.querySelector("[data-review-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          await api("/api/student/reviews", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
          studentNotice = "Thank you! Your course review has been submitted.";
        } catch (err) {
          studentNotice = err.message;
        }
        loadAndDraw();
      });
      main.querySelectorAll("[data-print-receipt]").forEach((b) => {
        b.addEventListener("click", () => {
          const info = JSON.parse(b.getAttribute("data-print-receipt"));
          mountShell(`
            <div class="portal-card portal-profile" style="max-width:640px;margin:0 auto;">
              <p class="portal-kicker">Official Fee Receipt · Yuitor Smart Classes</p>
              <div class="portal-heading"><h1>Receipt ${escapeHtml(info.receipt)}</h1><button type="button" class="portal-button portal-button--small" onclick="window.print()">Print</button></div>
              <p class="portal-subtitle">Trimurti Vihar, Near Venus Academy, Muradnagar - 201206 · +91 78-2728-9292 · admission@yuitor.com</p>
              <div class="portal-personal-grid" style="margin-top:16px;">
                <div class="portal-detail"><span>Student</span><strong>${escapeHtml(info.student)}</strong></div>
                <div class="portal-detail"><span>Invoice</span><strong>${escapeHtml(info.invoice)}</strong></div>
                <div class="portal-detail"><span>Course</span><strong>${escapeHtml(info.course)}</strong></div>
                <div class="portal-detail"><span>Amount Paid</span><strong>${formatINR(info.amount)}</strong></div>
                <div class="portal-detail"><span>Date</span><strong>${escapeHtml(info.date)}</strong></div>
              </div>
              <div style="margin-top:18px;"><button type="button" class="portal-button portal-button--quiet portal-button--small" data-back-fees>← Back to Fees</button></div>
            </div>`);
          getMain().querySelector("[data-back-fees]")?.addEventListener("click", loadAndDraw);
        });
      });
      main.querySelectorAll("[data-print-cert]").forEach((b) => {
        b.addEventListener("click", () => {
          const cert = JSON.parse(b.getAttribute("data-print-cert"));
          mountShell(`
            <div class="portal-card portal-profile" style="max-width:680px;margin:0 auto;text-align:center;padding:36px;">
              <p class="portal-kicker" style="justify-content:center;">Certificate of Completion · Yuitor Smart Classes</p>
              <h1 style="margin:8px 0;">${escapeHtml(cert.student)}</h1>
              <p class="portal-subtitle" style="margin:0 auto 14px;">has successfully completed all lessons for <strong>${escapeHtml(cert.course)}</strong> at Yuitor Smart Classes, Muradnagar.</p>
              <p class="portal-hint">Certificate ID: <strong>${escapeHtml(cert.code)}</strong></p>
              <div class="portal-actions" style="justify-content:center;margin-top:20px;">
                <button type="button" class="portal-button portal-button--small" onclick="window.print()">Print Certificate</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-back-courses>← Back to Courses</button>
              </div>
            </div>`);
          getMain().querySelector("[data-back-courses]")?.addEventListener("click", loadAndDraw);
        });
      });
      main.querySelectorAll("[data-req-refund]").forEach((b) => {
        b.addEventListener("click", async () => {
          const reason = await openPromptModal({
            title: "Request Fee Refund",
            label: "Reason for refund request (min 5 characters)",
            defaultValue: "Batch change request",
            minLength: 5,
          });
          if (reason.trim().length < 5) return;
          try {
            await api("/api/payments/refund-request", {
              method: "POST",
              body: { paymentId: Number(b.getAttribute("data-req-refund")), reason },
            });
            studentNotice = "Refund request submitted to Yuitor Admin.";
          } catch (err) {
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-sub-assign]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          try {
            const fd = new FormData(f);
            let fileUrl = "";
            const file = fd.get("file");
            if (file instanceof File && file.size > 0) {
              const up = await uploadFile(file);
              fileUrl = up.url;
            }
            await api(`/api/student/assignments/${f.getAttribute("data-sub-assign")}/submit`, {
              method: "POST",
              body: { submissionText: fd.get("submissionText"), fileUrl },
            });
            studentNotice = "Assignment submitted.";
          } catch (err) {
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-quiz-form]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          try {
            const answers = Array.from(new FormData(f).values()).map(Number);
            await api(`/api/student/quizzes/${f.getAttribute("data-quiz-form")}/attempt`, { method: "POST", body: { answers } });
          } catch (err) {
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelector("[data-stu-avatar-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const file = new FormData(e.target).get("file");
          if (file instanceof File && file.size > 0) {
            const up = await uploadFile(file);
            await api("/api/auth/avatar", { method: "PATCH", body: { avatarUrl: up.url } });
            session.user.avatar_url = up.url;
            loadAndDraw();
          }
        } catch (err) {
          studentNotice = err.message;
          loadAndDraw();
        }
      });
      main.querySelector("[data-support-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          await api("/api/student/support", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
          studentNotice = "Support message sent to Yuitor Team.";
        } catch (err) {
          studentNotice = err.message;
        }
        loadAndDraw();
      });
    }
    await loadAndDraw();
  }

  // ==================== TEACHER PANEL ====================
  async function renderTeacherPanel(session) {
    if (session.user.verification_status !== "approved") {
      mountShell(`
        ${impersonationBanner(session)}
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Teacher Verification Pending</p>
          <div class="portal-heading"><h1>Verification Pending</h1></div>
          <div class="portal-message">${escapeHtml(session.pendingMessage || BRAND_PENDING_MSG)}</div>
          <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
        </div>`);
      root.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
        await api("/api/auth/logout", { method: "POST" });
        window.location.assign("/login");
      });
      return;
    }

    let tab = "overview";
    let selectedCourseId = null;
    let editingLessonId = null;
    let activeSubmissions = null;
    let teacherNotice = "";

    async function loadAndDraw() {
      const dash = await api("/api/teacher/dashboard");
      if (!selectedCourseId && dash.courses?.length) selectedCourseId = dash.courses[0].id;
      const lessonsData = selectedCourseId ? await api(`/api/teacher/courses/${selectedCourseId}/lessons`) : { lessons: [] };
      const selectedCourse = (dash.courses || []).find((c) => Number(c.id) === Number(selectedCourseId));

      const navItems = [
        ["overview", "Dashboard", "dashboard"],
        ["lessons", "Courses & Lessons", "book"],
        ["students", "Students & Attendance", "users"],
        ["schedules", "Schedules & Grading", "calendar"],
        ["profile", "Profile & Availability", "user"],
      ];

      let bodyHtml = "";
      if (tab === "overview") {
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${(dash.courses || []).length}</strong><span>Assigned Courses</span></div><div class="portal-stat-icon">${icon("book")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.students || []).length}</strong><span>Students</span></div><div class="portal-stat-icon">${icon("users")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.schedules || []).length}</strong><span>Class Schedules</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.assignments || []).length}</strong><span>Assignments</span></div><div class="portal-stat-icon">${icon("award")}</div></div>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Publish Class Announcement</h3>
            <form class="portal-form" data-t-ann-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course (Optional)</label><select name="courseId"><option value="">All My Students</option>${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
              </div>
              <div class="portal-field"><label>Announcement</label><textarea name="body" required></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Post Announcement</button>
            </form>
          </div>`;
      } else if (tab === "lessons") {
        const editLesson = (lessonsData.lessons || []).find((l) => Number(l.id) === Number(editingLessonId));
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div class="portal-form-grid" style="margin-bottom:12px;">
              <div class="portal-field">
                <label>Select Assigned Course</label>
                <select data-t-course>${(dash.courses || []).map((c) => `<option value="${c.id}"${Number(selectedCourseId) === Number(c.id) ? " selected" : ""}>${escapeHtml(c.title)}</option>`).join("")}</select>
              </div>
            </div>
            ${
              selectedCourse
                ? `<form class="portal-form" data-t-course-edit style="margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid var(--pt-border);">
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Course Description</label><input name="description" value="${escAttr(selectedCourse.description || "")}"></div>
                      <div class="portal-field"><label>Duration (Months)</label><input name="durationMonths" type="number" min="1" max="60" value="${Number(selectedCourse.duration_months || 12)}"></div>
                      <div class="portal-field"><label>Update Course Thumbnail</label><input name="thumbnail" type="file" accept=".png,.jpg,.jpeg,.webp"></div>
                    </div>
                    <div><button type="submit" class="portal-button portal-button--small portal-button--quiet">Update Course Details</button></div>
                  </form>`
                : ""
            }
            <h3 class="portal-section-title">${editLesson ? `Edit Lesson: ${escapeHtml(editLesson.title)}` : "Add Lesson"}</h3>
            <form class="portal-form" ${editLesson ? `data-t-edit-lesson="${editLesson.id}"` : "data-t-lesson-form"}>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Lesson Title *</label><input name="title" required value="${escAttr(editLesson?.title || "")}"></div>
                <div class="portal-field"><label>Type</label><select name="lessonType"><option value="text"${editLesson?.lesson_type === "text" ? " selected" : ""}>Text Notes</option><option value="video"${editLesson?.lesson_type === "video" ? " selected" : ""}>Video</option><option value="pdf"${editLesson?.lesson_type === "pdf" ? " selected" : ""}>PDF Notes</option></select></div>
                <div class="portal-field"><label>Material / Video URL</label><input name="materialUrl" value="${escAttr(editLesson?.material_url || editLesson?.video_url || "")}" placeholder="https:// or uploaded PDF URL"></div>
                <div class="portal-field"><label>Or Upload Study PDF / Image</label><input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
              </div>
              <div class="portal-field"><label>Content / Summary</label><textarea name="content">${escapeHtml(editLesson?.content || "")}</textarea></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button portal-button--small">${editLesson ? "Save Lesson" : "Add Lesson"}</button>
                ${editLesson ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-edit-lesson>Cancel</button>` : ""}
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Lessons Order (Drag &amp; Drop or use ↑ / ↓)</h3>
            <div data-drag-lesson-list>
              ${(lessonsData.lessons || []).map((l, idx) => `
                <div class="portal-detail portal-drag-row" draggable="true" data-lesson-id="${l.id}" style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
                  <div><strong>${idx + 1}. ${escapeHtml(l.title)}</strong><span>${escapeHtml(l.lesson_type)} · ${l.is_visible ? "Visible" : "Hidden"}${l.material_url ? " · Attachment linked" : ""}</span></div>
                  <div class="portal-actions">
                    ${idx > 0 ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-move-l="${l.id}" data-dir="-1">${icon("arrowUp")}</button>` : ""}
                    ${idx < lessonsData.lessons.length - 1 ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-move-l="${l.id}" data-dir="1">${icon("arrowDown")}</button>` : ""}
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-edit-l="${l.id}">${icon("edit")} Edit</button>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-vis-l="${l.id}" data-vis="${l.is_visible ? 0 : 1}">${l.is_visible ? "Hide" : "Show"}</button>
                    <button type="button" class="portal-button portal-button--small portal-button--danger" data-del-l="${l.id}">${icon("trash")}</button>
                  </div>
                </div>`).join("") || `<p class="portal-hint">No lessons yet.</p>`}
            </div>
          </div>`;
      } else if (tab === "students") {
        bodyHtml = `
          <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Student</th><th>Course</th><th>Progress</th><th>Mark Today</th></tr></thead>
            <tbody>
              ${(dash.students || []).map((s) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(s.full_name)}</span><span class="portal-cell-sub">${escapeHtml(s.phone)}</span></td>
                <td>${escapeHtml(s.course_title)}</td>
                <td>${s.progress_percent}%</td>
                <td><div class="portal-actions">
                  <button type="button" class="portal-button portal-button--small" data-att="${s.id}" data-cid="${s.course_id}" data-st="present">Present</button>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-att="${s.id}" data-cid="${s.course_id}" data-st="absent">Absent</button>
                </div></td>
              </tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No assigned students yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
      } else if (tab === "schedules") {
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Schedule Class / Online Session</h3>
            <form class="portal-form" data-t-sched-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Session Title</label><input name="title" required placeholder="e.g. Algebra Doubt Session"></div>
                <div class="portal-field"><label>Date</label><input name="scheduledDate" type="date" required></div>
                <div class="portal-field"><label>Start Time</label><input name="startTime" value="16:00" required></div>
                <div class="portal-field"><label>End Time</label><input name="endTime" value="17:00" required></div>
                <div class="portal-field"><label>Mode</label><select name="mode"><option value="offline">Classroom (Muradnagar)</option><option value="online">Online (Meet/Zoom)</option></select></div>
                <div class="portal-field"><label>Meeting Link (if online)</label><input name="meetingLink" placeholder="https://meet.google.com/..."></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Schedule Class</button>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Create Assignment &amp; Grade Submissions</h3>
            <form class="portal-form" data-t-assign-form style="margin-bottom:16px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
                <div class="portal-field"><label>Due Date</label><input name="dueDate" type="date" required></div>
                <div class="portal-field"><label>Max Marks</label><input name="maxMarks" type="number" value="50"></div>
              </div>
              <div class="portal-field"><label>Instructions</label><textarea name="description"></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Publish Assignment</button>
            </form>
            ${(dash.assignments || []).map((a) => `<div class="portal-detail" style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(a.title)} (${escapeHtml(a.course_title)})</strong><span>Due: ${escapeHtml(a.due_date)} · Submissions: ${a.submissions_count}</span></div><button type="button" class="portal-button portal-button--small portal-button--quiet" data-view-subs="${a.id}">Review Submissions</button></div>`).join("")}
            ${activeSubmissions ? `<div style="margin-top:12px;"><h4>Submissions</h4>${(activeSubmissions.submissions || []).map((s) => `<form class="portal-form" data-grade-sub="${s.id}" style="border-top:1px solid var(--pt-border);padding-top:10px;margin-top:10px;"><div><strong>${escapeHtml(s.student_name)}</strong>: ${escapeHtml(s.submission_text)} ${s.file_url ? `<a href="${escAttr(s.file_url)}" target="_blank" rel="noopener">View Attachment</a>` : ""}</div><div class="portal-form-grid"><input name="marksObtained" type="number" placeholder="Marks" value="${s.marks_obtained ?? ""}" required><input name="feedback" placeholder="Feedback" value="${escAttr(s.feedback || "")}"></div><button type="submit" class="portal-button portal-button--small">Save Grade</button></form>`).join("") || `<p class="portal-hint">No student submissions yet.</p>`}</div>` : ""}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Quick MCQ Quiz Builder</h3>
            <form class="portal-form" data-t-quiz-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Quiz Title</label><input name="title" required></div>
                <div class="portal-field"><label>Question 1</label><input name="qText" required placeholder="e.g. What is SI unit of Force?"></div>
                <div class="portal-field"><label>4 Comma-Separated Options</label><input name="qOptions" required placeholder="Newton, Joule, Watt, Pascal"></div>
                <div class="portal-field"><label>Correct Option Index (0–3)</label><input name="correctIndex" type="number" min="0" max="3" value="0"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Publish Quiz</button>
            </form>
          </div>`;
      } else {
        const tp = dash.profile || {};
        const earn = dash.earningsSummary || {};
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Earnings &amp; Payout Status</h3>
            <div class="portal-personal-grid">
              <div class="portal-detail"><span>Monthly Payout Rate</span><strong>${formatINR(earn.monthlyPayoutRate || tp.monthly_payout_rate || 0)}</strong></div>
              <div class="portal-detail"><span>Assigned Active Students</span><strong>${Number(earn.activeStudentsCount || 0)}</strong></div>
              <div class="portal-detail"><span>Configured Payout UPI</span><strong>${escapeHtml(earn.payoutUpi || tp.payout_upi || "Not set yet")}</strong></div>
            </div>
            ${earn.limitationNote ? `<p class="portal-hint" style="margin-top:10px;">${escapeHtml(earn.limitationNote)}</p>` : ""}
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Profile Photo</h3>
            <form class="portal-form" data-t-avatar-form>
              <div class="portal-actions">
                <img src="${escAttr(session.user.avatar_url || "/yuitor-icon-192.png")}" alt="Avatar" class="portal-avatar">
                <input type="file" name="file" accept=".png,.jpg,.jpeg,.webp" required>
                <button type="submit" class="portal-button portal-button--small">${icon("upload")} Upload Photo</button>
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Faculty Profile &amp; Availability</h3>
            <form class="portal-form" data-t-prof-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Full Name</label><input name="fullName" value="${escAttr(session.user.full_name)}"></div>
                <div class="portal-field"><label>Qualification</label><input name="qualification" value="${escAttr(tp.qualification || "")}"></div>
                <div class="portal-field"><label>Availability Status</label><select name="availabilityStatus"><option value="available"${tp.availability_status === "available" ? " selected" : ""}>Available</option><option value="vacation"${tp.availability_status === "vacation" ? " selected" : ""}>Vacation Mode</option></select></div>
                <div class="portal-field"><label>Vacation Note</label><input name="vacationNote" value="${escAttr(tp.vacation_note || "")}"></div>
                <div class="portal-field"><label>Payout UPI (Optional)</label><input name="payoutUpi" value="${escAttr(tp.payout_upi || "")}"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Save Profile</button>
            </form>
          </div>`;
      }

      const noticeHtml = teacherNotice
        ? `<div class="portal-message portal-message--success" style="margin-bottom:14px;">${escapeHtml(teacherNotice)}</div>`
        : "";

      const main = renderWorkspace({
        session,
        portalTitle: "Teacher Portal",
        navItems,
        activeTab: tab,
        onTabChange: (next) => {
          tab = next;
          editingLessonId = null;
          teacherNotice = "";
          loadAndDraw();
        },
        notifications: dash.notifications || [],
        bodyHtml: noticeHtml + bodyHtml,
      });

      const runTeacherAction = async (fn, successMsg) => {
        try {
          await fn();
          teacherNotice = successMsg || "";
        } catch (err) {
          teacherNotice = err?.message || "Action failed. Please check inputs and try again.";
        }
        loadAndDraw();
      };

      main.querySelector("[data-t-ann-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/announcements", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Announcement published.");
      });
      main.querySelector("[data-t-course]")?.addEventListener("change", (e) => {
        selectedCourseId = Number(e.target.value);
        editingLessonId = null;
        teacherNotice = "";
        loadAndDraw();
      });
      main.querySelector("[data-t-course-edit]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runTeacherAction(async () => {
          let thumbnailUrl;
          const f = fd.get("thumbnail");
          if (f instanceof File && f.size > 0) {
            const up = await uploadFile(f);
            thumbnailUrl = up.url;
          }
          await api(`/api/teacher/courses/${selectedCourseId}`, {
            method: "PATCH",
            body: { description: fd.get("description"), durationMonths: Number(fd.get("durationMonths") || 12), thumbnailUrl },
          });
        }, "Course details updated.");
      });
      main.querySelector("[data-t-lesson-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runTeacherAction(async () => {
          let materialUrl = String(fd.get("materialUrl") || "");
          const f = fd.get("file");
          if (f instanceof File && f.size > 0) {
            const up = await uploadFile(f);
            materialUrl = up.url;
          }
          await api(`/api/teacher/courses/${selectedCourseId}/lessons`, {
            method: "POST",
            body: {
              title: fd.get("title"),
              lessonType: fd.get("lessonType"),
              materialUrl,
              content: fd.get("content"),
            },
          });
        }, "Lesson added.");
      });
      main.querySelector("[data-t-edit-lesson]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const lid = e.target.getAttribute("data-t-edit-lesson");
        const fd = new FormData(e.target);
        await runTeacherAction(async () => {
          let materialUrl = String(fd.get("materialUrl") || "");
          const f = fd.get("file");
          if (f instanceof File && f.size > 0) {
            const up = await uploadFile(f);
            materialUrl = up.url;
          }
          await api(`/api/teacher/lessons/${lid}`, {
            method: "PATCH",
            body: { title: fd.get("title"), lessonType: fd.get("lessonType"), materialUrl, content: fd.get("content") },
          });
          editingLessonId = null;
        }, "Lesson updated.");
      });
      main.querySelector("[data-cancel-edit-lesson]")?.addEventListener("click", () => {
        editingLessonId = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-edit-l]").forEach((b) => {
        b.addEventListener("click", () => {
          editingLessonId = Number(b.getAttribute("data-edit-l"));
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-del-l]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            await api(`/api/teacher/lessons/${b.getAttribute("data-del-l")}`, { method: "DELETE" });
          }, "Lesson deleted.");
        });
      });

      // Drag-and-drop lesson reorder
      const dragList = main.querySelector("[data-drag-lesson-list]");
      let draggedId = null;
      dragList?.querySelectorAll("[data-lesson-id]").forEach((row) => {
        row.addEventListener("dragstart", () => {
          draggedId = Number(row.getAttribute("data-lesson-id"));
          row.classList.add("is-dragging");
        });
        row.addEventListener("dragend", () => row.classList.remove("is-dragging"));
        row.addEventListener("dragover", (e) => e.preventDefault());
        row.addEventListener("drop", async (e) => {
          e.preventDefault();
          const targetId = Number(row.getAttribute("data-lesson-id"));
          if (!draggedId || draggedId === targetId) return;
          const ids = (lessonsData.lessons || []).map((l) => Number(l.id));
          const fromIdx = ids.indexOf(draggedId);
          const toIdx = ids.indexOf(targetId);
          if (fromIdx >= 0 && toIdx >= 0) {
            ids.splice(toIdx, 0, ids.splice(fromIdx, 1)[0]);
            await runTeacherAction(async () => {
              await api(`/api/teacher/courses/${selectedCourseId}/lessons/reorder`, { method: "POST", body: { orderedIds: ids } });
            }, "Lesson order updated.");
          }
        });
      });

      main.querySelectorAll("[data-move-l]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = Number(b.getAttribute("data-move-l"));
          const dir = Number(b.getAttribute("data-dir"));
          const ids = (lessonsData.lessons || []).map((l) => l.id);
          const idx = ids.indexOf(id);
          if (idx >= 0 && idx + dir >= 0 && idx + dir < ids.length) {
            [ids[idx], ids[idx + dir]] = [ids[idx + dir], ids[idx]];
            await runTeacherAction(async () => {
              await api(`/api/teacher/courses/${selectedCourseId}/lessons/reorder`, { method: "POST", body: { orderedIds: ids } });
            }, "Lesson order updated.");
          }
        });
      });
      main.querySelectorAll("[data-vis-l]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            await api(`/api/teacher/lessons/${b.getAttribute("data-vis-l")}`, {
              method: "PATCH",
              body: { isVisible: b.getAttribute("data-vis") === "1" },
            });
          }, "Lesson visibility updated.");
        });
      });
      main.querySelectorAll("[data-att]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            await api("/api/teacher/attendance", {
              method: "POST",
              body: {
                courseId: Number(b.getAttribute("data-cid")),
                attDate: new Date().toISOString().slice(0, 10),
                records: [{ studentId: Number(b.getAttribute("data-att")), status: b.getAttribute("data-st") }],
              },
            });
          }, "Attendance marked.");
        });
      });
      main.querySelector("[data-t-sched-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/schedules", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Class schedule saved.");
      });
      main.querySelector("[data-t-assign-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/assignments", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Assignment published.");
      });
      main.querySelectorAll("[data-view-subs]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            activeSubmissions = await api(`/api/teacher/assignments/${b.getAttribute("data-view-subs")}/submissions`);
          }, "");
        });
      });
      main.querySelectorAll("[data-grade-sub]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          await runTeacherAction(async () => {
            await api(`/api/teacher/submissions/${f.getAttribute("data-grade-sub")}/grade`, {
              method: "POST",
              body: Object.fromEntries(new FormData(f).entries()),
            });
          }, "Submission graded.");
        });
      });
      main.querySelector("[data-t-quiz-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const options = String(fd.get("qOptions") || "").split(",").map((s) => s.trim()).filter(Boolean);
        await runTeacherAction(async () => {
          await api("/api/teacher/quizzes", {
            method: "POST",
            body: {
              courseId: Number(fd.get("courseId")),
              title: fd.get("title"),
              maxMarks: 10,
              durationMinutes: 15,
              questions: [{ question: fd.get("qText"), options, correctIndex: Number(fd.get("correctIndex") || 0) }],
            },
          });
        }, "Quiz published.");
      });
      main.querySelector("[data-t-avatar-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const file = new FormData(e.target).get("file");
        if (file instanceof File && file.size > 0) {
          await runTeacherAction(async () => {
            const up = await uploadFile(file);
            await api("/api/auth/avatar", { method: "PATCH", body: { avatarUrl: up.url } });
            session.user.avatar_url = up.url;
          }, "Profile photo updated.");
        }
      });
      main.querySelector("[data-t-prof-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/profile", { method: "PATCH", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Faculty profile saved.");
      });
    }
    await loadAndDraw();
  }

  // ==================== ROUTER ====================
  const CUSTOM_PUBLIC_PATHS = new Set([
    "/admission",
    "/subjects",
    "/ai-learning",
    "/computer-courses",
    "/english-speaking",
    "/teachers",
    "/faqs",
    "/testimonials",
    "/courses",
  ]);

  function isHandledPath(path) {
    return (
      path.startsWith("/admin") ||
      path.startsWith("/student") ||
      path.startsWith("/teacher") ||
      path.startsWith("/unsubscribe/") ||
      path === "/login" ||
      path === "/register" ||
      CUSTOM_PUBLIC_PATHS.has(path)
    );
  }

  async function startPortal(path) {
    if (CUSTOM_PUBLIC_PATHS.has(path) || path.startsWith("/unsubscribe/")) {
      await renderPublicExtension(path);
      return;
    }
    if (path === "/admin/setup.php" || path === "/admin-setup") {
      await renderAdminSetup();
      return;
    }
    if (path === "/register" || path === "/student/register.php") {
      renderRegister("student");
      return;
    }
    if (path === "/teacher/register.php" || path === "/teacher-apply.php") {
      renderRegister("teacher");
      return;
    }

    let session = null;
    try {
      session = await api("/api/auth/me");
    } catch {
      session = null;
    }
    const user = session?.authenticated ? session.user : null;

    if (path === "/login" || path.endsWith("/login.php")) {
      const defRole = path.startsWith("/admin") ? "admin" : path.startsWith("/teacher") ? "teacher" : "student";
      if (user) {
        const dest = user.role === "super_admin" || user.role === "admin" ? "/admin/" : user.role === "teacher" ? "/teacher/" : "/student/";
        window.location.replace(dest);
        return;
      }
      renderLogin(defRole);
      return;
    }

    if (path.startsWith("/admin")) {
      if (user && (user.role === "super_admin" || user.role === "admin")) {
        await renderAdminPanel(session);
        return;
      }
      renderLogin("admin", user ? "Signed in with a non-admin account." : "");
      return;
    }

    if (path.startsWith("/teacher")) {
      if (user && user.role === "teacher") {
        await renderTeacherPanel(session);
        return;
      }
      renderLogin("teacher", user ? "Signed in as non-teacher. Please sign in with a Teacher account." : "");
      return;
    }

    if (path.startsWith("/student")) {
      if (user && user.role === "student") {
        await renderStudentPanel(session);
        return;
      }
      renderLogin("student", user ? "Signed in as non-student. Please sign in with a Student account." : "");
      return;
    }
  }

  function boot() {
    let lastMountedPath = null;
    let mountRaf = 0;

    const tryMountForCurrentPath = () => {
      const path = window.location.pathname.replace(/\/+$/, "") || "/";
      if (!isHandledPath(path)) return false;
      const main = getMain();
      const header = root.querySelector(".yu-shared-header");
      const footer = root.querySelector(".yu-shared-footer");
      if (!main || !header || !footer) return false;
      if (main.dataset.yuPortalMounted === "true" && lastMountedPath === path) return true;
      if (main.dataset.yuPortalMounted !== "true" && !main.textContent.includes("404")) return false;
      lastMountedPath = path;
      main.classList.add("portal-main");
      main.dataset.yuPortalMounted = "true";
      startPortal(path);
      return true;
    };

    tryMountForCurrentPath();

    const scheduleMount = () => {
      const path = window.location.pathname.replace(/\/+$/, "") || "/";
      if (!isHandledPath(path) || mountRaf) return;
      mountRaf = window.requestAnimationFrame(() => {
        mountRaf = 0;
        tryMountForCurrentPath();
      });
    };

    const observer = new MutationObserver(scheduleMount);
    observer.observe(root, { childList: true, subtree: true });

    const origPush = history.pushState;
    history.pushState = function (...args) {
      origPush.apply(this, args);
      const main = getMain();
      const nextPath = window.location.pathname.replace(/\/+$/, "") || "/";
      if (main?.dataset.yuPortalMounted === "true" && !isHandledPath(nextPath)) {
        window.location.assign(window.location.href);
        return;
      }
      window.setTimeout(tryMountForCurrentPath, 40);
    };

    const origReplace = history.replaceState;
    history.replaceState = function (...args) {
      origReplace.apply(this, args);
      window.setTimeout(tryMountForCurrentPath, 40);
    };

    window.addEventListener("popstate", () => {
      const main = getMain();
      const nextPath = window.location.pathname.replace(/\/+$/, "") || "/";
      if (main?.dataset.yuPortalMounted === "true" && !isHandledPath(nextPath)) {
        window.location.assign(window.location.href);
        return;
      }
      window.setTimeout(tryMountForCurrentPath, 40);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
