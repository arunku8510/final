(() => {
  "use strict";
  if (document.getElementById("yu-ai-guide-root")) return;

  const SHREYA_INTRO =
    "Hello! My name is Shreya, and I am Yuitor Smart Classes’ Smart AI Assistant. How can I help you?";

  let conversationId = sessionStorage.getItem("yuitor_shreya_conv_id") || "";
  let visitorId = sessionStorage.getItem("yuitor_visitor_id") || "";
  if (!visitorId) {
    visitorId = "v-" + Math.random().toString(36).slice(2, 10);
    sessionStorage.setItem("yuitor_visitor_id", visitorId);
  }

  let busy = false;
  let currentRating = 5;

  const root = document.createElement("div");
  root.id = "yu-ai-guide-root";
  root.style.cssText =
    "position:fixed;bottom:92px;right:20px;z-index:9999;font-family:system-ui,-apple-system,sans-serif;";

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.id = "yu-smart-ai-toggle";
  toggle.textContent = "Ask Shreya";
  toggle.style.cssText =
    "background:#0f172a;color:#fff;border:2px solid #12a1a1;padding:11px 18px;border-radius:999px;font-weight:700;font-size:14px;cursor:pointer;box-shadow:0 10px 25px rgba(15,23,42,.28);";

  const box = document.createElement("div");
  box.hidden = true;
  box.style.cssText =
    "width:360px;max-width:calc(100vw - 32px);background:#fff;border:1px solid #cbd9e6;border-radius:16px;box-shadow:0 18px 40px rgba(15,23,42,.24);overflow:hidden;margin-bottom:10px;";

  box.innerHTML = `
    <div style="background:#0f172a;color:#fff;padding:12px 14px;display:flex;justify-content:space-between;align-items:center;gap:8px;">
      <div>
        <div style="font-weight:700;font-size:14.5px;">Shreya · Yuitor Smart AI</div>
        <div style="font-size:11px;color:#78d3d3;">Courses, Admissions, Classes &amp; Support</div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <button type="button" id="yu-chat-info-btn" style="background:#1e293b;color:#cbd5e1;border:0;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer;">Info</button>
        <button type="button" id="yu-chat-rate-btn" style="background:#1e293b;color:#cbd5e1;border:0;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer;">Rate</button>
        <button type="button" id="yu-chat-close" style="background:none;border:0;color:#fff;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
      </div>
    </div>
    <div id="yu-chat-contact" hidden style="padding:10px;background:#f8fafc;border-bottom:1px solid #e2e8f0;display:none;gap:6px;font-size:12px;">
      <input id="yu-v-name" type="text" placeholder="Your name (optional)" style="padding:6px 8px;border:1px solid #cbd9e6;border-radius:8px;font-size:12px;">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
        <input id="yu-v-phone" type="tel" placeholder="Mobile (optional)" style="padding:6px 8px;border:1px solid #cbd9e6;border-radius:8px;font-size:12px;">
        <input id="yu-v-email" type="email" placeholder="Email (optional)" style="padding:6px 8px;border:1px solid #cbd9e6;border-radius:8px;font-size:12px;">
      </div>
    </div>
    <form id="yu-chat-rate" hidden style="padding:10px;background:#eff6ff;border-bottom:1px solid #bfdbfe;display:none;gap:6px;font-size:12px;">
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <strong style="color:#0f172a;">Rate Shreya</strong>
        <div id="yu-stars" style="display:flex;gap:4px;"></div>
      </div>
      <input id="yu-fb-text" type="text" placeholder="Optional feedback..." style="padding:6px 8px;border:1px solid #cbd9e6;border-radius:8px;font-size:12px;">
      <button type="submit" style="background:#0f172a;color:#fff;border:0;padding:6px 10px;border-radius:8px;font-weight:600;cursor:pointer;">Save Feedback</button>
    </form>
    <div id="yu-chat-msgs" style="height:280px;overflow-y:auto;padding:12px;background:#f5f9fc;display:flex;flex-direction:column;gap:8px;font-size:13px;line-height:1.48;"></div>
    <form id="yu-chat-form" style="display:flex;gap:6px;padding:10px;border-top:1px solid #dbe6ef;background:#fff;">
      <input id="yu-chat-in" type="text" maxlength="500" required placeholder="Ask in English or Hindi..." style="flex:1;padding:8px 10px;border:1px solid #cbd9e6;border-radius:10px;font-size:13px;">
      <button type="submit" style="background:#12a1a1;color:#fff;border:0;padding:8px 14px;border-radius:10px;font-weight:700;cursor:pointer;">Send</button>
    </form>
  `;

  root.append(box, toggle);
  document.body.appendChild(root);

  const msgsEl = box.querySelector("#yu-chat-msgs");
  const form = box.querySelector("#yu-chat-form");
  const input = box.querySelector("#yu-chat-in");
  const closeBtn = box.querySelector("#yu-chat-close");
  const infoBtn = box.querySelector("#yu-chat-info-btn");
  const rateBtn = box.querySelector("#yu-chat-rate-btn");
  const contactPanel = box.querySelector("#yu-chat-contact");
  const rateForm = box.querySelector("#yu-chat-rate");
  const starsWrap = box.querySelector("#yu-stars");

  const localMessages = [{ sender: "assistant", message: SHREYA_INTRO }];

  function renderMessages(list) {
    msgsEl.innerHTML = "";
    const items = Array.isArray(list) && list.length ? list : [{ sender: "assistant", message: SHREYA_INTRO }];
    for (const m of items) {
      const div = document.createElement("div");
      const isUser = m.sender === "user";
      div.style.cssText = isUser
        ? "align-self:flex-end;background:#0f172a;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;"
        : "align-self:flex-start;background:#fff;border:1px solid #dbe6ef;color:#0f172a;padding:9px 11px;border-radius:12px;max-width:90%;white-space:pre-line;";
      div.textContent = m.message;
      msgsEl.appendChild(div);
    }
    msgsEl.scrollTop = msgsEl.scrollHeight;
  }

  function renderStars() {
    starsWrap.innerHTML = "";
    for (let i = 1; i <= 5; i++) {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = i <= currentRating ? "★" : "☆";
      b.style.cssText = `background:none;border:0;font-size:16px;cursor:pointer;color:${i <= currentRating ? "#d97706" : "#94a3b8"};padding:0 2px;`;
      b.addEventListener("click", () => {
        currentRating = i;
        renderStars();
      });
      starsWrap.appendChild(b);
    }
  }
  renderStars();
  renderMessages(localMessages);

  function localFallbackReply(text) {
    const q = String(text || "").trim().toLowerCase();
    const isHindi =
      /[\u0900-\u097F]|\b(kya|kaise|kitni|fees|batayein|batao|chahiye|karna|nahi|ho raha|madad|admission lena|namaste)\b/i.test(
        text
      );
    if (/^(hi|hello|hey|namaste|hlo)[!.\s]*$/i.test(q)) return SHREYA_INTRO;
    if (/\b(who are you|your name|kaun ho|aap kaun)\b/i.test(q)) return SHREYA_INTRO;

    // Quick math helper
    const pct = q.match(/(\d+(?:\.\d+)?)\s*(?:%|percent)\s*(?:of|ka|on)\s*(\d+(?:\.\d+)?)/i);
    if (pct) return `${pct[1]}% of ${pct[2]} = ${Number(((Number(pct[1]) / 100) * Number(pct[2])).toFixed(4))}.`;
    const arith = q.replace(/^(?:what is|calculate|solve)\s+/i, "").replace(/\?+$/, "").trim();
    if (/^[\d\s+\-*/().]+$/.test(arith) && /[+\-*/]/.test(arith)) {
      try {
        const v = Function(`"use strict"; return (${arith});`)();
        if (typeof v === "number" && Number.isFinite(v)) return `${arith} = ${Number(v.toFixed(4))}`;
      } catch {
        // Ignore invalid expressions
      }
    }

    if (/^\s*(i want admission|admission|apply|join|enroll|daakhila)\b/i.test(q) && !/\b(class|neet|jee|cuet|computer|english|ai|6|7|8|9|10|11|12)\b/i.test(q)) {
      return isHindi ? "Bilkul! Aap kis class ya course mein admission lena chahte hain?" : "Sure! Which class or course are you interested in?";
    }
    if (/\b(fee|fees|price|charges|kitni)\b/i.test(q) && !/\b(5|6|7|8|9|10|11|12|neet|jee|cuet|computer|english|ai|python|spoken)\b/i.test(q)) {
      return isHindi ? "Aap kis class ya course ki fees jaanna chahte hain?" : "Which class or course would you like to know the fees for?";
    }
    if (/\b(cannot log in|can't login|cant login|login problem|login issue|otp|sign in)\b/i.test(q)) {
      return isHindi
        ? "Kya aapko OTP verification mein dikkat aa rahi hai ya account login karne mein?"
        : "Are you having trouble with OTP verification or logging into your account?";
    }
    if (/\b(class\s*6|class\s*7|class\s*8|6th|7th|8th)\b/i.test(q)) {
      return "Classes 6th–8th fees: ₹1,000–₹1,300/month (CBSE/UP/ICSE). Visit /fee-calculator or apply on /admission.";
    }
    if (/\b(class\s*9|class\s*10|9th|10th)\b/i.test(q)) {
      return "Classes 9th–10th Board Mastery fees: ₹1,400/month (₹14,300/year) for CBSE, ₹1,200/month for UP Board, ₹1,500/month for ICSE.";
    }
    if (/\b(class\s*11|class\s*12|11th|12th)\b/i.test(q)) {
      return "Classes 11th–12th subject coaching fees: ₹1,500–₹1,800/month depending on board. Apply on /admission.";
    }
    if (/\b(neet|jee)\b/i.test(q)) {
      return "NEET & JEE Foundation/Target coaching fees: ₹2,400/month (₹24,500/year). Book a free demo on /contact.";
    }
    if (/\b(cuet|nda|ssc|banking)\b/i.test(q)) {
      return "CUET & Competitive Exam coaching fees start at ₹1,800–₹2,000/month at Yuitor Muradnagar.";
    }
    if (/\b(computer|dca|tally|ccc|ai|python|coding)\b/i.test(q)) {
      return "Computer Courses (DCA/CCC/Tally) start at ₹1,200/month and AI/Python Coding starts at ₹800–₹2,100/month.";
    }
    if (/\b(english|spoken)\b/i.test(q)) {
      return "Spoken English & Communication batches start at ₹1,500/month. Visit /english-speaking for details.";
    }
    if (/\b(address|location|where|muradnagar|kahan|contact|phone|whatsapp|call)\b/i.test(q)) {
      return "Yuitor Smart Classes is at Trimurti Vihar, Near Venus Academy, Muradnagar - 201206. Call/WhatsApp: +91 78-2728-9292.";
    }
    return isHindi
      ? "Main Yuitor Smart Classes ke courses, fees, admission (/admission), aur Muradnagar batches ke baare mein madad kar sakti hoon. Call/WhatsApp: +91 78-2728-9292."
      : "I can help with Yuitor Smart Classes courses, fees (/fee-calculator), Muradnagar admissions (/admission), and portal login (/login). For direct counselling, call +91 78-2728-9292.";
  }

  async function safeFetchJson(url, payload) {
    const res = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(payload || {}),
    });
    const text = await res.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    return { ok: res.ok, status: res.status, data };
  }

  async function ensureSession() {
    try {
      const { ok, data } = await safeFetchJson("/api/public/chatbot/session", { conversationId, visitorId });
      if (!ok) return;
      if (data?.conversation?.id) {
        conversationId = data.conversation.id;
        sessionStorage.setItem("yuitor_shreya_conv_id", conversationId);
      }
      if (Array.isArray(data?.messages) && data.messages.length) {
        renderMessages(data.messages);
      }
    } catch {
      // Keep local intro visible cleanly
    }
  }

  async function sendMessage(text) {
    const clean = String(text || "").trim();
    if (!clean || busy) return;
    busy = true;
    input.disabled = true;

    localMessages.push({ sender: "user", message: clean });

    const uBubble = document.createElement("div");
    uBubble.style.cssText =
      "align-self:flex-end;background:#0f172a;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;";
    uBubble.textContent = clean;
    msgsEl.appendChild(uBubble);

    const typing = document.createElement("div");
    typing.style.cssText =
      "align-self:flex-start;background:#fff;border:1px solid #dbe6ef;color:#64748b;padding:7px 11px;border-radius:12px;font-size:12px;";
    typing.textContent = "Shreya is typing...";
    msgsEl.appendChild(typing);
    msgsEl.scrollTop = msgsEl.scrollHeight;
    input.value = "";

    try {
      if (!conversationId) await ensureSession();
      const payload = {
        conversationId,
        message: clean,
        visitorName: box.querySelector("#yu-v-name").value.trim() || undefined,
        visitorPhone: box.querySelector("#yu-v-phone").value.trim() || undefined,
        visitorEmail: box.querySelector("#yu-v-email").value.trim() || undefined,
      };
      let { ok, data } = await safeFetchJson("/api/public/chatbot/message", payload);
      if (!ok && conversationId) {
        // Retry once with fresh conversationId in case stale ID failed
        conversationId = "";
        sessionStorage.removeItem("yuitor_shreya_conv_id");
        ({ ok, data } = await safeFetchJson("/api/public/chatbot/message", { ...payload, conversationId: "" }));
      }
      if (data?.conversationId) {
        conversationId = data.conversationId;
        sessionStorage.setItem("yuitor_shreya_conv_id", conversationId);
      }
      if (ok && Array.isArray(data?.messages) && data.messages.length) {
        renderMessages(data.messages);
      } else if (ok && data?.reply) {
        typing.textContent = data.reply;
        typing.style.color = "#0f172a";
      } else if (data?.error) {
        typing.textContent = data.error;
        typing.style.color = "#0f172a";
      } else {
        const reply = localFallbackReply(clean);
        localMessages.push({ sender: "assistant", message: reply });
        typing.textContent = reply;
        typing.style.color = "#0f172a";
      }
    } catch {
      const reply = localFallbackReply(clean);
      localMessages.push({ sender: "assistant", message: reply });
      typing.textContent = reply;
      typing.style.color = "#0f172a";
    } finally {
      busy = false;
      input.disabled = false;
      input.focus();
    }
  }

  toggle.addEventListener("click", () => {
    box.hidden = !box.hidden;
    if (!box.hidden) {
      ensureSession();
      input.focus();
    }
  });
  closeBtn.addEventListener("click", () => {
    box.hidden = true;
  });
  infoBtn.addEventListener("click", () => {
    contactPanel.hidden = !contactPanel.hidden;
    contactPanel.style.display = contactPanel.hidden ? "none" : "grid";
  });
  rateBtn.addEventListener("click", () => {
    rateForm.hidden = !rateForm.hidden;
    rateForm.style.display = rateForm.hidden ? "none" : "grid";
  });
  rateForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      if (!conversationId) await ensureSession();
      await safeFetchJson("/api/public/chatbot/feedback", {
        conversationId,
        rating: currentRating,
        feedback: box.querySelector("#yu-fb-text").value.trim(),
        resolved: currentRating >= 4,
      });
    } catch {
      // Keep UI responsive
    }
    rateForm.hidden = true;
    rateForm.style.display = "none";
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendMessage(input.value);
  });
})();
