(() => {
  "use strict";

  const root = document.getElementById("root");
  if (!root) return;

  const DEFAULT_META_COLOR = "#0F172A";
  const DISMISS_BANNER_PREFIX = "yuitor_festival_banner_dismissed_";
  const DISMISS_POPUP_PREFIX = "yuitor_festival_popup_dismissed_";
  const SEATS_DISMISSED_KEY = "yuitor_seats_popup_dismissed";

  const controllerState = {
    serverConfig: null,
    transientConfig: null,
    resolution: null,
    fetching: false,
    popupAutoTimer: null,
    lastAutoPopupKey: null,
  };

  function getEngine() {
    return window.YuitorFestivalEngine || null;
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    })[ch]);
  }

  const PORTAL_ROUTE_RE = /^\/(?:admin(?:-setup)?|student|teacher|teacher-apply\.php|login|register|unsubscribe|erp)(?:\/|$|\.)/i;

  function isPortalRoute() {
    const p = window.location.pathname || "/";
    return PORTAL_ROUTE_RE.test(p);
  }

  function navigateSpa(href) {
    if (!href) return;
    try {
      const targetUrl = new URL(href, window.location.origin);
      if (targetUrl.origin === window.location.origin && !PORTAL_ROUTE_RE.test(targetUrl.pathname)) {
        window.history.pushState({}, "", targetUrl.pathname + targetUrl.search + targetUrl.hash);
        window.dispatchEvent(new PopStateEvent("popstate"));
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
    } catch {
      // Fallback to normal navigation
    }
    window.location.assign(href);
  }

  function copyPromoToClipboard(code, buttonEl) {
    if (!code) return;
    const finish = () => {
      if (!buttonEl) return;
      const orig = buttonEl.dataset.origLabel || buttonEl.textContent || "Copy Code";
      buttonEl.dataset.origLabel = orig;
      buttonEl.textContent = "Copied!";
      buttonEl.classList.add("is-copied");
      window.setTimeout(() => {
        if (buttonEl.isConnected) {
          buttonEl.textContent = orig;
          buttonEl.classList.remove("is-copied");
        }
      }, 2000);
    };

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(code).then(finish).catch(() => {
        fallbackCopy(code);
        finish();
      });
    } else {
      fallbackCopy(code);
      finish();
    }
  }

  function fallbackCopy(text) {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    } catch {
      // Ignore clipboard failures
    }
  }

  function getUrlPreviewOverrides() {
    try {
      const params = new URLSearchParams(window.location.search);
      const fest = params.get("festival");
      const dateParam = params.get("festivalDate");
      if (fest === "none" || fest === "off" || fest === "disabled") {
        return { mode: "disabled", manualFestivalId: null, simulatedDateIST: null };
      }
      if (fest) {
        return { mode: "manual", manualFestivalId: fest, simulatedDateIST: null };
      }
      if (dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)) {
        return { mode: "automatic", manualFestivalId: null, simulatedDateIST: dateParam };
      }
    } catch {
      // Ignore malformed query strings
    }
    return null;
  }

  function getEffectiveConfig() {
    const engine = getEngine();
    const base = engine ? { ...engine.DEFAULT_ADMIN_CONFIG } : {
      mode: "automatic",
      manualFestivalId: null,
      simulatedDateIST: null,
      overrides: {},
    };
    const merged = {
      ...base,
      ...(controllerState.serverConfig || {}),
      ...(controllerState.transientConfig || {}),
      overrides: {
        ...(controllerState.serverConfig?.overrides || {}),
        ...(controllerState.transientConfig?.overrides || {}),
      },
    };
    const urlOverride = getUrlPreviewOverrides();
    if (urlOverride) {
      return { ...merged, ...urlOverride };
    }
    return merged;
  }

  function getMotifEmblemSvg(motif, accent) {
    switch (motif) {
      case "diwali_diyas":
        return `<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true">
          <defs>
            <radialGradient id="yuFlameGlow" cx="50%" cy="45%" r="50%">
              <stop offset="0%" stop-color="#FFFBEB"/>
              <stop offset="55%" stop-color="#F59E0B"/>
              <stop offset="100%" stop-color="#EA580C" stop-opacity="0"/>
            </radialGradient>
          </defs>
          <circle cx="24" cy="18" r="14" fill="url(#yuFlameGlow)"/>
          <path class="yu-diya-flame" d="M24 7c3.6 5.2 5.4 9.1 5.4 12.2a5.4 5.4 0 0 1-10.8 0C18.6 16.1 20.4 12.2 24 7Z" fill="#FBBF24"/>
          <path class="yu-diya-flame" d="M24 11.5c1.8 2.8 2.7 5 2.7 6.8a2.7 2.7 0 0 1-5.4 0c0-1.8.9-4 2.7-6.8Z" fill="#FEF3C7"/>
          <path d="M9 28h30c-1.8 7.5-7.8 11.8-15 11.8S10.8 35.5 9 28Z" fill="#D97706"/>
          <path d="M12 28h24c-1.4 4.2-6 6.8-12 6.8S13.4 32.2 12 28Z" fill="#F59E0B"/>
          <ellipse cx="24" cy="28" rx="15" ry="2.6" fill="#FCD34D"/>
        </svg>`;
      case "eid_crescent":
        return `<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true">
          <path d="M28.5 10a13.5 13.5 0 1 0 9.5 23 11 11 0 1 1-9.5-23Z" fill="#D4AF37"/>
          <polygon points="34,13 35.4,16.6 39.2,16.8 36.2,19.1 37.2,22.8 34,20.7 30.8,22.8 31.8,19.1 28.8,16.8 32.6,16.6" fill="#FDE68A"/>
        </svg>`;
      case "holi_gulal":
        return `<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true">
          <circle cx="19" cy="20" r="10" fill="#EC4899" opacity="0.85"/>
          <circle cx="30" cy="22" r="9" fill="#0D9488" opacity="0.82"/>
          <circle cx="24" cy="30" r="8.5" fill="#F59E0B" opacity="0.88"/>
          <circle cx="34" cy="14" r="3" fill="#7C3AED"/>
          <circle cx="12" cy="31" r="2.6" fill="#DB2777"/>
        </svg>`;
      case "christmas_snow":
        return `<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true">
          <path d="M24 8l6 10h-4l6 9h-5l5 8H16l5-8h-5l6-9h-4l6-10Z" fill="#16A34A"/>
          <rect x="21.5" y="35" width="5" height="6" rx="1" fill="#B45309"/>
          <polygon points="24,4 25.3,7.3 28.8,7.5 26,9.7 27,13 24,11 21,13 22,9.7 19.2,7.5 22.7,7.3" fill="#FACC15"/>
        </svg>`;
      case "patriotic_tricolor":
        return `<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true">
          <rect x="8" y="10" width="32" height="9" rx="2" fill="#EA580C"/>
          <rect x="8" y="19" width="32" height="10" fill="#FFFFFF" stroke="#CBD5E1" stroke-width="0.6"/>
          <rect x="8" y="29" width="32" height="9" rx="2" fill="#15803D"/>
          <circle cx="24" cy="24" r="4" fill="none" stroke="#1D4ED8" stroke-width="1.5"/>
          <circle cx="24" cy="24" r="1.2" fill="#1D4ED8"/>
        </svg>`;
      case "rakhi_threads":
        return `<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true">
          <path d="M6 24h36" stroke="#D97706" stroke-width="3" stroke-linecap="round"/>
          <circle cx="24" cy="24" r="10" fill="#BE185D" stroke="#FBBF24" stroke-width="2.5"/>
          <circle cx="24" cy="24" r="4.5" fill="#FDE68A"/>
        </svg>`;
      case "navratri_garba":
        return `<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true">
          <circle cx="24" cy="24" r="15" fill="none" stroke="#F59E0B" stroke-width="2" stroke-dasharray="4 3"/>
          <line x1="14" y1="34" x2="34" y2="14" stroke="#FB7185" stroke-width="3.2" stroke-linecap="round"/>
          <line x1="14" y1="14" x2="34" y2="34" stroke="#FBBF24" stroke-width="3.2" stroke-linecap="round"/>
        </svg>`;
      case "sikh_lamps":
        return `<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true">
          <circle cx="24" cy="24" r="13" fill="none" stroke="#D97706" stroke-width="2.2"/>
          <path d="M24 9v30M15 16c4 5 4 11 0 16M33 16c-4 5-4 11 0 16" stroke="#1E3A8A" stroke-width="2.4" fill="none" stroke-linecap="round"/>
        </svg>`;
      default:
        return `<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true">
          <circle cx="24" cy="24" r="11" fill="${escapeHtml(accent || "#F59E0B")}" opacity="0.22"/>
          <polygon points="24,8 27.6,18.2 38.4,18.4 29.8,24.9 33,35.2 24,29 15,35.2 18.2,24.9 9.6,18.4 20.4,18.2" fill="${escapeHtml(accent || "#F59E0B")}"/>
        </svg>`;
    }
  }

  function buildDiyaSvg() {
    return `<svg class="yu-diya-svg" viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <radialGradient id="yuHeroDiyaAura" cx="50%" cy="35%" r="50%">
          <stop offset="0%" stop-color="#FEF3C7" stop-opacity="0.95"/>
          <stop offset="55%" stop-color="#F59E0B" stop-opacity="0.35"/>
          <stop offset="100%" stop-color="#F59E0B" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <circle cx="32" cy="22" r="20" fill="url(#yuHeroDiyaAura)"/>
      <path class="yu-diya-flame" d="M32 9c5 7.2 7.5 12.6 7.5 16.8a7.5 7.5 0 0 1-15 0C24.5 21.6 27 16.2 32 9Z" fill="#F59E0B"/>
      <path class="yu-diya-flame" d="M32 15c2.6 4 3.9 7 3.9 9.4a3.9 3.9 0 0 1-7.8 0c0-2.4 1.3-5.4 3.9-9.4Z" fill="#FEF9C3"/>
      <path d="M12 37h40c-2.5 10.5-10.8 16.5-20 16.5S14.5 47.5 12 37Z" fill="#B45309"/>
      <path d="M15 37h34c-2 6.2-8.2 10-17 10s-15-3.8-17-10Z" fill="#D97706"/>
      <ellipse cx="32" cy="37" rx="20" ry="3.4" fill="#FBBF24"/>
    </svg>`;
  }

  function buildTrimGarland(motif) {
    if (motif === "diwali_diyas") {
      return `
        <svg viewBox="0 0 120 20" width="96" height="16" aria-hidden="true">
          <path d="M0 4 Q20 16 40 4 T80 4 T120 4" fill="none" stroke="#FBBF24" stroke-width="1.6"/>
          <circle cx="20" cy="10" r="2.8" fill="#F59E0B"/>
          <circle cx="60" cy="10" r="3.2" fill="#FDE68A"/>
          <circle cx="100" cy="10" r="2.8" fill="#FB923C"/>
        </svg>`;
    }
    if (motif === "patriotic_tricolor") {
      return `
        <svg viewBox="0 0 100 16" width="88" height="14" aria-hidden="true">
          <polygon points="0,0 20,0 10,14" fill="#EA580C"/>
          <polygon points="20,0 40,0 30,14" fill="#FFFFFF"/>
          <polygon points="40,0 60,0 50,14" fill="#15803D"/>
          <polygon points="60,0 80,0 70,14" fill="#EA580C"/>
          <polygon points="80,0 100,0 90,14" fill="#15803D"/>
        </svg>`;
    }
    if (motif === "eid_crescent") {
      return `
        <svg viewBox="0 0 100 18" width="88" height="15" aria-hidden="true">
          <path d="M0 3 Q25 14 50 3 T100 3" fill="none" stroke="#D4AF37" stroke-width="1.4"/>
          <circle cx="25" cy="9" r="2.5" fill="#FDE68A"/>
          <circle cx="75" cy="9" r="2.5" fill="#34D399"/>
        </svg>`;
    }
    return `
      <svg viewBox="0 0 100 18" width="88" height="15" aria-hidden="true">
        <path d="M0 3 Q25 14 50 3 T100 3" fill="none" stroke="currentColor" stroke-width="1.4" opacity="0.7"/>
        <circle cx="25" cy="9" r="2.3" fill="currentColor"/>
        <circle cx="75" cy="9" r="2.3" fill="currentColor"/>
      </svg>`;
  }

  function buildHeroOrnamentsHtml(motif) {
    if (motif === "diwali_diyas") {
      return `
        <span class="yu-sparkle" style="top:14%;left:46%;animation-delay:0.2s"></span>
        <span class="yu-sparkle" style="top:24%;right:14%;animation-delay:1.1s"></span>
        <span class="yu-sparkle" style="top:62%;left:8%;animation-delay:2.0s"></span>
        <span class="yu-sparkle" style="top:38%;right:6%;animation-delay:0.7s"></span>
        <span class="yu-sparkle" style="bottom:26%;left:48%;animation-delay:2.7s"></span>
        <div class="yu-diya-row" aria-hidden="true">
          ${buildDiyaSvg()}
          ${buildDiyaSvg()}
          ${buildDiyaSvg()}
        </div>`;
    }
    if (motif === "eid_crescent") {
      return `
        <div class="yu-eid-lanterns" aria-hidden="true">
          <svg class="yu-lantern-sway" width="34" height="72" viewBox="0 0 34 72">
            <line x1="17" y1="0" x2="17" y2="20" stroke="#D4AF37" stroke-width="1.5"/>
            <path d="M10 20h14l4 14-11 16-11-16Z" fill="rgba(212,175,55,0.22)" stroke="#D4AF37" stroke-width="1.6"/>
            <circle cx="17" cy="34" r="4" fill="#FDE68A"/>
          </svg>
          <svg class="yu-lantern-sway" width="28" height="58" viewBox="0 0 34 72">
            <line x1="17" y1="0" x2="17" y2="16" stroke="#34D399" stroke-width="1.5"/>
            <path d="M10 16h14l4 14-11 16-11-16Z" fill="rgba(52,211,153,0.18)" stroke="#34D399" stroke-width="1.6"/>
            <circle cx="17" cy="30" r="3.5" fill="#FDE68A"/>
          </svg>
        </div>`;
    }
    if (motif === "christmas_snow") {
      return `
        <span class="yu-snow-dot" style="left:12%;animation-delay:0s"></span>
        <span class="yu-snow-dot" style="left:28%;animation-delay:2.2s"></span>
        <span class="yu-snow-dot" style="left:52%;animation-delay:4.1s"></span>
        <span class="yu-snow-dot" style="left:74%;animation-delay:1.5s"></span>
        <span class="yu-snow-dot" style="left:89%;animation-delay:3.3s"></span>`;
    }
    if (motif === "holi_gulal") {
      return `
        <div class="yu-holi-splash" style="width:180px;height:180px;top:-40px;right:12%;background:radial-gradient(circle,#ec4899,transparent 70%)"></div>
        <div class="yu-holi-splash" style="width:150px;height:150px;bottom:30px;left:4%;background:radial-gradient(circle,#0d9488,transparent 70%);animation-delay:1.8s"></div>`;
    }
    return "";
  }

  function getLiveCountdown() {
    const engine = getEngine();
    const res = controllerState.resolution;
    if (!engine || !res || !res.activeOccurrence) {
      return {
        formattedCompact: "00h : 00m : 00s",
        formattedClock: "",
      };
    }
    const isPreviewOrManual = res.mode === "manual" || res.isSimulatedDate;
    return engine.getFestivalCountdownParts(
      res.activeOccurrence.endDate,
      new Date(),
      isPreviewOrManual
    );
  }

  const setTextIfChanged = (el, val) => {
    if (el && el.textContent !== val) el.textContent = val;
  };

  function updateLiveTimers() {
    if (document.hidden) return;
    const res = controllerState.resolution;
    if (!res || !res.activeOccurrence) return;
    const headTimer = document.getElementById("yu-festival-head-countdown");
    const headClock = document.getElementById("yu-festival-head-clock");
    const bannerTimer = document.getElementById("yu-festival-banner-countdown");
    const popupTimer = document.getElementById("yu-festival-popup-countdown");
    if (!headTimer && !headClock && !bannerTimer && !popupTimer) return;

    const countdown = getLiveCountdown();
    setTextIfChanged(headTimer, `Ends in ${countdown.formattedCompact}`);
    if (headClock && countdown.formattedClock) {
      setTextIfChanged(headClock, countdown.formattedClock);
    }
    setTextIfChanged(bannerTimer, countdown.formattedCompact);
    setTextIfChanged(popupTimer, `Offer ends in ${countdown.formattedCompact} · ${countdown.formattedClock}`);
  }

  function closeFestivalPromoPopup(persistDismiss = true) {
    const overlay = document.getElementById("yu-festival-promo-popup");
    if (overlay) {
      overlay.remove();
    }
    const res = controllerState.resolution;
    if (persistDismiss && res && res.activeOccurrence) {
      const key = `${DISMISS_POPUP_PREFIX}${res.activeOccurrence.festival.id}_${res.istNow.isoDate}`;
      try {
        window.localStorage?.setItem(key, "1");
      } catch {
        // Ignore storage restrictions
      }
    }
  }

  function openFestivalPromoPopup(force = false) {
    const res = controllerState.resolution;
    if (!res || !res.activeOccurrence || !res.activePromo) return;
    if (!force && isPortalRoute()) return;

    const occ = res.activeOccurrence;
    const festival = occ.festival;
    const theme = res.activeTheme;
    const promo = res.activePromo;
    const dismissKey = `${DISMISS_POPUP_PREFIX}${festival.id}_${res.istNow.isoDate}`;

    if (!force) {
      try {
        if (window.localStorage?.getItem(dismissKey) === "1") return;
      } catch {
        // Ignore storage restrictions
      }
      if (document.querySelector(".yu-shared-popup")) {
        return;
      }
    }

    const countdown = getLiveCountdown();
    let overlay = document.getElementById("yu-festival-promo-popup");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "yu-festival-promo-popup";
      overlay.className = "yu-festival-popup-overlay";
      overlay.setAttribute("role", "dialog");
      overlay.setAttribute("aria-modal", "true");
      overlay.setAttribute("aria-labelledby", "yu-festival-popup-heading");
      overlay.dataset.testid = "festival-promo-popup";
      document.body.appendChild(overlay);
    }

    const sig = `${festival.id}|${promo.code}|${occ.effectiveGreetingTitle}`;
    if (overlay.dataset.sig !== sig) {
      overlay.dataset.sig = sig;
      const shortName = festival.name.replace(/\s*\([^)]*\)/g, "").trim() || festival.name;
      overlay.innerHTML = `
        <div class="yu-festival-popup-card">
          <button type="button" class="yu-festival-popup-close" data-testid="button-festival-popup-close" aria-label="Close ${escapeHtml(shortName)} discount offer">×</button>
          <div class="yu-festival-popup-top">
            <div class="yu-festival-popup-emblem">${getMotifEmblemSvg(theme.motif, theme.accent)}</div>
            <span class="yu-festival-popup-pill">
              <span aria-hidden="true">✳</span>
              <span>${escapeHtml(shortName)} Special · 30% OFF</span>
            </span>
          </div>
          <h3 id="yu-festival-popup-heading" class="yu-festival-popup-title">${escapeHtml(occ.effectiveGreetingTitle)}</h3>
          <p class="yu-festival-popup-offer">
            Today on <strong>${escapeHtml(shortName)}</strong>, get a <strong>${promo.discountPercent}% discount</strong> on all courses!
          </p>
          <p class="yu-festival-popup-sub">${escapeHtml(occ.effectiveGreetingSubtitle)}</p>
          <div class="yu-festival-popup-promo-box">
            <div>
              <span class="yu-promo-label">FESTIVAL PROMO CODE</span>
              <strong class="yu-promo-code" data-testid="festival-popup-promo-code">${escapeHtml(promo.code)}</strong>
            </div>
            <button type="button" class="yu-promo-copy-btn" data-copy-code="${escapeHtml(promo.code)}" data-testid="button-popup-copy-promo">Copy Code</button>
          </div>
          <p class="yu-festival-popup-timer" id="yu-festival-popup-countdown" data-testid="festival-popup-timer">
            Offer ends in ${escapeHtml(countdown.formattedCompact)} · ${escapeHtml(countdown.formattedClock)}
          </p>
          <div class="yu-festival-popup-actions">
            <a href="/contact?promo=${encodeURIComponent(promo.code)}" class="yu-fhero-cta" data-testid="button-festival-popup-cta">Claim ${promo.discountPercent}% Discount ↗</a>
          </div>
        </div>
      `;

      overlay.querySelector('[data-testid="button-festival-popup-close"]')?.addEventListener("click", () => {
        closeFestivalPromoPopup(true);
      });
      overlay.addEventListener("click", (ev) => {
        if (ev.target === overlay) {
          closeFestivalPromoPopup(true);
        }
      });
      overlay.querySelector("[data-copy-code]")?.addEventListener("click", (ev) => {
        copyPromoToClipboard(promo.code, ev.currentTarget);
      });
      overlay.querySelector('[data-testid="button-festival-popup-cta"]')?.addEventListener("click", (ev) => {
        ev.preventDefault();
        closeFestivalPromoPopup(true);
        navigateSpa(`/contact?promo=${encodeURIComponent(promo.code)}`);
      });
    }
  }

  function scheduleFestivalPopupIfNeeded(resolution) {
    if (!resolution || !resolution.activeOccurrence || !resolution.activePromo || isPortalRoute()) {
      if (controllerState.popupAutoTimer) {
        window.clearTimeout(controllerState.popupAutoTimer);
        controllerState.popupAutoTimer = null;
      }
      controllerState.lastAutoPopupKey = null;
      closeFestivalPromoPopup(false);
      return;
    }
    const key = `${resolution.activeOccurrence.festival.id}_${resolution.istNow.isoDate}`;
    if (controllerState.lastAutoPopupKey === key) return;

    if (controllerState.popupAutoTimer) {
      window.clearTimeout(controllerState.popupAutoTimer);
      controllerState.popupAutoTimer = null;
    }

    const dismissKey = `${DISMISS_POPUP_PREFIX}${key}`;
    let alreadyDismissed = false;
    try {
      alreadyDismissed = window.localStorage?.getItem(dismissKey) === "1";
    } catch {
      alreadyDismissed = false;
    }
    if (alreadyDismissed) return;

    controllerState.lastAutoPopupKey = key;
    controllerState.popupAutoTimer = window.setTimeout(() => {
      controllerState.popupAutoTimer = null;
      openFestivalPromoPopup(false);
    }, 1800);
  }

  function removeFestiveDom() {
    document.getElementById("yu-festival-header-trim")?.remove();
    document.getElementById("yu-festival-banner")?.remove();
    document.getElementById("yu-festival-hero-ornaments")?.remove();
    document.getElementById("yu-festival-footer-wish")?.remove();
    closeFestivalPromoPopup(false);
  }

  let lastMeasuredWidth = 0;
  let cachedHeaderHeight = 0;
  let cachedHeaderBottom = 0;

  function applyFestivalDom(resolution) {
    const html = document.documentElement;
    const occ = resolution.activeOccurrence;
    const theme = resolution.activeTheme;
    const promo = resolution.activePromo;
    const portalRoute = isPortalRoute();

    if (!occ || !promo || portalRoute) {
      if (!occ || !promo) {
        if (html.getAttribute("data-festival") !== "none") html.setAttribute("data-festival", "none");
        if (html.getAttribute("data-festival-motif") !== "academic_default") html.setAttribute("data-festival-motif", "academic_default");
        if (html.getAttribute("data-festival-dark") !== "false") html.setAttribute("data-festival-dark", "false");
        document
          .querySelectorAll('meta[name="theme-color"], meta[name="msapplication-TileColor"]')
          .forEach((m) => {
            if (m.getAttribute("content") !== DEFAULT_META_COLOR) m.setAttribute("content", DEFAULT_META_COLOR);
          });
      }
      removeFestiveDom();
      return;
    }

    const festival = occ.festival;
    const shortName = festival.name.replace(/\s*\([^)]*\)/g, "").trim() || festival.name;
    const countdown = getLiveCountdown();

    if (html.getAttribute("data-festival") !== festival.id) html.setAttribute("data-festival", festival.id);
    if (html.getAttribute("data-festival-motif") !== theme.motif) html.setAttribute("data-festival-motif", theme.motif);
    const darkStr = theme.isDark ? "true" : "false";
    if (html.getAttribute("data-festival-dark") !== darkStr) html.setAttribute("data-festival-dark", darkStr);
    document
      .querySelectorAll('meta[name="theme-color"], meta[name="msapplication-TileColor"]')
      .forEach((m) => {
        if (m.getAttribute("content") !== theme.bg) m.setAttribute("content", theme.bg);
      });

    // 1. Header decorative trim + live running timer & promo code in head
    const header = root.querySelector(".yu-shared-header");
    if (header) {
      let trim = document.getElementById("yu-festival-header-trim");
      if (!trim) {
        trim = document.createElement("div");
        trim.id = "yu-festival-header-trim";
        trim.className = "yu-festival-header-trim";
        header.appendChild(trim);
        lastMeasuredWidth = 0;
      }
      const trimSig = `${festival.id}|${promo.code}|${resolution.istNow.isoDate}`;
      if (trim.dataset.sig !== trimSig) {
        trim.dataset.sig = trimSig;
        trim.innerHTML = `
          <div class="yu-festival-trim-left">
            <span class="yu-festival-trim-dot" aria-hidden="true"></span>
            <span class="yu-festival-trim-text">Today on <strong>${escapeHtml(shortName)}</strong>: <strong>${promo.discountPercent}% OFF</strong></span>
            <span class="yu-festival-trim-code">Code: <strong>${escapeHtml(promo.code)}</strong></span>
          </div>
          <div class="yu-festival-trim-right">
            <span class="yu-head-timer" id="yu-festival-head-countdown" data-testid="festival-head-timer">Ends in ${escapeHtml(countdown.formattedCompact)}</span>
            <span class="yu-head-clock" id="yu-festival-head-clock" data-testid="festival-head-clock">${escapeHtml(countdown.formattedClock)}</span>
            <span class="yu-festival-trim-garland" aria-hidden="true">${buildTrimGarland(theme.motif)}</span>
          </div>
        `;
        lastMeasuredWidth = 0;
      }
      const viewportW = window.innerWidth;
      if (lastMeasuredWidth !== viewportW || cachedHeaderHeight === 0) {
        lastMeasuredWidth = viewportW;
        const headerRect = header.getBoundingClientRect();
        cachedHeaderHeight = Math.ceil(headerRect.height);
        cachedHeaderBottom = Math.ceil(headerRect.bottom);
        if (cachedHeaderHeight > 0) {
          html.style.setProperty("--yu-header-height", `${cachedHeaderHeight}px`);
        }
        if (cachedHeaderBottom > 0) {
          html.style.setProperty("--yu-header-bottom", `${cachedHeaderBottom}px`);
        }
      }
    }

    // 2. Hero-Style Festival Offer & Greeting Showcase directly below header on ALL pages
    const main = root.querySelector("main");
    const dismissKey = `${DISMISS_BANNER_PREFIX}${festival.id}_${resolution.istNow.isoDate}`;
    const isDismissed = window.sessionStorage?.getItem(dismissKey) === "1";

    if (main && !isDismissed) {
      let bannerWrap = document.getElementById("yu-festival-banner");
      if (!bannerWrap) {
        bannerWrap = document.createElement("section");
        bannerWrap.id = "yu-festival-banner";
        bannerWrap.className = "yu-festival-banner-wrap";
        bannerWrap.setAttribute("role", "region");
        bannerWrap.setAttribute("aria-label", `${shortName} Festival Celebration and 30% Discount Offer`);
        main.prepend(bannerWrap);
      } else if (bannerWrap.parentElement !== main) {
        main.prepend(bannerWrap);
      }

      const sig = `${festival.id}|${promo.code}|${occ.effectiveGreetingTitle}|${occ.effectiveGreetingSubtitle}|${resolution.istNow.isoDate}|${resolution.mode}`;
      if (bannerWrap.dataset.sig !== sig) {
        bannerWrap.dataset.sig = sig;
        const modeLabel = resolution.mode === "manual"
          ? "Festival Celebration"
          : resolution.isSimulatedDate
          ? "IST Calendar Preview"
          : occ.isExactDay
          ? "Today in India (IST)"
          : "Festive Week (IST)";

        bannerWrap.innerHTML = `
          <div class="yu-festival-hero-card" data-testid="festival-greeting-banner">
            <button type="button" class="yu-festival-banner-close" aria-label="Dismiss ${escapeHtml(shortName)} showcase" title="Dismiss banner">×</button>
            <div class="yu-fhero-grid">
              <div class="yu-fhero-copy">
                <div class="yu-fhero-pill">
                  <span class="yu-fhero-mark" aria-hidden="true">✳</span>
                  <span>${escapeHtml(shortName)} · ${escapeHtml(festival.tradition)} · ${escapeHtml(modeLabel)}</span>
                </div>
                <h2 class="yu-fhero-title">
                  ${escapeHtml(occ.effectiveGreetingTitle)}
                  <br />
                  <em>Today on ${escapeHtml(shortName)} — ${promo.discountPercent}% Discount!</em>
                </h2>
                <p class="yu-fhero-lede">
                  ${escapeHtml(occ.effectiveGreetingSubtitle)} Use promo code <strong>${escapeHtml(promo.code)}</strong> for <strong>${promo.discountPercent}% OFF</strong> on school coaching, board batches, JEE, NEET &amp; CUET programmes.
                </p>
                <div class="yu-fhero-offer-bar">
                  <div class="yu-promo-ticket">
                    <div>
                      <span class="yu-promo-label">PROMO CODE</span>
                      <strong class="yu-promo-code" data-testid="festival-promo-code">${escapeHtml(promo.code)}</strong>
                    </div>
                    <button type="button" class="yu-promo-copy-btn" data-copy-code="${escapeHtml(promo.code)}" data-testid="button-copy-promo">Copy Code</button>
                  </div>
                  <div class="yu-fhero-timer-box">
                    <span class="yu-promo-label">OFFER ENDS IN (IST)</span>
                    <strong class="yu-fhero-timer-val" id="yu-festival-banner-countdown" data-testid="festival-banner-timer">${escapeHtml(countdown.formattedCompact)}</strong>
                  </div>
                  <a href="/contact?promo=${encodeURIComponent(promo.code)}" class="yu-fhero-cta" data-testid="button-banner-claim">Claim ${promo.discountPercent}% Off <span aria-hidden="true">↗</span></a>
                  <button type="button" class="yu-fhero-popup-btn" data-testid="button-open-festival-popup">Offer Popup</button>
                </div>
              </div>
              <div class="yu-fhero-aside">
                <div class="yu-festival-emblem-lg">${getMotifEmblemSvg(theme.motif, theme.accent)}</div>
                <div class="yu-fhero-discount-badge">
                  <strong>${promo.discountPercent}% OFF</strong>
                  <span>Festival Admission Offer</span>
                </div>
                <p class="yu-fhero-aside-note">Valid for Classes 6–12 · JEE · NEET · CUET (${escapeHtml(
                  resolution.mode === "manual"
                    ? `${shortName} Special · Ends 11:59 PM IST`
                    : resolution.istNow.formattedDate
                )})</p>
              </div>
            </div>
          </div>
        `;

        bannerWrap.querySelector(".yu-festival-banner-close")?.addEventListener("click", () => {
          try {
            window.sessionStorage?.setItem(dismissKey, "1");
          } catch {
            // Ignore storage restrictions
          }
          bannerWrap.remove();
        });
        bannerWrap.querySelector("[data-copy-code]")?.addEventListener("click", (ev) => {
          copyPromoToClipboard(promo.code, ev.currentTarget);
        });
        bannerWrap.querySelector('[data-testid="button-open-festival-popup"]')?.addEventListener("click", () => {
          openFestivalPromoPopup(true);
        });
        bannerWrap.querySelector('[data-testid="button-banner-claim"]')?.addEventListener("click", (ev) => {
          ev.preventDefault();
          navigateSpa(`/contact?promo=${encodeURIComponent(promo.code)}`);
        });
      }
    } else if (isDismissed) {
      document.getElementById("yu-festival-banner")?.remove();
    }

    // 3. Hero Lightweight Ornaments (when on Homepage)
    const hero = root.querySelector(".yn-home .yn-hero");
    if (hero) {
      let ornaments = document.getElementById("yu-festival-hero-ornaments");
      if (!ornaments) {
        ornaments = document.createElement("div");
        ornaments.id = "yu-festival-hero-ornaments";
        ornaments.className = "yu-festival-hero-ornaments";
        ornaments.setAttribute("aria-hidden", "true");
        hero.appendChild(ornaments);
      }
      if (ornaments.dataset.motif !== theme.motif) {
        ornaments.dataset.motif = theme.motif;
        ornaments.innerHTML = buildHeroOrnamentsHtml(theme.motif);
      }
    } else {
      document.getElementById("yu-festival-hero-ornaments")?.remove();
    }

    // 4. Footer Festive Wish + Promo Code reminder
    const footer = root.querySelector("footer.yu-shared-footer");
    if (footer) {
      let footerWish = document.getElementById("yu-festival-footer-wish");
      if (!footerWish) {
        footerWish = document.createElement("div");
        footerWish.id = "yu-festival-footer-wish";
        footerWish.className = "yu-festival-footer-wish";
        footer.prepend(footerWish);
      }
      const footerSig = `${festival.id}|${promo.code}|${occ.effectiveGreetingTitle}`;
      if (footerWish.dataset.sig !== footerSig) {
        footerWish.dataset.sig = footerSig;
        footerWish.innerHTML = `
          <span>✦ ${escapeHtml(occ.effectiveGreetingTitle)} — Today on ${escapeHtml(shortName)}: ${promo.discountPercent}% OFF (Code: ${escapeHtml(promo.code)})</span>
          <span>Yuitor Smart Classes · ${escapeHtml(festival.name)} (${escapeHtml(occ.year)})</span>
        `;
      }
    }

    scheduleFestivalPopupIfNeeded(resolution);
    updateLiveTimers();
  }

  let syncPending = false;
  let applyingDom = false;
  const observerConfig = { childList: true, subtree: true };
  const observer = new MutationObserver((mutations) => {
    if (applyingDom) return;
    const isExternal = mutations.some((m) => {
      const targetEl = m.target instanceof Element ? m.target : m.target?.parentElement;
      if (!targetEl) return false;
      return !targetEl.closest(
        "#yu-festival-header-trim, #yu-festival-banner, #yu-festival-hero-ornaments, #yu-festival-footer-wish, #yu-festival-promo-popup",
      );
    });
    if (isExternal) syncFestivalTheme();
  });

  function syncFestivalTheme() {
    if (syncPending) return;
    syncPending = true;
    window.requestAnimationFrame(() => {
      syncPending = false;
      const engine = getEngine();
      if (!engine) return;
      const config = getEffectiveConfig();
      const resolution = engine.resolveFestivalState(config, new Date());
      controllerState.resolution = resolution;
      applyingDom = true;
      observer.disconnect();
      try {
        applyFestivalDom(resolution);
      } finally {
        observer.observe(root, observerConfig);
        applyingDom = false;
      }
    });
  }

  async function fetchFestivalConfig() {
    if (controllerState.fetching) return;
    controllerState.fetching = true;
    try {
      const response = await fetch("/api/festival.php", {
        cache: "no-store",
        credentials: "same-origin",
        headers: { Accept: "application/json" },
      });
      if (response.ok) {
        const data = await response.json();
        if (data && data.config) {
          controllerState.serverConfig = data.config;
          syncFestivalTheme();
        }
      }
    } catch {
      // Fallback cleanly to automatic IST engine defaults
    } finally {
      controllerState.fetching = false;
      syncFestivalTheme();
    }
  }

  // Ensure if legacy Seats Filling Fast popup ever appears in DOM despite localStorage, clicking close persists permanently
  document.addEventListener("click", (ev) => {
    const target = ev.target instanceof Element ? ev.target : null;
    if (!target) return;
    if (target.closest('[data-testid="button-popup-close"], [data-testid="button-popup-cta"]')) {
      try {
        window.localStorage?.setItem(SEATS_DISMISSED_KEY, "1");
      } catch {
        // Ignore storage restrictions
      }
      window.setTimeout(() => openFestivalPromoPopup(true), 250);
    }
  });

  window.addEventListener("yuitor:seats-popup-dismissed", () => {
    window.setTimeout(() => openFestivalPromoPopup(true), 250);
  });

  window.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape" && document.getElementById("yu-festival-promo-popup")) {
      closeFestivalPromoPopup(true);
    }
  });

  window.YuitorFestivalController = {
    getResolution() {
      const engine = getEngine();
      return engine ? engine.resolveFestivalState(getEffectiveConfig(), new Date()) : null;
    },
    getConfig() {
      return getEffectiveConfig();
    },
    setTransientConfig(cfg) {
      controllerState.transientConfig = cfg || null;
      syncFestivalTheme();
    },
    async reloadConfig() {
      controllerState.transientConfig = null;
      await fetchFestivalConfig();
    },
    openPromoPopup(force = true) {
      openFestivalPromoPopup(force);
    },
    syncNow() {
      syncFestivalTheme();
    },
  };

  observer.observe(root, observerConfig);

  window.addEventListener("popstate", syncFestivalTheme);
  window.addEventListener("resize", () => {
    lastMeasuredWidth = 0;
    syncFestivalTheme();
  });
  window.addEventListener("yuitor:festival-config-updated", (ev) => {
    if (ev && ev.detail) {
      controllerState.serverConfig = ev.detail;
      controllerState.transientConfig = null;
    }
    syncFestivalTheme();
  });

  // Live 1-second timer tick for header clock/countdown, showcase timer, and popup timer
  window.setInterval(updateLiveTimers, 1000);

  // Check every 60 seconds for IST midnight festival transition
  window.setInterval(syncFestivalTheme, 60000);

  syncFestivalTheme();
  fetchFestivalConfig();
})();
