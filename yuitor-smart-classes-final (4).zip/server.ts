import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import express from "express";
import cookieParser from "cookie-parser";
import { APP_ROOT, getDb, UPLOADS_DIR } from "./server/db.js";
import { sameOriginGuard } from "./server/security.js";
import { startEmailScheduler } from "./server/mailer.js";
import { createAuthRouter } from "./server/routes/auth.js";
import { createAdminRouter } from "./server/routes/admin.js";
import { createMarketingRouter } from "./server/routes/marketing.js";
import { createStudentRouter } from "./server/routes/student.js";
import { createTeacherRouter } from "./server/routes/teacher.js";
import { createPaymentsRouter } from "./server/routes/payments.js";
import { createPublicRouter } from "./server/routes/public.js";

const PUBLIC_DIR = path.join(APP_ROOT, "public");
const PORT = Number(process.env.PORT || 3000);
const HOST = "0.0.0.0";

const STATIC_EXT_RE = /\.(?:js|mjs|css|map|png|jpe?g|webp|gif|svg|ico|woff2?|ttf|eot|json|xml|txt|pdf|sqlite|db|zip|tar|gz|bak|sql|env|log)$/i;
const PRIVATE_ROUTE_RE = /^\/(?:admin(?:-setup)?|student|teacher|teacher-apply\.php|login|register|unsubscribe|erp)(?:\/|$|\.)/i;
const COMPRESSIBLE_CT_RE = /^(?:text\/|application\/(?:javascript|ecmascript|json|xml|xhtml\+xml)|image\/svg\+xml)/i;
const HASHED_ASSET_RE = /\/assets\/.*-[A-Za-z0-9_-]{8}\.(?:js|css)$/i;

function applyStaticCacheHeaders(res: express.Response, filePath: string) {
  if (/\.html$/i.test(filePath)) {
    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
  } else if (filePath.includes(`${path.sep}assets${path.sep}images${path.sep}`) || HASHED_ASSET_RE.test(filePath)) {
    res.setHeader("Cache-Control", "public, max-age=604800, immutable");
  } else if (/\.(?:js|css|json|svg|png|jpe?g|webp|ico|woff2?)$/i.test(filePath)) {
    res.setHeader("Cache-Control", "public, max-age=3600, must-revalidate");
  }
}

function gzipResponseMiddleware(req: express.Request, res: express.Response, next: express.NextFunction) {
  const acceptEncoding = String(req.headers["accept-encoding"] || "");
  if (!/\bgzip\b/i.test(acceptEncoding) || req.method === "HEAD") {
    next();
    return;
  }

  let gzipStream: zlib.Gzip | null = null;
  let bypass = false;
  const origWrite = res.write.bind(res);
  const origEnd = res.end.bind(res);
  const origWriteHead = res.writeHead.bind(res);

  function decide() {
    if (gzipStream || bypass) return;
    if (
      res.getHeader("Content-Encoding") ||
      res.getHeader("Content-Range") ||
      res.statusCode === 204 ||
      res.statusCode === 206 ||
      res.statusCode === 304
    ) {
      bypass = true;
      return;
    }
    const ct = String(res.getHeader("Content-Type") || "");
    if (!COMPRESSIBLE_CT_RE.test(ct)) {
      bypass = true;
      return;
    }
    const len = Number(res.getHeader("Content-Length") || 0);
    if (len > 0 && len < 1024) {
      bypass = true;
      return;
    }
    res.removeHeader("Content-Length");
    res.setHeader("Content-Encoding", "gzip");
    res.setHeader("Vary", "Accept-Encoding");
    gzipStream = zlib.createGzip({ level: 6 });
    gzipStream.on("data", (chunk) => origWrite(chunk));
    gzipStream.on("drain", () => res.emit("drain"));
    gzipStream.on("error", () => origEnd());
    gzipStream.on("end", () => origEnd());
  }

  res.writeHead = ((statusCode: number, reasonOrHeaders?: any, maybeHeaders?: any) => {
    const hdrObj = typeof reasonOrHeaders === "object" && reasonOrHeaders !== null ? reasonOrHeaders : maybeHeaders;
    if (hdrObj && typeof hdrObj === "object") {
      for (const [k, v] of Object.entries(hdrObj)) {
        if (v !== undefined) res.setHeader(k, v as any);
      }
    }
    res.statusCode = statusCode;
    decide();
    if (typeof reasonOrHeaders === "string") {
      return origWriteHead(statusCode, reasonOrHeaders);
    }
    return origWriteHead(statusCode);
  }) as typeof res.writeHead;

  res.write = ((chunk: any, encoding?: any, cb?: any) => {
    decide();
    if (gzipStream) {
      if (typeof encoding === "function") return gzipStream.write(chunk, encoding);
      return gzipStream.write(chunk, encoding, cb);
    }
    return origWrite(chunk, encoding, cb);
  }) as typeof res.write;

  res.end = ((chunk?: any, encoding?: any, cb?: any) => {
    decide();
    if (gzipStream) {
      if (typeof chunk === "function") {
        gzipStream.end(chunk);
      } else if (typeof encoding === "function") {
        gzipStream.end(chunk, encoding);
      } else if (chunk !== undefined) {
        gzipStream.end(chunk, encoding, cb);
      } else {
        gzipStream.end();
      }
      return res;
    }
    return origEnd(chunk, encoding, cb);
  }) as typeof res.end;

  next();
}

export function createApp() {
  const db = getDb();
  startEmailScheduler(db);

  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", 1);

  app.use((_req, res, next) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    next();
  });

  app.use(gzipResponseMiddleware);
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ extended: true, limit: "1mb" }));
  app.use(cookieParser());

  app.use("/api", (_req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    next();
  });
  app.use("/api", sameOriginGuard);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "yuitor-smart-classes", timestamp: new Date().toISOString() });
  });

  app.use("/api/auth", createAuthRouter(db));
  app.use("/api/admin", createAdminRouter(db));
  app.use("/api/marketing", createMarketingRouter(db));
  app.use("/api/student", createStudentRouter(db));
  app.use("/api/teacher", createTeacherRouter(db));
  app.use("/api/payments", createPaymentsRouter(db));
  app.use("/api", createPublicRouter(db));

  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "API endpoint not found." });
  });

  // Legacy ERP route redirect into unified portal routes
  app.get(["/erp", "/erp/index.php"], (req, res) => {
    const role = String(req.query.role || "").toLowerCase();
    res.redirect(302, role === "teacher" ? "/teacher/" : "/student/");
  });

  // Uploaded materials & avatars (safe static serving, dotfiles denied)
  app.use("/uploads", express.static(UPLOADS_DIR, { dotfiles: "deny", index: false, fallthrough: false }));

  // Direct HTML serving for clean URLs & directory route shells (avoids 301 trailing-slash redirects)
  app.get("*", (req, res, next) => {
    const reqPath = req.path || "/";
    if (STATIC_EXT_RE.test(reqPath) && !reqPath.endsWith(".php")) {
      next();
      return;
    }
    if (PRIVATE_ROUTE_RE.test(reqPath)) {
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.setHeader("Cache-Control", "no-store");
    } else {
      res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    }
    const safeRel = reqPath.replace(/^\/+|\/+$/g, "");
    if (safeRel && !safeRel.includes("..")) {
      const candidate = path.join(PUBLIC_DIR, safeRel, "index.html");
      if (candidate.startsWith(PUBLIC_DIR) && fs.existsSync(candidate)) {
        res.sendFile(candidate);
        return;
      }
    }
    next();
  });

  // Static website assets
  app.use(
    express.static(PUBLIC_DIR, {
      dotfiles: "deny",
      index: "index.html",
      extensions: ["html"],
      redirect: false,
      setHeaders: applyStaticCacheHeaders,
    })
  );

  // SPA / Portal route fallback
  app.get("*", (req, res) => {
    const reqPath = req.path || "/";
    if (STATIC_EXT_RE.test(reqPath) && !reqPath.endsWith(".php")) {
      res.status(404).type("text/plain").send("Not Found");
      return;
    }

    if (PRIVATE_ROUTE_RE.test(reqPath)) {
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.setHeader("Cache-Control", "no-store");
      res.sendFile(path.join(PUBLIC_DIR, "index.html"));
      return;
    }

    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    const safeRel = reqPath.replace(/^\/+|\/+$/g, "");
    if (safeRel && !safeRel.includes("..")) {
      const candidate = path.join(PUBLIC_DIR, safeRel, "index.html");
      if (candidate.startsWith(PUBLIC_DIR) && fs.existsSync(candidate)) {
        res.sendFile(candidate);
        return;
      }
    }

    res.sendFile(path.join(PUBLIC_DIR, "index.html"));
  });

  app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error("[Yuitor Server Error]", err?.message || err);
    if (req.path.startsWith("/api")) {
      res.status(Number(err?.status || 500)).json({ error: err?.message || "Internal server error." });
      return;
    }
    res.status(500).type("text/plain").send("Server error");
  });

  return { app, db };
}

const shouldAutoListen =
  process.env.YUITOR_NO_LISTEN !== "1" &&
  process.env.NODE_ENV !== "test" &&
  !process.env.VITEST;

export const serverApp = shouldAutoListen ? createApp().app : null;

if (serverApp) {
  serverApp.listen(PORT, HOST, () => {
    console.log(`Yuitor Smart Classes unified server listening on http://${HOST}:${PORT}`);
  });
}
