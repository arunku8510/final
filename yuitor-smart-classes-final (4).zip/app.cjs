// CommonJS startup bridge for cPanel / LiteSpeed / Phusion Passenger Node.js selectors
// Set Startup File to either "server.js" or "app.cjs" inside your hosting panel.
import("./server.js").catch((err) => {
  console.error("[Yuitor] Failed to boot server.js:", err);
  process.exit(1);
});
